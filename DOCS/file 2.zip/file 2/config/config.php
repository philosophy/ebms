<?php 
//error_reporting(0);
//define components for mysql_connect
define("LOCALHOST",'localhost'); //for local domain host
define("USERNAME","root"); //for username
define("DBASE","ebms");    //for database
define("PASSWORD",""); //for password

//start connection
$con= mysql_connect(LOCALHOST,USERNAME,PASSWORD);

//set character configuration of the database
mysql_set_charset('utf8',$con); 

if (!$con)
  {
  die("Something went wrong. We can't connect to the database right now.<br/> ". mysql_error());
  }

mysql_select_db(DBASE, $con);

?>