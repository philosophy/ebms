
		var idSelector;
	function datagrid(containerId,visibility)
		{
		var selectorArray = containerId.split(";");
		
			for(i=0;i<selectorArray.length;i++)
				{
				idSelector = "#"+selectorArray[i];
				$(idSelector).find("table").addClass("datagrid-table");
				$(idSelector).find("th").attr({id:"datagrid-head",nowrap:"true"});
				$(idSelector).find("tr").attr({id:"datagrid-row"});
				$(idSelector).find("td").attr({id:"datagrid-cell",nowrap:"true"});
				}
				
			if(visibility==true)
				{
				$(".datagrid-container").fadeTo("fast",1,
					function()
					{
					$("#tabbed-grid").show();
					}).show();
				}
			else if(visibility==false)
				{
				//Do Nothing
				}
			
		}
		
		
	//sets the Title for the datagrid
	
	function headTitle(data)
		{
		var headTitle = data.replace(/-/g," ");
		$("#head-title").text(headTitle).css({"text-transform":"capitalize"});
		}
		
		
	function displayDatagrid(data)
		{
			$("div.datagrid-container").fadeTo("slow",0).css({"z-index":"9"});
			$("div#"+data).fadeTo("slow",1).show().css({"z-index":"10"});	
		}
		
	function applyDatepicker()
	{
		$("#datepickers").show();
	}
	
	function listType()
	{
		$("#listType").show();
	}
	
	function datagridMenu(formRef,btn)
	{
	var btnArr = btn.split(";");
	
	$("#body-content-container").append("<div class='datagrid-crud-menu'></div>");
	$(".datagrid-container").css(
		{
			"width": "820px",
			"margin-left":"-170px"
		}
		);
		
		for(i=0;i<btnArr.length;i++)
		{
			$(".datagrid-crud-menu").append("<button class='datagrid-crud-button callModalForm' id='"+btnArr[i]+"' ref='"+btnArr[i]+"_"+formRef+"' style='background-image:url(/ebms/images/crudIcons/"+btnArr[i]+"Icon.png); background-size:90% 90%; background-position:center 2px;background-repeat:no-repeat' title='"+btnArr[i]+"'></button>");
		}
	
	
	}
	
	
		
		
		