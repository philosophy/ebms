$(document).ready(function(){

var dataString = "";	
//checkDailyAlarm();
	//setInterval(checkDailyAlarm,(1000*60*60*24));

function setAlarmPeriod(period)
{
	dataString = period;
	
	
		$.ajax({
		url:"/EBMS/apps/controller/taskReminder/checkTaskAlarm.php",
		type:"POST",
		data:"repeat="+dataString,
		success:
			function(response)
			{
			if(response=="Nothing")
			{
			//do nothing
			
			}
			
			else 
			alert(response);
			}
		});
	
}
	
	
function checkDailyAlarm()
{
setAlarmPeriod("Daily");
}

function checkMonthlyAlarm()
{
setAlarmPeriod("Monthly");
}

function checkYearlyAlarm()
{
setAlarmPeriod("Yearly");
}


});