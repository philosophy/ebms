	
	function inputMask(idSelector,text){
	//by default, set Text as the value of input box
	$("#"+idSelector).val(text);
	
	$("#"+idSelector).focusin(function(){
		var txtVal = $(this).val().trim();
		
		if(txtVal == text)
		{
			$(this).val("");
		}
	
		});
		
	$("#"+idSelector).focusout(function(){
		var txtVal = $(this).val().trim();
		
		if(txtVal == "")
		{
			$(this).val(text);
		}

		});
}
		
	
	
	