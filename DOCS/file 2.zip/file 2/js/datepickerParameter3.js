﻿$(document).ready(function(){
	var parent = ".graph-cont[ref='industry-type'] ";

	//by default, daily option is selected
	$(parent+"#daily").addClass("optionActive");
	check();
	
	function check()
	{
	if($(parent+"#daily").hasClass("optionActive"))
		{
		$(parent+"#daily_datepicker").show();
		}
	else
		{
		$(parent+"#daily_datepicker").hide();
		}
	
	if($(parent+"#weekly").hasClass("optionActive"))
		{
		$(parent+"#weekly_datepicker").show();
		}
	else
		{
		$(parent+"#weekly_datepicker").hide();
		}
		
	
	if($(parent+"#monthly").hasClass("optionActive"))
		{
		$(parent+"#monthly_datepicker").show();
		}
	else
		{
		$(parent+"#monthly_datepicker").hide();
		}
	
	}
	
	$(".period-option li a").click(function(){
		var id = $(this).attr("id");
		$(".period-option li a").removeClass("optionActive");
		$(".period-option li a#"+id).addClass("optionActive");
		check();
	return false;
	});
});