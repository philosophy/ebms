//dashboard-view-datepicker	
	$(function() {
		var day = $( "#dayFrom,#dayTo" ).datepicker({
			defaultDate: "+1w",
			dateFormat: "yy-mm-dd",
			changeMonth: true,
			changeYear: true,
			constrainInput: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				var option = this.id == "dayFrom" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings );
				day.not( this ).datepicker( "option", option, date );
			}
		});
		

		var week = $( "#weekFrom,#weekTo" ).datepicker({
			defaultDate: "+1w",
			showWeek: true,
			weekHeader: "Week No.",
			firstDay: 1,
			dateFormat: "yy-mm-dd",
			maxDate: new Date(),
			changeMonth: true,
			changeYear: true,
			constrainInput: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate) {
				var option = this.id == "weekFrom" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings );
				week.not( this ).datepicker( "option", option, date );
				
				if(this.id == "weekFrom")
					$("#weekFrom").attr("weekFromNo",$.datepicker.iso8601Week(new Date(selectedDate)));
				if(this.id == "weekTo")
					$("#weekTo").attr("weekToNo",$.datepicker.iso8601Week(new Date(selectedDate)));
				
				if($("#weekFrom").attr("weekFromNo"))
				$("#weekFrom").val("Week No. "+$("#weekFrom").attr("weekFromNo"));
				
				if($("#weekTo").attr("weekToNo"))
				$("#weekTo").val("Week No. "+$("#weekTo").attr("weekToNo"));
				} 
		});
		
		
			
		//regular datepicker
		var dates = $( "#from,#to" ).datepicker({
			defaultDate: "+1w",
			changeYear: true,
			dateFormat: "yy-mm-dd",
			changeMonth: true,
			constrainInput: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				var option = this.id == "from" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings );
				dates.not( this ).datepicker( "option", option, date );
			}
		});
		
		
		$("#monthFrom,#monthTo").bind("focus blur",function(){
			$(".ui-datepicker-calendar").hide();
		});
		$('#monthFrom,#monthTo').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'MM yy',
			constrainInput: true,
		showButtonPanel: true,
        onClose: function(dateText, inst) { 
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).datepicker('setDate', new Date(year, month, 1));
        }
    });
	
	
	
	});

