﻿$(document).ready(function(){
	var parent = ".graph-cont[ref='customer-stat'] ";

	//by default, daily option is selected
	$(parent+"#daily").addClass("optionActive");
	check();
	
	function check()
	{
	if($(parent+"#daily").hasClass("optionActive"))
		{
		$(parent+"#daily_datepicker").show();
		}
	else
		{
		$(parent+"#daily_datepicker").hide();
		}
	
	if($(parent+"#weekly").hasClass("optionActive"))
		{
		$(parent+"#weekly_datepicker").show();
		}
	else
		{
		$(parent+"#weekly_datepicker").hide();
		}
		
	
	if($(parent+"#monthly").hasClass("optionActive"))
		{
		$(parent+"#monthly_datepicker").show();
		}
	else
		{
		$(parent+"#monthly_datepicker").hide();
		}
	
	}
	
	$(".period-option li a").click(function(){
		var id = $(this).attr("id");
		$(".period-option li a").removeClass("optionActive");
		$(".period-option li a#"+id).addClass("optionActive");
		check();
	return false;
	});
	
	//dashboard-view-datepicker	
	$(function() {
		var dates = $(parent+"#daily_datepicker #from,"+parent+"#daily_datepicker #to" ).datepicker({
			defaultDate: "+1w",
			dateFormat: "MM dd, yy",
			changeMonth: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				var option = this.id == "from" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings );
				dates.not( this ).datepicker( "option", option, date );
			}
		});
		
		var dates = $(parent+"#weekly_datepicker #from,"+parent+"#weekly_datepicker #to" ).datepicker({
			defaultDate: "+1w",
			showWeek: true,
			weekHeader: "Week No.",
			dateFormat: "MM dd, yy",
			changeMonth: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				var option = this.id == "from" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings );
				dates.not( this ).datepicker( "option", option, date );
			}
		});
	});
});