$(document).ready(function(){
	$("#btn-submit").click(function(){
		login_auth();
		return false;
		});
	});