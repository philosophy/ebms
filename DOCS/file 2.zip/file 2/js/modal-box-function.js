
var mask_id = "bg-mask";
var elem_id = "elem-modal";
var class_name = "modal";

//Function that executes container element modality
function modal(size,title,ref)
{

//strip out the dashes on the title
title = title.replace(/-/g," "); 

$("body").css({"overflow":"hidden"});
$("body").append("<div id='"+mask_id+"'></div>");
$("#"+mask_id).animate({opacity:"0.8",filter:"alpha(opacity=80)"},"slow");

$("."+class_name+"."+ref).css({"width":Number(size)});
$("."+class_name+"."+ref+" div.handle").width((Number(size)+22)).prepend("<b>"+title+"</b>");

if(ref == "forgot-password")
	{
	height_allowance = "0";
	width_allowance = "0";
	}
else 
	{
	height_allowance = "-600";
	width_allowance = "10";
	}
var y_axis = (($("."+class_name+"."+ref).height() +(Number(height_allowance)))/2);
var x_axis = (($("."+class_name+"."+ref).width() +(Number(width_allowance)))/2);


$("."+class_name+"."+ref).show();
$("."+class_name+"."+ref).css({"margin-top":-y_axis,"margin-left":-x_axis});
$("."+class_name+"."+ref).draggable({handle:"div.handle"});


}
//end function modal


//function that executes closing of modal container
function close_modal(ref)
{
	$("#"+mask_id).animate({opacity:"0",filter:"alpha(opacity=0)"},"slow")
	$("#"+mask_id).remove();
	$("div.handle").remove("p");
	$("."+class_name).hide();
	$("body").css({"overflow":"auto"});
}
	

