
$(document).ready(function(){

if($.browser.msie)
{
window.open("/ebms/apps/view/siteException.php","_self");
}

// if ($.cookie("user") != null)
// {
	// alert('meron pa cookie');
// }

checkUserCookie();

function checkUserCookie()
{
	if($.cookie("ebmsLoginUname") != null)
	{
		
		$("#uname").val($.cookie("ebmsLoginUname"));
		$("#rememberUser").trigger("click");
	}
	
	else 
	{
		$("#uname").val("");
	}
}

	$("#rememberUser").click(function(){
		
		var checkVal = $(this).val();
		var uname = $("#uname").val().trim();
		
			if(checkVal == "true")
				{
					if(uname != "")
					{
					$(this).val("false");
					$.cookie("ebmsLoginUname",uname);
					}
				}
			
			else if(checkVal == "false")
				{
				$(this).val("true");
				$.cookie("ebmsLoginUname",null);
				}
			
		});
});

function login_auth()
{
		//get values from text fields
		
		$.post('/EBMS/apps/view/login/checkInactiveCustomers.php');
		var uname = $("#uname").val().trim();
		var pword = $("#pword").val().trim();
		var load ="<img src='/EBMS/images/loading-gif/loading.gif'>";
		var text;
		
			if(uname == '' || pword == '')
				{
				text ="<span class='err'>Please complete necessary details</span>";
				$("#log-info").html(text).animate({opacity:"1",filter:"alpha(opacity=100)"},"slow");
					
					if(uname == "")
					$("#uname").focus();
					
					else if(pword == "")
					$("#pword").focus();
					
				}
			
			else if(uname != '' && pword != '')
			{
				var dataString = "uname=" + uname + "&pword=" + pword;
				
				$.ajax(
				{
					type: "POST",
					url: "/EBMS/apps/controller/login/isOnlineYes.php",
					data:dataString,
					success: 	
					function(response)
					{
						if (response == "Not logged in")
						{
							$.ajax(
							{
								type: "POST",
								url: "/EBMS/apps/controller/login/login-auth.php",
								data: dataString,
								cache: false,
								beforeSend:
								function()
								{
								
								text = "<span class='ok'>Iniatializing ... </span>";
								},
								success: 
								function(response)
								{
									$.cookie("userIsLogin", uname, { path: '/' });
									$.cookie("userUsername", uname, { path: '/', expires: 1 });
									
									// alert($.cookie("userIsLogin"));
									
									var responseStatus,responseMessage;
								
									if(response == "correct")
									{
										responseStatus = "ok";
										responseMessage = "<span class='"+responseStatus+"'>Loading "+load+"</span>";
										$("body,html").css({"cursor":"wait"});
										$.cookie("ebmsCustBal","true");
										setTimeout("window.open('/EBMS/apps/view/home/?page=home','_self')",10);
										// alert(dataString);
									}
										
									else if(response == "incorrect")
										{
										$("#uname").focus().select();
										responseStatus = "err";
										responseMessage = "<span class='"+responseStatus+"'>Username / Password combination incorrect.<br/>Try Again.</span>";
										}
										
								$("#log-info").html(responseMessage).animate({opacity:"1",filter:"alpha(opacity=100)"},"slow");
								
								}

							});
							
							
						}
						else if (response == "Logged in")
						{
							$("#uname").focus().select();
							responseStatus = "err";
							responseMessage = "<span class='"+responseStatus+"'>This user is already logged in.</span>";
							$("#log-info").html(responseMessage).animate({opacity:"1",filter:"alpha(opacity=100)"},"slow");		
						}
						
						else
						{
							$("#uname").focus().select();
							responseStatus = "err";
							responseMessage = "<span class='"+responseStatus+"'>Username / Password combination incorrect.<br/>Try Again.</span>";
							$("#log-info").html(responseMessage).animate({opacity:"1",filter:"alpha(opacity=100)"},"slow");		
						}

					}
				});
			}

}
//end login auth function 


		