//process the logout of the user 

$(function(){
	$(".logout").click(function()
	{
		$.ajax(
		{
			url:"/EBMS/apps/controller/logout/logout.php",
			type:"POST",
			success:
			function(response)
			{
				// alert(response);
				window.open("/EBMS/","_self");
			}
		});
		// $.post("/EBMS/apps/controller/logout/logout.php",
		// function(data)
		// {
			// alert(
		// }
		// );
	});
});
	