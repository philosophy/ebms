﻿$(document).ready(function(){
	//by default, daily option is selected
	$("#daily").addClass("optionActive");
	check();
	
	function check()
	{
	if($("#daily").hasClass("optionActive"))
		{
		$("#daily_datepicker").show();
		}
	else
		{
		$("#daily_datepicker").hide();
		}
	
	if($("#weekly").hasClass("optionActive"))
		{
		$("#weekly_datepicker").show();
		}
	else
		{
		$("#weekly_datepicker").hide();
		}
		
	
	if($("#monthly").hasClass("optionActive"))
		{
		$("#monthly_datepicker").show();
		}
	else
		{
		$("#monthly_datepicker").hide();
		}
	
	}
	
	$(".period-option li a").click(function(){
		var id = $(this).attr("id");
		$(".period-option li a").removeClass("optionActive");
		$(".period-option li a#"+id).addClass("optionActive");
		check();
	return false;
	});
});