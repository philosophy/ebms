$(document).ready(function(){
		$(".period-option li a#weekly").hide();
		
		var windowWidth = $(".graph-cont").width();
		var numSlides = $(".slider-nav li").length;
		var num = 1,numWidth = 0;
		
		var slideWidth = windowWidth * numSlides;
		
		$(".graph-slider").css({"width":(slideWidth+100)});
		$("#graph-tabs ul.graph-nav li a").click(function(){
		
		
			var href = $(this).attr("href").substring(1);
			$("#hidden").val(href);
			//unset tabOnDisplay class to all anchors
			$("#graph-tabs ul.graph-nav li a").removeClass("tabOnDisplay");
			
			//now set tabOnDisplay class on the clicked anchor
			$(this).addClass("tabOnDisplay");
			
			var rel = $(this).attr("rel");
			num = Number(rel)-1;
			next();
			
			function next()
			{
			num += 1;
			if(num >= (numSlides+1))
			{
				num = 1;
			}
				
			numWidth = (Number(num)-1) * windowWidth;
			
			slide();
			}
			
			
			function slide()
			{
			$("#graph-window").stop().animate({scrollLeft:(numWidth+4)},"slow");
			//make all graph divs invisible
			$("#graph-tabs").find("div.graph-cont").fadeTo("slow",0);
			
			//now make the necessary div visible
			$("div.graph-cont[rel='"+rel+"']").stop().fadeTo("slow",1);
			}

			return false;
			});
		});