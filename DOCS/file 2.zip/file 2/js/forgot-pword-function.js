//Event to be called when "Forgot Password?" is clicked
	$(function(){
		$("#forgot").click(function(){
		var title = $(this).attr("rel");
		var ref = title;
		var size = $(this).attr("name");
		modal(size,title,ref);
		return false;
		});
		
		$("#close").click(function(){
		var ref = $(this).attr("rel");
		close_modal(ref);
		return false;
		});
		
		});
				