$.post("crm.php",
			function(response)
				{
				$("#crm-profile").append(response);
				datagrid("crm-profile",true);
				
				$("#crm-profile table tr").click(function(){
					
					//remove all active classes in tr element
					$("#crm-profile table").find("tr").removeClass("activeTr");
					
					//then, set the active class to the clicked tr element
					$(this).addClass("activeTr");
					
					$.post("issuedItem.php",{customerCode:$(this).attr("a")},
						function(response)
						{
						$("#tabs-3").html(response);
						datagrid("tabs-3",true);
						});
					});
				
				});