<?php 
	$settingsBtn = "<div id='settings-btn' >Settings <img src='../../../images/icons/settings-icon.png'></div>";
	
	$optionsPane = "<div id='graph-options-pane'><label for='from'>From</label><input type='text' id='from' name='from'/><label for='to'>to</label><input type='text' id='to' name='to'/><b>Pop Out <img src='../../../images/icons/popout-icon.png'></b></div>";
		
	$toolbarDiv = "<div id='settings'>".settingsBtn.optionsPane."</div>";
?>