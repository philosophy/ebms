
	
	//$("#modalFormWrapper").load("/ebms/apps/view/modalForm/modalForms.php");
	
	var close="";
	
	var popupWindow = "";
	var url,height,width;
	function newPopup(url,height,width) 
	{
	popupWindow = window.open(
		url,'popUpWindow','height='+height+',width='+width+',left=400,top=40,resizable=no,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
	
	}
	
	
	
	
	function closepopup()
	{
	}
	
	$(document).ready(function(){
	
	$("#closeBtn").click(function(){
	closepopup();
	});
		
	
	
	
	});

	
	function callModal(arg)
	{
	close = "<div class='formClose' title='Close'>x</div>";
	
	if($(".formClose").length == 0)
	$("div.modalForm").append(close);
	
	var ref = $(arg).attr("ref");
	var fade = "<div class='formFade'></div>";
	
	if($(".formFade").length == 0)
	$("body").append(fade);
	
	$("div#"+ref+".modalForm").stop().fadeTo("fast",1).show("500");
	
	$("div.modalForm").draggable({handle:"div#modalTitle"});
	modalForm(ref);
	return false;
	}
	
	function modalForm(ref)	
	{
	
	var w = $("body").find("div#"+ref+".modalForm").attr("w");
			w = Number(w);
			
	var domWidth = $("html").width();
	
	
	
	$("input[datepicker=true]").datepicker({
		changeYear:true,
		changeMonth:true,
		dateFormat: "yy-mm-dd"
	});
	
	$(".sliderHour").slider({
			value:0,
			min: 0,
			max: 23,
			step: 1,
			slide: function( event, ui ) {
				$( "input[timepickerHour=true]" ).val( ui.value +" hours");
			}
		});
	$(".sliderMinute").slider({
			value:0,
			min: 0,
			max: 59,
			step: 1,
			slide: function( event, ui ) {
				$( "input[timepickerMinute=true]" ).val( ui.value+" minutes");
			}
		});
		
		$( "input[timepickerHour=true" ).val( $( ".sliderHour" ).slider( "value" ));
		$( "input[timepickerMinute=true" ).val( $( ".sliderMinute" ).slider( "value" ));
	
	$("div#"+ref+".modalForm").width(w);
	
	
	
	var popMargLeft = ($('div#'+ref+".modalForm").width() + 20) / 2;
	
	popMargLeft = Math.abs(popMargLeft);

	
	//Apply Margin to Popup
    $("div#"+ref+".modalForm").css({
        'margin-left' : -popMargLeft
    });
	
	
	$("div.modalForm button").click(function(){
	return false;
	});
	
	$(".formClose").click(function(){
	$(".import").hide();
	$(".formSubFade").remove();
	$("div#"+ref+".modalForm").hide(500,
		function()
		{
			$(".formFade").fadeOut(300,
				function(){
					$(".formFade").remove();	
					$(".formClose").remove();
					});
			$("div#"+ref+".modalForm").hide();
		});
	
	return false;
	});
	
	$("#cancel.formButton").click(function(){
	$(".import").hide();
	$("div#"+ref+".modalForm").fadeOut("slow",0,
		function()
		{
			$(".formFade").fadeOut(300,
				function(){
					$(".formFade").remove();		
					$(".formClose").remove();
					});
			$("div#"+ref+".modalForm").hide();
		});
	
	});
	
	}
	
