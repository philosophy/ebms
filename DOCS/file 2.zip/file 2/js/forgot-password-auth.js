$(document).ready(function(){
	var uname_box_val, forgot_pword_ans, user_fullname_val;
		
	$("#uname_box_finder").click(function(){
		uname_box_val = $("#uname_fetch").val().trim();
		user_fullname_val = $("#user_fullname").val().trim();
			
			
					$.post("../../controller/forgotPword/forgot-pword-controller.php",{step:1,uname:uname_box_val,user_fullname:user_fullname_val},
						function(response)
							{
							if(response == "null value")
								{
								alert("Please complete necessary details");
								}
								
							else if(response == "not found")
								{
								alert("Username not found");
								$("#uname_fetch").select();
								}
								
							else
								{
								$("#security_question_uname_finder").hide();
								$("#security_question").show();
								$(".question").val(response);
								}
							});
					
				
				return false;
			});//end uname finder click function
			
			
	
	$(".ans-submit").click(function(){
		forgot_pword_ans = $(".ans").val();
			
			$.post("../../controller/forgotPword/forgot-pword-controller.php",{step:2,uname:uname_box_val,forgot_pword_answer:forgot_pword_ans},
				function(response)
					{
					if(response)
						{
						$("#new_pword").focus();
						$("#security_question").hide();
						$("#new_password_container").show();
						$("#new_password_container").css({"height":$("#forgot-pword-container").height()-100})
						}
					else if(!response)
						{
						alert("Incorrect Answer");
						$(".ans").select();
						}
					}
				);
			return false;
			
		});
		
	
	$(".change-pword-submit").click(function(){
		var new_pword = $("#new_pword").val().trim();
		var verify_pword = $("#verify_new_pword").val().trim();
		
		if(new_pword != "" && verify_pword != "")
		{
			if(new_pword!=verify_pword)
				{
				alert("Passwords did not match");
				}
			
			else //if passwords matched
				{
				$.post("../../controller/forgotPword/forgot-pword-controller.php",{step:3,uname:uname_box_val,new_pword:new_pword},
				function(response)
					{
					alert(response);
					$("a#close").trigger("click");
					location.reload();
					}
					);
				}
		}
		else 
		{
		alert("Please complete necessary fields");
		}		
			return false;
			});
		
		
	/*when close button is clicked
	$("#forgot-pword-container a#close").click(function(){
		$(this).find("input").val("");
		inputMask("ans","Your Answer here...");
		$("#security_question_uname_finder").show();
		$("#security_question").hide();
		$("#new_password_container").find("input").val("").hide();
		});
	*/
		
		
		
});