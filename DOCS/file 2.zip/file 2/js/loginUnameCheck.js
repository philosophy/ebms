﻿$(document).ready(function(){

	$("form[name='loginForm'] #uname").focusout(function(){
		
		var uname = $(this).val().trim();
		
		if(uname != "")
		{
			$.ajax({
				url:"../../../apps/controller/login/loginUnameCheck.php",
				type:"POST",
				data: "uname="+uname,
				cache: false,
				success:
					function(response)
					{
					if(response != "")
					{
					var text ="<span class='err'>"+response+"</span>";
					$("#log-info").html(text).animate({opacity:"1",filter:"alpha(opacity=100)"},"slow");
					}
					
					else 
					{
					$("#log-info").html("").fadeTo(0,"slow");
					}
					}
				});
		}
		else 
		{
		//do nothing
		}
		
	});

});