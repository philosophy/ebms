function modal(size)
{

var mask_id = "bg-mask";
var elem_id = "elem-modal";
var class_name = "modal";

$("body").append("<div id='"+mask_id+"'></div>");
$("#"+mask_id).animate({opacity:"0.8",filter:"alpha(opacity=80)"},"slow");

$("."+class_name).css({"width":size});

$("div.handle").width(size+22);

var y_axis = (($("."+class_name).height() - 600)/2);
var x_axis = (($("."+class_name).width() +10)/2);


$("."+class_name).show();
$("."+class_name).css({"margin-top":-y_axis,"margin-left":-x_axis});
$("."+class_name).draggable({handle:"div.handle"});

}
