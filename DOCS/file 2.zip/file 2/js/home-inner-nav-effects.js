//inner nav display effects

		$(document).ready(function(){
			function megaHoverOver()
			{
			var windowSize = $(window).width();
			//alert(windowSize);
			if(windowSize > 1400)
			$(this).find("ul").stop().fadeTo('fast', 0.99).show();
			
			else if(windowSize <= 1400)
			{
			var w1 = $(this).width();
			var w2 = $(this).find("ul").width();
			$(this).find("ul").css({"margin-left":(-1)*((w1+w2)-80)}).stop().fadeTo('fast', 0.99).show();
			}
			
			}

			function megaHoverOut()
			{ 
			$(this).find("ul").stop().fadeTo('fast', 0, function() {
			$(this).hide();	  
			});
			}

			var config = {
			sensitivity: 2, // number = sensitivity threshold (must be 1 or higher)
			interval: 100, // number = milliseconds for onMouseOver polling interval
			over: megaHoverOver, // function = onMouseOver callback (REQUIRED)
			timeout: 300, // number = milliseconds delay before onMouseOut
			out: megaHoverOut // function = onMouseOut callback (REQUIRED)
			};

		$("ul.sub-nav li#sub-nav-list").hoverIntent(config);
		});
