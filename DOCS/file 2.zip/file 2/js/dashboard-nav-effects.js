//dashboard navigation javacsripts
	$(function(){
		
		//by default arrow pointer will be displayed
		$("#sales").css({"display":"block"});
		
		$("#dashboard-nav ul li").live("click",function(){
			
			$("#dashboard-nav ul li").find("img#thumbs").removeClass("divOnDisplay");
			$(this).find("img#thumbs").addClass("divOnDisplay");
						
			var activeDiv = $(this).find("img#thumbs").attr("alt").toLowerCase();
				if($("img#thumbs").hasClass("divOnDisplay"))
					{
					$(".point").css({"display":"none"});
					$("#"+activeDiv).css({"display":"block"});
					}
				
				
			$("#iframe-dashboard").attr("src","../dashboard/dashboard-view-"+activeDiv+".php");
			
			});
	});