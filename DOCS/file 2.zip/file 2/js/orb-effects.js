//orb effects function		
		
		$(document).ready(function(){
			
			function megaHoverOver()
			{
			$("#orb").stop().animate(
			{
			width:"108px",
			height:"98px",
			marginLeft:"-35px",
			marginTop:"-35px",
			left:"-35px",
			top:"0px"
			},"fast");
			$(this).find(".orb-nav").stop().delay(100).fadeTo('fast', 0.99).show();
			}
			
			function megaHoverOut()
			{ 
			$("#orb").stop().animate({
			width:"68px",
			height:"65px",
			marginLeft:"0",
			marginTop:"0",
			left:"-50px",
			top:"-25px"
			},"fast");
			$(this).find(".orb-nav").stop().fadeTo('fast', 0, function() {
			$(this).hide();	  
			});
			}

			var config = {
			sensitivity: 2, // number = sensitivity threshold (must be 1 or higher)
			interval: 100, // number = milliseconds for onMouseOver polling interval
			over: megaHoverOver, // function = onMouseOver callback (REQUIRED)
			timeout: 300, // number = milliseconds delay before onMouseOut
			out: megaHoverOut // function = onMouseOut callback (REQUIRED)
		};

		$("ul.main-orb li#main-orb-list").hoverIntent(config);
		});
	
	function load_orb()
	{
	$("#orb-cont").stop().animate({opacity:"1",filter:"alpha(opacity=100)"},"5000").show();
	}
	