<?php
session_start();

if(isset($_SESSION['login']))
{
?>
	<script>
	window.open("apps/view/home/?page=home","_self");
	</script>
<?php 
}

else
{
?>
	<script>
	window.open("apps/view/login/login-view.php","_self");
	</script>
<?php 
}
?>