-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 21, 2011 at 06:09 AM
-- Server version: 5.1.56
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ebms`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `ACCOUNT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_NAME` varchar(150) DEFAULT NULL,
  `ACCOUNT_DESCRIPTION` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`ACCOUNT_ID`, `ACCOUNT_NAME`, `ACCOUNT_DESCRIPTION`, `IS_DELETED`) VALUES
(1, 'Cezar Pedraza', 'SSI Account', 0),
(2, 'Jet Bulante', 'SSI Account', 0),
(3, 'Sherwin Gutay', 'SSI Account', 0),
(4, 'Rosejelyn Bulante', 'SSI Account', 0),
(5, 'Happy Muños', 'SSI Account', 0),
(6, 'Jerald Facun', 'SSI Account', 0),
(7, 'Jansen Mangabat', 'SSI Account', 0),
(8, 'Clint Cabunilas', 'SSI Account', 0),
(9, 'Jason Sanje', 'SSI Account', 0),
(10, 'Carl Jerive Carreon', 'SSI Account', 0),
(11, 'Ricky Benitez', 'SSI Account', 0),
(12, 'Henry Jandayan', 'SSI Account', 0),
(13, 'Janine Grace Sales', 'SSI Account', 0);

-- --------------------------------------------------------

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
  `ACCOUNT_CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_CATEGORY_NAME` text,
  PRIMARY KEY (`ACCOUNT_CATEGORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `account_category`
--

INSERT INTO `account_category` (`ACCOUNT_CATEGORY_ID`, `ACCOUNT_CATEGORY_NAME`) VALUES
(1, 'Cash Receipt'),
(2, 'Cash Disbursement');

-- --------------------------------------------------------

--
-- Table structure for table `account_listing`
--

CREATE TABLE IF NOT EXISTS `account_listing` (
  `REF_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `REF_HDR_TYPE` varchar(10) DEFAULT NULL,
  `ACCOUNT_ID` int(11) DEFAULT '0',
  `ACCOUNT_TYPE_ID` int(11) DEFAULT '0',
  `PAYMENT_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`REF_HDR_ID`),
  KEY `ACCOUNT_TYPE_ID` (`ACCOUNT_TYPE_ID`),
  KEY `ACCOUNT_ID` (`ACCOUNT_ID`),
  KEY `PAYMENT_ID` (`PAYMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `account_sub_category`
--

CREATE TABLE IF NOT EXISTS `account_sub_category` (
  `ACCOUNT_SUB_CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_SUB_CATEGORY_NAME` text,
  `ACCOUNT_CATEGORY_ID` int(11) DEFAULT '0',
  `ACCOUNT_TYPE_ID` int(11) DEFAULT '0',
  `CANNOT_BE_DELETED` int(11) DEFAULT '0',
  PRIMARY KEY (`ACCOUNT_SUB_CATEGORY_ID`),
  KEY `ACCOUNT_CATEGORY_ID` (`ACCOUNT_CATEGORY_ID`),
  KEY `ACCOUNT_TYPE_ID` (`ACCOUNT_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `account_sub_category`
--

INSERT INTO `account_sub_category` (`ACCOUNT_SUB_CATEGORY_ID`, `ACCOUNT_SUB_CATEGORY_NAME`, `ACCOUNT_CATEGORY_ID`, `ACCOUNT_TYPE_ID`, `CANNOT_BE_DELETED`) VALUES
(1, 'Capital', 1, 3, 1),
(2, 'Cash', 1, 1, 1),
(3, 'Accounts Receivables', 1, 1, 1),
(4, 'Accounts Payable', 2, 2, 1),
(5, 'Sales', 1, 1, 1),
(6, 'Expenses', 2, 3, 1),
(7, 'Cash On Hand', 1, 1, 1),
(8, 'Cash In Bank', 1, 1, 1),
(9, 'Cash From Sales', 1, 1, 0),
(10, 'Collection From AR', 1, 1, 0),
(11, 'Supplies', 1, 1, 1),
(12, 'Fixed Assets', 1, 1, 0),
(13, 'Drawings', 2, 3, 1),
(14, 'Notes Payable', 2, 2, 0),
(15, 'Bank Loan', 2, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `account_type`
--

CREATE TABLE IF NOT EXISTS `account_type` (
  `ACCOUNT_TYPE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_TYPE_NAME` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ACCOUNT_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `account_type`
--

INSERT INTO `account_type` (`ACCOUNT_TYPE_ID`, `ACCOUNT_TYPE_NAME`) VALUES
(1, 'Asset'),
(2, 'Liability'),
(3, 'Owners Equity');

-- --------------------------------------------------------

--
-- Table structure for table `adjustment_detail`
--

CREATE TABLE IF NOT EXISTS `adjustment_detail` (
  `ADJ_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ADJ_DTL_ITEM_DESCRIPTION` text,
  `ADJ_DTL_REMARKS` text,
  `ADJ_DTL_ADD` int(11) DEFAULT '0',
  `ADJ_DTL_LESS` int(11) DEFAULT '0',
  `ADJ_HDR_ID` int(11) DEFAULT '0',
  `ITEM_CODE` varchar(25) DEFAULT '0',
  PRIMARY KEY (`ADJ_DTL_ID`),
  KEY `ADJ_HDR_ID` (`ADJ_HDR_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=98 ;

--
-- Dumping data for table `adjustment_detail`
--

INSERT INTO `adjustment_detail` (`ADJ_DTL_ID`, `ADJ_DTL_ITEM_DESCRIPTION`, `ADJ_DTL_REMARKS`, `ADJ_DTL_ADD`, `ADJ_DTL_LESS`, `ADJ_HDR_ID`, `ITEM_CODE`) VALUES
(79, ' GSM: 2.0', 'aaaaaaaaaa', 200, 0, 44, 'OS-BP-000002'),
(80, ' General Description: qwerty a4tech', 'asdf', 100, 0, 45, 'CE-K-000080'),
(81, ' General Description: QWERTY keyboard', 'asdf', 101, 0, 45, 'CE-K-000005'),
(82, ' General Description: Monitor, Screen Size: 17 inches, Resolution: 640x480', 'asdf', 105, 0, 45, 'CE-M-000001'),
(83, ' General Description: Ballpen', 'asdf', 80, 0, 45, 'OS-B-000003'),
(84, ' General Description: Printer canon', 'asdf', 90, 0, 45, 'CE-P-000073'),
(85, ' General Description: Point', 'asdf', 50, 0, 45, 'OS-B-000079'),
(86, ' General Description: QWERTY keyboard', '', 50, 0, 46, 'CE-K-000005'),
(87, ' Size: Letter, GSM: .9', '', 41, 0, 46, 'CE-K-000004'),
(88, ' General Description: Point', '', 100, 0, 46, 'OS-B-000079'),
(89, ' General Description: qwerty', '', 100, 0, 47, 'AS-2011-000072'),
(90, ' General Description: Asset Printer', '', 100, 0, 47, 'AS-2011-000074'),
(91, ' General Description: .5 point', '', 100, 0, 47, 'AS-2011-000076'),
(92, ' General Description: HBW', '', 100, 0, 47, 'AS-2011-000077'),
(93, ' Resolution: 768x680', '', 100, 0, 47, 'AS-2011-000078'),
(94, ' General Description: qwerty', '', 1, 0, 48, 'AS-2011-000072'),
(95, ' General Description: qwerty', '', 0, 1, 49, 'AS-2011-000072'),
(96, ' General Description: First', '', 5, 0, 50, 'CE-D-000082'),
(97, ' General Description: First', '', 0, 5, 51, 'CE-D-000082');

-- --------------------------------------------------------

--
-- Table structure for table `adjustment_header`
--

CREATE TABLE IF NOT EXISTS `adjustment_header` (
  `ADJ_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ADJ_HDR_CODE` varchar(16) DEFAULT NULL,
  `ADJ_HDR_DATE` date DEFAULT NULL,
  `ADJ_HDR_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `ADJ_CREATED_BY_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`ADJ_HDR_ID`),
  KEY `ADJ_CREATED_BY_ID` (`ADJ_CREATED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `adjustment_header`
--

INSERT INTO `adjustment_header` (`ADJ_HDR_ID`, `ADJ_HDR_CODE`, `ADJ_HDR_DATE`, `ADJ_HDR_REMARKS`, `IS_DELETED`, `ADJ_CREATED_BY_ID`) VALUES
(44, 'ADJ-2011-000044', '2011-12-06', 'aaaaaaaa', 0, 14),
(45, 'ADJ-2011-000045', '2011-12-06', 'asdf', 0, 14),
(46, 'ADJ-2011-000046', '2011-12-07', '', 0, 26),
(47, 'ADJ-2011-000047', '2011-12-07', '100', 0, 26),
(48, 'ADJ-2011-000048', '2011-12-19', '', 0, 27),
(49, 'ADJ-2011-000049', '2011-12-19', '', 0, 27),
(50, 'ADJ-2011-000050', '2011-12-19', 'haha', 0, 27),
(51, 'ADJ-2011-000051', '2011-12-19', '', 0, 27);

-- --------------------------------------------------------

--
-- Table structure for table `approval_list`
--

CREATE TABLE IF NOT EXISTS `approval_list` (
  `APPROVAL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `APPROVAL_DESCRIPTION` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`APPROVAL_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `approval_list`
--

INSERT INTO `approval_list` (`APPROVAL_ID`, `APPROVAL_DESCRIPTION`, `IS_DELETED`) VALUES
(1, 'Purchase Requisition', 0),
(2, 'Over Time', 0),
(3, 'Leave', 0),
(4, 'Expenses', 0);

-- --------------------------------------------------------

--
-- Table structure for table `approvers_list`
--

CREATE TABLE IF NOT EXISTS `approvers_list` (
  `APPROVAL_ID` int(11) NOT NULL DEFAULT '0',
  `EMP_ID` int(11) NOT NULL DEFAULT '0',
  `IS_GRANTED` tinyint(4) NOT NULL,
  PRIMARY KEY (`APPROVAL_ID`,`EMP_ID`),
  KEY `APPROVAL_ID` (`APPROVAL_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approvers_list`
--

INSERT INTO `approvers_list` (`APPROVAL_ID`, `EMP_ID`, `IS_GRANTED`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ap_detail`
--

CREATE TABLE IF NOT EXISTS `ap_detail` (
  `AP_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AP_DTL_AMOUNT` double(15,3) DEFAULT '0.000',
  `AP_DTL_DESCRIPTION` text,
  `AP_HDR_ID` int(11) DEFAULT '0',
  `ACCOUNT_ID` int(11) DEFAULT '0',
  `ACCOUNT_TYPE_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`AP_DTL_ID`),
  KEY `AP_HDR_ID` (`AP_HDR_ID`),
  KEY `ACCOUNT_ID` (`ACCOUNT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=202 ;

--
-- Dumping data for table `ap_detail`
--

INSERT INTO `ap_detail` (`AP_DTL_ID`, `AP_DTL_AMOUNT`, `AP_DTL_DESCRIPTION`, `AP_HDR_ID`, `ACCOUNT_ID`, `ACCOUNT_TYPE_ID`) VALUES
(4, 50300.000, 'PO', 14, 2, 4),
(7, 11.000, '11', 16, 2, 4),
(8, 11.000, '11', 16, 2, 4),
(9, 50300.000, 'PO', 17, 2, 4),
(10, 700.000, 'jkfldsa', 17, 2, 14),
(11, 50300.000, 'PO', 17, 2, 4),
(12, 700.000, 'jkfldsa', 17, 2, 14),
(13, 50300.000, 'PO', 17, 2, 4),
(14, 700.000, 'jkfldsa', 17, 2, 14),
(15, 50300.000, 'PO', 17, 2, 4),
(16, 700.000, 'jkfldsa', 17, 2, 14),
(17, 50300.000, 'PO', 17, 2, 4),
(18, 700.000, 'jkfldsa', 17, 2, 14),
(19, 50300.000, 'PO', 17, 2, 4),
(20, 700.000, 'jkfldsa', 17, 2, 14),
(21, 50300.000, 'PO', 17, 2, 4),
(22, 700.000, 'jkfldsa', 17, 2, 14),
(23, 50300.000, 'PO', 17, 2, 4),
(24, 700.000, 'jkfldsa', 17, 2, 14),
(25, 50300.000, 'PO', 17, 2, 4),
(26, 700.000, 'jkfldsa', 17, 2, 14),
(27, 50300.000, 'PO', 17, 2, 4),
(28, 700.000, 'jkfldsa', 17, 2, 14),
(29, 50300.000, 'PO', 17, 2, 4),
(30, 700.000, 'jkfldsa', 17, 2, 14),
(31, 50300.000, 'PO', 17, 2, 4),
(32, 700.000, 'jkfldsa', 17, 2, 14),
(33, 50300.000, 'PO', 17, 2, 4),
(34, 700.000, 'jkfldsa', 17, 2, 14),
(35, 50300.000, 'PO', 17, 2, 4),
(36, 700.000, 'jkfldsa', 17, 2, 14),
(37, 50300.000, 'PO', 17, 2, 4),
(38, 700.000, 'jkfldsa', 17, 2, 14),
(39, 50300.000, 'PO', 17, 2, 4),
(40, 700.000, 'jkfldsa', 17, 2, 14),
(41, 50300.000, 'PO', 17, 2, 4),
(42, 700.000, 'jkfldsa', 17, 2, 14),
(43, 50300.000, 'PO', 17, 2, 4),
(44, 700.000, 'jkfldsa', 17, 2, 14),
(45, 50300.000, 'PO', 17, 2, 4),
(46, 700.000, 'jkfldsa', 17, 2, 14),
(47, 11.000, '11', 17, 2, 4),
(48, 11.000, '11', 17, 2, 4),
(49, 11.000, '11', 17, 2, 4),
(50, 11.000, '11', 17, 2, 4),
(51, 11.000, '11', 17, 2, 4),
(52, 11.000, '11', 17, 2, 4),
(89, 700.000, 'jkfdlsa', 15, 2, 14),
(90, 3915000.000, 'PO', 15, 2, 4),
(91, 50300.000, 'PO', 19, 2, 4),
(92, 50300.000, 'PO', 19, 2, 4),
(125, 1.000, ' jk', 21, 2, 14),
(126, 3.000, 'jkfldas', 21, 2, 14),
(127, 10.000, 'a', 21, 2, 14),
(128, 1.000, 'fda', 21, 2, 15),
(129, 200.000, '', 22, 2, 4),
(130, 123.000, '', 22, 2, 4),
(131, 38475.000, 'From PO', 23, 2, 4),
(132, 550.000, 'Jah', 24, 2, 14),
(133, 50000.000, 'From PO', 25, 2, 4),
(134, 500.000, 'Description', 25, 2, 4),
(135, 27.000, 'haha', 26, 2, 4),
(136, 100.000, 'hfjkdsa', 27, 2, 15),
(137, 200.000, 'Last Test', 28, 2, 14),
(138, 24.000, 'jfkdlsajklfdsa', 29, 2, 15),
(139, 12.000, 'fdsa', 29, 2, 14),
(140, 38475.000, 'PO', 29, 2, 4),
(141, 50300.000, 'PO', 30, 2, 4),
(142, 30.000, 'ka', 30, 2, 14),
(143, 35.000, 'ka', 30, 2, 15),
(144, 38475.000, 'PO', 31, 2, 4),
(145, 40.000, 'il', 31, 2, 14),
(146, 45.000, 'jfkdlsail', 31, 2, 14),
(147, 11.000, ' jk', 32, 2, 14),
(148, 50300.000, 'PO', 32, 2, 4),
(149, 12.000, ' jk', 32, 2, 14),
(150, 1.000, 'j', 33, 2, 14),
(151, 2.000, 'j', 33, 2, 15),
(152, 38475.000, 'PO', 34, 2, 4),
(153, 9.000, 'fdshjk', 34, 2, 14),
(154, 19.000, 'fdshjk', 34, 2, 14),
(155, 38475.000, 'PO', 35, 2, 4),
(156, 100.000, 'jkf', 35, 2, 14),
(157, 200.000, 'jkf', 35, 2, 15),
(158, 1000.000, 'jkfldsa', 36, 2, 14),
(159, 1500.000, 'jkfldsa', 36, 2, 14),
(160, 10.000, 'jfkdas', 37, 2, 14),
(161, 50300.000, 'PO', 38, 2, 4),
(162, 3915000.000, 'PO', 39, 2, 4),
(163, 200.000, '', 40, 2, 4),
(164, 38475.000, 'From PO', 40, 2, 4),
(165, 44.000, '', 41, 2, 4),
(166, 555.000, '', 42, 2, 15),
(167, 550.000, '0', 43, 2, 15),
(168, 1000.000, '0', 44, 2, 15),
(169, 123.000, '', 45, 2, 4),
(170, 100.000, 'haha', 46, 2, 14),
(171, 500.000, 'Transportation Expense', 47, 2, 4),
(173, 100.000, 'asdf', 49, 2, 4),
(174, 200.000, 'fsa ', 50, 2, 14),
(175, 200.000, ' jkfdlsa', 51, 2, 14),
(176, 200.000, 'fjkdsa', 52, 2, 14),
(177, 1000.000, 'jfkdsla', 53, 2, 14),
(178, 2700.000, 'jfkdlsa', 54, 2, 14),
(179, 14.000, 'asdf', 55, 2, 4),
(180, 72.000, 'asdf', 56, 2, 4),
(181, 50300.000, 'PO', 57, 2, 4),
(182, 100.000, 'TEST', 58, 2, 4),
(183, 100.000, 'TEST', 58, 2, 4),
(184, 100.000, 'TEST', 58, 2, 4),
(185, 100.000, 'TEST', 58, 2, 4),
(186, 100.000, 'TEST', 58, 2, 4),
(187, 100.000, 'TEST', 58, 2, 4),
(188, 100.000, 'TEST', 58, 2, 4),
(189, 100.000, 'TEST', 58, 2, 4),
(190, 100.000, 'TEST', 58, 2, 4),
(191, 100.000, 'TEST', 58, 2, 4),
(192, 100.000, 'TEST', 58, 2, 4),
(193, 100.000, 'TEST', 58, 2, 4),
(194, 100.000, 'TEST', 58, 2, 4),
(195, 100.000, 'TEST', 58, 2, 4),
(196, 100.000, 'TEST', 58, 2, 4),
(197, 100.000, 'TEST', 58, 2, 4),
(198, 100.000, 'TEST', 58, 2, 4),
(199, 100.000, 'TEST', 58, 2, 4),
(200, 100.000, 'TEST', 58, 2, 4),
(201, 100.000, 'TEST', 58, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `ap_header`
--

CREATE TABLE IF NOT EXISTS `ap_header` (
  `AP_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AP_HDR_CODE` varchar(20) DEFAULT NULL,
  `AP_HDR_AMOUNT` double(15,3) DEFAULT '0.000',
  `AP_HDR_DATE` date DEFAULT NULL,
  `AP_HDR_DUE_DATE` date NOT NULL,
  `AP_HDR_PARTICULAR` varchar(200) DEFAULT NULL,
  `AP_HDR_DESCRIPTION` text,
  `AP_HDR_REF_NO` varchar(20) DEFAULT NULL,
  `AP_HDR_REF_TYPE` varchar(10) DEFAULT NULL,
  `AP_HDR_REMARKS` text,
  `AP_HDR_CREATED_BY_ID` int(11) DEFAULT '0',
  `SUPPLIER_ID` int(11) DEFAULT '0',
  `IS_DELETED` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`AP_HDR_ID`),
  KEY `AP_HDR_CREATED_BY_ID` (`AP_HDR_CREATED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `ap_header`
--

INSERT INTO `ap_header` (`AP_HDR_ID`, `AP_HDR_CODE`, `AP_HDR_AMOUNT`, `AP_HDR_DATE`, `AP_HDR_DUE_DATE`, `AP_HDR_PARTICULAR`, `AP_HDR_DESCRIPTION`, `AP_HDR_REF_NO`, `AP_HDR_REF_TYPE`, `AP_HDR_REMARKS`, `AP_HDR_CREATED_BY_ID`, `SUPPLIER_ID`, `IS_DELETED`) VALUES
(1, 'AP-00001', 3000.000, '2002-01-10', '2002-01-31', '', 'Water Bill', 'WTRBILL-0001', 'Utilities', '', 1, 0, 0),
(2, 'AP-2011-000002', 3915000.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000011', 'AP', NULL, 1, 0, 0),
(3, 'AP-2011-000003', 38500.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(4, 'AP-2011-000004', 51000.000, '2011-11-29', '2011-12-12', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(5, 'AP-2011-000005', 51000.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(6, 'AP-2011-000006', 51000.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(7, 'AP-2011-000007', 50300.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(8, 'AP-2011-000008', 50300.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(9, 'AP-2011-000009', 38475.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(10, 'AP-2011-000010', 50300.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(11, 'AP-2011-000011', 50300.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(12, 'AP-2011-000012', 50300.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(13, 'AP-2011-000013', 22.000, '2011-11-29', '2011-12-16', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(14, 'AP-2011-000014', 50300.000, '2011-11-29', '2011-11-30', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(15, 'AP-2011-000015', 3915700.000, '2011-11-29', '2011-12-03', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 1),
(16, 'AP-2011-000016', 22.000, '2011-12-01', '2011-12-16', '', NULL, '', 'AP', NULL, 1, 0, 0),
(17, 'EXP-2011-000017', 5.000, '2011-12-01', '2011-12-01', '', NULL, 'PO-2011-00021', 'Expense', NULL, 1, 0, 0),
(18, 'EXP-2011-000018', 55.000, '2011-12-01', '2011-12-01', '', NULL, '', 'Expense', NULL, 2, 0, 0),
(19, 'EXP-2011-000019', 50300.000, '2011-12-01', '2011-12-01', '', NULL, 'PO-2011-000001', 'Expense', NULL, 14, 1, 0),
(20, 'AP-2011-000020', 51001.000, '2011-12-01', '2011-12-02', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(21, 'AP-2011-000021', 15.000, '2011-12-01', '2011-12-02', '', NULL, '', 'AP', NULL, 1, 0, 0),
(22, 'EXP-2011-000022', 323.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 16, 0, 0),
(23, 'EXP-2011-000023', 38475.000, '2011-12-02', '2011-12-02', '', NULL, 'PO-2011-000010', 'Expense', NULL, 14, 1, 0),
(24, 'EXP-2011-000024', 550.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 16, 0, 0),
(25, 'EXP-2011-000025', 50500.000, '2011-12-02', '2011-12-02', '', NULL, 'PO-2011-000013', 'Expense', NULL, 2, 9, 0),
(26, 'AP-2011-000026', 27.000, '2011-12-02', '2011-12-12', '', NULL, '', 'AP', NULL, 1, 0, 0),
(27, 'AP-2011-000027', 100.000, '2011-12-02', '2011-12-03', '', NULL, '', 'AP', NULL, 1, 0, 0),
(28, 'AP-2011-000028', 200.000, '2011-12-02', '2011-12-09', '', NULL, '', 'AP', NULL, 1, 0, 0),
(29, 'AP-2011-000029', 38511.000, '2011-12-02', '2011-12-16', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(30, 'AP-2011-000030', 50365.000, '2011-12-02', '2011-12-09', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(31, 'AP-2011-000031', 38560.000, '2011-12-02', '2011-12-09', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(32, 'AP-2011-000032', 50323.000, '2011-12-02', '2011-12-07', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(33, 'AP-2011-000033', 3.000, '2011-12-02', '2011-12-02', '', NULL, '', 'AP', NULL, 1, 0, 0),
(34, 'AP-2011-000034', 38503.000, '2011-12-02', '2011-12-14', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(35, 'AP-2011-000035', 38775.000, '2011-12-02', '2011-12-05', '', NULL, 'PO-2011-000010', 'AP', NULL, 1, 0, 0),
(36, 'AP-2011-000036', 2500.000, '2011-12-02', '2011-12-15', '', NULL, '', 'AP', NULL, 1, 0, 0),
(37, 'AP-2011-000037', 10.000, '2011-12-02', '2011-12-01', '', NULL, '', 'AP', NULL, 1, 0, 0),
(38, 'AP-2011-000038', 50300.000, '2011-12-02', '2011-12-06', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(39, 'AP-2011-000039', 3915000.000, '2011-12-02', '2011-12-08', '', NULL, 'PO-2011-000011', 'AP', NULL, 1, 0, 0),
(40, 'EXP-2011-000040', 38675.000, '2011-12-02', '2011-12-02', '', NULL, 'PO-2011-000010', 'Expense', NULL, 16, 1, 0),
(41, 'EXP-2011-000041', 44.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 1, 0, 0),
(42, 'EXP-2011-000042', 555.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 16, 0, 0),
(43, 'EXP-2011-000043', 550.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 14, 0, 0),
(44, 'EXP-2011-000044', 1000.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 1, 0, 0),
(45, 'EXP-2011-000045', 123.000, '2011-12-02', '2011-12-02', '', NULL, '', 'Expense', NULL, 14, 0, 0),
(46, 'AP-2011-000046', 100.000, '2011-12-06', '2011-12-07', '', NULL, '', 'AP', NULL, 14, 0, 1),
(47, 'AP-2011-000047', 500.000, '2011-12-06', '2011-12-16', '', NULL, '', 'AP', NULL, 17, 0, 1),
(49, 'EXP-2011-000048', 100.000, '2011-12-06', '2011-12-06', '', NULL, '', 'Expense', NULL, 17, 0, 0),
(50, 'AP-2011-000050', 200.000, '2011-12-06', '2011-12-09', '', NULL, '', 'AP', NULL, 14, 0, 0),
(51, 'AP-2011-000051', 200.000, '2011-12-06', '2011-12-07', '', NULL, '', 'AP', NULL, 14, 0, 1),
(52, 'AP-2011-000052', 200.000, '2011-12-06', '2011-12-15', '', NULL, '', 'AP', NULL, 14, 0, 0),
(53, 'AP-2011-000053', 1000.000, '2011-12-06', '2011-12-08', '', NULL, '', 'AP', NULL, 14, 0, 0),
(54, 'AP-2011-000054', 2700.000, '2011-12-06', '2011-12-08', '', NULL, '', 'AP', NULL, 14, 0, 0),
(55, 'EXP-2011-000055', 14.000, '2011-12-06', '2011-12-06', '', NULL, '', 'Expense', NULL, 2, 0, 0),
(56, 'EXP-2011-000056', 72.000, '2011-12-06', '2011-12-06', '', NULL, '', 'Expense', NULL, 17, 0, 0),
(57, 'AP-2011-000057', 50300.000, '2011-12-07', '2011-12-15', '', NULL, 'PO-2011-000001', 'AP', NULL, 1, 0, 0),
(58, 'EXP-2011-000058', 2000.000, '2011-12-07', '2011-12-07', '', NULL, '', 'Expense', NULL, 26, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `AREA_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AREA_NAME` varchar(100) DEFAULT NULL,
  `AREA_DESCRIPTION` varchar(500) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`AREA_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`AREA_ID`, `AREA_NAME`, `AREA_DESCRIPTION`, `IS_DELETED`) VALUES
(1, 'Washington St.', 'none', 0),
(2, 'Reyes St.', 'none', 0),
(3, 'E. Ramos St.', 'none', 0),
(4, 'Abraham St.', 'none', 0),
(5, 'Malubay St.', 'none', 0),
(6, 'Javier St.', 'none', 0),
(7, 'Wilson St.', 'St.', 0),
(8, 'Jacinto St.', 'none', 0),
(9, 'Fabie St.', 'none', 0),
(10, 'Tonio St.', 'none', 0);

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

CREATE TABLE IF NOT EXISTS `asset` (
  `ASSET_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ASSET_CODE` varchar(20) DEFAULT NULL,
  `ASSET_QTY` int(11) DEFAULT '0',
  `ASSET_UNIT_PRICE` double(15,3) DEFAULT '0.000',
  `ASSET_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `BRAND_ID` int(11) DEFAULT '0',
  `CATEGORY_ID` int(11) DEFAULT '0',
  `SUB_CATEGORY_ID` int(11) DEFAULT '0',
  `ASSET_IMAGE` text,
  `UNIT_ID` int(11) DEFAULT '0',
  `Minimum_Stock` int(11) NOT NULL,
  `Normal_Stock` int(11) NOT NULL,
  PRIMARY KEY (`ASSET_ID`),
  KEY `BRAND_ID` (`BRAND_ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`),
  KEY `SUB_CATEGORY_ID` (`SUB_CATEGORY_ID`),
  KEY `UNIT_ID` (`UNIT_ID`),
  KEY `ASSET_CODE` (`ASSET_CODE`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `asset`
--

INSERT INTO `asset` (`ASSET_ID`, `ASSET_CODE`, `ASSET_QTY`, `ASSET_UNIT_PRICE`, `ASSET_REMARKS`, `IS_DELETED`, `BRAND_ID`, `CATEGORY_ID`, `SUB_CATEGORY_ID`, `ASSET_IMAGE`, `UNIT_ID`, `Minimum_Stock`, `Normal_Stock`) VALUES
(1, 'AS-2011-000001', 3, 15.000, NULL, 0, 1, 1, 1, 'LCD-Monitors.jpg', 1, 100, 400),
(2, 'AS-2011-2', 7, 10.000, NULL, 0, 1, 1, 2, 'bond-paper.jpg', 2, 300, 260),
(3, 'AS-2011-000003', 7, 47.500, 'remarks', 0, 2, 2, 2, NULL, 3, 50, 50);

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE IF NOT EXISTS `audit_trail` (
  `AUDIT_DATE` date DEFAULT NULL,
  `AUDIT_TIME` time DEFAULT NULL,
  `AUDIT_ACTION_TAKEN` text,
  `EMP_ID` int(11) DEFAULT '0',
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `audit_trail`
--

INSERT INTO `audit_trail` (`AUDIT_DATE`, `AUDIT_TIME`, `AUDIT_ACTION_TAKEN`, `EMP_ID`) VALUES
('2011-12-06', '10:40:31', 'Location record updated.', 1),
('2011-12-06', '10:42:57', 'Withdrawal record created.', 1),
('2011-12-06', '10:52:40', 'Withdrawal record created.', 1),
('2011-12-06', '10:58:25', 'The user logged in', 1),
('2011-12-06', '11:01:37', 'The user logged out', 1),
('2011-12-06', '11:01:44', 'The user logged in', 14),
('2011-12-06', '11:07:04', 'Customer record deleted.', 1),
('2011-12-06', '11:07:09', 'Customer record restored.', 1),
('2011-12-06', '11:10:53', 'Location record deleted.', 1),
('2011-12-06', '11:10:56', 'The user logged out', 14),
('2011-12-06', '11:10:57', 'Location record deleted.', 1),
('2011-12-06', '11:11:01', 'Location record deleted.', 1),
('2011-12-06', '11:11:50', 'The user logged in', 14),
('2011-12-06', '11:14:34', 'Location record updated.', 1),
('2011-12-06', '11:14:35', 'Location record updated.', 1),
('2011-12-06', '11:14:41', 'Contact record updated.', 1),
('2011-12-06', '11:14:46', 'Contact record updated.', 1),
('2011-12-06', '11:14:52', 'Contact record updated.', 1),
('2011-12-06', '11:14:59', 'Contact record updated.', 1),
('2011-12-06', '11:15:43', 'Location record deleted.', 1),
('2011-12-06', '11:15:56', 'Location record restored.', 1),
('2011-12-06', '11:18:12', 'The user logged in', 14),
('2011-12-06', '11:18:21', 'Location record updated.', 1),
('2011-12-06', '11:18:49', 'Contact record updated.', 1),
('2011-12-06', '11:19:03', 'Contact record updated.', 1),
('2011-12-06', '11:20:18', 'Contact record updated.', 1),
('2011-12-06', '11:21:22', 'Contact record deleted.', 1),
('2011-12-06', '11:21:25', 'Contact record restored.', 1),
('2011-12-06', '11:28:54', 'The user logged out', 14),
('2011-12-06', '11:34:09', 'The user logged in', 2),
('2011-12-06', '11:40:22', 'The user logged out', 2),
('2011-12-06', '11:40:40', 'The user logged in', 1),
('2011-12-06', '11:41:17', 'The user logged in', 14),
('2011-12-06', '11:45:52', 'The user logged out', 1),
('2011-12-06', '11:46:14', 'The user logged in', 1),
('2011-12-06', '11:47:19', 'The user logged out', 1),
('2011-12-06', '11:47:36', 'The user logged out', 14),
('2011-12-06', '11:47:57', 'The user logged in', 14),
('2011-12-06', '11:48:02', 'The user logged in', 1),
('2011-12-06', '11:48:32', 'The user logged out', 1),
('2011-12-06', '11:48:59', 'The user logged out', 14),
('2011-12-06', '11:49:03', 'The user logged in', 14),
('2011-12-06', '11:49:21', 'The user logged in', 14),
('2011-12-06', '11:49:42', 'The user logged out', 14),
('2011-12-06', '11:49:49', 'The user logged in', 14),
('2011-12-06', '11:50:44', 'The user logged out', 14),
('2011-12-06', '11:50:49', 'The user logged in', 17),
('2011-12-06', '12:22:19', 'The user logged out', 14),
('2011-12-06', '12:22:42', 'The user logged in', 14),
('2011-12-06', '12:27:30', 'The user logged in', 14),
('2011-12-06', '12:29:07', 'The user logged out', 14),
('2011-12-06', '12:29:30', 'The user logged in', 14),
('2011-12-06', '12:35:06', 'The user logged out', 14),
('2011-12-06', '12:35:18', 'The user logged in', 14),
('2011-12-06', '12:36:00', 'The user logged out', 14),
('2011-12-06', '12:37:21', 'The user logged in', 17),
('2011-12-06', '12:45:45', 'The user logged in', 2),
('2011-12-06', '12:48:20', 'The user logged in', 1),
('2011-12-06', '12:49:27', 'The user logged in', 2),
('2011-12-06', '12:52:58', 'The user logged out', 1),
('2011-12-06', '12:53:04', 'The user logged out', 1),
('2011-12-06', '12:55:56', 'The user logged in', 1),
('2011-12-06', '12:58:55', 'The user logged in', 14),
('2011-12-06', '13:01:24', 'The user logged in', 17),
('2011-12-06', '13:18:54', 'The user logged in', 2),
('2011-12-06', '14:43:31', 'The user logged in', 17),
('2011-12-06', '14:53:18', 'Employee time in', 1),
('2011-12-06', '14:53:39', 'Employee time out', 1),
('2011-12-06', '14:54:12', 'The user logged out', 14),
('2011-12-06', '14:58:06', 'The user logged in', 14),
('2011-12-06', '14:58:11', 'The user logged out', 14),
('2011-12-06', '14:58:57', 'The user logged in', 14),
('2011-12-06', '14:59:03', 'The user logged out', 14),
('2011-12-06', '14:59:49', 'The user logged in', 14),
('2011-12-06', '15:01:10', 'The user logged out', 14),
('2011-12-06', '15:03:32', 'The user logged in', 14),
('2011-12-06', '15:04:12', 'The user logged out', 14),
('2011-12-06', '15:07:24', 'The user logged in', 14),
('2011-12-06', '15:19:19', 'The user logged in', 1),
('2011-12-06', '15:24:44', 'The user logged out', 14),
('2011-12-06', '15:25:16', 'The user logged out', 14),
('2011-12-06', '15:25:26', 'The user logged in', 14),
('2011-12-06', '15:25:56', 'The user logged out', 14),
('2011-12-06', '15:25:59', 'The user logged out', 14),
('2011-12-06', '15:27:00', 'The user logged in', 14),
('2011-12-06', '15:27:41', 'The user logged out', 14),
('2011-12-06', '15:28:06', 'The user logged in', 14),
('2011-12-06', '15:29:33', 'The user logged out', 14),
('2011-12-06', '15:29:47', 'The user logged in', 14),
('2011-12-06', '15:30:19', 'The user logged out', 14),
('2011-12-06', '15:35:09', 'The user logged in', 14),
('2011-12-06', '15:35:39', 'The user logged out', 14),
('2011-12-06', '15:35:48', 'The user logged in', 14),
('2011-12-06', '15:36:40', 'The user logged out', 14),
('2011-12-06', '15:36:50', 'The user logged in', 14),
('2011-12-06', '15:37:47', 'The user logged out', 14),
('2011-12-06', '15:38:24', 'The user logged in', 14),
('2011-12-06', '15:38:52', 'The user logged out', 14),
('2011-12-06', '15:38:58', 'The user logged out', 14),
('2011-12-06', '15:39:37', 'The user logged in', 14),
('2011-12-06', '16:10:17', 'The user logged in', 14),
('2011-12-06', '16:10:28', 'The user logged out', 14),
('2011-12-06', '16:13:39', 'The user logged in', 14),
('2011-12-06', '16:19:18', 'The user logged out', 14),
('2011-12-06', '16:27:37', 'The user logged in', 14),
('2011-12-06', '16:30:24', 'The user logged out', 14),
('2011-12-06', '16:45:23', 'The user logged in', 14),
('2011-12-06', '16:45:28', 'The user logged in', 14),
('2011-12-06', '16:45:29', 'The user logged in', 14),
('2011-12-06', '16:45:29', 'The user logged in', 14),
('2011-12-06', '16:45:30', 'The user logged in', 14),
('2011-12-06', '16:46:38', 'The user logged out', 14),
('2011-12-06', '16:47:01', 'The user logged in', 14),
('2011-12-06', '16:48:23', 'The user logged out', 14),
('2011-12-06', '16:48:48', 'The user logged in', 14),
('2011-12-06', '16:49:14', 'The user logged out', 14),
('2011-12-06', '16:56:44', 'Withdrawal record created.', 1),
('2011-12-06', '16:57:29', 'The user logged in', 14),
('2011-12-06', '16:57:56', 'Employee time in', 17),
('2011-12-06', '16:58:03', 'Employee time out', 17),
('2011-12-06', '16:58:50', 'The user logged out', 14),
('2011-12-06', '16:59:11', 'The user logged in', 14),
('2011-12-06', '16:59:37', 'The user logged in', 14),
('2011-12-06', '16:59:44', 'The user logged in', 14),
('2011-12-06', '16:59:58', 'The user logged out', 14),
('2011-12-06', '17:00:03', 'The user logged in', 14),
('2011-12-06', '17:00:04', 'The user logged in', 14),
('2011-12-06', '17:00:05', 'The user logged in', 14),
('2011-12-06', '17:00:45', 'The user logged out', 14),
('2011-12-06', '17:01:35', 'The user logged out', 14),
('2011-12-06', '17:03:31', 'The user logged in', 14),
('2011-12-06', '17:04:49', 'The user logged out', 14),
('2011-12-06', '17:05:11', 'The user logged in', 14),
('2011-12-06', '17:06:48', 'The user logged out', 14),
('2011-12-06', '17:08:13', 'The user logged in', 14),
('2011-12-06', '17:08:42', 'The user logged out', 14),
('2011-12-06', '17:11:07', 'The user logged in', 14),
('2011-12-06', '17:15:35', 'The user logged out', 14),
('2011-12-06', '17:15:42', 'The user logged in', 14),
('2011-12-06', '17:16:07', 'The user logged out', 14),
('2011-12-06', '17:16:14', 'The user logged in', 14),
('2011-12-06', '17:16:31', 'The user logged out', 14),
('2011-12-06', '17:18:24', 'The user logged in', 14),
('2011-12-06', '17:20:17', 'The user logged out', 14),
('2011-12-06', '17:20:24', 'The user logged in', 14),
('2011-12-06', '17:20:44', 'The user logged out', 14),
('2011-12-06', '17:20:51', 'The user logged in', 14),
('2011-12-06', '17:20:58', 'The user logged out', 14),
('2011-12-06', '17:25:31', 'The user logged in', 14),
('2011-12-06', '17:29:08', 'The user logged in', 1),
('2011-12-06', '17:29:23', 'The user logged out', 1),
('2011-12-06', '17:34:40', 'The user logged in', 1),
('2011-12-06', '17:37:40', 'The user logged out', 1),
('2011-12-06', '17:38:13', 'The user logged in', 1),
('2011-12-06', '17:40:02', 'The user logged in', 2),
('2011-12-06', '17:47:17', 'The user logged out', 1),
('2011-12-06', '17:48:47', 'The user logged in', 1),
('2011-12-06', '17:48:59', 'The user logged out', 1),
('2011-12-06', '17:50:40', 'The user logged in', 1),
('2011-12-06', '17:50:59', 'The user logged out', 1),
('2011-12-06', '17:54:44', 'The user logged in', 1),
('2011-12-06', '17:54:55', 'The user logged out', 1),
('2011-12-06', '17:55:33', 'The user logged in', 1),
('2011-12-06', '17:55:50', 'The user logged out', 1),
('2011-12-06', '17:56:26', 'The user logged in', 1),
('2011-12-06', '17:56:32', 'The user logged out', 14),
('2011-12-06', '17:56:40', 'The user logged out', 14),
('2011-12-06', '17:57:23', 'The user logged in', 14),
('2011-12-06', '18:07:51', 'The user logged in', 1),
('2011-12-06', '18:08:40', 'The user logged in', 1),
('2011-12-06', '18:36:10', 'Contact record restored.', 14),
('2011-12-06', '18:47:41', 'The user logged in', 17),
('2011-12-06', '18:48:40', 'The user logged in', 1),
('2011-12-06', '19:08:59', 'Employee profile updated.', 1),
('2011-12-06', '19:09:10', 'Employee profile updated.', 1),
('2011-12-06', '19:09:11', 'Employee profile updated.', 1),
('2011-12-06', '19:09:40', 'Employee record deleted.', 1),
('2011-12-06', '19:09:49', 'Employee profile updated.', 1),
('2011-12-06', '19:10:05', 'Employee profile updated.', 1),
('2011-12-06', '19:10:06', 'Employee profile updated.', 1),
('2011-12-06', '19:18:27', 'Customer record updated.', 17),
('2011-12-06', '19:18:47', 'Customer record updated.', 17),
('2011-12-06', '19:23:23', 'The user logged out', 14),
('2011-12-06', '19:23:28', 'The user logged in', 14),
('2011-12-06', '19:24:10', 'The user logged out', 14),
('2011-12-06', '19:24:34', 'The user logged in', 14),
('2011-12-06', '19:30:00', 'Employee record restored.', 14),
('2011-12-06', '19:32:27', 'Employee record restored.', 1),
('2011-12-06', '19:35:09', 'File leave updated.', 1),
('2011-12-06', '19:58:16', 'Customer record updated.', 1),
('2011-12-06', '19:58:52', 'Location record created.', 1),
('2011-12-06', '19:59:22', 'Customer record updated.', 1),
('2011-12-06', '20:03:25', 'Customer record updated.', 17),
('2011-12-06', '20:06:25', 'Customer record updated.', 17),
('2011-12-06', '20:07:05', 'Location record created.', 17),
('2011-12-06', '20:07:20', 'Customer record updated.', 17),
('2011-12-06', '20:19:15', 'The user logged out', 1),
('2011-12-06', '20:22:34', 'The user logged in', 1),
('2011-12-06', '20:22:43', 'The user logged in', 1),
('2011-12-06', '20:22:56', 'The user logged out', 1),
('2011-12-06', '20:23:05', 'The user logged in', 1),
('2011-12-06', '20:23:15', 'The user logged out', 1),
('2011-12-06', '20:23:18', 'The user logged out', 1),
('2011-12-06', '20:23:26', 'The user logged in', 1),
('2011-12-06', '20:23:38', 'The user logged in', 1),
('2011-12-06', '20:23:49', 'The user logged out', 1),
('2011-12-06', '20:24:01', 'The user logged out', 1),
('2011-12-06', '20:24:10', 'The user logged in', 1),
('2011-12-06', '20:29:09', 'The user logged in', 1),
('2011-12-06', '20:31:55', 'The user logged out', 1),
('2011-12-06', '20:37:44', 'The user logged in', 1),
('2011-12-06', '20:44:36', 'The user logged out', 1),
('2011-12-06', '21:20:25', 'The user logged in', 1),
('2011-12-07', '09:07:28', 'The user logged in', 1),
('2011-12-07', '09:10:02', 'Customer record updated.', 1),
('2011-12-07', '09:10:33', 'Location record created.', 1),
('2011-12-07', '09:12:00', 'Location record updated.', 1),
('2011-12-07', '09:18:56', 'Customer record deleted.', 1),
('2011-12-07', '09:19:00', 'Customer record deleted.', 1),
('2011-12-07', '09:19:21', 'Customer record restored.', 1),
('2011-12-07', '10:45:10', 'The user logged in', 2),
('2011-12-07', '10:48:56', 'The user logged in', 14),
('2011-12-07', '10:49:52', 'The user logged out', 2),
('2011-12-07', '10:49:56', 'The user logged in', 2),
('2011-12-07', '10:50:38', 'The user logged out', 1),
('2011-12-07', '10:50:46', 'The user logged in', 16),
('2011-12-07', '10:50:48', 'The user logged in', 1),
('2011-12-07', '10:51:13', 'The user logged out', 2),
('2011-12-07', '10:51:20', 'The user logged out', 16),
('2011-12-07', '10:53:38', 'The user logged in', 2),
('2011-12-07', '11:05:09', 'The user logged in', 16),
('2011-12-07', '11:06:32', 'The user logged out', 16),
('2011-12-07', '11:06:44', 'The user logged in', 16),
('2011-12-07', '11:08:05', 'The user logged in', 17),
('2011-12-07', '11:08:40', 'The user logged out', 17),
('2011-12-07', '11:08:47', 'The user logged in', 15),
('2011-12-07', '11:11:17', 'Employee record created.', 16),
('2011-12-07', '11:11:17', 'Educational background created.', 16),
('2011-12-07', '11:11:17', 'Work history detail created.', 16),
('2011-12-07', '11:11:17', 'Employee record updated.', 16),
('2011-12-07', '11:11:19', 'Employee record created.', 16),
('2011-12-07', '11:11:24', 'The user logged in', 1),
('2011-12-07', '11:11:41', 'Employee record deleted.', 16),
('2011-12-07', '11:11:47', 'Employee record deleted.', 16),
('2011-12-07', '11:11:53', 'Employee record created.', 14),
('2011-12-07', '11:11:53', 'Educational background created.', 14),
('2011-12-07', '11:11:53', 'Educational background created.', 14),
('2011-12-07', '11:11:53', 'Educational background created.', 14),
('2011-12-07', '11:11:53', 'Work history detail created.', 14),
('2011-12-07', '11:11:54', 'Work history detail created.', 14),
('2011-12-07', '11:11:54', 'Employee record updated.', 14),
('2011-12-07', '11:14:12', 'Employee record created.', 1),
('2011-12-07', '11:14:12', 'Educational background created.', 1),
('2011-12-07', '11:14:12', 'Work history detail created.', 1),
('2011-12-07', '11:14:12', 'Employee record updated.', 1),
('2011-12-07', '11:14:40', 'Employee record created.', 16),
('2011-12-07', '11:14:41', 'Educational background created.', 16),
('2011-12-07', '11:14:41', 'Work history detail created.', 16),
('2011-12-07', '11:14:41', 'Employee record updated.', 16),
('2011-12-07', '11:15:05', 'Employee record created.', 14),
('2011-12-07', '11:15:05', 'Educational background created.', 14),
('2011-12-07', '11:15:05', 'Work history detail created.', 14),
('2011-12-07', '11:15:05', 'Employee record updated.', 14),
('2011-12-07', '11:15:12', 'Employee record created.', 14),
('2011-12-07', '11:17:59', 'Work history detail created.', 14),
('2011-12-07', '11:18:37', 'Work history detail created.', 14),
('2011-12-07', '11:20:03', 'Educational background created.', 14),
('2011-12-07', '11:20:03', 'Educational background created.', 14),
('2011-12-07', '11:20:04', 'Educational background created.', 14),
('2011-12-07', '11:21:50', 'The user logged out', 14),
('2011-12-07', '11:22:33', 'The user logged in', 14),
('2011-12-07', '11:23:53', 'Educational background created.', 1),
('2011-12-07', '11:23:53', 'Work history detail created.', 1),
('2011-12-07', '11:23:53', 'Employee record updated.', 1),
('2011-12-07', '11:23:53', 'Employee record created.', 1),
('2011-12-07', '11:27:11', 'The user logged out', 16),
('2011-12-07', '11:28:16', 'The user logged in', 16),
('2011-12-07', '11:28:45', 'Educational background created.', 1),
('2011-12-07', '11:28:45', 'Work history detail created.', 1),
('2011-12-07', '11:28:45', 'Employee record updated.', 1),
('2011-12-07', '11:28:46', 'Employee record created.', 1),
('2011-12-07', '11:29:38', 'Employee profile updated.', 16),
('2011-12-07', '11:33:00', 'Educational background created.', 14),
('2011-12-07', '11:33:00', 'Work history detail created.', 14),
('2011-12-07', '11:33:00', 'Employee record updated.', 14),
('2011-12-07', '11:33:00', 'Employee record created.', 14),
('2011-12-07', '11:38:04', 'The user logged out', 14),
('2011-12-07', '11:38:11', 'The user logged in', 26),
('2011-12-07', '11:39:48', 'Educational background created.', 16),
('2011-12-07', '11:39:48', 'Work history detail created.', 16),
('2011-12-07', '11:39:48', 'Employee record updated.', 16),
('2011-12-07', '11:39:48', 'Employee record created.', 16),
('2011-12-07', '11:40:17', 'Employee record deleted.', 16),
('2011-12-07', '11:40:54', 'The user logged out', 16),
('2011-12-07', '11:40:59', 'The user logged in', 27),
('2011-12-07', '11:43:39', 'The user logged out', 1),
('2011-12-07', '11:43:52', 'The user logged in', 1),
('2011-12-07', '11:50:34', 'Educational background created.', 1),
('2011-12-07', '11:50:34', 'Work history detail created.', 1),
('2011-12-07', '11:50:34', 'Employee record updated.', 1),
('2011-12-07', '11:50:34', 'Employee record created.', 1),
('2011-12-07', '12:02:29', 'Educational background created.', 1),
('2011-12-07', '12:02:29', 'Work history detail created.', 1),
('2011-12-07', '12:02:29', 'Employee record updated.', 1),
('2011-12-07', '12:02:29', 'Employee record created.', 1),
('2011-12-07', '12:03:45', 'The user logged in', 15),
('2011-12-07', '12:05:31', 'Educational background created.', 1),
('2011-12-07', '12:05:31', 'Work history detail created.', 1),
('2011-12-07', '12:05:31', 'Employee record updated.', 1),
('2011-12-07', '12:05:31', 'Employee record created.', 1),
('2011-12-07', '12:14:45', 'Educational background created.', 1),
('2011-12-07', '12:14:45', 'Work history detail created.', 1),
('2011-12-07', '12:14:45', 'Employee record updated.', 1),
('2011-12-07', '12:14:45', 'Employee record created.', 1),
('2011-12-07', '12:17:01', 'Educational background created.', 1),
('2011-12-07', '12:17:01', 'Work history detail created.', 1),
('2011-12-07', '12:17:01', 'Employee record updated.', 1),
('2011-12-07', '12:17:01', 'Employee record created.', 1),
('2011-12-07', '12:20:45', 'Educational background created.', 1),
('2011-12-07', '12:20:45', 'Work history detail created.', 1),
('2011-12-07', '12:20:45', 'Employee record updated.', 1),
('2011-12-07', '12:20:45', 'Employee record created.', 1),
('2011-12-07', '13:50:36', 'The user logged in', 27),
('2011-12-07', '14:09:57', 'The user logged in', 17),
('2011-12-07', '14:10:59', 'The user logged out', 27),
('2011-12-07', '14:11:25', 'The user logged in', 27),
('2011-12-07', '14:11:40', 'The user logged in', 14),
('2011-12-07', '14:12:56', 'The user logged in', 27),
('2011-12-07', '14:16:56', 'The user logged in', 15),
('2011-12-07', '14:35:16', 'The user logged in', 26),
('2011-12-07', '15:02:44', 'The user logged out', 27),
('2011-12-07', '15:03:01', 'The user logged in', 27),
('2011-12-07', '15:03:51', 'The user logged in', 27),
('2011-12-07', '15:05:19', 'The user logged in', 2),
('2011-12-07', '15:07:02', 'The user logged in', 15),
('2011-12-07', '15:08:20', 'The user logged in', 27),
('2011-12-07', '15:08:54', 'The user logged out', 27),
('2011-12-07', '15:09:10', 'The user logged in', 27),
('2011-12-07', '15:09:35', 'The user logged in', 27),
('2011-12-07', '15:09:52', 'The user logged in', 27),
('2011-12-07', '15:10:26', 'The user logged in', 27),
('2011-12-07', '15:11:01', 'The user logged in', 27),
('2011-12-07', '15:13:09', 'Withdrawal record created.', 26),
('2011-12-07', '15:13:22', 'The user logged in', 27),
('2011-12-07', '15:13:44', 'The user logged in', 27),
('2011-12-07', '15:14:02', 'The user logged in', 27),
('2011-12-07', '15:14:37', 'The user logged in', 27),
('2011-12-07', '15:15:30', 'The user logged in', 2),
('2011-12-07', '15:16:09', 'The user logged out', 27),
('2011-12-07', '15:16:17', 'The user logged in', 27),
('2011-12-07', '15:16:32', 'The user logged in', 27),
('2011-12-07', '15:16:43', 'The user logged in', 27),
('2011-12-07', '15:16:45', 'The user logged in', 2),
('2011-12-07', '15:17:05', 'The user logged in', 2),
('2011-12-07', '15:17:10', 'The user logged out', 2),
('2011-12-07', '15:17:13', 'The user logged in', 27),
('2011-12-07', '15:17:17', 'The user logged in', 1),
('2011-12-07', '15:17:26', 'The user logged in', 2),
('2011-12-07', '15:18:16', 'The user logged in', 1),
('2011-12-07', '15:18:32', 'The user logged in', 17),
('2011-12-07', '15:22:15', 'Educational background created.', 2),
('2011-12-07', '15:22:15', 'Educational background created.', 2),
('2011-12-07', '15:22:15', 'Work history detail created.', 2),
('2011-12-07', '15:22:15', 'Employee record updated.', 2),
('2011-12-07', '15:22:15', 'Employee record created.', 2),
('2011-12-07', '15:23:52', 'The user logged in', 27),
('2011-12-07', '15:24:06', 'Educational background created.', 1),
('2011-12-07', '15:24:06', 'Work history detail created.', 1),
('2011-12-07', '15:24:06', 'Employee record updated.', 1),
('2011-12-07', '15:24:06', 'Employee record created.', 1),
('2011-12-07', '15:24:53', 'Employee profile updated.', 1),
('2011-12-07', '15:25:07', 'Employee profile updated.', 1),
('2011-12-07', '15:25:08', 'Employee profile updated.', 1),
('2011-12-07', '15:26:02', 'Work history detail updated.', 1),
('2011-12-07', '15:27:54', 'The user logged out', 2),
('2011-12-07', '15:28:03', 'The user logged in', 36),
('2011-12-07', '16:01:18', 'The user logged out', 27),
('2011-12-07', '16:01:22', 'The user logged out', 27),
('2011-12-07', '16:15:18', 'The user logged out', 17),
('2011-12-07', '16:15:22', 'The user logged out', 17),
('2011-12-07', '16:17:41', 'The user logged in', 14),
('2011-12-07', '16:37:11', 'Educational background created.', 1),
('2011-12-07', '16:37:11', 'Work history detail created.', 1),
('2011-12-07', '16:37:11', 'Employee record updated.', 1),
('2011-12-07', '16:37:11', 'Employee record created.', 1),
('2011-12-07', '16:48:44', 'The user logged in', 2),
('2011-12-07', '17:58:48', 'Customer record deleted.', 15),
('2011-12-07', '18:38:13', 'The user logged out', 2),
('2011-12-08', '09:02:47', 'The user logged in', 27),
('2011-12-08', '09:07:02', 'The user logged out', 27),
('2011-12-08', '09:07:16', 'The user logged in', 27),
('2011-12-08', '09:07:51', 'The user logged in', 27),
('2011-12-08', '09:08:35', 'The user logged in', 27),
('2011-12-08', '09:08:48', 'The user logged in', 27),
('2011-12-08', '09:16:47', 'The user logged out', 27),
('2011-12-08', '09:16:57', 'The user logged in', 27),
('2011-12-08', '09:17:58', 'The user logged out', 27),
('2011-12-08', '09:18:02', 'The user logged out', 27),
('2011-12-08', '09:18:31', 'The user logged in', 27),
('2011-12-08', '09:19:01', 'The user logged out', 27),
('2011-12-08', '09:19:10', 'The user logged in', 27),
('2011-12-08', '09:21:14', 'The user logged in', 27),
('2011-12-08', '09:28:06', 'The user logged out', 27),
('2011-12-08', '09:28:15', 'The user logged in', 27),
('2011-12-08', '09:28:17', 'The user logged in', 15),
('2011-12-08', '09:29:44', 'The user logged in', 27),
('2011-12-08', '09:29:58', 'The user logged out', 27),
('2011-12-08', '09:30:12', 'The user logged out', 27),
('2011-12-08', '09:30:32', 'The user logged in', 27),
('2011-12-08', '09:31:22', 'The user logged in', 14),
('2011-12-08', '09:32:42', 'The user logged out', 27),
('2011-12-08', '09:32:47', 'The user logged in', 27),
('2011-12-08', '09:33:43', 'The user logged out', 27),
('2011-12-08', '09:33:49', 'The user logged out', 27),
('2011-12-08', '09:34:18', 'The user logged in', 27),
('2011-12-08', '09:36:20', 'The user logged out', 27),
('2011-12-08', '09:36:42', 'The user logged in', 27),
('2011-12-08', '09:38:49', 'The user logged out', 27),
('2011-12-08', '09:38:56', 'The user logged in', 27),
('2011-12-08', '09:53:01', 'The user logged out', 27),
('2011-12-08', '09:53:07', 'The user logged out', 27),
('2011-12-08', '09:53:14', 'The user logged in', 27),
('2011-12-08', '09:53:19', 'The user logged out', 27),
('2011-12-08', '10:01:39', 'The user logged in', 27),
('2011-12-08', '10:07:13', 'The user logged in', 27),
('2011-12-08', '10:10:05', 'The user logged out', 27),
('2011-12-08', '10:10:55', 'The user logged in', 27),
('2011-12-08', '10:14:46', 'The user logged out', 27),
('2011-12-08', '10:15:24', 'The user logged in', 27),
('2011-12-08', '10:52:27', 'The user logged in', 26),
('2011-12-08', '10:55:59', 'The user logged out', 14),
('2011-12-08', '10:56:04', 'The user logged in', 14),
('2011-12-08', '10:56:16', 'The user logged out', 14),
('2011-12-08', '10:56:23', 'The user logged in', 14),
('2011-12-08', '11:00:19', 'Employee time in', 14),
('2011-12-08', '11:53:51', 'The user logged out', 27),
('2011-12-08', '11:53:55', 'The user logged out', 14),
('2011-12-08', '11:54:02', 'The user logged in', 14),
('2011-12-08', '11:54:27', 'The user logged in', 27),
('2011-12-08', '12:01:46', 'The user logged out', 14),
('2011-12-08', '12:01:51', 'The user logged in', 14),
('2011-12-08', '12:03:08', 'The user logged out', 14),
('2011-12-08', '12:03:14', 'The user logged in', 14),
('2011-12-08', '12:03:30', 'The user logged out', 27),
('2011-12-08', '12:03:34', 'The user logged in', 27),
('2011-12-08', '12:05:49', 'The user logged out', 27),
('2011-12-08', '12:06:34', 'The user logged in', 27),
('2011-12-08', '12:09:55', 'The user logged out', 14),
('2011-12-08', '12:11:40', 'The user logged in', 14),
('2011-12-08', '12:16:56', 'The user logged out', 27),
('2011-12-08', '12:17:00', 'The user logged out', 27),
('2011-12-08', '12:17:50', 'The user logged in', 27),
('2011-12-08', '12:19:17', 'The user logged out', 27),
('2011-12-08', '12:19:50', 'The user logged in', 27),
('2011-12-08', '12:26:54', 'Employee profile updated.', 14),
('2011-12-08', '12:27:54', 'Employee profile updated.', 14),
('2011-12-08', '12:29:39', 'Employee profile updated.', 14),
('2011-12-08', '12:30:30', 'The user logged in', 27),
('2011-12-08', '12:34:24', 'The user logged out', 14),
('2011-12-08', '12:34:28', 'The user logged in', 14),
('2011-12-08', '12:36:16', 'The user logged out', 27),
('2011-12-08', '12:37:00', 'The user logged in', 27),
('2011-12-08', '12:37:23', 'The user logged out', 14),
('2011-12-08', '12:38:07', 'The user logged out', 27),
('2011-12-08', '12:38:39', 'The user logged in', 27),
('2011-12-08', '12:40:05', 'The user logged out', 27),
('2011-12-08', '12:46:58', 'The user logged in', 27),
('2011-12-08', '12:51:02', 'The user logged in', 27),
('2011-12-08', '12:52:26', 'The user logged in', 16),
('2011-12-08', '12:56:42', 'The user logged in', 27),
('2011-12-08', '12:57:04', 'The user logged out', 27),
('2011-12-08', '12:57:20', 'The user logged in', 27),
('2011-12-08', '12:57:47', 'The user logged out', 27),
('2011-12-08', '12:58:00', 'The user logged in', 27),
('2011-12-08', '12:59:01', 'The user logged in', 27),
('2011-12-08', '12:59:22', 'The user logged in', 27),
('2011-12-08', '12:59:33', 'The user logged out', 27),
('2011-12-08', '12:59:40', 'The user logged in', 27),
('2011-12-08', '12:59:50', 'The user logged out', 27),
('2011-12-08', '13:00:18', 'The user logged in', 16),
('2011-12-08', '13:00:44', 'The user logged in', 16),
('2011-12-08', '13:01:46', 'The user logged in', 27),
('2011-12-08', '13:02:23', 'The user logged out', 26),
('2011-12-08', '13:02:49', 'The user logged in', 16),
('2011-12-08', '13:03:14', 'The user logged in', 16),
('2011-12-08', '13:33:10', 'The user logged in', 27),
('2011-12-08', '13:35:02', 'The user logged in', 2),
('2011-12-08', '13:54:19', 'The user logged out', 16),
('2011-12-08', '13:54:45', 'The user logged out', 27),
('2011-12-08', '13:54:48', 'The user logged in', 27),
('2011-12-08', '14:05:40', 'The user logged out', 2),
('2011-12-08', '14:05:48', 'The user logged out', 2),
('2011-12-08', '14:05:58', 'The user logged in', 14),
('2011-12-08', '14:06:04', 'The user logged out', 14),
('2011-12-08', '14:06:05', 'The user logged in', 2),
('2011-12-08', '14:06:11', 'The user logged out', 2),
('2011-12-08', '14:06:12', 'The user logged in', 1),
('2011-12-08', '14:06:30', 'The user logged in', 36),
('2011-12-08', '14:06:36', 'The user logged in', 14),
('2011-12-08', '14:06:40', 'The user logged out', 1),
('2011-12-08', '14:11:21', 'The user logged in', 1),
('2011-12-08', '15:01:12', 'The user logged in', 26),
('2011-12-08', '16:15:06', 'Withdrawal record created.', 1),
('2011-12-08', '17:27:13', 'The user logged out', 1),
('2011-12-08', '17:27:20', 'The user logged out', 1),
('2011-12-08', '17:27:43', 'The user logged in', 1),
('2011-12-08', '17:50:48', 'The user logged in', 16),
('2011-12-08', '17:55:24', 'The user logged out', 1),
('2011-12-08', '18:38:17', 'The user logged out', 36),
('2011-12-08', '18:43:31', 'The user logged out', 16),
('2011-12-08', '18:43:39', 'The user logged out', 16),
('2011-12-09', '09:14:09', 'The user logged in', 27),
('2011-12-09', '09:14:46', 'Withdrawal record created.', 27),
('2011-12-09', '09:30:27', 'The user logged in', 15),
('2011-12-09', '09:39:09', 'The user logged out', 27),
('2011-12-09', '09:39:43', 'The user logged in', 1),
('2011-12-09', '09:39:51', 'The user logged out', 1),
('2011-12-09', '09:40:57', 'The user logged in', 1),
('2011-12-09', '09:41:30', 'The user logged in', 1),
('2011-12-09', '09:46:13', 'The user logged in', 17),
('2011-12-09', '10:42:51', 'Customer record deleted.', 15),
('2011-12-09', '10:42:56', 'Customer record deleted.', 15),
('2011-12-09', '10:54:14', 'Withdrawal record created.', 1),
('2011-12-09', '10:58:00', 'The user logged out', 17),
('2011-12-09', '11:01:39', 'The user logged in', 17),
('2011-12-09', '11:01:47', 'The user logged out', 17),
('2011-12-09', '11:02:08', 'The user logged in', 17),
('2011-12-09', '11:03:42', 'The user logged out', 17),
('2011-12-09', '11:04:05', 'The user logged out', 1),
('2011-12-09', '11:04:36', 'The user logged in', 27),
('2011-12-09', '11:04:42', 'The user logged out', 27),
('2011-12-09', '11:04:45', 'The user logged in', 27),
('2011-12-09', '11:08:09', 'The user logged in', 1),
('2011-12-09', '11:09:08', 'The user logged out', 1),
('2011-12-09', '11:09:29', 'The user logged in', 1),
('2011-12-09', '11:11:00', 'The user logged out', 1),
('2011-12-09', '11:11:07', 'The user logged in', 1),
('2011-12-09', '11:13:10', 'The user logged out', 1),
('2011-12-09', '11:13:16', 'The user logged in', 1),
('2011-12-09', '11:19:15', 'The user logged out', 1),
('2011-12-09', '11:19:27', 'The user logged in', 1),
('2011-12-09', '11:24:16', 'The user logged out', 1),
('2011-12-09', '11:24:24', 'The user logged in', 1),
('2011-12-09', '11:25:27', 'The user logged out', 1),
('2011-12-09', '11:30:18', 'The user logged in', 1),
('2011-12-09', '11:32:26', 'The user logged out', 1),
('2011-12-09', '11:32:32', 'The user logged in', 1),
('2011-12-09', '11:34:24', 'Withdrawal record created.', 27),
('2011-12-09', '11:36:44', 'Withdrawal record created.', 27),
('2011-12-09', '11:58:48', 'Withdrawal record created.', 27),
('2011-12-09', '12:01:15', 'Withdrawal record created.', 27),
('2011-12-09', '12:14:43', 'Customer record restored.', 15),
('2011-12-09', '12:31:51', 'Customer record updated.', 1),
('2011-12-09', '12:32:15', 'Customer record updated.', 1),
('2011-12-09', '12:33:06', 'Customer record updated.', 1),
('2011-12-09', '12:34:59', 'Customer record updated.', 1),
('2011-12-09', '12:38:32', 'Customer record updated.', 1),
('2011-12-09', '13:16:28', 'Customer record updated.', 1),
('2011-12-09', '13:39:19', 'The user logged in', 14),
('2011-12-09', '13:58:55', 'Location record updated.', 1),
('2011-12-09', '13:59:39', 'The user logged in', 36),
('2011-12-09', '15:20:39', 'The user logged in', 15),
('2011-12-09', '15:50:17', 'The user logged in', 2),
('2011-12-09', '16:20:49', 'The user logged out', 14),
('2011-12-09', '16:49:10', 'The user logged in', 1),
('2011-12-09', '17:04:44', 'The user logged out', 1),
('2011-12-09', '17:04:57', 'The user logged in', 1),
('2011-12-09', '18:02:51', 'The user logged out', 36),
('2011-12-09', '18:37:58', 'The user logged in', 14),
('2011-12-09', '18:49:31', 'The user logged in', 14),
('2011-12-09', '19:09:36', 'The user logged in', 2),
('2011-12-12', '10:19:39', 'The user logged in', 26),
('2011-12-12', '10:19:45', 'The user logged out', 26),
('2011-12-12', '10:19:59', 'The user logged in', 27),
('2011-12-12', '10:26:20', 'The user logged in', 15),
('2011-12-12', '12:02:48', 'Location record created.', 15),
('2011-12-12', '12:21:16', 'Location record deleted.', 15),
('2011-12-12', '12:21:25', 'Location record restored.', 15),
('2011-12-12', '12:22:48', 'The user logged in', 17),
('2011-12-12', '13:09:15', 'Customer record updated.', 17),
('2011-12-12', '13:09:26', 'Customer record updated.', 17),
('2011-12-12', '13:13:23', 'Customer record updated.', 17),
('2011-12-12', '13:13:55', 'Customer record updated.', 17),
('2011-12-12', '13:16:26', 'Customer record updated.', 17),
('2011-12-12', '13:17:51', 'Customer record updated.', 17),
('2011-12-12', '13:43:56', 'Location record deleted.', 15),
('2011-12-12', '14:18:08', 'The user logged in', 16),
('2011-12-12', '14:41:40', 'Location record restored.', 15),
('2011-12-12', '14:41:51', 'Contact record restored.', 15),
('2011-12-12', '15:12:21', 'Contact record updated.', 15),
('2011-12-12', '15:13:08', 'Contact record updated.', 15),
('2011-12-12', '15:37:03', 'Contact record deleted.', 16),
('2011-12-12', '15:37:11', 'Contact record restored.', 16),
('2011-12-12', '15:37:20', 'The user logged in', 17),
('2011-12-12', '15:38:08', 'Location record deleted.', 16),
('2011-12-12', '15:38:15', 'Location record deleted.', 16),
('2011-12-12', '15:38:19', 'Location record restored.', 16),
('2011-12-12', '15:44:44', 'Location record deleted.', 16),
('2011-12-12', '15:47:36', 'Location record restored.', 16),
('2011-12-12', '15:57:05', 'Contact record deleted.', 15),
('2011-12-12', '17:13:41', 'The user logged in', 17),
('2011-12-12', '17:14:20', 'The user logged out', 17),
('2011-12-13', '12:23:15', 'The user logged in', 15),
('2011-12-13', '13:16:22', 'The user logged in', 36),
('2011-12-13', '17:41:39', 'The user logged out', 36),
('2011-12-13', '17:42:55', 'The user logged in', 36),
('2011-12-13', '17:43:39', 'The user logged out', 36),
('2011-12-16', '11:15:04', 'The user logged in', 17),
('2011-12-16', '11:20:01', 'The user logged out', 17),
('2011-12-16', '11:20:59', 'The user logged in', 1),
('2011-12-16', '11:22:44', 'The user logged in', 27),
('2011-12-16', '11:22:55', 'The user logged out', 1),
('2011-12-16', '11:23:02', 'The user logged in', 1),
('2011-12-16', '13:09:02', 'The user logged out', 1),
('2011-12-16', '13:10:36', 'The user logged out', 27),
('2011-12-16', '13:10:45', 'The user logged in', 15),
('2011-12-16', '13:10:50', 'The user logged in', 27),
('2011-12-16', '13:11:04', 'The user logged out', 27),
('2011-12-16', '13:11:11', 'The user logged in', 27),
('2011-12-16', '13:12:18', 'The user logged in', 16),
('2011-12-16', '13:13:44', 'The user logged out', 27),
('2011-12-16', '13:13:49', 'The user logged out', 16),
('2011-12-16', '13:14:02', 'The user logged in', 27),
('2011-12-16', '13:14:11', 'The user logged in', 16),
('2011-12-16', '13:41:07', 'The user logged out', 16),
('2011-12-16', '13:41:57', 'The user logged in', 15),
('2011-12-16', '13:42:21', 'The user logged in', 17),
('2011-12-16', '13:45:40', 'The user logged out', 17),
('2011-12-16', '13:46:51', 'The user logged in', 17),
('2011-12-16', '13:46:56', 'The user logged out', 17),
('2011-12-16', '13:49:59', 'The user logged in', 17),
('2011-12-16', '13:50:04', 'The user logged out', 17),
('2011-12-16', '13:56:53', 'The user logged in', 1),
('2011-12-16', '13:57:01', 'The user logged out', 1),
('2011-12-16', '14:04:33', 'The user logged in', 1),
('2011-12-16', '14:04:35', 'The user logged in', 1),
('2011-12-16', '14:04:37', 'The user logged in', 1),
('2011-12-16', '14:04:47', 'The user logged out', 1),
('2011-12-16', '14:04:55', 'The user logged in', 1),
('2011-12-16', '14:04:59', 'The user logged in', 1),
('2011-12-16', '14:05:06', 'The user logged out', 1),
('2011-12-16', '14:06:12', 'The user logged out', 1),
('2011-12-16', '14:06:20', 'The user logged in', 1),
('2011-12-16', '14:06:22', 'The user logged in', 1),
('2011-12-16', '14:06:24', 'The user logged in', 1),
('2011-12-16', '14:06:30', 'The user logged out', 1),
('2011-12-16', '14:07:27', 'The user logged in', 1),
('2011-12-16', '14:07:39', 'The user logged out', 1),
('2011-12-16', '14:07:44', 'The user logged in', 1),
('2011-12-16', '14:10:50', 'The user logged out', 1),
('2011-12-16', '14:11:02', 'The user logged in', 1),
('2011-12-16', '14:11:17', 'The user logged in', 1),
('2011-12-16', '14:11:19', 'The user logged in', 1),
('2011-12-16', '14:12:48', 'The user logged out', 1),
('2011-12-16', '14:17:47', 'The user logged in', 1),
('2011-12-16', '14:17:55', 'The user logged out', 1),
('2011-12-16', '14:18:00', 'The user logged in', 1),
('2011-12-16', '14:18:04', 'The user logged out', 1),
('2011-12-16', '14:18:59', 'The user logged in', 1),
('2011-12-16', '14:19:24', 'The user logged out', 1),
('2011-12-16', '14:21:39', 'The user logged in', 1),
('2011-12-16', '14:21:44', 'The user logged out', 1),
('2011-12-16', '14:40:03', 'The user logged in', 1),
('2011-12-16', '14:40:11', 'The user logged out', 1),
('2011-12-16', '14:41:00', 'Contact record restored.', 15),
('2011-12-16', '14:41:22', 'The user logged in', 17),
('2011-12-16', '14:43:02', 'The user logged out', 17),
('2011-12-16', '14:44:31', 'The user logged in', 1),
('2011-12-16', '14:44:37', 'The user logged out', 1),
('2011-12-16', '14:45:35', 'The user logged in', 1),
('2011-12-16', '14:46:32', 'The user logged out', 1),
('2011-12-16', '14:46:40', 'The user logged in', 1),
('2011-12-16', '14:46:46', 'The user logged out', 1),
('2011-12-16', '14:47:02', 'The user logged in', 1),
('2011-12-16', '14:47:13', 'The user logged out', 1),
('2011-12-16', '14:52:13', 'The user logged in', 1),
('2011-12-16', '14:52:19', 'The user logged out', 1),
('2011-12-16', '14:52:36', 'The user logged in', 1),
('2011-12-16', '14:52:48', 'The user logged out', 1),
('2011-12-16', '14:58:38', 'The user logged in', 1),
('2011-12-16', '14:58:50', 'The user logged out', 1),
('2011-12-16', '15:05:25', 'The user logged in', 16),
('2011-12-16', '15:05:33', 'The user logged out', 16),
('2011-12-16', '15:07:23', 'The user logged in', 17),
('2011-12-16', '16:43:14', 'The user logged out', 17),
('2011-12-16', '16:43:29', 'The user logged in', 17),
('2011-12-19', '09:57:29', 'The user logged in', 16),
('2011-12-19', '10:00:02', 'The user logged out', 16),
('2011-12-19', '10:00:07', 'The user logged in', 16),
('2011-12-19', '10:00:12', 'The user logged out', 16),
('2011-12-19', '10:01:41', 'The user logged in', 27),
('2011-12-19', '11:06:10', 'Withdrawal record created.', 27),
('2011-12-19', '11:23:13', 'Withdrawal record WITH-2011-000031 updated.', 27),
('2011-12-19', '11:23:35', 'Withdrawal record WITH-2011-000031 updated.', 27),
('2011-12-19', '11:30:57', 'Item receiving record created.', 27),
('2011-12-19', '11:37:56', 'Item receiving record REC-2011-000022 updated.', 27),
('2011-12-19', '11:52:31', 'Item receiving record created.', 27),
('2011-12-19', '12:01:40', 'Item CE-D-000082 adjusted.', 27),
('2011-12-19', '12:35:09', 'Item adjustment ADJ-2011-000050 updated.', 27),
('2011-12-19', '12:38:30', 'Item CE-D-000082 adjustedby 5.', 27),
('2011-12-19', '12:50:50', 'Product record created.', 27),
('2011-12-19', '13:05:26', 'Product record CE-M-000104 updated.', 27),
('2011-12-19', '13:06:18', 'Asset record AS-2011-000072 updated.', 27),
('2011-12-19', '13:18:53', 'Product record CE-M-000104 deleted.', 27),
('2011-12-19', '13:19:27', 'Asset record AS-2011-000072 deleted.', 27),
('2011-12-19', '13:21:26', 'Product record CE-M-000104 restored.', 27),
('2011-12-19', '13:21:44', 'Asset record AS-2011-000072 restored.', 27),
('2011-12-19', '13:33:56', 'Product CE-M-000104 transferred to asset.', 27),
('2011-12-19', '13:34:42', 'Asset record CE-M-000104 transferred to product.', 27),
('2011-12-19', '14:05:22', 'The user logged in', 1),
('2011-12-19', '14:23:04', 'Maintenance Reminder for asset AS-2011-000078 created.', 27),
('2011-12-19', '14:26:35', 'The user logged in', 14),
('2011-12-19', '14:29:41', 'Maintenance reminder for asset AS-2011-000078 updated.', 27),
('2011-12-19', '14:30:56', 'Maintenance reminder for asset AS-2011-000078 deleted.', 27),
('2011-12-19', '14:32:02', 'Maintenance reminder for asset AS-2011-000078 restored.', 27),
('2011-12-19', '14:42:57', 'Maintenance history record for asset AS-2011-000078 created.', 27),
('2011-12-19', '14:44:25', 'Maintenance history record for asset AS-2011-000078 updated.', 27),
('2011-12-19', '14:45:26', 'Maintenance history record for asset AS-2011-000078 deleted.', 27),
('2011-12-19', '14:46:20', 'Maintenance history record for asset AS-2011-000078 restored.', 27),
('2011-12-19', '15:02:19', 'The user logged out', 1),
('2011-12-19', '15:09:30', 'Order slip record created.', 27),
('2011-12-19', '15:09:42', 'Payment for order slip OS-2011-000012 created.', 27),
('2011-12-19', '15:10:36', 'Order slip record created.', 27),
('2011-12-19', '15:11:12', 'Order slip record created.', 27),
('2011-12-19', '15:11:16', 'Payment for order slip OS-2011-000014 created.', 27),
('2011-12-19', '15:27:37', 'Order slip record OS-2011-000013 deleted.', 27),
('2011-12-19', '15:29:17', 'Order slip record OS-2011-000013 restored.', 27),
('2011-12-19', '15:40:31', 'Order slip record OS-2011-000014 imported to DR.', 27),
('2011-12-19', '16:01:04', 'Delivery receipt DR-2011-000002 updated.', 27),
('2011-12-19', '16:03:15', 'Delivery receipt DR-2011-000002 deleted.', 27),
('2011-12-19', '16:03:52', 'Delivery receipt DR-2011-000002 restored.', 27),
('2011-12-19', '16:04:41', 'Delivery receipt DR-2011-000002 deleted.', 27),
('2011-12-19', '16:04:45', 'Delivery receipt DR-2011-000002 restored.', 27),
('2011-12-19', '16:20:32', 'Purchase request record created.', 27),
('2011-12-19', '16:56:35', 'Purchase request record PR-2011-000025 updated.', 27),
('2011-12-19', '17:00:54', 'Purchase request record  updated.', 27),
('2011-12-19', '17:02:30', 'Purchase request record  deleted.', 27),
('2011-12-19', '17:04:29', 'Purchase request record  deleted.', 27),
('2011-12-19', '17:04:30', 'Purchase request record  deleted.', 27),
('2011-12-19', '17:05:42', 'Purchase request record  deleted.', 27),
('2011-12-19', '17:10:14', 'Purchase request record PR-2011-000025 deleted.', 27),
('2011-12-19', '17:11:02', 'Purchase request record PR-2011-000025 restored.', 27),
('2011-12-19', '17:11:30', 'Purchase request record PR-2011-000025 updated.', 27),
('2011-12-19', '17:15:50', 'Purchase request record PR-2011-000025 approved.', 27),
('2011-12-19', '17:34:44', 'The user logged in', 27),
('2011-12-20', '10:42:07', 'The user logged in', 15),
('2011-12-20', '11:57:03', 'The user logged in', 27),
('2011-12-20', '12:14:08', 'Purchase order record created.', 27),
('2011-12-20', '12:24:18', 'Purchase request record created.', 27),
('2011-12-20', '12:24:41', 'Purchase request record PR-2011-000026 approved.', 27),
('2011-12-20', '12:40:18', 'Purchase order record created.', 27),
('2011-12-20', '12:44:44', 'Purchase request record created.', 27),
('2011-12-20', '12:44:56', 'Purchase request record PR-2011-000027 updated.', 27),
('2011-12-20', '12:45:06', 'Purchase request record PR-2011-000027 approved.', 27),
('2011-12-20', '13:30:19', 'Purchase request record created.', 27),
('2011-12-20', '13:30:25', 'Purchase request record PR-2011-000028 approved.', 27),
('2011-12-20', '13:43:36', 'The user logged out', 27),
('2011-12-20', '13:50:06', 'The user logged in', 27),
('2011-12-20', '13:53:36', 'Purchase order record created.', 27),
('2011-12-20', '14:09:18', 'Purchase order record PO-2011-000020 updated.', 27),
('2011-12-20', '14:09:41', 'Purchase order record PO-2011-000020 updated.', 27),
('2011-12-20', '14:11:26', 'Purchase order record PO-2011-000020 deleted.', 27),
('2011-12-20', '14:11:57', 'Purchase order record PO-2011-000020 restored.', 27),
('2011-12-20', '14:19:12', 'Supplier Record created.', 27),
('2011-12-20', '14:22:50', 'Supplier record  updated.', 27),
('2011-12-20', '14:27:08', 'Supplier record  updated.', 27),
('2011-12-20', '14:27:52', 'Supplier record  updated.', 27),
('2011-12-20', '14:28:28', 'Supplier record SP-000010 updated.', 27),
('2011-12-20', '14:30:52', 'Supplier record SP-000010 deleted.', 27),
('2011-12-20', '14:30:56', 'Supplier record SP-000010 restored.', 27),
('2011-12-20', '14:30:57', 'Supplier record SP-000010 restored.', 27),
('2011-12-20', '14:31:12', 'Supplier record SP-000010 deleted.', 27),
('2011-12-20', '14:31:24', 'Supplier record SP-000010 restored.', 27),
('2011-12-20', '14:49:07', 'Educational background created.', 27),
('2011-12-20', '14:49:07', 'Work history detail created.', 27),
('2011-12-20', '14:49:07', 'Employee record updated.', 27),
('2011-12-20', '14:49:07', 'Employee record created.', 27),
('2011-12-20', '14:49:07', 'Personnel record created.', 27),
('2011-12-20', '14:51:40', 'Employee record deleted.', 27),
('2011-12-20', '14:52:04', 'Employee record restored.', 27),
('2011-12-20', '15:08:56', 'Employee record deleted.', 15),
('2011-12-20', '15:15:43', 'Employee record restored.', 27),
('2011-12-20', '15:17:40', 'Employee schedule for EMP-2011HR-000038 created.', 27),
('2011-12-20', '15:41:57', 'Employee schedule for EMP-2011HR-000038 updated.', 27),
('2011-12-20', '15:47:01', 'Employee schedule for EMP-2011HR-000038 updated.', 27),
('2011-12-20', '16:07:30', 'Employee schedule for EMP-2011HR-000038 created.', 27),
('2011-12-20', '16:15:28', 'Employee schedule for EMP-2011HR-000038 created.', 27),
('2011-12-20', '16:16:11', 'Employee schedule for EMP-2011HR-000038 deleted.', 27),
('2011-12-20', '16:31:24', 'Multiple employee schedule for EMP-2011HR-000038 updated.', 27),
('2011-12-20', '16:33:42', 'Employee time in', 27),
('2011-12-20', '16:33:55', 'Employee time out', 27),
('2011-12-20', '16:35:24', 'Employee time in', 38),
('2011-12-20', '16:36:38', 'Employee time out', 38),
('2011-12-21', '09:42:50', 'The user logged in', 1),
('2011-12-21', '12:13:33', 'The user logged in', 27),
('2011-12-21', '12:24:31', 'The user logged in', 1),
('2011-12-21', '12:29:02', 'The user logged out', 1),
('2011-12-21', '12:29:31', 'Employee time in', 27),
('2011-12-21', '12:30:43', 'The user logged in', 1),
('2011-12-21', '12:30:48', 'The user logged out', 1),
('2011-12-21', '12:30:59', 'The user logged in', 1),
('2011-12-21', '12:36:07', 'The user logged out', 1),
('2011-12-21', '12:36:14', 'The user logged in', 1),
('2011-12-21', '12:36:20', 'The user logged out', 1),
('2011-12-21', '12:37:20', 'Payroll record for EMP-2011HR-000038 created.', 27),
('2011-12-21', '12:37:23', 'The user logged in', 1),
('2011-12-21', '12:40:00', 'The user logged out', 1),
('2011-12-21', '12:40:07', 'The user logged in', 1),
('2011-12-21', '13:08:00', 'Payroll record for EMP-2011HR-000038 updated.', 27),
('2011-12-21', '13:15:26', 'Payroll record for EMP-2011HR-000038 deleted.', 27),
('2011-12-21', '13:17:25', 'Payroll record for EMP-2011HR-000038 restored.', 27),
('2011-12-21', '13:30:40', 'Cash advance record for EMP-2011HR-000038 created.', 27),
('2011-12-21', '13:37:17', 'Cash advance record for EMP-2011FD-000027 updated.', 27),
('2011-12-21', '13:48:06', 'Cash advance record for EMP-2011HR-000038 deleted.', 27),
('2011-12-21', '13:50:15', 'Cash advance record for EMP-2011HR-000038 restored.', 27);

-- --------------------------------------------------------

--
-- Table structure for table `balance_sheet_settings`
--

CREATE TABLE IF NOT EXISTS `balance_sheet_settings` (
  `ACCOUNT_SUB_CATEGORY_ID` int(11) DEFAULT '0',
  `BAL_TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `BANK_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANK_NAME` varchar(150) DEFAULT NULL,
  `BANK_ADDRESS` varchar(200) DEFAULT NULL,
  `BANK_PHONE_NO` varchar(100) DEFAULT NULL,
  `BANK_FAX_NO` varchar(100) DEFAULT NULL,
  `BANK_WEBSITE` varchar(100) DEFAULT NULL,
  `BANK_EMAIL_ADDRESS` varchar(100) DEFAULT NULL,
  `BANK_CONTACT_PERSON` varchar(150) DEFAULT NULL,
  `BANK_CONTACT_POSITION` varchar(100) DEFAULT NULL,
  `BANK_CONTACT_DEPARTMENT` varchar(100) DEFAULT NULL,
  `BANK_CONTACT_PHONE_NO` varchar(100) DEFAULT NULL,
  `BANK_CONTACT_MOBILE_NO` varchar(100) DEFAULT NULL,
  `BANK_CONTACT_EMAIL_ADDRESS` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`BANK_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`BANK_ID`, `BANK_NAME`, `BANK_ADDRESS`, `BANK_PHONE_NO`, `BANK_FAX_NO`, `BANK_WEBSITE`, `BANK_EMAIL_ADDRESS`, `BANK_CONTACT_PERSON`, `BANK_CONTACT_POSITION`, `BANK_CONTACT_DEPARTMENT`, `BANK_CONTACT_PHONE_NO`, `BANK_CONTACT_MOBILE_NO`, `BANK_CONTACT_EMAIL_ADDRESS`, `IS_DELETED`) VALUES
(1, 'LandBank', 'Pasong Tamo, Makati City', '567-23-23', '+44-208-1234567', 'www.landbank.com.ph', 'landbank@yahoo.com.ph', 'Watson Land', 'Consultant', 'HR', '892-43-00', '09157011485', 'watson@yahoo.com', 0),
(2, 'Banco Filipino', 'Ayala, Makati City', '324-43-00', '+33-108-1224369', 'www.bancofilipino.com.ph', 'bancofilipino@yahoo.com.ph', 'Kyoseko Himoto', 'Consultant', 'HR', '800-33-20', '09237011687', 'himoto101@yahoo.com', 0),
(3, 'Bank of the Philippines Island', 'Paco, Manila City', '889-00-23', '+64-333-1488867', 'www.bpi.com.ph', 'bpi@yahoo.com.ph', 'Maylene Bulante', 'Consultant', 'HR', '834-63-65', '09190011483', 'm.bulante@yahoo.com', 0),
(4, 'Asia Development Bank', 'Ortigas, Makati City', '963-32-08', '+40-318-1436567', 'www.adb.com.ph', 'adb@yahoo.com.ph', 'John Valeros', 'Consultant', 'HR', '878-73-50', '09157011467', 'joh_valeros@yahoo.com', 0),
(5, 'Bank of Commerce', 'Pasong Tamo, Mandaluyong City', '850-56-99', '+10-700-0000567', 'www.commercebank.com.ph', 'commercebank@yahoo.com.ph', 'Luzviminda Banag', 'Consultant', 'HR', '892-43-00', '0915471880', 'bannag@yahoo.com', 0),
(6, 'Banco De Oro', 'Guadalupe, Makati City', '434-76-00', '+80-740-1230123', 'www.bdo.com.ph', 'bdo@yahoo.com.ph', 'Aiko Baygan', 'Consultant', 'HR', '872-43-99', '09157895954', 'baygan103@yahoo.com', 0),
(7, 'Robinsons Bank Corporation', 'Lawton, Manila City', '801-43-22', '+42-408-6294567', 'www.rbc.com.ph', 'rbc@yahoo.com.ph', 'Gelica Ramos', 'Consultant', 'HR', '802-83-20', '09157011000', 'gelica_ramos@yahoo.com', 0),
(8, 'China Bank', 'Kalentong, Mandaluyong City', '553-74-86', '+23-687-4523567', 'www.chinabank.com.ph', 'chinabank@yahoo.com.ph', 'Yael Bunao', 'Consultant', 'HR', '880-67-27', '09895011812', 'y_b@yahoo.com', 0),
(9, 'Export Bank', 'Sinto, Pasay City', '532-86-33', '+88-248-2236567', 'www.exportbank.com.ph', 'exportbank@yahoo.com.ph', 'Herald Sy', 'Consultant', 'HR', '843-43-43', '09157332008', 'sy_herald124@yahoo.com', 0),
(10, 'East West Banking Corporation', 'San Roque, Paranaque City', '342-74-21', '+12-000-0534587', 'www.eastwestbank.com.ph', 'eastwestbank@yahoo.com.ph', 'Benigno Sotto', 'Consultant', 'HR', '834-00-00', '09156821485', 'benignosotto@yahoo.com', 0),
(11, 'SSI', 'Manila', '843948394839', '3984394838', 'www.ssibank.com.ph', 'ssi@ssibank.com.ph', 'Ricky Benitez', 'Delivery Boy', 'Utility', '09834344', '908343434', 'ricky@yahoo.com', 0),
(12, 'Galaxy Bank', 'Pasay', '038434839', '9834983948', 'www.galaxybank.com.ph', 'galaxybank@yahoo.com', 'Janine Sales', 'Accountant', 'Accounting', '0849034839', '98394344', 'janine@yahoo.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE IF NOT EXISTS `bank_account` (
  `BANK_ACCOUNT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANK_ACCOUNT_NO` varchar(20) DEFAULT NULL,
  `BANK_ACCOUNT_NAME` varchar(200) DEFAULT NULL,
  `BANK_ACCOUNT_TYPE` varchar(100) DEFAULT NULL,
  `BANK_ACCOUNT_TEL_NO` varchar(100) DEFAULT NULL,
  `BANK_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`BANK_ACCOUNT_ID`),
  KEY `BANK_ID` (`BANK_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`BANK_ACCOUNT_ID`, `BANK_ACCOUNT_NO`, `BANK_ACCOUNT_NAME`, `BANK_ACCOUNT_TYPE`, `BANK_ACCOUNT_TEL_NO`, `BANK_ID`) VALUES
(1, '15989-325465', '1st Account', 'Current', '1', 2),
(2, '222222222222', '2', 'Savings', NULL, 2),
(3, '333333333333', 'TEST', 'Current', NULL, 2),
(4, '44444444444', 'TEST4', 'Savings', NULL, 1),
(5, '098-340-4342-34', 'Sigma Account', 'Current', NULL, 11),
(6, '098-331-4342-34', 'SIS account', 'Current', NULL, 11),
(7, '078-811-4342-34', 'Suntrust', 'Current', NULL, 11),
(9, '0094-09349-93434', 'Bulante', 'Current', NULL, 10),
(10, '3498-03493430-43', 'Lenovo Account', 'Savings', NULL, 12);

-- --------------------------------------------------------

--
-- Table structure for table `bank_deposit_detail`
--

CREATE TABLE IF NOT EXISTS `bank_deposit_detail` (
  `BANK_DEPOSIT_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANK_DEPOSIT_DTL_REF_NO` varchar(20) DEFAULT NULL,
  `BANK_DEPOSIT_DTL_REF_TYPE` varchar(25) DEFAULT NULL,
  `BANK_DEPOSIT_DTL_AMOUNT` double(15,3) DEFAULT '0.000',
  `BANK_DEPOSIT_HDR_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`BANK_DEPOSIT_DTL_ID`),
  KEY `BANK_DEPOSIT_HDR_ID` (`BANK_DEPOSIT_HDR_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `bank_deposit_detail`
--

INSERT INTO `bank_deposit_detail` (`BANK_DEPOSIT_DTL_ID`, `BANK_DEPOSIT_DTL_REF_NO`, `BANK_DEPOSIT_DTL_REF_TYPE`, `BANK_DEPOSIT_DTL_AMOUNT`, `BANK_DEPOSIT_HDR_ID`) VALUES
(4, '34-8437972-1', 'Cheque', 3.000, 4),
(5, '34-87493794-0', 'Cheque', 50000.000, 5),
(6, 'OE-2011-000002', 'Owners Equity', 500.000, 12),
(7, 'OE-2011-000003', 'Owners Equity', 90000.000, 13),
(8, 'OE-2011-000004', 'Owners Equity', 66.000, 14),
(9, 'OE-2011-000005', 'Owners Equity', 9044.000, 15),
(10, 'OE-2011-000006', 'Owners Equity', 15.000, 16),
(11, 'OE-2011-000007', 'Owners Equity', 1.000, 17),
(12, 'OE-2011-000009', 'Owners Equity', 7.000, 18),
(13, 'OE-2011-000013', 'Owners Equity', 11.000, 19),
(14, 'OE-2011-000014', 'Owners Equity', 4000.000, 20),
(15, '23-437429-1', 'Cheque', 468.000, 21),
(16, '34-5847547-5', 'Cheque', 450.000, 22),
(17, '34-893498327-1', 'Cheque', 5000.000, 23),
(18, '34-893498327-1', 'Cheque', 5000.000, 24),
(19, '34-893498327-1', 'Cheque', 5000.000, 26),
(20, '34-9843794732-2', 'Cheque', 50000.000, 27),
(21, '34-894739872-111', 'Cheque', 25000.000, 28),
(22, '12-43498798-00', 'Cheque', 20000.000, 29),
(23, '34-3489498321-29', 'Cheque', 5000.000, 30),
(24, '29292929292929', 'Cheque', 10000.000, 31),
(27, '1111111111-11', 'Cheque', 3000.000, 34),
(28, '34-90382-1', 'Cheque', 2000.000, 35),
(29, 'DEP-2011-000038', 'Cash On Hand', 1000.000, 38),
(30, 'DEP-2011-000039', 'Cash On Hand', 50000.000, 39),
(31, '34-9479823798-1', 'Cheque', 15000.000, 40),
(32, '34-894739879-1', 'Cheque', 500.000, 41),
(33, '34-98778-1', 'Cheque', 323.000, 42),
(34, '125-328974', 'Cheque', 257.000, 43),
(35, 'DEP-2011-000044', 'Cash On Hand', 15000000.000, 44),
(36, 'OE-2011-000020', 'Owners Equity', 100.000, 45),
(37, 'q2312312', 'Cheque', 1257.000, 46),
(38, '12354', 'Cheque', 51685.000, 47),
(39, '4324531', 'Cheque', 1234.000, 48),
(40, '5495-5656-56', 'Cheque', 11515243.000, 49),
(41, '123456789', 'Cheque', 1234.000, 50),
(42, 'DEP-2011-000051', 'Cash On Hand', 500.000, 51),
(43, '83782738728', 'Cheque', 20000.000, 52);

-- --------------------------------------------------------

--
-- Table structure for table `bank_deposit_header`
--

CREATE TABLE IF NOT EXISTS `bank_deposit_header` (
  `BANK_DEPOSIT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANK_DEPOSIT_NO` varchar(20) DEFAULT NULL,
  `BANK_DEPOSIT_AMOUNT` double(15,3) DEFAULT '0.000',
  `REF_HDR_TYPE` varchar(20) DEFAULT NULL,
  `BANK_DEPOSIT_HDR_REMARKS` text,
  `BANK_ACCOUNT_ID` int(11) DEFAULT '0',
  `BANK_DEPOSIT_BY_ID` int(11) DEFAULT '0',
  `BANK_ID` int(11) DEFAULT '0',
  `BANK_DEPOSIT_DATE` date NOT NULL,
  PRIMARY KEY (`BANK_DEPOSIT_ID`),
  KEY `BANK_ACCOUNT_ID` (`BANK_ACCOUNT_ID`),
  KEY `BANK_DEPOSIT_BY_ID` (`BANK_DEPOSIT_BY_ID`),
  KEY `BANK_ID` (`BANK_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `bank_deposit_header`
--

INSERT INTO `bank_deposit_header` (`BANK_DEPOSIT_ID`, `BANK_DEPOSIT_NO`, `BANK_DEPOSIT_AMOUNT`, `REF_HDR_TYPE`, `BANK_DEPOSIT_HDR_REMARKS`, `BANK_ACCOUNT_ID`, `BANK_DEPOSIT_BY_ID`, `BANK_ID`, `BANK_DEPOSIT_DATE`) VALUES
(4, 'DEP-2011-000001', 3.000, 'Cheque', NULL, 4, 1, 2, '2011-11-22'),
(5, 'DEP-2011-000005', 50000.000, 'Cheque', NULL, 4, 1, 2, '2011-11-24'),
(12, 'DEP-2011-000006', 500.000, 'Owners Equity', 'Bank', 4, 1, 1, '2011-11-24'),
(13, 'DEP-2011-000013', 90000.000, 'Owners Equity', '', 4, 1, 1, '2011-11-24'),
(14, 'DEP-2011-000014', 66.000, 'Owners Equity', '66', 4, 1, 1, '2011-11-24'),
(15, 'DEP-2011-000015', 9044.000, 'Owners Equity', 'Trip', 1, 1, 2, '2011-11-24'),
(16, 'DEP-2011-000016', 15.000, 'Owners Equity', '15', 4, 1, 1, '2011-11-24'),
(17, 'DEP-2011-000017', 1.000, 'Owners Equity', '1', 4, 1, 1, '2011-11-24'),
(18, 'DEP-2011-000018', 7.000, 'Owners Equity', '7', 4, 1, 1, '2011-11-24'),
(19, 'DEP-2011-000019', 11.000, 'Owners Equity', '11', 4, 1, 1, '2011-11-24'),
(20, 'DEP-2011-000020', 4000.000, 'Owners Equity', 'Trip lang magsago', 4, 1, 1, '2011-11-24'),
(21, 'DEP-2011-000021', 468.000, 'Cheque', NULL, 1, 1, 2, '2011-11-24'),
(22, 'DEP-2011-000022', 450.000, 'Cheque', NULL, 3, 1, 2, '2011-11-24'),
(23, 'DEP-2011-000023', 5000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-28'),
(24, 'DEP-2011-000024', 5000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-28'),
(25, 'DEP-2011-000025', 5000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-28'),
(26, 'DEP-2011-000026', 5000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-28'),
(27, 'DEP-2011-000027', 50000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-29'),
(28, 'DEP-2011-000028', 25000.000, 'Cheque', NULL, 1, 1, 2, '2011-11-29'),
(29, 'DEP-2011-000029', 20000.000, 'Cheque', NULL, 3, 1, 2, '2011-11-29'),
(30, 'DEP-2011-000030', 5000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-29'),
(31, 'DEP-2011-000031', 10000.000, 'Cheque', NULL, 1, 1, 2, '2011-11-29'),
(34, 'DEP-2011-000032', 3000.000, 'Cheque', NULL, 4, 1, 1, '2011-11-29'),
(35, 'DEP-2011-000035', 2000.000, 'Cheque', NULL, 9, 1, 10, '2011-12-01'),
(38, 'DEP-2011-000038', 1000.000, 'Cash On Hand', '', 5, 16, 11, '2011-12-03'),
(39, 'DEP-2011-000039', 50000.000, 'Cash On Hand', '', 9, 1, 10, '2011-12-02'),
(40, 'DEP-2011-000040', 15000.000, 'Cheque', NULL, 9, 1, 10, '2011-12-02'),
(41, 'DEP-2011-000041', 500.000, 'Cheque', NULL, 9, 1, 10, '2011-12-02'),
(42, 'DEP-2011-000042', 323.000, 'Cheque', NULL, 9, 1, 10, '2011-12-02'),
(43, 'DEP-2011-000043', 257.000, 'Cheque', NULL, 9, 1, 10, '2011-12-02'),
(44, 'DEP-2011-000044', 15000000.000, 'Cash On Hand', '', 9, 1, 10, '2011-12-15'),
(45, 'DEP-2011-000045', 100.000, 'Owners Equity', 'asdf', 4, 1, 1, '2011-12-06'),
(46, 'DEP-2011-000046', 1257.000, 'Cheque', NULL, 9, 17, 10, '2011-12-06'),
(47, 'DEP-2011-000047', 51685.000, 'Cheque', NULL, 9, 17, 10, '2011-12-06'),
(48, 'DEP-2011-000048', 1234.000, 'Cheque', NULL, 9, 17, 10, '2011-12-06'),
(49, 'DEP-2011-000049', 11515243.000, 'Cheque', NULL, 9, 17, 10, '2011-12-06'),
(50, 'DEP-2011-000050', 1234.000, 'Cheque', NULL, 9, 1, 10, '2011-12-07'),
(51, 'DEP-2011-000051', 500.000, 'Cash On Hand', 'HHH', 9, 26, 10, '2011-12-13'),
(52, 'DEP-2011-000052', 20000.000, 'Cheque', NULL, 2, 17, 2, '2011-12-12');

-- --------------------------------------------------------

--
-- Table structure for table `bank_withdrawal`
--

CREATE TABLE IF NOT EXISTS `bank_withdrawal` (
  `BANK_WITH_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANK_WITH_NO` varchar(100) DEFAULT NULL,
  `BANK_WITH_AMOUNT` double(15,3) DEFAULT '0.000',
  `BANK_WITH_DATE` date DEFAULT NULL,
  `BANK_WITH_REMARKS` text,
  `BANK_ID` int(11) DEFAULT '0',
  `BANK_ACCOUNT_ID` int(11) DEFAULT '0',
  `BANK_WITH_WITHDRAWN_BY_ID` int(11) DEFAULT '0',
  `BANK_WITH_REF_TYPE` varchar(100) NOT NULL,
  `BANK_WITH_REF_NO` varchar(100) NOT NULL,
  PRIMARY KEY (`BANK_WITH_ID`),
  KEY `BANK_ID` (`BANK_ID`),
  KEY `BANK_ACCOUNT_ID` (`BANK_ACCOUNT_ID`),
  KEY `BANK_WITH_WITHDRAWN_BY_ID` (`BANK_WITH_WITHDRAWN_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `bank_withdrawal`
--

INSERT INTO `bank_withdrawal` (`BANK_WITH_ID`, `BANK_WITH_NO`, `BANK_WITH_AMOUNT`, `BANK_WITH_DATE`, `BANK_WITH_REMARKS`, `BANK_ID`, `BANK_ACCOUNT_ID`, `BANK_WITH_WITHDRAWN_BY_ID`, `BANK_WITH_REF_TYPE`, `BANK_WITH_REF_NO`) VALUES
(1, 'WITH-2011-000001', 10000.000, '2011-12-01', NULL, 1, 4, 1, '', ''),
(2, 'WITH-2011-000002', 50000.000, '2011-12-01', '', 11, 5, 2, '', ''),
(3, 'BANK-WITH-2011-000003', 6.000, '2011-12-02', '', 11, 6, 1, '', ''),
(4, 'BANK-WITH-2011-000004', 32431.000, '2011-12-02', NULL, 11, 6, 1, 'Cheque', '33333333'),
(5, 'BANK-WITH-2011-000005', 50001.000, '2011-12-02', NULL, 12, 10, 1, 'Cheque', '0000000000'),
(6, 'BANK-WITH-2011-000006', 10000.000, '2011-12-02', NULL, 2, 1, 1, 'Cheque', '111111111'),
(7, 'BANK-WITH-2011-000007', 550.000, '2011-12-02', NULL, 10, 9, 1, 'Cheque', '123-456789'),
(8, 'BANK-WITH-2011-000008', 5.000, '2011-12-02', NULL, 10, 9, 1, 'Cheque', '37218973'),
(9, 'BANK-WITH-2011-000009', 1500000.000, '2011-12-02', NULL, 10, 9, 1, 'Cheque', '505050505050'),
(10, 'BANK-WITH-2011-000010', 1000.000, '2011-12-06', NULL, 1, 4, 17, 'Cheque', '1000'),
(11, 'BANK-WITH-2011-000011', 100.000, '2011-12-06', NULL, 10, 9, 17, 'Cheque', '202020220'),
(12, 'BANK-WITH-2011-000012', 714.000, '2011-12-06', NULL, 10, 9, 17, 'Cheque', '4732908748329742'),
(13, 'BANK-WITH-2011-000013', 10.000, '2011-12-06', NULL, 10, 9, 1, 'Cheque', '0909090909090'),
(14, 'BANK-WITH-2011-000014', 50500.000, '2011-12-06', NULL, 2, 1, 1, 'Cheque', '123456-5465'),
(15, 'BANK-WITH-2011-000015', 700.000, '2011-12-06', NULL, 10, 9, 1, 'Cheque', '76575645356'),
(16, 'BANK-WITH-2011-000016', 123.000, '2011-12-06', NULL, 10, 9, 1, 'Cheque', '76576463234'),
(17, 'BANK-WITH-2011-000017', 1877.000, '2011-12-06', NULL, 10, 9, 17, 'Cheque', '4867486456'),
(18, 'BANK-WITH-2011-000018', 500.000, '2011-12-06', NULL, 10, 9, 17, 'Cheque', '65484984'),
(19, 'BANK-WITH-2011-000019', 500.000, '2011-12-06', NULL, 10, 9, 17, 'Cheque', '65484984'),
(20, 'BANK-WITH-2011-000020', 300.000, '2011-12-07', NULL, 10, 9, 1, 'Cheque', '456456456'),
(21, 'BANK-WITH-2011-000021', 500.000, '2011-12-07', 'HHH', 10, 9, 26, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `barangay`
--

CREATE TABLE IF NOT EXISTS `barangay` (
  `BARANGAY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BARANGAY_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `CITY_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`BARANGAY_ID`),
  KEY `CITY_ID` (`CITY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `barangay`
--

INSERT INTO `barangay` (`BARANGAY_ID`, `BARANGAY_NAME`, `IS_DELETED`, `CITY_ID`) VALUES
(1, 'Brgy. Pio del Pilar', 0, 1),
(2, 'Brgy. Tejeros', 0, 2),
(3, 'Brgy. Pinagbuhatan', 0, 3),
(4, 'Brgy. Pinagkaisahan', 0, 4),
(5, 'Brgy. Asuncion', 0, 5),
(6, 'Brgy. Payatas', 0, 6),
(7, 'Brgy. Bangkal', 0, 7),
(8, 'Brgy. New Era', 0, 8),
(9, 'Brgy. Rosales', 0, 9),
(10, 'Brgy. Tales', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `BRAND_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BRAND_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `CATEGORY_ID` int(11) DEFAULT '0',
  `SUB_CATEGORY_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`BRAND_ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`),
  KEY `SUB_CATEGORY_ID` (`SUB_CATEGORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`BRAND_ID`, `BRAND_NAME`, `IS_DELETED`, `CATEGORY_ID`, `SUB_CATEGORY_ID`) VALUES
(1, 'LG', 0, 3, 1),
(2, 'Skill Craft', 0, 2, 2),
(3, 'Faber Castell', 0, 2, 3),
(4, 'Pilot', 0, 2, 3),
(5, 'Lotus', 0, 2, 3),
(6, 'HBW', 0, 2, 3),
(7, 'Best Buy', 0, 2, 2),
(8, 'Acer', 0, 3, 4),
(9, 'A4tech', 0, 3, 6),
(10, 'Acer', 0, 3, 6),
(11, 'Canon', 0, 3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `button`
--

CREATE TABLE IF NOT EXISTS `button` (
  `BUTTON_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BUTTON_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`BUTTON_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `button`
--

INSERT INTO `button` (`BUTTON_ID`, `BUTTON_NAME`, `IS_DELETED`) VALUES
(1, 'Save', 0),
(2, 'Edit', 0),
(3, 'Delete', 0),
(4, 'Approve', 0),
(5, 'Disapprove', 0),
(6, 'Post', 0),
(7, 'Clear', 0),
(8, 'Cancel', 0),
(9, 'Restore', 0),
(10, 'Print', 0),
(11, 'Import', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cash_flow`
--

CREATE TABLE IF NOT EXISTS `cash_flow` (
  `CASH_F_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CASH_F_YEAR` int(11) DEFAULT '0',
  `CASH_F_JAN` double(15,3) DEFAULT '0.000',
  `CASH_F_FEB` double(15,3) DEFAULT '0.000',
  `CASH_F_MAR` double(15,3) DEFAULT '0.000',
  `CASH_F_APR` double(15,3) DEFAULT '0.000',
  `CASH_F_MAY` double(15,3) DEFAULT '0.000',
  `CASH_F_JUN` double(15,3) DEFAULT '0.000',
  `CASH_F_JUL` double(15,3) DEFAULT '0.000',
  `CASH_F_AUG` double(15,3) DEFAULT '0.000',
  `CASH_F_SEP` double(15,3) DEFAULT '0.000',
  `CASH_F_OCT` double(15,3) DEFAULT '0.000',
  `CASH_F_NOV` double(15,3) DEFAULT '0.000',
  `CASH_F_DEC` double(15,3) DEFAULT '0.000',
  `CASH_F_VALUES` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CASH_F_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cash_flow_settings`
--

CREATE TABLE IF NOT EXISTS `cash_flow_settings` (
  `ACCOUNT_SUB_CATEGORY_ID` int(11) DEFAULT '0',
  `FLOW_TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_on_hand`
--

CREATE TABLE IF NOT EXISTS `cash_on_hand` (
  `CASH_ON_HAND_AMOUNT` double(15,3) DEFAULT '0.000'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_on_hand`
--

INSERT INTO `cash_on_hand` (`CASH_ON_HAND_AMOUNT`) VALUES
(366853.000);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATEGORY_CODE` varchar(10) NOT NULL,
  `CATEGORY_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`CATEGORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CATEGORY_ID`, `CATEGORY_CODE`, `CATEGORY_NAME`, `IS_DELETED`) VALUES
(1, 'OE', 'Office Equipment', 0),
(2, 'OSupp', 'Office Supplies', 0),
(3, 'CompEq', 'Computer Equipment', 0),
(4, 'CompSupp', 'Computer Supplies', 0),
(5, 'Mot', 'Motorpool', 0),
(6, 'Misc', 'Miscellanous', 0),
(7, 'Auto', 'Automobile', 0),
(8, 'LOG', 'Logistics', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category_sub_category`
--

CREATE TABLE IF NOT EXISTS `category_sub_category` (
  `SUB_CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `SUB_CATEGORY_CODE` varchar(10) NOT NULL,
  `SUB_CATEGORY_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `CATEGORY_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`SUB_CATEGORY_ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `category_sub_category`
--

INSERT INTO `category_sub_category` (`SUB_CATEGORY_ID`, `SUB_CATEGORY_CODE`, `SUB_CATEGORY_NAME`, `IS_DELETED`, `CATEGORY_ID`) VALUES
(1, 'M', 'Monitor', 0, 3),
(2, 'BP', 'Bond Paper', 0, 2),
(3, 'B', 'Ballpen', 0, 2),
(4, 'Dsk', 'Desktop', 0, 3),
(5, 'Char', 'Chairs', 0, 1),
(6, 'Kbd', 'Keyboard', 0, 3),
(7, 'Pr', 'Printer', 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `character_references`
--

CREATE TABLE IF NOT EXISTS `character_references` (
  `CHAR_REF_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CHAR_REF_PERSON_NAME` varchar(100) DEFAULT NULL,
  `CHAR_REF_CONTACT_NO` varchar(100) DEFAULT NULL,
  `CHAR_REF_POSITION` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `WORK_EXP_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`CHAR_REF_ID`),
  KEY `WORK_EXP_ID` (`WORK_EXP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `check_profile`
--

CREATE TABLE IF NOT EXISTS `check_profile` (
  `CHECK_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CHECK_NO` varchar(20) DEFAULT NULL,
  `CHECK_DUE_DATE` date DEFAULT NULL,
  `CHECK_DATE_ISSUED` date DEFAULT NULL,
  `CHECK_AMOUNT` double(15,3) DEFAULT '0.000',
  `CHECK_TYPE` varchar(20) DEFAULT NULL,
  `CHECK_ACCOUNT_NO` varchar(20) DEFAULT NULL,
  `CHECK_ACCOUNT_NAME` varchar(150) DEFAULT NULL,
  `CHECK_REMARKS` text,
  `CHECK_REF_HDR_TYPE` varchar(20) DEFAULT NULL,
  `CHECK_REF_NO` varchar(20) DEFAULT NULL,
  `CHECK_DATE_POSTED` date DEFAULT NULL,
  `IS_POSTED` tinyint(1) DEFAULT '0',
  `IS_CLEARED` tinyint(1) NOT NULL DEFAULT '0',
  `BANK_ID` int(11) DEFAULT '0',
  `CUSTOMER_ID` int(11) NOT NULL,
  `FLAG` varchar(5) DEFAULT NULL,
  `CREATED_BY_ID` int(11) DEFAULT '0',
  `CHECK_REF_HDR_NO` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CHECK_ID`),
  KEY `BANK_ID` (`BANK_ID`),
  KEY `CREATED_BY_ID` (`CREATED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `check_profile`
--

INSERT INTO `check_profile` (`CHECK_ID`, `CHECK_NO`, `CHECK_DUE_DATE`, `CHECK_DATE_ISSUED`, `CHECK_AMOUNT`, `CHECK_TYPE`, `CHECK_ACCOUNT_NO`, `CHECK_ACCOUNT_NAME`, `CHECK_REMARKS`, `CHECK_REF_HDR_TYPE`, `CHECK_REF_NO`, `CHECK_DATE_POSTED`, `IS_POSTED`, `IS_CLEARED`, `BANK_ID`, `CUSTOMER_ID`, `FLAG`, `CREATED_BY_ID`, `CHECK_REF_HDR_NO`) VALUES
(4, '45-3273279-9', '2011-11-25', '2011-11-16', 10000.000, 'Post-Dated', '1', 'Cezar Pedraza', NULL, 'AP', 'AP-00001', NULL, 0, 1, 1, 2, NULL, 1, NULL),
(16, '34-8437972-1', '2011-11-25', '2011-11-22', 3.000, 'On-Dated', '1', '1st Account', NULL, 'OS', 'OS-070111-0021101', NULL, 1, 0, 1, 4, NULL, 1, 'PN-2011-000035'),
(17, '23-437429-1', '2011-11-30', '2011-11-25', 468.000, 'On-Dated', '222222222222', '2', NULL, 'OS', 'OS-121211-0012120', NULL, 1, 0, 2, 2, NULL, 1, 'PN-2011-000036'),
(18, '34-5847547-5', '2011-11-25', '2011-11-18', 450.000, 'Post-Dated', '15989-325465', '1st Account', NULL, 'OS', 'OS-062111-0000014', NULL, 1, 0, 2, 4, NULL, 1, 'PN-2011-000037'),
(19, '34-87493794-0', '2011-11-30', '2011-11-25', 50000.000, 'Post-Dated', '15989-325465', '1st Account', NULL, 'OS', 'OS-081211-0000012', NULL, 1, 0, 2, 5, NULL, 1, 'PN-2011-000044'),
(20, '34-893498327-1', '2011-11-30', '2011-11-28', 5000.000, 'On-Dated', '44444444444', 'TEST4', NULL, 'OS', 'OS-022111-1230825', '2011-11-28', 1, 0, 1, 2, NULL, 1, 'PN-2011-000046'),
(24, '34-9843794732-2', '2011-11-30', '2011-11-18', 50000.000, 'Post-Dated', '222222222222', '2', NULL, 'OS', 'OS-022111-1230825', '2011-11-29', 1, 0, 2, 2, 'C', 1, 'PN-2011-000048'),
(25, '34-894739872-111', '2011-11-30', '2011-11-24', 25000.000, 'Post-Dated', '44444444444', 'TEST4', NULL, 'OS', 'OS-022111-1230825', '2011-11-29', 1, 0, 1, 2, 'C', 1, 'PN-2011-000051'),
(26, '12-43498798-00', '2011-11-30', '2011-11-23', 20000.000, 'On-Dated', '44444444444', 'TEST4', NULL, 'OS', 'OS-062111-0000014', '2011-11-29', 1, 0, 1, 4, 'C', 1, 'PN-2011-000052'),
(27, '34-3489498321-29', '2011-11-30', '2011-11-23', 5000.000, 'On-Dated', '44444444444', 'TEST4', NULL, 'OS', 'OS-022111-1230825', '2011-11-29', 1, 0, 1, 2, 'C', 1, 'PN-2011-000053'),
(28, '29292929292929', '2011-11-30', '2011-11-23', 10000.000, 'On-Dated', '44444444444', 'TEST4', NULL, 'OS', 'OS-062111-0000014', '2011-11-29', 1, 0, 1, 4, 'C', 1, 'PN-2011-000054'),
(29, '1111111111-11', '2011-11-30', '2011-11-30', 3000.000, 'On-Dated', '44444444444', 'TEST4', NULL, 'OS', 'OS-022111-1230825', '2011-11-29', 1, 0, 1, 2, 'C', 1, 'PN-2011-000055'),
(32, '34-90382-1', '2011-12-30', '2011-12-15', 2000.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-022111-1230825', '2011-12-01', 1, 0, 10, 2, 'C', 1, 'PN-2011-000057'),
(35, '123-456789', '2011-12-14', '2011-12-29', 550.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'Expense', 'EXP-2011-000024', NULL, 0, 1, 10, 0, 'B', 16, 'PN-2011-000060'),
(36, '0000000000', '2011-12-24', '2011-12-23', 50001.000, 'Post-Dated', '3498-03493430-43', 'Lenovo Account', NULL, 'CA', 'VCH-2011-000008', NULL, 0, 1, 12, 1, 'E', 1, NULL),
(37, '111111111', '2011-12-19', '2011-12-03', 10000.000, 'Post-Dated', '15989-325465', '1st Account', NULL, 'CA', 'VCH-2011-000009', NULL, 0, 1, 2, 16, 'E', 1, NULL),
(38, '33333333', '2011-12-15', '2011-12-14', 32431.000, 'Post-Dated', '098-331-4342-34', 'SIS account', NULL, 'CA', 'VCH-2011-000010', NULL, 0, 1, 11, 1, 'E', 1, NULL),
(39, '123456-5465', '2011-12-02', '2011-12-01', 50500.000, 'On-Dated', '15989-325465', '1st Account', NULL, 'Expense', 'EXP-2011-000025', NULL, 0, 1, 2, 0, 'B', 2, 'PN-2011-000062'),
(40, '34-9479823798-1', '2011-12-23', '2011-12-02', 15000.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-022111-1230825', '2011-12-02', 1, 0, 10, 2, 'C', 1, 'PN-2011-000083'),
(42, '37218973', '2011-12-08', '2011-12-03', 5.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000027', NULL, 0, 1, 10, 0, 'B', 1, 'PN-2011-000089'),
(43, '34-98778-1', '2011-12-30', '2011-12-02', 323.000, 'Post-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-2011-000130', '2011-12-02', 1, 0, 10, 2, 'C', 1, 'PN-2011-000090'),
(44, '0909090909090', '2011-12-06', '2011-12-05', 10.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000027', NULL, 0, 1, 10, 0, 'B', 1, 'PN-2011-000091'),
(45, '202020220', '2011-12-07', '2011-12-06', 100.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000028', NULL, 0, 1, 10, 0, 'B', 1, 'PN-2011-000093'),
(46, '125-328974', '2011-12-23', '2011-12-02', 257.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-2011-000133', '2011-12-02', 1, 0, 10, 9, 'C', 1, 'PN-2011-000094'),
(47, '546547688-0', '2011-12-23', '2011-12-02', 500.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-2011-000133', '2011-12-06', 1, 0, 10, 9, 'C', 1, 'PN-2011-000095'),
(48, '505050505050', '2011-12-09', '2011-12-07', 1500000.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000039', NULL, 0, 1, 10, 0, 'B', 1, 'PN-2011-000097'),
(49, 'q2312312', '2011-12-22', '2011-12-19', 1257.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', '', '2011-12-06', 1, 0, 10, 3, 'C', 1, 'PN-2011-000101'),
(52, '1000', '2011-12-29', '2011-12-08', 1000.000, 'On-Dated', '44444444444', 'TEST4', NULL, 'Expense', 'EXP-2011-000044', NULL, 0, 1, 1, 0, 'B', 1, 'PN-2011-000106'),
(53, '12354', '2011-12-31', '2011-12-16', 51685.000, 'Post-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-2011-000002', '2011-12-06', 1, 0, 10, 3, 'C', 17, 'PN-2011-000008'),
(54, '4732908748329742', '2011-12-09', '2011-12-07', 714.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000053', NULL, 0, 1, 10, 0, 'B', 14, 'PN-2011-000009'),
(56, '76575645356', '2011-12-23', '2011-12-08', 700.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000054', NULL, 0, 1, 10, 0, 'B', 1, 'PN-2011-000016'),
(57, '76576463234', '2011-12-31', '2011-12-22', 123.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000054', NULL, 0, 1, 10, 0, 'B', 1, 'PN-2011-000019'),
(58, '4867486456', '2011-12-16', '2011-12-01', 1877.000, 'Post-Dated', '0094-09349-93434', 'Bulante', NULL, 'AP', 'AP-2011-000054', NULL, 0, 1, 10, 0, 'B', 17, 'PN-2011-000020'),
(59, '4324531', '2011-12-20', '2011-12-01', 1234.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-2011-000014', '2011-12-06', 1, 0, 10, 1, 'C', 17, 'PN-2011-000023'),
(60, '5495-5656-56', '2011-12-06', '2011-12-06', 11515243.000, 'On-Dated', '0094-09349-93434', 'Bulante', NULL, 'OS', 'OS-2011-000016', '2011-12-06', 1, 0, 10, 1, 'C', 1, 'PN-2011-000031');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `CITY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CITY_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`CITY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`CITY_ID`, `CITY_NAME`, `IS_DELETED`) VALUES
(1, 'Makati City', 0),
(2, 'Manila City', 0),
(3, 'Quezon City', 0),
(4, 'Mandaluyong City', 0),
(5, 'Pasay City', 0),
(6, 'Parañaque City', 0),
(7, 'Malabon City', 0),
(8, 'Pasig City', 0),
(9, 'Taguig City', 0),
(10, 'San Juan City', 0);

-- --------------------------------------------------------

--
-- Table structure for table `company_information`
--

CREATE TABLE IF NOT EXISTS `company_information` (
  `COMPANY_NAME` varchar(100) DEFAULT NULL,
  `COMPANY_ADDRESS` text,
  `COMPANY_PHONE_NO` varchar(100) DEFAULT NULL,
  `COMPANY_MOBILE_NO` varchar(100) DEFAULT NULL,
  `COMPANY_FAX_NO` varchar(100) DEFAULT NULL,
  `COMPANY_EMAIL_ADDRESS` varchar(100) DEFAULT NULL,
  `COMPANY_WEBSITE` varchar(100) DEFAULT NULL,
  `COMPANY_LOGO` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_information`
--

INSERT INTO `company_information` (`COMPANY_NAME`, `COMPANY_ADDRESS`, `COMPANY_PHONE_NO`, `COMPANY_MOBILE_NO`, `COMPANY_FAX_NO`, `COMPANY_EMAIL_ADDRESS`, `COMPANY_WEBSITE`, `COMPANY_LOGO`) VALUES
('SMESoft Incorporated', '2nd st, Fabie Subdivision Paco, Manila', '5452485', '09123456789', '45454r5', 'smesoft@yahoo.com', 'http://smesoft.com.ph', 'ebms-logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `CONTACT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONTACT_NAME` varchar(100) DEFAULT NULL,
  `CONTACT_DEPARTMENT` varchar(100) DEFAULT NULL,
  `CONTACT_JOB_TITLE` varchar(100) DEFAULT NULL,
  `CONTACT_EMAIL_ADDRESS` varchar(150) DEFAULT NULL,
  `CONTACT_PHONE_NO` varchar(100) DEFAULT NULL,
  `CONTACT_MOBILE_NO` varchar(100) DEFAULT NULL,
  `CONTACT_FAX_NO` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `LOCATION_ID` int(11) DEFAULT '0',
  `POSITION_ID` int(11) DEFAULT NULL,
  `DEPARTMENT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`CONTACT_ID`),
  KEY `LOCATION_ID` (`LOCATION_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`CONTACT_ID`, `CONTACT_NAME`, `CONTACT_DEPARTMENT`, `CONTACT_JOB_TITLE`, `CONTACT_EMAIL_ADDRESS`, `CONTACT_PHONE_NO`, `CONTACT_MOBILE_NO`, `CONTACT_FAX_NO`, `IS_DELETED`, `LOCATION_ID`, `POSITION_ID`, `DEPARTMENT_ID`) VALUES
(1, 'Maileen Reyes', 'Marketing Department', 'Reception', 'maileen.contact@yahoo.com', '09137011354', '802-13-42', '10213123-1212', 0, 1, 1, 1),
(2, 'Cristofer Bunao', 'Finance Department', 'Finance Manager', 'cristofer.contact@yahoo.com', '09943611354', '794-13-42', '13513123-1212', 0, 4, 2, 2),
(3, 'Maricar Dulano', 'Sales Department', 'Sales Head', 'maricar.contact@yahoo.com', '09139051332', '812-13-46', '10215293-9912', 1, 6, 3, 1),
(4, 'Anita Santos', 'Admission Department', 'Staff', 'anita.contact@yahoo.com', '09157011366', '802-13-12', '23013123-1112', 0, 3, 1, 2),
(5, 'Jet Pangan', 'Registration Department', 'Registration Personnel', 'jet.contact@yahoo.com', '09401011000', '435-41-45', '50113123-3042', 0, 2, 2, 2),
(6, 'Janine', 'IT Department', 'Programmer', '', '', '09175462214', '', 0, 9, 18, 6),
(11, 'Supplier', 'Finance Department', 'Sales Manager', 'asgdasugd@yeyhoo.com', '123456789', '3423423', '123456789', 0, 19, 2, 2),
(12, 'Supplier Man', 'Project Department', 'Asset Custodian', 'huhuhu@yahoo.com', '089089', '45645', '12342343', 0, 20, 5, 5),
(13, 'Juan', 'IT Department', 'Project Manager', 'r@yahoo.com', '', '', '', NULL, 10, 8, 6),
(14, 'Janine Sales', 'Executive Department', 'IT Consultant/Specialist', 'janine@yahoo.com', '', '', '', 0, 11, 1, 1),
(15, 'Ayiee', '', 'Owner/Executive', 'naj@yahoo.com', '', '', '', 0, 23, 1, 1),
(16, 'Hohoho', '', 'Owner/Executive', 'naj@yahoo.com', '', '', '', NULL, 23, 1, 1),
(17, 'salamin', 'Executive Department', 'Owner/Executive', 'jfjsdakj', '( 12)-313-2123123', '( 12)3123121321', '', 0, 24, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `control_no`
--

CREATE TABLE IF NOT EXISTS `control_no` (
  `CONTROL_DOC_TYPE` varchar(20) DEFAULT NULL,
  `CONTROL_DOC_COUNTER` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `control_no`
--

INSERT INTO `control_no` (`CONTROL_DOC_TYPE`, `CONTROL_DOC_COUNTER`) VALUES
('PR', 1001),
('PR', 1002),
('OS', 1001),
('OS', 1002),
('EMP', 1001),
('EMP', 1002);

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE IF NOT EXISTS `currency` (
  `CUR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CUR_NAME` text NOT NULL,
  `CUR_SYMBOL` text NOT NULL,
  `IS_DELETED` tinyint(4) NOT NULL DEFAULT '0',
  `IS_FLAG` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CUR_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`CUR_ID`, `CUR_NAME`, `CUR_SYMBOL`, `IS_DELETED`, `IS_FLAG`) VALUES
(1, 'Pesos', 'Php', 0, 0),
(2, 'Dollar', '$', 0, 1),
(3, 'Yen', '¥', 0, 0),
(4, 'Euro', '€', 0, 0),
(5, 'Pound', '£', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_profile`
--

CREATE TABLE IF NOT EXISTS `customer_profile` (
  `CUSTOMER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CUSTOMER_CODE` varchar(20) DEFAULT NULL,
  `CUSTOMER_NAME` varchar(150) DEFAULT NULL,
  `CUSTOMER_EMAIL_ADDRESS` varchar(150) DEFAULT NULL,
  `CUSTOMER_PHONE_NO` varchar(100) DEFAULT NULL,
  `CUSTOMER_MOBILE_NO` varchar(100) DEFAULT NULL,
  `CUSTOMER_FAX_NO` varchar(100) DEFAULT NULL,
  `CUSTOMER_REMARKS` text,
  `IS_ACTIVE` tinyint(1) DEFAULT '1',
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `CUSTOMER_TYPE_ID` int(11) DEFAULT '0',
  `INDUSTRY_TYPE_ID` int(11) DEFAULT '0',
  `DATE_CREATED` date NOT NULL,
  PRIMARY KEY (`CUSTOMER_ID`),
  KEY `CUSTOMER_TYPE_ID` (`CUSTOMER_TYPE_ID`),
  KEY `INDUSTRY_TYPE_ID` (`INDUSTRY_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `customer_profile`
--

INSERT INTO `customer_profile` (`CUSTOMER_ID`, `CUSTOMER_CODE`, `CUSTOMER_NAME`, `CUSTOMER_EMAIL_ADDRESS`, `CUSTOMER_PHONE_NO`, `CUSTOMER_MOBILE_NO`, `CUSTOMER_FAX_NO`, `CUSTOMER_REMARKS`, `IS_ACTIVE`, `IS_DELETED`, `CUSTOMER_TYPE_ID`, `INDUSTRY_TYPE_ID`, `DATE_CREATED`) VALUES
(1, '20110209-00001', 'Jerald Facundo', 'jerald_facun@yahoo.com', '09175011343', '890-23-53', ' 44-208-1234567', 'none', 1, 0, 1, 0, '2002-01-06'),
(2, '20111202-00002', 'Jason Sanje', 'jayson_sanje@yahoo.com', '09154361343', '813-97-00', '+44-208-1234567', '', 1, 0, 2, 2, '2001-12-19'),
(3, '20110215-00003', 'Jansen Mangabat', 'jansen_mangabat@yahoo.com', '09136011653', '821-32-57', '44-208-1234567', 'none', 1, 0, 3, 2, '2001-01-09'),
(4, '20110412-00004', 'Carl Carreon', 'carl_carreon@yahoo.com', '09172011000', '816-21-41', '+44-208-1234567', 'none', 1, 0, 2, 1, '2002-01-17'),
(5, '20110610-00005', 'Clint Cabunilas', 'clint_cabunilas@yahoo.com', '09123015653', '814-43-03', '+44-208-1234567', 'none', 1, 0, 2, 2, '2002-01-06'),
(6, '20110323-00006', 'Ricky Benitez', 'ricky_benitez@yahoo.com', '09175017676', '864-03-68', ' 44-208-1234567', 'none', 1, 0, 2, 0, '2001-10-17'),
(7, '20110101-00007', 'Henry Jandayan II', 'henry_jandayan@yahoo.com', '09154000763', '890-23-03', '44-208-1234567', 'none', 1, 0, 3, 2, '2002-01-14'),
(8, '20110612-00008', 'Janine Grace Sales', 'janine_sales@yahoo.com', '09146711343', '895-53-09', '44-208-1234567', 'none', 1, 0, 1, 0, '2001-12-22'),
(9, '20110220-00009', 'Happy Muñoz', 'happy_muñoz@yahoo.com', '09175061001', '860-83-74', ' 44-208-1234567', 'none', 1, 0, 1, 0, '2002-01-02'),
(10, '20110724-00010', 'Rosejelynn Bulante', 'jelaii@yahoo.com', '09178611755', '898-24-00', '44-208-1234567', '', 1, 0, 1, 0, '2001-04-01'),
(11, 'CUS-2011-000011', 'SMESoft Inc.', 'inquire@smesoft.com.ph', '', '', '', '', 1, 0, 3, 2, '2011-11-10'),
(12, 'CUS-2011-000012', 'Faith Printer Rental', 'faith@yahoo.com', '', '4124364', '', '', 1, 0, 3, 3, '2011-11-10'),
(13, 'CUS-2011-000013', 'McDonald''s', '', '', '', '', '', 1, 0, 2, 1, '2011-11-11'),
(14, 'CUS-2011-000014', 'Se7en Inc.', 'seveninc@gmail.com', '', '', '', '', 1, 0, 3, 2, '2011-11-18'),
(15, 'CUS-2011-000015', 'Ricky', 'ricky.benitez@smesoft.com.ph', '', '', '', '', 1, 0, 1, 0, '2011-11-28'),
(16, 'CUS-2011-000016', 'Sun Cellular', 'suncellular@yahoo.com', '', '09222354321', '', '', 1, 0, 3, 2, '2011-12-06'),
(17, 'CUS-2011-000017', 'Jet Bulante', '', '9849384', '098430984', '03943094', '', 1, 0, 1, 1, '2011-12-06'),
(18, 'CUS-2011-000018', 'Sherwin Gutay', '', '', '', '', '', 1, 0, 2, 2, '2011-12-06'),
(19, 'CUS-2011-000019', 'Analyn Ordonez', '', '', '( 63)9269238891', '', '', 1, 0, 3, 2, '2011-12-06'),
(20, 'CUS-2011-000020', 'Catherine', '', '', '', '', '', 0, 0, 3, 2, '2011-12-06'),
(21, 'CUS-2011-000021', 'CRP New', '', '', '', '', '', 1, 1, 1, 0, '2011-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `customer_type`
--

CREATE TABLE IF NOT EXISTS `customer_type` (
  `CUSTOMER_TYPE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CUSTOMER_TYPE_CODE` varchar(10) NOT NULL,
  `CUSTOMER_TYPE_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`CUSTOMER_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customer_type`
--

INSERT INTO `customer_type` (`CUSTOMER_TYPE_ID`, `CUSTOMER_TYPE_CODE`, `CUSTOMER_TYPE_NAME`, `IS_DELETED`) VALUES
(1, 'WKN', 'Walk-In', 0),
(2, 'RSD', 'Residential', 0),
(3, 'OFC', 'Office', 0);

-- --------------------------------------------------------

--
-- Table structure for table `deduction`
--

CREATE TABLE IF NOT EXISTS `deduction` (
  `DEDUCTION_NO` int(11) NOT NULL AUTO_INCREMENT,
  `DEDUCTION_NAME` varchar(100) NOT NULL,
  `DEDUCTION_DESC` varchar(100) NOT NULL,
  `IS_DELETED` int(11) NOT NULL DEFAULT '0',
  `IS_FLAG` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`DEDUCTION_NO`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `deduction`
--

INSERT INTO `deduction` (`DEDUCTION_NO`, `DEDUCTION_NAME`, `DEDUCTION_DESC`, `IS_DELETED`, `IS_FLAG`) VALUES
(1, 'SSS', 'Health Benefits', 0, 1),
(2, 'PAG-IBIG', 'Housing Benefits', 0, 1),
(3, 'PhilHealth', 'Health Benefits', 0, 1),
(4, 'Caritas', 'Loan Benefits', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `DEPT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `DEPT_CODE` varchar(10) NOT NULL,
  `DEPT_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`DEPT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DEPT_ID`, `DEPT_CODE`, `DEPT_NAME`, `IS_DELETED`) VALUES
(1, 'EXD', 'Executive Department', 0),
(2, 'FD', 'Finance Department', 0),
(3, 'ACCT', 'Accounting Department', 0),
(4, 'SUP', 'Supplies Department', 0),
(5, 'PD', 'Project Department', 0),
(6, 'IT', 'IT Department', 0),
(7, 'SD', 'Sales Department', 0),
(8, 'HR', 'Human Resource Department', 0),
(9, 'MKT', 'Marketing Department', 0),
(10, 'MD', 'Manufacturing Department', 0),
(11, 'RD', 'Research and Development Department', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dr_detail`
--

CREATE TABLE IF NOT EXISTS `dr_detail` (
  `DR_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `DR_DTL_QTY` int(11) DEFAULT '0',
  `DR_DTL_ITEM_DESCRIPTION` text,
  `DR_HDR_ID` varchar(20) DEFAULT '0',
  `ITEM_ID` varchar(20) DEFAULT '0',
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`DR_DTL_ID`),
  KEY `DR_HDR_ID` (`DR_HDR_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `dr_detail`
--

INSERT INTO `dr_detail` (`DR_DTL_ID`, `DR_DTL_QTY`, `DR_DTL_ITEM_DESCRIPTION`, `DR_HDR_ID`, `ITEM_ID`, `ITEM_FLAG`) VALUES
(1, 1, ' Size: Letter, GSM: .9', 'DR-2011-000004', 'CE-K-000004', NULL),
(2, 1, ' General Description: QWERTY keyboard', 'DR-2011-000004', 'CE-K-000005', NULL),
(3, 1, ' Size: Letter, GSM: .9', 'DR-2011-000001', 'CE-K-000004', NULL),
(4, 1, ' General Description: QWERTY keyboard', 'DR-2011-000001', 'CE-K-000005', NULL),
(5, 3, ' General Description: qwert', 'DR-2011-000002', 'CE-K-000080', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dr_header`
--

CREATE TABLE IF NOT EXISTS `dr_header` (
  `DR_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `DR_HDR_NO` varchar(20) DEFAULT NULL,
  `DR_HDR_DATE` date DEFAULT NULL,
  `DR_HDR_REF_NO` varchar(20) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `CUSTOMER_ID` int(11) DEFAULT '0',
  `DR_HDR_BILL_TO_ID` int(11) DEFAULT '0',
  `DR_HDR_SHIP_TO_ID` int(11) DEFAULT '0',
  `AREA_ID` int(11) NOT NULL,
  `DR_HDR_SHIP_CONTACT_ID` int(11) DEFAULT '0',
  `DR_HDR_DELIVERED_BY_ID` int(11) DEFAULT '0',
  `DR_HDR_CREATED_BY_ID` int(11) DEFAULT '0',
  `DR_HDR_GROSS_AMOUNT` double(15,3) NOT NULL,
  `DR_HDR_NET_AMOUNT` double NOT NULL,
  `DR_HDR_DISCOUNT_PERCENT` double NOT NULL,
  `DR_HDR_REMARKS` text NOT NULL,
  PRIMARY KEY (`DR_HDR_ID`),
  KEY `CUSTOMER_ID` (`CUSTOMER_ID`),
  KEY `DR_HDR_BILL_TO_ID` (`DR_HDR_BILL_TO_ID`),
  KEY `DR_HDR_SHIP_TO_ID` (`DR_HDR_SHIP_TO_ID`),
  KEY `DR_HDR_SHIP_CONTACT_ID` (`DR_HDR_SHIP_CONTACT_ID`),
  KEY `DR_HDR_DELIVERED_BY_ID` (`DR_HDR_DELIVERED_BY_ID`),
  KEY `DR_HDR_CREATED_BY_ID` (`DR_HDR_CREATED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `dr_header`
--

INSERT INTO `dr_header` (`DR_HDR_ID`, `DR_HDR_NO`, `DR_HDR_DATE`, `DR_HDR_REF_NO`, `IS_DELETED`, `CUSTOMER_ID`, `DR_HDR_BILL_TO_ID`, `DR_HDR_SHIP_TO_ID`, `AREA_ID`, `DR_HDR_SHIP_CONTACT_ID`, `DR_HDR_DELIVERED_BY_ID`, `DR_HDR_CREATED_BY_ID`, `DR_HDR_GROSS_AMOUNT`, `DR_HDR_NET_AMOUNT`, `DR_HDR_DISCOUNT_PERCENT`, `DR_HDR_REMARKS`) VALUES
(1, 'DR-2011-000001', '2011-12-07', 'OS-2011-000001', 0, 2, 2, 2, 7, 5, 14, 26, 700.000, 700, 0, ''),
(2, 'DR-2011-000002', '2011-12-19', 'OS-2011-000014', 0, 2, 2, 2, 10, 5, 1, 27, 1500.000, 1500, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `earning`
--

CREATE TABLE IF NOT EXISTS `earning` (
  `EARNING_NO` int(11) NOT NULL AUTO_INCREMENT,
  `EARNING_NAME` varchar(100) NOT NULL,
  `EARNING_DESC` varchar(100) NOT NULL,
  `IS_DELETED` int(11) NOT NULL DEFAULT '0',
  `IS_FLAG` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`EARNING_NO`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `earning`
--

INSERT INTO `earning` (`EARNING_NO`, `EARNING_NAME`, `EARNING_DESC`, `IS_DELETED`, `IS_FLAG`) VALUES
(1, 'Transpo Allowance', 'For additional transportation fee', 0, 1),
(2, 'Special Holiday', 'A working holiday', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `educational_background`
--

CREATE TABLE IF NOT EXISTS `educational_background` (
  `EDUC_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EDUC_SCHOOL_NAME` varchar(100) DEFAULT NULL,
  `EDUC_YEAR_GRADUATED` int(4) DEFAULT NULL,
  `EDUC_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `EMP_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`EDUC_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `educational_background`
--

INSERT INTO `educational_background` (`EDUC_ID`, `EDUC_SCHOOL_NAME`, `EDUC_YEAR_GRADUATED`, `EDUC_REMARKS`, `IS_DELETED`, `EMP_ID`) VALUES
(39, 'dfdfdf', 3434, 'fdfdf', 0, 36),
(40, 'asdf', 34234, '', 0, 37),
(41, 'Jan lang', 1974, '', 0, 38);

-- --------------------------------------------------------

--
-- Table structure for table `employee_cash_advance`
--

CREATE TABLE IF NOT EXISTS `employee_cash_advance` (
  `EMP_CASH_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_CASH_CODE` varchar(20) DEFAULT NULL,
  `EMP_CASH_DATE` date DEFAULT NULL,
  `EMP_CASH_AMOUNT` double(10,2) DEFAULT NULL,
  `EMP_CASH_PAYMENT_TYPE` varchar(10) DEFAULT NULL,
  `EMP_CASH_REMARKS` text,
  `EMP_CASH_STATUS` varchar(20) DEFAULT 'NOT APPROVED',
  `EMP_ID` int(11) DEFAULT NULL,
  `EMP_CASH_APPROVED_BY_ID` int(11) DEFAULT NULL,
  `IS_DELETED` tinyint(4) DEFAULT '0',
  `IS_FLAG` tinyint(4) DEFAULT '0',
  `CHECK_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`EMP_CASH_ID`),
  KEY `EMP_ID` (`EMP_ID`),
  KEY `EMP_CASH_APPROVED_BY_ID` (`EMP_CASH_APPROVED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `employee_cash_advance`
--

INSERT INTO `employee_cash_advance` (`EMP_CASH_ID`, `EMP_CASH_CODE`, `EMP_CASH_DATE`, `EMP_CASH_AMOUNT`, `EMP_CASH_PAYMENT_TYPE`, `EMP_CASH_REMARKS`, `EMP_CASH_STATUS`, `EMP_ID`, `EMP_CASH_APPROVED_BY_ID`, `IS_DELETED`, `IS_FLAG`, `CHECK_ID`) VALUES
(8, 'VCH-2011-000008', '2011-12-02', 50001.00, 'CHECK', 'testing', 'APPROVED', 1, 1, 0, 1, 36),
(9, 'VCH-2011-000009', '2011-12-02', 10000.00, 'CHECK', 'Test CA', 'APPROVED', 16, 1, 0, 0, 37),
(10, 'VCH-2011-000010', '2011-12-02', 32431.00, 'CHECK', 'dsfsdfsd', 'APPROVED', 1, 1, 0, 1, 38),
(11, 'VCH-2011-000011', '2011-12-06', 500.00, 'CASH', 'sdfg', 'APPROVED', 14, 1, 0, 0, NULL),
(12, 'VCH-2011-000012', '2011-12-07', 2700.00, 'CASH', '', 'NOT APPROVED', 27, NULL, 0, 0, NULL),
(13, 'VCH-2011-000013', '2011-12-07', 100.00, 'CASH', 'asdf', 'NOT APPROVED', 2, NULL, 0, 0, NULL),
(14, 'VCH-2011-000014', '2011-12-07', 1600.00, 'CASH', '160', 'NOT APPROVED', 26, NULL, 0, 0, NULL),
(15, 'VCH-2011-000015', '2011-12-21', 27.00, 'CASH', '', 'NOT APPROVED', 38, NULL, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_profile`
--

CREATE TABLE IF NOT EXISTS `employee_profile` (
  `EMP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_CODE` varchar(20) DEFAULT NULL,
  `EMP_FIRST_NAME` varchar(100) DEFAULT NULL,
  `EMP_MIDDLE_NAME` varchar(100) DEFAULT NULL,
  `EMP_LAST_NAME` varchar(100) DEFAULT NULL,
  `EMP_ADDRESS` text,
  `EMP_BIRTH_DATE` date DEFAULT NULL,
  `EMP_GENDER` varchar(6) DEFAULT NULL,
  `EMP_MARITAL_STATUS` varchar(100) DEFAULT NULL,
  `EMP_HOME_PHONE_NO` varchar(100) DEFAULT NULL,
  `EMP_WORK_PHONE_NO` varchar(100) DEFAULT NULL,
  `EMP_DATE_HIRED` date DEFAULT NULL,
  `EMP_SSS_NO` varchar(100) DEFAULT NULL,
  `EMP_TIN_NO` varchar(100) DEFAULT NULL,
  `EMP_PHIL_HEALTH` varchar(100) DEFAULT NULL,
  `EMP_PAG_IBIG` varchar(100) DEFAULT NULL,
  `EMP_SALARY` double(15,3) DEFAULT '0.000',
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `EMP_STATUS_ID` int(11) DEFAULT '0',
  `DEPT_ID` int(11) DEFAULT '0',
  `POSITION_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`EMP_ID`),
  KEY `EMP_STATUS_ID` (`EMP_STATUS_ID`),
  KEY `DEPT_ID` (`DEPT_ID`),
  KEY `JOB_TITLE_ID` (`POSITION_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `employee_profile`
--

INSERT INTO `employee_profile` (`EMP_ID`, `EMP_CODE`, `EMP_FIRST_NAME`, `EMP_MIDDLE_NAME`, `EMP_LAST_NAME`, `EMP_ADDRESS`, `EMP_BIRTH_DATE`, `EMP_GENDER`, `EMP_MARITAL_STATUS`, `EMP_HOME_PHONE_NO`, `EMP_WORK_PHONE_NO`, `EMP_DATE_HIRED`, `EMP_SSS_NO`, `EMP_TIN_NO`, `EMP_PHIL_HEALTH`, `EMP_PAG_IBIG`, `EMP_SALARY`, `IS_DELETED`, `EMP_STATUS_ID`, `DEPT_ID`, `POSITION_ID`) VALUES
(1, 'EMP-10-000001', 'Cezar', 'Romero', 'Pedraza', 'Paco, Manila', '2011-11-25', 'male', 'married', '813-03-00', '532-53-00', '0000-00-00', '34-2612652-3', '33781562284', '06-000074350-3', '34-2612652-3', 50000.000, 0, 1, 6, 8),
(2, 'EMP-11-000002', 'Richard', 'Aquino', 'Peig', 'Ayala, Makati', '0000-00-00', 'male', 'single', '853-20-34', '432-78-99', '0000-00-00', '31-2962742-2', '32185462212', '03-000454370-2', '31-4612632-1', 60000.000, 0, 1, 6, 8),
(14, 'EMP-2011FD-000014', 'Carl Jerive', 'Cañete', 'Carreon', '578 Brgy. San Jose Mandaluyong City', '2011-11-08', 'male', 'single', '094890358', '098908905', '2011-11-08', '780-343-3-4-33', '3-434-4-334-4343', '3434-3434-3-33', '34039-4344-43', 15000.000, 0, 4, 2, 11),
(15, 'EMP-2011EXD-000015', 'Jansen', '', 'Mangabat', 'email', '2011-11-16', 'male', 'single', '09384390', '938490384908', '2011-11-09', '83498', '98', '98', '098', 6000.000, 0, 1, 1, 1),
(16, 'EMP-2011FD-000016', 'Janine Grace', '', 'Sales', 'jan jan lang', '2011-11-01', 'female', 'single', 'asdfasd', 'asdfasdf', '2011-11-09', '33', '33', '33', '33', 5.000, 0, 2, 2, 2),
(17, 'EMP-2011FD-000017', 'Ricky', 'Vicedo', 'Benitez', 'Quezon City', '1992-04-12', 'male', 'single', '092692388991', '09058038456', '2011-07-04', '', '', '', '', 2000.000, 0, 3, 2, 18),
(26, 'EMP-2011FD-000026', 'Henry', 'Pague', 'Jandayan', 'Mandaluyong City', '1991-11-11', 'male', 'single', '21316549', '3535138', '2011-12-07', ' 65 656 653', '35135131', '54351351', '31.513.51', 250000.000, 0, 1, 2, 18),
(27, 'EMP-2011FD-000027', 'Mark Jason', '', 'Sanje', 'Cainta, Rizal', '1992-07-05', 'male', 'single', '6821648', '6821648', '2011-12-08', '', '', '', '', 270000.000, 0, 1, 2, 2),
(36, 'EMP-2011EXD-000036', 'Jerald', 'Aquino', 'Facun', 'odifjdoi', '2011-12-01', 'male', 'single', '8130300', '8130300', '2011-12-01', '', '', '', '', 5656.000, 0, 2, 1, 1),
(37, 'EMP-2011ACCT-000037', 'asdf', '', 'asdf', 'asdf', '2011-12-08', 'male', 'married', 'asdf', 'asdf', '2011-12-09', '2352', '5235', '3523', '23523', 23523523.000, 0, 1, 3, 3),
(38, 'EMP-2011HR-000038', 'Rosejelynn', 'Constantino', 'Bulante', 'Quezon City', '1991-05-27', 'female', 'widowed', '( 12)-313-2123123', '( 45)-645-6456456', '2011-12-21', '', '', '', '', 27000.000, 0, 1, 8, 15);

-- --------------------------------------------------------

--
-- Table structure for table `employee_schedule`
--

CREATE TABLE IF NOT EXISTS `employee_schedule` (
  `EMP_SCH_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_DAYS` varchar(10) DEFAULT NULL,
  `EMP_START_TIME` time DEFAULT NULL,
  `EMP_END_TIME` time DEFAULT NULL,
  `EMP_START_BREAK_TIME` time DEFAULT NULL,
  `EMP_END_BREAK_TIME` time DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `EMP_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`EMP_SCH_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `employee_schedule`
--

INSERT INTO `employee_schedule` (`EMP_SCH_ID`, `EMP_DAYS`, `EMP_START_TIME`, `EMP_END_TIME`, `EMP_START_BREAK_TIME`, `EMP_END_BREAK_TIME`, `IS_DELETED`, `EMP_ID`) VALUES
(1, 'Monday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 1),
(2, 'Tuesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 1),
(3, 'Wednesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 1),
(4, 'Thursday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 1),
(5, 'Friday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 1),
(6, 'Saturday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 1),
(10, 'Monday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 2),
(13, 'Sunday', '09:00:00', '17:00:00', '12:00:00', '14:00:00', 0, 1),
(14, 'Tuesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 2),
(15, 'Wednesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 2),
(16, 'Thursday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 2),
(17, 'Friday', '09:00:00', '17:00:00', '12:00:00', '12:30:00', 0, 2),
(18, 'Monday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(19, 'Tuesday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(20, 'Wednesday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(21, 'Thursday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(22, 'Friday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(23, 'Saturday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(24, 'Sunday', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 14),
(25, 'Monday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(26, 'Tuesday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(27, 'Wednesday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(28, 'Thursday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(29, 'Friday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(30, 'Saturday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(31, 'Sunday', '09:00:00', '17:00:00', '01:18:00', '07:00:00', 0, 15),
(32, 'Monday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 16),
(33, 'Tuesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 16),
(34, 'Wednesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 16),
(35, 'Thursday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 16),
(36, 'Friday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 16),
(37, 'Monday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 17),
(38, 'Tuesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 17),
(39, 'Wednesday', '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 17),
(52, 'Wednesday', '08:00:00', '19:00:00', '12:00:00', '13:00:00', 0, 38),
(53, 'Thursday', '08:00:00', '19:00:00', '12:00:00', '13:00:00', 0, 38),
(54, 'Friday', '08:00:00', '19:00:00', '12:00:00', '13:00:00', 0, 38),
(55, 'Saturday', '08:00:00', '19:00:00', '12:00:00', '13:00:00', 0, 38),
(56, 'Sunday', '08:00:00', '19:00:00', '12:00:00', '13:00:00', 0, 38),
(57, 'Monday', '08:00:00', '18:00:00', '12:00:00', '13:00:00', 0, 38),
(58, 'Tuesday', '08:00:00', '19:00:00', '12:00:00', '13:00:00', 0, 38);

-- --------------------------------------------------------

--
-- Table structure for table `employee_time_sheet_record`
--

CREATE TABLE IF NOT EXISTS `employee_time_sheet_record` (
  `EMP_TIME_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_DATE_IN` date DEFAULT NULL,
  `EMP_TIME_IN` time DEFAULT NULL,
  `EMP_TIME_OUT` time DEFAULT NULL,
  `EMP_TOTAL_HRS_WORKED` int(11) DEFAULT NULL,
  `EMP_TOTAL_MINS_WORKED` int(11) DEFAULT NULL,
  `EMP_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`EMP_TIME_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `employee_time_sheet_record`
--

INSERT INTO `employee_time_sheet_record` (`EMP_TIME_ID`, `EMP_DATE_IN`, `EMP_TIME_IN`, `EMP_TIME_OUT`, `EMP_TOTAL_HRS_WORKED`, `EMP_TOTAL_MINS_WORKED`, `EMP_ID`) VALUES
(1, '2011-07-01', '08:00:00', '10:00:00', 16, 130, 1),
(2, '2011-07-01', '08:00:00', '12:00:00', 18, 140, 2),
(3, '2011-09-02', '09:32:28', '10:32:28', 1, 60, 1),
(4, '2011-09-16', '18:29:36', '18:29:42', 0, 0, 1),
(5, '2011-09-30', '15:19:20', '16:19:20', 1, 60, 1),
(6, '2011-11-21', '14:58:39', '16:43:46', 2, 105, 1),
(8, '2011-12-02', '15:09:31', '20:09:31', 5, 300, 1),
(19, '2011-12-06', '14:53:18', '14:53:39', 0, 0, 1),
(20, '2011-12-06', '16:57:56', '16:58:03', 0, 0, 17),
(21, '2011-12-08', '11:00:19', '22:00:19', 8, 480, 14),
(22, '2011-12-20', '16:33:42', '16:33:55', 0, 0, 27),
(23, '2011-12-20', '16:35:24', '16:40:38', 0, 5, 38),
(24, '2011-12-21', '12:29:31', NULL, NULL, NULL, 27);

-- --------------------------------------------------------

--
-- Table structure for table `emp_status`
--

CREATE TABLE IF NOT EXISTS `emp_status` (
  `EMP_STATUS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_STATUS_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`EMP_STATUS_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `emp_status`
--

INSERT INTO `emp_status` (`EMP_STATUS_ID`, `EMP_STATUS_NAME`, `IS_DELETED`) VALUES
(1, 'Regular', 0),
(2, 'Contractual', 0),
(3, 'Probitionary', 0),
(4, 'Relief', 0);

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE IF NOT EXISTS `form` (
  `FORM_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FORM_NAME` varchar(100) DEFAULT NULL,
  `FORM_SET` tinyint(1) DEFAULT '0',
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`FORM_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`FORM_ID`, `FORM_NAME`, `FORM_SET`, `IS_DELETED`) VALUES
(1, 'Company Information Manager Form', 1, 0),
(2, 'Employee Form', 1, 0),
(3, 'Customer Profile Form', 1, 0),
(4, 'Order Slip Records Form', 1, 0),
(5, 'Delivery Receipt Form', 1, 0),
(6, 'Purchase Request Form', 1, 0),
(7, 'Purchase Order Form', 1, 0),
(8, 'Supplier Form', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_button`
--

CREATE TABLE IF NOT EXISTS `form_button` (
  `FORM_ID` int(11) NOT NULL,
  `BUTTON_ID` int(11) NOT NULL,
  UNIQUE KEY `UNIQUE_ID` (`FORM_ID`,`BUTTON_ID`),
  KEY `FORM_ID` (`FORM_ID`),
  KEY `BUTTON_ID` (`BUTTON_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_button`
--

INSERT INTO `form_button` (`FORM_ID`, `BUTTON_ID`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(2, 3),
(2, 9),
(2, 10),
(3, 1),
(3, 2),
(3, 3),
(3, 9),
(3, 10),
(4, 1),
(4, 3),
(4, 9),
(4, 10),
(4, 11),
(5, 2),
(5, 3),
(5, 9),
(5, 10),
(6, 1),
(6, 2),
(6, 3),
(6, 9),
(6, 10);

-- --------------------------------------------------------

--
-- Table structure for table `general_ledger`
--

CREATE TABLE IF NOT EXISTS `general_ledger` (
  `GL_DATE` date DEFAULT NULL,
  `GL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `GL_REF_NO` varchar(100) DEFAULT NULL,
  `GL_AMOUNT` double(15,3) DEFAULT '0.000',
  `ACCOUNT_CATEGORY_ID` int(11) DEFAULT '0',
  `ACCOUNT_SUB_CATEGORY_ID` int(11) DEFAULT '0',
  `TYPE` varchar(10) DEFAULT NULL,
  `GL_SOURCE_DOC` varchar(150) DEFAULT NULL,
  `ACCOUNT_TYPE_ID` int(11) DEFAULT '0',
  `GL_DELETED` int(11) DEFAULT '0',
  PRIMARY KEY (`GL_ID`),
  KEY `ACCOUNT_CATEGORY_ID` (`ACCOUNT_CATEGORY_ID`),
  KEY `ACCOUNT_SUB_CATEGORY_ID` (`ACCOUNT_SUB_CATEGORY_ID`),
  KEY `ACCOUNT_TYPE_ID` (`ACCOUNT_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `general_ledger`
--

INSERT INTO `general_ledger` (`GL_DATE`, `GL_ID`, `GL_REF_NO`, `GL_AMOUNT`, `ACCOUNT_CATEGORY_ID`, `ACCOUNT_SUB_CATEGORY_ID`, `TYPE`, `GL_SOURCE_DOC`, `ACCOUNT_TYPE_ID`, `GL_DELETED`) VALUES
('2011-12-19', 1, 'OS-2011-000012', 1000.000, 1, 2, 'OS', 'PN-2011-000059', 1, 0),
('2011-12-19', 2, 'OS-2011-000012', 1000.000, 1, 5, 'OS', 'PN-2011-000059', 1, 0),
('2011-12-19', 3, 'OS-2011-000012', 1000.000, 1, 7, 'OS', 'PN-2011-000059', 1, 0),
('2011-12-19', 4, 'OS-2011-000012', 1000.000, 1, 9, 'OS', 'PN-2011-000059', 1, 0),
('2011-12-19', 5, 'OS-2011-000013', 500.000, 1, 5, 'AR', 'PN-2011-000060', 1, 0),
('2011-12-19', 6, 'OS-2011-000013', 500.000, 1, 3, 'AR', 'PN-2011-000060', 1, 0),
('2011-12-19', 7, 'OS-2011-000014', 1500.000, 1, 2, 'OS', 'PN-2011-000060', 1, 0),
('2011-12-19', 8, 'OS-2011-000014', 1500.000, 1, 5, 'OS', 'PN-2011-000060', 1, 0),
('2011-12-19', 9, 'OS-2011-000014', 1500.000, 1, 7, 'OS', 'PN-2011-000060', 1, 0),
('2011-12-19', 10, 'OS-2011-000014', 1500.000, 1, 9, 'OS', 'PN-2011-000060', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `income_statement_settings`
--

CREATE TABLE IF NOT EXISTS `income_statement_settings` (
  `ACCOUNT_SUB_CATEGORY_ID` int(11) DEFAULT '0',
  `INC_TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `industry_type`
--

CREATE TABLE IF NOT EXISTS `industry_type` (
  `INDUSTRY_TYPE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `INDUSTRY_TYPE_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`INDUSTRY_TYPE_ID`),
  KEY `INDUSTRY_TYPE_NAME` (`INDUSTRY_TYPE_NAME`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `industry_type`
--

INSERT INTO `industry_type` (`INDUSTRY_TYPE_ID`, `INDUSTRY_TYPE_NAME`, `IS_DELETED`) VALUES
(1, 'Manufacturing', 0),
(2, 'Information Technology', 0),
(3, 'Merchandising', 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_maintenance_history`
--

CREATE TABLE IF NOT EXISTS `item_maintenance_history` (
  `ITEM_HISTORY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ITEM_CODE` varchar(25) DEFAULT '0',
  `ITEM_FLAG` varchar(1) NOT NULL DEFAULT '0',
  `ITEM_PERSON_NAME` varchar(150) DEFAULT NULL,
  `ITEM_FINDINGS` text,
  `ITEM_STEP_TAKEN` text,
  `ITEM_PERSON_CONTACT_NO` varchar(100) DEFAULT NULL,
  `ITEM_DATE` date DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ITEM_HISTORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `item_maintenance_history`
--

INSERT INTO `item_maintenance_history` (`ITEM_HISTORY_ID`, `ITEM_CODE`, `ITEM_FLAG`, `ITEM_PERSON_NAME`, `ITEM_FINDINGS`, `ITEM_STEP_TAKEN`, `ITEM_PERSON_CONTACT_NO`, `ITEM_DATE`, `IS_DELETED`) VALUES
(1, 'AS-2011-000004', '1', 'Ricky Benitez', 'Baliw', 'Wala', '934-23-43', '2011-09-04', 0),
(2, 'AS-2011-000004', '0', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '2011-11-02', 1),
(3, 'AS-2011-000004', '0', 'Jason Sanje', ':)', 'LOL', '12345678', '2011-11-01', 1),
(4, 'AS-2011-000042', '0', 'Henry Jandayan', 'Panget', 'Wala pag-asa -Jason Sanje', '12345687', '2011-11-23', 1),
(5, 'AS-2011-000046', '0', 'Henry II', 'Dead Pixels', 'Replace', '5684558', '2011-11-02', 1),
(6, 'AS-2011-000004', '0', 'HHHHHHH', 'HHHHHHHHH', '', 'HHHHHHH', '2011-11-10', 0),
(7, 'AS-2011-000057', '0', '333', '333', '333', '333', '2011-11-08', 0),
(8, 'AS-2011-000057', '0', '333', '333', 'qwerty', '333', '2011-11-08', 1),
(9, 'AS-2011-000058', '0', '333', '333', '333', '333', '2011-11-08', 0),
(10, 'AS-2011-000004', '0', '55', '55', '55', '55', '2011-11-17', 0),
(11, 'AS-2011-000004', '0', 'Carl Carreon', 'May tama sa utak.', 'Wala ng pagasa.', '1234567', '2011-12-15', 0),
(12, 'AS-2011-000061', '0', 'aasdf', 'asdf', 'qwerty', 'asdf', '2011-12-15', 0),
(13, 'AS-2011-000061', '0', 'qwerty', 'qwerty', 'qwerty', 'qwerty', '2011-12-13', 1),
(14, 'AS-2011-000074', '0', 'Jason Sanje', 'Empty Cartridge', 'Replace', '123456', '2011-12-15', 0),
(15, 'AS-2011-000078', '0', 'Ricky Benitez', 'Broken VGA chord', 'Replace', '4448885', '2011-12-15', 0),
(16, 'AS-2011-000103', '0', 'asdf', 'asdf', 'asdf', 'asdfas', '2011-12-14', 1),
(17, 'AS-2011-000078', '0', 'Ricky Benitez', 'Sira', 'Repair', '1234567', '2011-12-20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_maintenance_reminder`
--

CREATE TABLE IF NOT EXISTS `item_maintenance_reminder` (
  `ITEM_MAINTENANCE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ITEM_CODE` varchar(25) DEFAULT '0',
  `STATUS` tinyint(1) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `ALERT_DATE` date NOT NULL,
  `ALERT_TIME` time NOT NULL,
  `SUBJECT` varchar(50) NOT NULL,
  `NOTE` varchar(100) NOT NULL,
  `REMIND_EVERY` varchar(50) NOT NULL,
  PRIMARY KEY (`ITEM_MAINTENANCE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `item_maintenance_reminder`
--

INSERT INTO `item_maintenance_reminder` (`ITEM_MAINTENANCE_ID`, `ITEM_CODE`, `STATUS`, `IS_DELETED`, `ALERT_DATE`, `ALERT_TIME`, `SUBJECT`, `NOTE`, `REMIND_EVERY`) VALUES
(2, 'AS-2011-000061', 1, 0, '2011-11-09', '00:00:00', 'TEST', 'notes notes notes', 'Daily'),
(3, 'AS-2011-000054', 0, 1, '2011-11-11', '05:05:00', 'HHH', 'HHH', 'Daily'),
(4, 'AS-2011-000042', 1, 0, '2011-11-05', '10:05:00', 'TEST', 'TEst notes test notes', 'Weekly'),
(5, 'AS-2011-000046', 0, 0, '2011-11-05', '05:05:05', ':)', 'gfd', 'Monthly'),
(6, 'AS-2011-000046', 0, 0, '2011-11-02', '05:12:00', 'TRIP', 'asdf', 'Daily'),
(7, 'AS-2011-000046', 1, 1, '2011-12-22', '05:12:16', 'HHHH', 'alsdfkj', 'Daily'),
(8, 'AS-2011-000061', 0, 1, '2011-12-21', '15:00:00', 'asdf', 'asdf', 'Daily'),
(9, 'AS-2011-000061', 1, 0, '2011-12-07', '14:50:00', 'asdf', 'asdf', 'Daily'),
(10, 'AS-2011-000072', 1, 0, '2011-12-15', '20:41:00', 'Clean the keyboard', 'maintenance', 'Monthly'),
(11, 'AS-2011-000078', 1, 0, '2011-12-08', '12:27:00', 'Si Facun', 'Tutumbling', 'Daily'),
(12, 'AS-2011-000103', 1, 0, '2011-12-14', '06:00:00', 'asdf', 'asdf', 'Daily'),
(13, 'AS-2011-000078', 1, 0, '2011-12-20', '00:00:00', 'Si Facun Ulit', 'Tutumbling part 2', 'Weekly');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE IF NOT EXISTS `leaves` (
  `LEAVE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LEAVE_FROM_DATE` date DEFAULT NULL,
  `LEAVE_TO_DATE` date DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `IS_FLAG` tinyint(4) NOT NULL DEFAULT '0',
  `EMP_ID` int(11) DEFAULT '0',
  `LEAVE_TYPE_ID` int(11) DEFAULT '0',
  `PAYROLL_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`LEAVE_ID`),
  KEY `EMP_ID` (`EMP_ID`),
  KEY `LEAVE_TYPE_ID` (`LEAVE_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`LEAVE_ID`, `LEAVE_FROM_DATE`, `LEAVE_TO_DATE`, `IS_DELETED`, `IS_FLAG`, `EMP_ID`, `LEAVE_TYPE_ID`, `PAYROLL_ID`) VALUES
(1, '2011-11-02', '2011-11-16', 0, 1, 1, 6, 8),
(2, '2011-09-01', '2011-10-31', 0, 0, 1, 12, 8),
(3, '2011-10-25', '2011-10-27', 0, 0, 2, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `leave_type`
--

CREATE TABLE IF NOT EXISTS `leave_type` (
  `LEAVE_TYPE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LEAVE_TYPE_NAME` varchar(100) DEFAULT NULL,
  `LEAVE_NO_OF_DAYS` int(11) DEFAULT '0',
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`LEAVE_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `leave_type`
--

INSERT INTO `leave_type` (`LEAVE_TYPE_ID`, `LEAVE_TYPE_NAME`, `LEAVE_NO_OF_DAYS`, `IS_DELETED`) VALUES
(1, 'Vacation Leave', 19, 0),
(2, 'Sick Leave', 14, 0),
(3, 'Sick Leave Injury', 14, 0),
(4, 'Maternal Leave', 14, 0),
(5, 'Paternal Leave', 14, 0),
(6, 'Administrative Leave', 14, 0),
(7, 'Leave Without Pay', 14, 0),
(8, 'Military Leave', 14, 0),
(9, 'Leave For Appointment by Governor', 14, 0),
(10, 'Convention Leave', 14, 0),
(11, 'Leave For Union Office', 14, 0),
(12, 'Medical Leave', 14, 0),
(13, 'Leave for Emergency Civilian Duty', 14, 0),
(14, 'State Family Leave', 14, 0),
(15, 'Leave For Elective Office', 14, 0),
(16, 'Leave For Jury Duty', 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `LOCATION_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION_NAME` varchar(150) DEFAULT NULL,
  `LOCATION_ADDRESS` varchar(200) DEFAULT NULL,
  `LOCATION_PHONE_NO` varchar(100) DEFAULT NULL,
  `LOCATION_FAX_NO` varchar(100) DEFAULT NULL,
  `LOCATION_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `AREA_ID` int(11) DEFAULT '0',
  `CITY_ID` int(11) DEFAULT '0',
  `BARANGAY_ID` int(11) DEFAULT '0',
  `CUSTOMER_ID` int(11) DEFAULT '0',
  `LOCATION_TYPE_ID` int(11) DEFAULT '0',
  `FLAG` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`LOCATION_ID`),
  KEY `AREA_ID` (`AREA_ID`),
  KEY `CITY_ID` (`CITY_ID`),
  KEY `BARANGAY_ID` (`BARANGAY_ID`),
  KEY `CUSTOMER_ID` (`CUSTOMER_ID`),
  KEY `LOCATION_TYPE_ID` (`LOCATION_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`LOCATION_ID`, `LOCATION_NAME`, `LOCATION_ADDRESS`, `LOCATION_PHONE_NO`, `LOCATION_FAX_NO`, `LOCATION_REMARKS`, `IS_DELETED`, `AREA_ID`, `CITY_ID`, `BARANGAY_ID`, `CUSTOMER_ID`, `LOCATION_TYPE_ID`, `FLAG`) VALUES
(1, 'Pio Del Pilar', 'Makati City', '842-32-44', '+44-208-1234567', 'none', 0, 1, 1, 1, 1, 1, 'C'),
(2, 'Tejeros', 'Manila City', '841-10-42', '44-208-1234567', 'none', 0, 2, 2, 2, 2, 2, 'C'),
(3, 'Pinagbuhatan', 'Quezon City', '888-32-40', '+44-208-1234567', 'none', 0, 3, 3, 3, 3, 1, 'C'),
(4, 'Pinagkaisahan', 'Mandaluyong City', '813-32-43', '+44-208-1234567', 'none', 0, 4, 4, 4, 4, 2, 'C'),
(5, 'Asuncion', 'Pasay City', '832-32-00', '+44-208-1234567', 'none', 0, 5, 5, 5, 5, 1, 'C'),
(6, 'Cubao', 'Parañaque City', '812-32-64', ' 44-208-1234567', 'none', 0, 6, 6, 6, 6, 2, 'C'),
(7, 'Bangkal', 'Malabon City', '892-32-11', ' 44-208-1234567', 'none', 0, 7, 7, 7, 7, 1, 'C'),
(8, 'New Era', 'Pasig City', '802-38-09', '+44-208-1234567', 'none', 0, 8, 8, 8, 8, 2, 'C'),
(9, 'Tales', 'San Juan City', '882-00-37', '44-208-1234567', 'none', 0, 9, 10, 10, 9, 2, 'C'),
(10, 'Tales', 'San Juan City', '882-00-37', '44-208-1234567', 'none', 0, 9, 10, 10, 10, 1, 'C'),
(11, 'QC Branch', '', '', '', NULL, 0, 3, 3, 3, 8, 2, 'C'),
(12, 'Paco', '', '', '', NULL, 0, 7, 2, 2, 12, 1, 'C'),
(16, 'Se7en Inc.', '', '', '', NULL, 0, 2, 1, 1, 14, 2, 'C'),
(19, 'ahuhuhu', 'ahihihi st', '1111111111', '1111111', NULL, 0, 1, 10, 10, 1, 2, 'S'),
(20, 'Supplier Location', 'waaaaah', '0989', '9123', NULL, 0, 1, 10, 10, 9, 1, 'S'),
(21, 'Cath', 'Brgy Pio Del Pilar E. Ramos St. Makati City', '', '', NULL, 0, 3, 1, 1, 20, 2, NULL),
(22, 'Sa kanto', '', '1234567', '', NULL, 0, 8, 2, 2, 21, 2, NULL),
(23, 'Main', 'E. Ramos St., Manila City', '( 63)-025-6765756', '( 63)-027-6573465', NULL, 0, 3, 2, 2, 19, 1, NULL),
(24, 'baso', 'baso', '( 12)-312-3123131', '', NULL, 0, 1, 1, 1, 10, 1, 'S');

-- --------------------------------------------------------

--
-- Table structure for table `location_type`
--

CREATE TABLE IF NOT EXISTS `location_type` (
  `LOCATION_TYPE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION_TYPE_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`LOCATION_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `location_type`
--

INSERT INTO `location_type` (`LOCATION_TYPE_ID`, `LOCATION_TYPE_NAME`, `IS_DELETED`) VALUES
(1, 'Main Office', 0),
(2, 'Branch', 0);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `NOTIF_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOTIF_DATE_TIME` datetime NOT NULL,
  `IS_MARKED` tinyint(3) unsigned NOT NULL,
  `NOTIF_REF_ID` varchar(45) NOT NULL,
  `NOTIF_REFERENCE` varchar(45) NOT NULL,
  PRIMARY KEY (`NOTIF_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`NOTIF_ID`, `NOTIF_DATE_TIME`, `IS_MARKED`, `NOTIF_REF_ID`, `NOTIF_REFERENCE`) VALUES
(1, '2011-09-21 13:07:04', 1, '1', 'taskReminder'),
(2, '2011-09-21 13:07:40', 1, '2', 'taskReminder'),
(3, '2011-09-21 13:07:04', 1, '1', 'taskReminder'),
(4, '2011-09-21 13:07:04', 1, '2', 'taskReminder'),
(5, '2011-09-21 13:07:04', 1, '3', 'taskReminder');

-- --------------------------------------------------------

--
-- Table structure for table `os_detail`
--

CREATE TABLE IF NOT EXISTS `os_detail` (
  `OS_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `OS_DTL_QTY` int(11) DEFAULT '0',
  `OS_DTL_ITEM_DESCRIPTION` text,
  `OS_DTL_STATUS` varchar(10) DEFAULT NULL,
  `OS_DTL_REMARKS` text,
  `OS_HDR_ID` varchar(20) DEFAULT '0',
  `UNIT_ID` int(11) DEFAULT NULL,
  `ITEM_ID` varchar(20) DEFAULT '0',
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`OS_DTL_ID`),
  KEY `OS_HDR_ID` (`OS_HDR_ID`),
  KEY `UNIT_ID` (`UNIT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `os_detail`
--

INSERT INTO `os_detail` (`OS_DTL_ID`, `OS_DTL_QTY`, `OS_DTL_ITEM_DESCRIPTION`, `OS_DTL_STATUS`, `OS_DTL_REMARKS`, `OS_HDR_ID`, `UNIT_ID`, `ITEM_ID`, `ITEM_FLAG`) VALUES
(1, 1, ' Size: Letter, GSM: .9', NULL, NULL, 'OS-2011-000001', NULL, 'CE-K-000004', NULL),
(2, 1, ' General Description: QWERTY keyboard', NULL, NULL, 'OS-2011-000001', NULL, 'CE-K-000005', NULL),
(40, 1, ' General Description: qwert', NULL, NULL, 'OS-2011-000005', NULL, 'CE-K-000005', NULL),
(41, 1, ' General Description: qwert', NULL, NULL, 'OS-2011-000006', NULL, 'CE-K-000080', NULL),
(42, 1, ' General Description: qwert', NULL, NULL, 'OS-2011-000006', NULL, 'CE-K-000005', NULL),
(43, 1, ' General Description: Monitor, Screen Size: 17 inches, Resolution: 640x480', NULL, NULL, 'OS-2011-000007', NULL, 'CE-M-000001', NULL),
(44, 1, ' General Description: Monitor, Screen Size: 17 inches, Resolution: 640x480', NULL, NULL, 'OS-2011-000009', NULL, 'CE-M-000001', NULL),
(46, 1, ' General Description: Monitor, Screen Size: 17 inches, Resolution: 640x480', NULL, NULL, 'OS-2011-000011', NULL, 'CE-M-000001', NULL),
(48, 3, ' General Description: qwert', NULL, NULL, 'OS-2011-000014', NULL, 'CE-K-000080', NULL),
(49, 1, ' General Description: Ballpen', NULL, NULL, 'OS-2011-000004', NULL, 'OS-B-000003', NULL),
(50, 1, ' General Description: qwert', NULL, NULL, 'OS-2011-000004', NULL, 'CE-K-000005', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `os_header`
--

CREATE TABLE IF NOT EXISTS `os_header` (
  `OS_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `OS_HDR_NO` varchar(20) DEFAULT NULL,
  `OS_HDR_DATE` date DEFAULT NULL,
  `OS_HDR_GROSS_AMOUNT` double(15,3) DEFAULT '0.000',
  `OS_HDR_NET_AMOUNT` double(15,3) DEFAULT '0.000',
  `OS_HDR_DISCOUNT_PERCENT` int(11) DEFAULT NULL,
  `OS_HDR_DISCOUNT_AMOUNT` double(15,3) DEFAULT '0.000',
  `OS_HDR_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `CUSTOMER_ID` int(11) DEFAULT '0',
  `OS_HDR_BILL_TO_ID` int(11) DEFAULT '0',
  `AREA_ID` int(11) DEFAULT '0',
  `SALES_PERSON_ID` int(11) DEFAULT '0',
  `CREATED_BY_ID` int(11) DEFAULT '0',
  `IS_AR` tinyint(1) NOT NULL,
  `OS_HDR_DEPOSIT` double(15,3) DEFAULT NULL,
  `OS_HDR_TERMS` int(11) DEFAULT NULL,
  `IS_CLEARED` int(11) DEFAULT '0',
  `OS_BALANCE` decimal(65,0) NOT NULL DEFAULT '0',
  PRIMARY KEY (`OS_HDR_ID`),
  KEY `CUSTOMER_ID` (`CUSTOMER_ID`),
  KEY `OS_HDR_BILL_TO_ID` (`OS_HDR_BILL_TO_ID`),
  KEY `AREA_ID` (`AREA_ID`),
  KEY `SALES_PERSON_ID` (`SALES_PERSON_ID`),
  KEY `CREATED_BY_ID` (`CREATED_BY_ID`),
  KEY `OS_HDR_NO` (`OS_HDR_NO`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `os_header`
--

INSERT INTO `os_header` (`OS_HDR_ID`, `OS_HDR_NO`, `OS_HDR_DATE`, `OS_HDR_GROSS_AMOUNT`, `OS_HDR_NET_AMOUNT`, `OS_HDR_DISCOUNT_PERCENT`, `OS_HDR_DISCOUNT_AMOUNT`, `OS_HDR_REMARKS`, `IS_DELETED`, `CUSTOMER_ID`, `OS_HDR_BILL_TO_ID`, `AREA_ID`, `SALES_PERSON_ID`, `CREATED_BY_ID`, `IS_AR`, `OS_HDR_DEPOSIT`, `OS_HDR_TERMS`, `IS_CLEARED`, `OS_BALANCE`) VALUES
(1, 'OS-2011-000001', '2011-10-18', 700.000, 700.000, 0, 0.000, '', 0, 2, 2, 2, 14, 14, 0, 0.000, 0, 1, '-49750'),
(2, 'OS-2011-000002', '2011-11-07', 2000000.000, 2000000.000, 0, 0.000, '', 0, 7, 7, 7, 2, 2, 0, 0.000, 0, 0, '1947800'),
(3, 'OS-2011-000003', '2011-12-07', 3500.000, 3500.000, 0, 0.000, '', 0, 14, 16, 2, 2, 2, 1, 0.000, 0, 0, '0'),
(4, 'OS-2011-000004', '2011-12-07', 225000.000, 225000.000, 0, 0.000, '', 0, 10, 10, 9, 2, 2, 1, 0.000, 0, 0, '-25000'),
(5, 'OS-2011-000005', '2011-12-09', 500.000, 500.000, 0, 0.000, '', 0, 2, 2, 2, 1, 1, 0, 0.000, 0, 1, '0'),
(6, 'OS-2011-000006', '2011-12-09', 1000.000, 1000.000, 0, 0.000, '', 0, 7, 7, 7, 1, 1, 0, 0.000, 0, 0, '-20234'),
(7, 'OS-2011-000007', '2011-12-09', 50000.000, 50000.000, 0, 0.000, '', 0, 1, 1, 1, 14, 14, 1, 0.000, 0, 0, '49255'),
(8, 'OS-2011-000008', '2011-12-09', 50000.000, 50000.000, 0, 0.000, '', 0, 3, 3, 3, 14, 14, 1, 0.000, 0, 0, '48766'),
(9, 'OS-2011-000009', '2011-12-09', 50000.000, 50000.000, 0, 0.000, '', 0, 8, 8, 8, 14, 14, 1, 0.000, 0, 0, '0'),
(10, 'OS-2011-000010', '2011-12-09', 500.000, 500.000, 0, 0.000, '', 0, 6, 6, 6, 14, 14, 1, 0.000, 0, 0, '-50734'),
(11, 'OS-2011-000011', '2011-12-13', 50000.000, 50000.000, 0, 0.000, '', 0, 1, 1, 1, 17, 17, 0, 0.000, 0, 1, '-1684'),
(12, 'OS-2011-000012', '2011-12-19', 1000.000, 1000.000, 0, 0.000, '', 0, 2, 2, 2, 27, 27, 0, 0.000, 0, 1, '-50000'),
(13, 'OS-2011-000013', '2011-12-19', 500.000, 500.000, 0, 0.000, '', 0, 2, 2, 2, 27, 27, 1, 0.000, 0, 0, '-1968'),
(14, 'OS-2011-000014', '2011-12-19', 1500.000, 1500.000, 0, 0.000, '', 0, 2, 2, 2, 27, 27, 0, 0.000, 0, 1, '-1234');

-- --------------------------------------------------------

--
-- Table structure for table `overtime`
--

CREATE TABLE IF NOT EXISTS `overtime` (
  `OVERTIME_ID` int(11) NOT NULL AUTO_INCREMENT,
  `OVERTIME_MINS` int(11) NOT NULL,
  `OVERTIME_DATE` date DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `IS_FLAG` tinyint(4) NOT NULL DEFAULT '0',
  `EMP_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`OVERTIME_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `overtime`
--

INSERT INTO `overtime` (`OVERTIME_ID`, `OVERTIME_MINS`, `OVERTIME_DATE`, `IS_DELETED`, `IS_FLAG`, `EMP_ID`) VALUES
(1, 300, '2011-11-02', 0, 0, 1),
(2, 60, '2011-11-04', 0, 0, 1),
(3, 350, '2011-11-07', 0, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `owners_equity`
--

CREATE TABLE IF NOT EXISTS `owners_equity` (
  `OE_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `OE_HDR_DATE` date DEFAULT NULL,
  `OE_HDR_AMOUNT` double(15,3) DEFAULT '0.000',
  `OE_HDR_REMARKS` text,
  `IS_DEPOSITED` tinyint(1) DEFAULT NULL,
  `IS_FLAG` tinyint(1) DEFAULT NULL,
  `OE_HDR_CTRL_NO` varchar(45) NOT NULL,
  PRIMARY KEY (`OE_HDR_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `owners_equity`
--

INSERT INTO `owners_equity` (`OE_HDR_ID`, `OE_HDR_DATE`, `OE_HDR_AMOUNT`, `OE_HDR_REMARKS`, `IS_DEPOSITED`, `IS_FLAG`, `OE_HDR_CTRL_NO`) VALUES
(1, '2011-11-24', 500.000, '', 0, 0, 'OE-2011-000001'),
(2, '2011-11-24', 500.000, '', 1, 0, 'OE-2011-000002'),
(3, '2011-11-24', 90000.000, '', 1, 0, 'OE-2011-000003'),
(5, '2011-11-24', 9044.000, '', 1, 0, 'OE-2011-000005'),
(10, '2011-11-24', 7.500, '', 0, 0, 'OE-2011-000010'),
(11, '2011-11-24', 3.500, '', 0, 0, 'OE-2011-000011'),
(14, '2011-11-24', 4000.000, '', 1, 0, 'OE-2011-000014'),
(15, '2011-11-24', 3.000, '', 0, 0, 'OE-2011-000015'),
(16, '2011-12-01', 800.000, '', 0, 0, 'OE-2011-000016'),
(17, '2011-12-05', 500.000, '', 0, 0, 'OE-2011-000017'),
(18, '2011-12-05', 32.000, '', 0, 0, 'OE-2011-000018'),
(19, '2011-12-06', 500.000, '', 0, 0, 'OE-2011-000019'),
(20, '2011-12-06', 100.000, '', 1, 0, 'OE-2011-000020'),
(21, '2011-12-06', 200.000, '', 0, 0, 'OE-2011-000021');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `PAYMENT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PAYMENT_NO` varchar(20) DEFAULT NULL,
  `PAYMENT_DATE` date DEFAULT NULL,
  `PAYMENT_REF_TYPE` varchar(10) DEFAULT NULL,
  `PAYMENT_PARTICULAR` varchar(200) DEFAULT NULL,
  `PAYMENT_TYPE` varchar(100) DEFAULT NULL,
  `PAYMENT_AMOUNT` double(15,3) DEFAULT '0.000',
  `IS_FROM_COLLECTION` tinyint(1) DEFAULT NULL,
  `PAYMENT_CREATED_BY_ID` int(11) DEFAULT '0',
  `PAYMENT_REF_NO` varchar(20) DEFAULT NULL,
  `OS_HDR_ID` int(11) NOT NULL,
  PRIMARY KEY (`PAYMENT_ID`),
  KEY `PAYMENT_CREATED_BY_ID` (`PAYMENT_CREATED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PAYMENT_ID`, `PAYMENT_NO`, `PAYMENT_DATE`, `PAYMENT_REF_TYPE`, `PAYMENT_PARTICULAR`, `PAYMENT_TYPE`, `PAYMENT_AMOUNT`, `IS_FROM_COLLECTION`, `PAYMENT_CREATED_BY_ID`, `PAYMENT_REF_NO`, `OS_HDR_ID`) VALUES
(1, 'PN-2011-000001', '2011-12-06', 'OS', 'Sales', 'cash', 1708.000, 0, 17, 'OS-2011-000001', 1),
(2, 'PN-2011-000002', '2011-12-06', 'Expense', 'Ricky', 'cash', 500.550, 0, 17, 'EXP-2011-000048', 0),
(3, 'PN-2011-000003', '2011-12-06', 'Expense', '100', 'cash', 100.000, 0, 2, 'EXP-2011-000048', 0),
(4, 'PN-2011-000004', '2011-12-06', 'OS', '', 'cash', 451.000, 0, 17, 'OS-2011-000003', 3),
(5, 'PN-2011-000005', '2011-12-06', 'AP', '', 'cash', 100.000, 0, 14, 'AP-2011-000053', 0),
(6, 'PN-2011-000006', '2011-12-06', 'AP', '', 'cash', 186.000, 0, 14, 'AP-2011-000053', 0),
(7, 'PN-2011-000007', '2011-12-06', 'OS', '48742', 'cash', 48742.000, 0, 17, 'OS-2011-000001', 1),
(8, 'PN-2011-000008', '2011-12-06', 'OS', '48742', 'cheque', 51685.000, 0, 17, 'OS-2011-000002', 2),
(9, 'PN-2011-000009', '2011-12-06', 'AP', '', 'cheque', 714.000, 0, 14, 'AP-2011-000053', 0),
(10, 'PN-2011-000010', '2011-12-06', 'Expense', '23232', 'cash', 14.000, 0, 2, 'EXP-2011-000055', 0),
(11, 'PN-2011-000011', '2011-12-06', 'Expense', 'asdfa', 'check', 72.000, 0, 17, 'EXP-2011-000056', 0),
(12, 'PN-2011-000012', '2011-12-06', 'OS', '', 'cash', 250000.000, 0, 17, 'OS-2011-000004', 4),
(13, 'PN-2011-000013', '2011-12-06', 'OS', '1234', 'cheque', 1234.000, 0, 17, 'OS-2011-000008', 8),
(14, 'PN-2011-000014', '2011-12-06', 'OS', '', 'cheque', 4936.000, 0, 17, 'OS-2011-000009', 9),
(15, 'PN-2011-000015', '2011-12-06', 'OS', '', 'cheque', 51234.000, 0, 17, 'OS-2011-000010', 10),
(16, 'PN-2011-000016', '2011-12-06', 'AP', '', 'cheque', 700.000, 0, 1, 'AP-2011-000054', 0),
(17, 'PN-2011-000017', '2011-12-06', 'OS', '', 'cheque', 51684.000, 0, 17, 'OS-2011-000011', 11),
(18, 'PN-2011-000018', '2011-12-06', 'OS', '', 'cheque', 50000.000, 0, 17, 'OS-2011-000012', 12),
(19, 'PN-2011-000019', '2011-12-06', 'AP', '', 'cheque', 123.000, 0, 1, 'AP-2011-000054', 0),
(20, 'PN-2011-000020', '2011-12-06', 'AP', '', 'cheque', 1877.000, 0, 17, 'AP-2011-000054', 0),
(21, 'PN-2011-000021', '2011-12-06', 'OS', '', 'cheque', 1234.000, 0, 17, 'OS-2011-000013', 13),
(22, 'PN-2011-000022', '2011-12-06', 'OS', '', 'cheque', 1234.000, 0, 17, 'OS-2011-000013', 13),
(23, 'PN-2011-000023', '2011-12-06', 'OS', '', 'cheque', 1234.000, 0, 17, 'OS-2011-000014', 14),
(24, 'PN-2011-000024', '2011-12-06', 'OS', '', 'cash', 1234.000, 0, 17, 'OS-2011-000015', 15),
(25, 'PN-2011-000025', '2011-12-06', 'AP', '', 'cash', 200.000, 0, 1, 'AP-2011-000052', 0),
(26, 'PN-2011-000026', '2011-12-06', 'AP', '', 'cash', 200.000, 0, 1, 'AP-2011-000052', 0),
(27, 'PN-2011-000027', '2011-12-06', 'AP', '', 'cash', 200.000, 0, 1, 'AP-2011-000052', 0),
(28, 'PN-2011-000028', '2011-12-06', 'AP', '', 'cash', 200.000, 0, 1, 'AP-2011-000051', 0),
(29, 'PN-2011-000029', '2011-12-06', 'AP', '', 'cash', 200.000, 0, 1, 'AP-2011-000050', 0),
(30, 'PN-2011-000030', '2011-12-06', 'AP', '', 'cash', 100.000, 0, 1, 'AP-2011-000046', 0),
(31, 'PN-2011-000031', '2011-12-06', 'OS', '', 'cheque', 11515243.000, 0, 1, 'OS-2011-000016', 16),
(32, 'PN-2011-000032', '2011-12-06', 'AP', '', 'cheque', 500.000, 0, 1, 'AP-2011-000047', 0),
(33, 'PN-2011-000033', '2011-12-06', 'AP', '', 'cheque', 500.000, 0, 1, 'AP-2011-000047', 0),
(34, 'PN-2011-000034', '2011-12-07', 'OS', '', 'cash', 1000.000, 0, 1, 'OS-2011-000017', 17),
(35, 'PN-2011-000035', '2011-12-07', 'OS', '', 'cash', 700.000, 0, 1, 'OS-2011-000018', 18),
(36, 'PN-2011-000036', '2011-12-07', 'OS', '', 'cheque', 1234.000, 0, 1, 'OS-2011-000006', 6),
(37, 'PN-2011-000037', '2011-12-07', 'AP', '', 'cheque', 300.000, 0, 1, 'AP-2011-000057', 0),
(38, 'PN-2011-000038', '2011-12-07', 'OS', '', 'cheque', 20000.000, 0, 1, 'OS-2011-000006', 6),
(39, 'PN-2011-000039', '2011-12-07', 'Expense', 'Test for many entries', 'cash', 2000.000, 0, 26, 'EXP-2011-000058', 0),
(40, 'PN-2011-000040', '2011-12-07', 'OS', 'TEST', 'cash', 500.000, 0, 1, 'OS-2011-000002', 2),
(41, 'PN-2011-000041', '2011-12-07', 'OS', 'asdf', 'cash', 15.000, 0, 1, 'OS-2011-000002', 2),
(42, 'PN-2011-000042', '2011-12-09', 'OS', '', 'cash', 500.000, 0, 1, 'OS-2011-000005', 5),
(43, 'PN-2011-000043', '2011-12-09', 'OS', '', 'cash', 45064.000, 0, 2, 'OS-2011-000009', 9),
(44, 'PN-2011-000044', '2011-12-09', 'OS', '', 'cash', 3049.000, 0, 2, 'OS-2011-000003', 3),
(58, 'PN-2011-000058', '2011-12-12', 'OS', '', 'cheque', 745.000, 0, 17, 'OS-2011-000007', 7),
(59, 'PN-2011-000059', '2011-12-19', 'OS', '', 'cash', 1000.000, 0, 27, 'OS-2011-000012', 12),
(60, 'PN-2011-000060', '2011-12-19', 'OS', '', 'cash', 1500.000, 0, 27, 'OS-2011-000014', 14);

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE IF NOT EXISTS `payroll` (
  `PAYROLL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PAYROLL_DATE` date DEFAULT NULL,
  `PAYROLL_DATE_FROM` date DEFAULT NULL,
  `PAYROLL_DATE_TO` date DEFAULT NULL,
  `PAYROLL_BASIC_SALARY` double(15,2) DEFAULT '0.00',
  `PAYROLL_DAILY_RATE` double(15,2) DEFAULT '0.00',
  `PAYROLL_HOURLY_RATE` double(15,2) DEFAULT '0.00',
  `PAYROLL_MINUTES_RATE` double(15,2) DEFAULT '0.00',
  `PAYROLL_OVERTIME_RATE` double(15,2) DEFAULT '0.00',
  `PAYROLL_OVERTIME_MINUTES` int(11) DEFAULT '0',
  `PAYROLL_REGULAR_HOLIDAY` double(15,2) DEFAULT '0.00',
  `PAYROLL_ALLOWANCE` double(15,2) NOT NULL DEFAULT '0.00',
  `PAYROLL_DAYS_WORK` int(11) DEFAULT '0',
  `PAYROLL_HOURS_WORK` int(11) DEFAULT '0',
  `PAYROLL_MINUTES_WORK` int(11) NOT NULL DEFAULT '0',
  `PAYROLL_TOTAL_EARNINGS` double(15,2) DEFAULT '0.00',
  `PAYROLL_TOTAL_LEAVE` double(15,2) NOT NULL,
  `PAYROLL_WITHOLDING_TAX` double(15,2) DEFAULT '0.00',
  `PAYROLL_WITHOLDING_PERCENT` int(11) NOT NULL,
  `PAYROLL_COMPANY_LOAN` double(15,2) DEFAULT '0.00',
  `PAYROLL_TOTAL_DEDUCTIONS` double(15,2) DEFAULT '0.00',
  `PAYROLL_CASH_ADVANCE_DEDUCTIONS` double(15,2) DEFAULT '0.00',
  `PAYROLL_NET_PAY` double(15,2) NOT NULL,
  `DEPT_ID` int(11) DEFAULT '0',
  `EMP_ID` int(11) DEFAULT '0',
  `IS_DELETED` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PAYROLL_ID`),
  KEY `DEPT_ID` (`DEPT_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`PAYROLL_ID`, `PAYROLL_DATE`, `PAYROLL_DATE_FROM`, `PAYROLL_DATE_TO`, `PAYROLL_BASIC_SALARY`, `PAYROLL_DAILY_RATE`, `PAYROLL_HOURLY_RATE`, `PAYROLL_MINUTES_RATE`, `PAYROLL_OVERTIME_RATE`, `PAYROLL_OVERTIME_MINUTES`, `PAYROLL_REGULAR_HOLIDAY`, `PAYROLL_ALLOWANCE`, `PAYROLL_DAYS_WORK`, `PAYROLL_HOURS_WORK`, `PAYROLL_MINUTES_WORK`, `PAYROLL_TOTAL_EARNINGS`, `PAYROLL_TOTAL_LEAVE`, `PAYROLL_WITHOLDING_TAX`, `PAYROLL_WITHOLDING_PERCENT`, `PAYROLL_COMPANY_LOAN`, `PAYROLL_TOTAL_DEDUCTIONS`, `PAYROLL_CASH_ADVANCE_DEDUCTIONS`, `PAYROLL_NET_PAY`, `DEPT_ID`, `EMP_ID`, `IS_DELETED`) VALUES
(8, '2011-12-02', '2011-12-01', '2011-12-03', 25000.00, 961.54, 252.00, 4.20, 0.00, 0, 0.00, 0.00, 54, 270, 16200, 92078.40, 24038.40, 0.00, 0, 0.00, 82432.00, 82432.00, 9646.40, 6, 1, 0),
(9, '2011-12-02', '2011-01-01', '2011-12-15', 30000.00, 1153.85, 0.00, 0.00, 0.00, 350, 0.00, 0.00, 27, 486, 3780, 0.00, 0.00, 0.00, 0, 0.00, 0.00, 0.00, 0.00, 6, 2, 0),
(10, '2011-12-21', '2011-12-19', '2011-12-20', 13500.00, 964.29, 177.63, 2.96, 0.00, 0, 0.00, 0.00, 1, 0, 5, 14.80, 0.00, 0.00, 0, 0.00, 0.00, 0.00, 14.80, 8, 38, 0),
(11, '2011-12-21', '2011-12-19', '2011-12-20', 13500.00, 964.29, 177.63, 2.96, 0.00, 0, 100.00, 0.00, 1, 0, 5, 114.80, 0.00, 0.00, 0, 0.00, 0.00, 0.00, 114.80, 8, 38, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_deduction`
--

CREATE TABLE IF NOT EXISTS `payroll_deduction` (
  `PAYROLL_DEDUCTION_NO` int(11) NOT NULL AUTO_INCREMENT,
  `PAYROLL_DEDUCTION_DESC` varchar(100) NOT NULL,
  `PAYROLL_DEDUCTION_AMOUNT` double(15,2) NOT NULL,
  `PAYROLL_ID` int(11) NOT NULL,
  PRIMARY KEY (`PAYROLL_DEDUCTION_NO`),
  KEY `PAYROLL_ID` (`PAYROLL_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `payroll_deduction`
--

INSERT INTO `payroll_deduction` (`PAYROLL_DEDUCTION_NO`, `PAYROLL_DEDUCTION_DESC`, `PAYROLL_DEDUCTION_AMOUNT`, `PAYROLL_ID`) VALUES
(45, 'SSS', 0.00, 9),
(46, 'PAG-IBIG', 0.00, 9),
(47, 'PRC', 0.00, 9),
(48, 'Caritas', 0.00, 9),
(49, 'SSS', 0.00, 8),
(50, 'PAG-IBIG', 0.00, 8),
(51, 'PRC', 0.00, 8),
(52, 'Caritas', 0.00, 8),
(53, 'SSS', 0.00, 10),
(54, 'PAG-IBIG', 0.00, 10),
(55, 'PhilHealth', 0.00, 10),
(56, 'Caritas', 0.00, 10),
(61, 'SSS', 0.00, 11),
(62, 'PAG-IBIG', 0.00, 11),
(63, 'PhilHealth', 0.00, 11),
(64, 'Caritas', 0.00, 11);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_earning`
--

CREATE TABLE IF NOT EXISTS `payroll_earning` (
  `PAYROLL_EARNING_NO` int(11) NOT NULL AUTO_INCREMENT,
  `PAYROLL_EARNING_DESC` varchar(100) NOT NULL,
  `PAYROLL_EARNING_AMOUNT` double(15,2) NOT NULL,
  `PAYROLL_ID` int(11) NOT NULL,
  PRIMARY KEY (`PAYROLL_EARNING_NO`),
  KEY `PAYROLL_ID` (`PAYROLL_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `payroll_earning`
--

INSERT INTO `payroll_earning` (`PAYROLL_EARNING_NO`, `PAYROLL_EARNING_DESC`, `PAYROLL_EARNING_AMOUNT`, `PAYROLL_ID`) VALUES
(23, 'Transpo Allowance', 0.00, 9),
(24, 'Special Holiday', 0.00, 9),
(25, 'Transpo Allowance', 0.00, 8),
(26, 'Special Holiday', 0.00, 8),
(27, 'Transpo Allowance', 0.00, 10),
(28, 'Special Holiday', 0.00, 10),
(31, 'Transpo Allowance', 0.00, 11),
(32, 'Special Holiday', 0.00, 11);

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE IF NOT EXISTS `position` (
  `POSITION_ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSITION_CODE` varchar(20) DEFAULT NULL,
  `POSITION_NAME` varchar(100) DEFAULT NULL,
  `POSITION_DESCRIPTION` text,
  `DEPT_ID` int(11) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`POSITION_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`POSITION_ID`, `POSITION_CODE`, `POSITION_NAME`, `POSITION_DESCRIPTION`, `DEPT_ID`, `IS_DELETED`) VALUES
(1, 'OE', 'Owner/Executive', 'none', 1, 0),
(2, 'SM', 'Sales Manager', 'none', 2, 0),
(3, 'ACT', 'Accountant', 'none', 3, 0),
(4, 'RC', 'Record Clerk', 'none', 4, 0),
(5, 'AC', 'Asset Custodian', 'none', 5, 0),
(6, 'WHP', 'Warehouse Personnel', 'none', 6, 0),
(7, 'SCKR', 'Stocks Checker', 'none', 7, 0),
(8, 'PM', 'Project Manager', 'none', 8, 0),
(9, 'FM', 'Finance Manager', 'none', 9, 0),
(10, 'MH', 'Marketing Head', 'none', 10, 0),
(11, 'IT', 'IT Consultant/Specialist', 'none', 6, 0),
(12, 'REC', 'Receptionist', 'none', 8, 0),
(13, 'ADMIN', 'Administrator', 'none', 6, 0),
(14, 'R/CF', 'Receptionist/Clerical Staff', 'none', 7, 0),
(15, 'HR', 'Human Resource Officer', 'none', 8, 0),
(16, 'TS', 'Technical Staff', 'none', 6, 0),
(17, 'PG', 'Purchasing Group', 'none', 7, 0),
(18, 'PROG', 'Programmer', 'Programmer', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `po_detail`
--

CREATE TABLE IF NOT EXISTS `po_detail` (
  `PO_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PO_DTL_QTY` int(11) DEFAULT '0',
  `PO_DTL_ORIGINAL_QTY` int(11) DEFAULT '0',
  `PO_DTL_ITEM_DESCRIPTION` text,
  `PO_DTL_STATUS` varchar(10) DEFAULT NULL,
  `PO_DTL_REMARKS` text,
  `PR_HDR_NO` varchar(20) DEFAULT '0',
  `PR_DTL_ID` int(11) DEFAULT '0',
  `PO_HDR_ID` int(11) DEFAULT '0',
  `ITEM_CODE` varchar(20) DEFAULT '0',
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  `UNIT_ID` int(11) NOT NULL DEFAULT '0',
  `IS_RECEIVED` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`PO_DTL_ID`),
  KEY `PR_DTL_ID` (`PR_DTL_ID`),
  KEY `PO_HDR_ID` (`PO_HDR_ID`),
  KEY `UNIT_ID` (`UNIT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `po_detail`
--

INSERT INTO `po_detail` (`PO_DTL_ID`, `PO_DTL_QTY`, `PO_DTL_ORIGINAL_QTY`, `PO_DTL_ITEM_DESCRIPTION`, `PO_DTL_STATUS`, `PO_DTL_REMARKS`, `PR_HDR_NO`, `PR_DTL_ID`, `PO_HDR_ID`, `ITEM_CODE`, `ITEM_FLAG`, `UNIT_ID`, `IS_RECEIVED`) VALUES
(5, 0, 1, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', NULL, NULL, 'PR-2011-000002', 2, 9, 'CE-M-1', NULL, 4, 2),
(6, 0, 1, ' General Description: Acer Keyboard HKB.0013.002', NULL, NULL, 'PR-2011-000002', 1, 9, 'CE-K-4', NULL, 4, 2),
(7, 0, 9, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', NULL, NULL, 'PR-2011-000003', 4, 10, 'CE-M-1', NULL, 4, 2),
(8, 0, 8, ' General Description: Monitor', NULL, NULL, 'PR-2011-000006', 5, 11, 'AS-2011-000058', NULL, 4, 2),
(9, 0, 1, ' General Description: Monitor', NULL, NULL, 'PR-2011-000011', 11, 12, 'AS-2011-000058', 'A', 4, 2),
(10, 0, 1, ' General Description: jhutf', NULL, NULL, 'PR-2011-000011', 12, 12, 'CE-K-000056', 'P', 6, 2),
(11, 0, 1, ' General Description: Monitor', NULL, NULL, 'PR-2011-000010', 10, 13, 'AS-2011-000058', 'A', 4, 2),
(12, 0, 17, ' General Description: Monitor', NULL, NULL, 'PR-2011-000009', 9, 14, 'AS-2011-000058', 'A', 4, 2),
(13, 0, 10, ' General Description: Monitor', NULL, NULL, 'PR-2011-000007', 6, 15, 'AS-2011-000058', 'A', 4, 2),
(14, 0, 5, ' General Description: jhutf', NULL, NULL, 'PR-2011-000007', 7, 15, 'CE-K-000056', 'P', 6, 2),
(15, 0, 20, ' General Description: 42, Screen Size: 42', NULL, NULL, 'PR-2011-000012', 14, 16, 'AS-2011-000042', 'A', 4, 2),
(16, 0, 10, ' General Description: Ballpen', NULL, NULL, 'PR-2011-000012', 15, 16, 'AS-2011-000061', 'A', 2, 2),
(17, 0, 15, ' General Description: 9', NULL, NULL, 'PR-2011-000012', 13, 16, 'AS-2011-000004', 'A', 2, 2),
(18, 15, 15, ' General Description: Ballpen', NULL, NULL, 'PR-2011-000013', 17, 17, 'AS-2011-000061', 'A', 2, 0),
(19, 27, 27, ' General Description: dvorak', NULL, NULL, 'PR-2011-000025', 35, 18, 'AS-2011-000072', 'A', 4, 0),
(20, 2, 2, ' General Description: 456456', NULL, NULL, 'PR-2011-000026', 36, 19, 'AS-2011-000103', 'A', 4, 0),
(21, 1, 1, ' General Description: qwert', NULL, NULL, 'PR-2011-000028', 38, 20, 'CE-K-000005', 'P', 2, 0),
(22, 1, 1, ' General Description: Monitor, Screen Size: 17 inches, Resolution: 640x480', NULL, NULL, 'PR-2011-000028', 39, 20, 'CE-M-000001', 'P', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `po_header`
--

CREATE TABLE IF NOT EXISTS `po_header` (
  `PO_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PO_HDR_NO` varchar(20) DEFAULT NULL,
  `PO_HDR_DATE_NEEDED` date DEFAULT NULL,
  `PO_HDR_DATE_REQUESTED` date DEFAULT NULL,
  `PO_HDR_CONTACT_NAME` varchar(100) DEFAULT NULL,
  `PO_HDR_PAYMENT_TYPE` varchar(10) DEFAULT NULL,
  `PO_HDR_GROSS_AMOUNT` double(15,3) DEFAULT '0.000',
  `PO_HDR_DISCOUNT_AMOUNT` double(15,3) DEFAULT '0.000',
  `PO_HDR_NET_AMOUNT` double(15,3) DEFAULT '0.000',
  `PO_HDR_TERMS` int(5) DEFAULT '0',
  `PO_HDR_REMARKS` text,
  `IS_AP` tinyint(1) DEFAULT '0',
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `PO_HDR_SOLD_TO_ID` int(11) DEFAULT '0',
  `PO_HDR_CREATED_BY_ID` int(11) DEFAULT '0',
  `SUPPLIER_ID` int(11) DEFAULT '0',
  `IS_RECEIVED` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`PO_HDR_ID`),
  KEY `PO_HDR_CREATED_BY_ID` (`PO_HDR_CREATED_BY_ID`),
  KEY `SUPPLIER_ID` (`SUPPLIER_ID`),
  KEY `PO_HDR_SOLD_TO_ID` (`PO_HDR_SOLD_TO_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `po_header`
--

INSERT INTO `po_header` (`PO_HDR_ID`, `PO_HDR_NO`, `PO_HDR_DATE_NEEDED`, `PO_HDR_DATE_REQUESTED`, `PO_HDR_CONTACT_NAME`, `PO_HDR_PAYMENT_TYPE`, `PO_HDR_GROSS_AMOUNT`, `PO_HDR_DISCOUNT_AMOUNT`, `PO_HDR_NET_AMOUNT`, `PO_HDR_TERMS`, `PO_HDR_REMARKS`, `IS_AP`, `IS_DELETED`, `PO_HDR_SOLD_TO_ID`, `PO_HDR_CREATED_BY_ID`, `SUPPLIER_ID`, `IS_RECEIVED`) VALUES
(9, 'PO-2011-000001', '2011-11-29', '2011-11-11', 'Happy Muñoz', 'Cash', 50300.000, 0.000, 50300.000, 0, '', 0, 0, 1, 1, 1, 0),
(10, 'PO-2011-000010', '2011-11-30', '2011-11-14', 'Happy Muñoz', 'Cash', 42750.000, 4275.000, 38475.000, 0, '', 0, 0, 1, 1, 1, 0),
(11, 'PO-2011-000011', '2011-11-25', '2011-11-23', 'Happy MuñozMr. SupplierMr. Supplier', 'Cash', 4350000.000, 435000.000, 3915000.000, 0, '', 0, 0, 1, 1, 1, 0),
(12, 'PO-2011-000012', '2011-11-30', '2011-11-23', 'Happy MuñozMr. SupplierMr. Supplier', 'Cash', 52468.000, 0.000, 52468.000, 0, '', 0, 0, 1, 1, 1, 2),
(13, 'PO-2011-000013', '2011-11-24', '2011-11-23', 'Supplier Man', 'Cash', 50000.000, 0.000, 50000.000, 0, '', 0, 0, 1, 1, 9, 0),
(14, 'PO-2011-000014', '2011-12-30', '2011-12-01', 'Supplier Man', 'Check', 7650000.000, 1530000.000, 6120000.000, 0, '', 0, 0, 16, 1, 9, 2),
(15, 'PO-2011-000015', '2011-12-31', '2011-12-01', 'Supplier', 'Cash', 4829616.000, 482961.600, 4346654.400, 0, '', 0, 0, 1, 1, 1, 2),
(16, 'PO-2011-000016', '2011-12-30', '2011-12-01', 'Supplier Man', 'Check', 4305.000, 430.500, 3874.500, 0, '', 0, 0, 14, 1, 9, 2),
(17, 'PO-2011-000017', '2011-12-31', '2011-12-01', 'Supplier', 'Cash', 15.000, 0.000, 15.000, 0, '', 0, 0, 1, 1, 1, 0),
(18, 'PO-2011-000018', '2011-12-21', '2011-12-20', 'Supplier', 'Cash', 0.000, 0.000, 0.000, 0, '', 0, 0, 1, 27, 1, 0),
(19, 'PO-2011-000019', '2011-12-21', '2011-12-20', 'Supplier', 'Cash', 132.000, 0.000, 132.000, 0, '', 0, 0, 1, 27, 1, 0),
(20, 'PO-2011-000020', '2011-12-21', '2011-12-20', 'Supplier', 'Cash', 50500.000, 0.000, 50500.000, 0, '', 0, 0, 1, 27, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_CODE` varchar(20) DEFAULT NULL,
  `PRODUCT_QTY` int(11) DEFAULT '0',
  `PRODUCT_UNIT_PRICE` double(15,3) DEFAULT '0.000',
  `PRODUCT_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `BRAND_ID` int(11) DEFAULT '0',
  `CATEGORY_ID` int(11) DEFAULT '0',
  `SUB_CATEGORY_ID` int(11) DEFAULT '0',
  `PRODUCT_IMAGE` text,
  `UNIT_ID` int(11) DEFAULT NULL,
  `MINIMUM_STOCK` int(11) NOT NULL,
  `NORMAL_STOCK` int(11) NOT NULL,
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`PRODUCT_ID`),
  KEY `BRAND_ID` (`BRAND_ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`),
  KEY `SUB_CATEGORY_ID` (`SUB_CATEGORY_ID`),
  KEY `UNIT_ID` (`UNIT_ID`),
  KEY `PRODUCT_CODE` (`PRODUCT_CODE`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=105 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `PRODUCT_CODE`, `PRODUCT_QTY`, `PRODUCT_UNIT_PRICE`, `PRODUCT_REMARKS`, `IS_DELETED`, `BRAND_ID`, `CATEGORY_ID`, `SUB_CATEGORY_ID`, `PRODUCT_IMAGE`, `UNIT_ID`, `MINIMUM_STOCK`, `NORMAL_STOCK`, `ITEM_FLAG`) VALUES
(1, 'CE-M-000001', 102, 50000.000, '', 0, 1, 3, 1, 'lg_w2261vg.jpg', 2, 105, 300, 'P'),
(2, 'OS-BP-000002', 108, 5000.000, NULL, 1, 2, 2, 2, 'bond-paper.jpg', 4, 300, 200, 'P'),
(3, 'OS-B-000003', 78, 450.000, '', 0, 5, 2, 3, 'Ballpoint.jpg', 2, 200, 100, 'P'),
(4, 'CE-K-000004', 149, 200.000, '234234', 1, 7, 2, 2, 'bond-paper.jpg', 2, 300, 200, 'P'),
(71, 'CE-K-000005', 145, 500.000, 'Keyboard', 0, 9, 3, 6, 'acer.jpg', 2, 2, 9, 'P'),
(72, 'AS-2011-000072', 97, 1000.000, '', 0, 9, 3, 6, '', 4, 2, 5, 'A'),
(73, 'CE-P-000073', 39, 5000.000, '', 0, 11, 3, 7, 'canon_printer_ip_4000_reset.jpg', 4, 1, 3, 'A'),
(74, 'AS-2011-000074', 96, 10000.000, '', 0, 11, 3, 7, 'printIcon.png', 4, 1, 3, 'A'),
(75, 'AS-2011-000075', 0, 150.000, '', 1, 7, 2, 2, 'bond-paper.jpg', 5, 1, 3, 'A'),
(76, 'AS-2011-000076', 201, 80.000, '', 0, 5, 2, 3, 'Ballpoint.jpg', 2, 1, 2, 'A'),
(77, 'AS-2011-000077', 96, 10.000, '', 0, 6, 2, 3, 'acer.jpg', 2, 1, 15, 'A'),
(78, 'AS-2011-000078', 95, 5000.000, '', 0, 1, 3, 1, 'LG.jpg', 2, 5, 10, 'A'),
(79, 'OS-B-000079', 150, 5.000, '', 0, 6, 2, 3, 'images (1).jpg', 4, 10, 50, 'P'),
(80, 'CE-K-000080', 94, 500.000, '', 0, 10, 3, 6, 'qwerty.gif', 2, 2, 11, 'P'),
(81, 'OS-B-000081', 0, 9.000, '', 0, 3, 2, 3, '55543.jpg', 4, 5, 30, 'P'),
(82, 'CE-D-000082', 0, 55000.000, '', 0, 8, 3, 4, 'images.jpg', 2, 1, 5, 'P'),
(102, 'OS-B-000083', 0, 1.000, '1', 0, 5, 2, 3, 'Ballpoint.jpg', 4, 2, 10, 'P'),
(103, 'AS-2011-000103', 0, 66.000, '66', 0, 11, 3, 7, '', 4, 66, 66, 'P'),
(104, 'CE-M-000104', 0, 27001.000, '', 0, 1, 3, 1, '', 4, 5, 5, 'P');

-- --------------------------------------------------------

--
-- Table structure for table `product_field`
--

CREATE TABLE IF NOT EXISTS `product_field` (
  `PRODUCT_FIELD_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_FIELD_NAME` varchar(100) DEFAULT NULL,
  `IS_ADD_TO_DESCRIPTION` tinyint(1) DEFAULT '0',
  `IS_DELETED` tinyint(1) DEFAULT '0',
  `SUB_CATEGORY_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`PRODUCT_FIELD_ID`),
  KEY `SUB_CATEGORY_ID` (`SUB_CATEGORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `product_field`
--

INSERT INTO `product_field` (`PRODUCT_FIELD_ID`, `PRODUCT_FIELD_NAME`, `IS_ADD_TO_DESCRIPTION`, `IS_DELETED`, `SUB_CATEGORY_ID`) VALUES
(1, 'General Description', 1, 0, 1),
(2, 'General Description', 1, 0, 2),
(3, 'Size', 1, 0, 2),
(4, 'GSM', 1, 0, 2),
(5, 'General Description', 1, 0, 3),
(22, 'Screen Size', 1, 0, 1),
(23, 'General Description', 1, 0, 4),
(24, 'Resolution', 1, 0, 1),
(27, 'General Description', 1, 0, 5),
(28, 'Carl Carreon Field', 1, 1, 3),
(29, '-Select Description-', 1, 1, 3),
(30, 'Facun Field', 1, 1, 1),
(31, 'Facun2', 1, 1, 1),
(32, 'General Description', 1, 0, 6),
(33, 'General Description', 1, 0, 7),
(34, 'CRT', 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_information`
--

CREATE TABLE IF NOT EXISTS `product_information` (
  `PRODUCT_FIELD_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` varchar(20) NOT NULL DEFAULT '0',
  `PRODUCT_DESCRIPTION` text,
  PRIMARY KEY (`PRODUCT_FIELD_ID`,`PRODUCT_ID`),
  KEY `PRODUCT_FIELD_ID` (`PRODUCT_FIELD_ID`),
  KEY `PRODUCT_ID` (`PRODUCT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `product_information`
--

INSERT INTO `product_information` (`PRODUCT_FIELD_ID`, `PRODUCT_ID`, `PRODUCT_DESCRIPTION`) VALUES
(1, 'AS-2011-000001', 'Tables'),
(1, 'AS-2011-000003', 'Chair'),
(1, 'AS-2011-000042', '42'),
(1, 'AS-2011-000078', 'monitor'),
(1, 'CE-M-000001', 'Monitor'),
(1, 'CE-M-000104', 'LED TV'),
(1, 'CE-M-1', 'ddd'),
(2, 'OS-BP-2', 'Typewriting Paper'),
(3, 'AS-2011-000075', 'Legal'),
(3, 'CE-K-000004', 'Letter'),
(3, 'OS-BP-000069', '123456'),
(3, 'OS-BP-2', 'A4'),
(4, 'AS-2011-000075', '2.0'),
(4, 'CE-K-000004', '.5'),
(4, 'OS-BP-000002', '2.0'),
(4, 'OS-BP-2', '80'),
(5, 'AS-2011-000004', 'Ballpens'),
(5, 'AS-2011-000061', 'Ballpen'),
(5, 'AS-2011-000076', '.5 point'),
(5, 'AS-2011-000077', 'HBW'),
(5, 'OS-B-000003', 'Ballpen'),
(5, 'OS-B-000043', 'uyf'),
(5, 'OS-B-000062', 'TEST'),
(5, 'OS-B-000063', 'rrere'),
(5, 'OS-B-000064', '123456'),
(5, 'OS-B-000066', '100'),
(5, 'OS-B-000068', '33'),
(5, 'OS-B-000079', 'Point'),
(5, 'OS-B-000081', 'Faber Castell'),
(5, 'OS-B-000083', 'Ballpen'),
(5, 'OS-B-3', 'Lotus'),
(22, 'AS-2011-000042', '42'),
(22, 'AS-2011-000057', '34'),
(22, 'AS-2011-000078', '23 inches'),
(22, 'CE-M-000001', '17 inches'),
(22, 'CE-M-1', 'ddd'),
(23, 'AS-2011-000070', 'acer'),
(23, 'CE-D-000082', 'First'),
(23, 'CE-K-000056', 'Acer'),
(23, 'CE-K-4', 'desktop'),
(23, 'OS-B-000039', 'Keyboard'),
(24, 'AS-2011-000078', '768x680'),
(24, 'CE-M-000001', '640x480'),
(24, 'CE-M-1', 'ddd'),
(32, 'AS-2011-000058', 'qwerty keyboard'),
(32, 'AS-2011-000072', 'dvorak'),
(32, 'CE-K-000005', 'qwert'),
(32, 'CE-K-000080', 'qwert'),
(33, 'AS-2011-000074', 'Asset Printer'),
(33, 'AS-2011-000103', '456456'),
(33, 'CE-P-000073', 'Printer canon');

-- --------------------------------------------------------

--
-- Table structure for table `pr_detail`
--

CREATE TABLE IF NOT EXISTS `pr_detail` (
  `PR_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PR_DTL_QTY` int(11) DEFAULT '0',
  `PR_DTL_ITEM_DESCRIPTION` text,
  `PR_DTL_STATUS` varchar(15) DEFAULT 'NOT APPROVED',
  `PR_DTL_REMARKS` text,
  `PR_HDR_ID` int(11) DEFAULT '0',
  `UNIT_ID` int(11) DEFAULT '0',
  `ITEM_CODE` varchar(20) DEFAULT '0',
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`PR_DTL_ID`),
  KEY `PR_HDR_ID` (`PR_HDR_ID`),
  KEY `UNIT_ID` (`UNIT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `pr_detail`
--

INSERT INTO `pr_detail` (`PR_DTL_ID`, `PR_DTL_QTY`, `PR_DTL_ITEM_DESCRIPTION`, `PR_DTL_STATUS`, `PR_DTL_REMARKS`, `PR_HDR_ID`, `UNIT_ID`, `ITEM_CODE`, `ITEM_FLAG`) VALUES
(1, 10, ' General Description: Acer Keyboard HKB.0013.002', 'APPROVED', NULL, 2, 4, 'CE-K-4', NULL),
(2, 10, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 'APPROVED', NULL, 2, 4, 'CE-M-1', NULL),
(3, 5, ' General Description: Acer Keyboard HKB.0013.002', 'APPROVED', NULL, 3, 4, 'CE-K-4', NULL),
(4, 1, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 'APPROVED', NULL, 3, 4, 'CE-M-1', NULL),
(5, 4, ' General Description: Monitor', 'APPROVED', NULL, 6, 4, 'AS-2011-000058', NULL),
(6, 1, ' General Description: Monitor', 'NOT APPROVED', NULL, 7, 4, 'AS-2011-000058', 'P'),
(7, 1, ' General Description: jhutf', 'NOT APPROVED', NULL, 7, 6, 'CE-K-000056', 'P'),
(8, 1, ' General Description: Monitor', 'APPROVED', NULL, 8, 4, 'AS-2011-000058', 'P'),
(9, 1, ' General Description: Monitor', 'APPROVED', NULL, 9, 4, 'AS-2011-000058', 'P'),
(10, 1, ' General Description: Monitor', 'APPROVED', NULL, 10, 4, 'AS-2011-000058', 'P'),
(11, 1, ' General Description: Monitor', 'APPROVED', NULL, 11, 4, 'AS-2011-000058', 'A'),
(12, 1, ' General Description: jhutf', 'APPROVED', NULL, 11, 6, 'CE-K-000056', 'P'),
(13, 15, ' General Description: 9', 'APPROVED', NULL, 12, 2, 'AS-2011-000004', 'A'),
(14, 20, ' General Description: 42, Screen Size: 42', 'APPROVED', NULL, 12, 4, 'AS-2011-000042', 'A'),
(15, 10, ' General Description: Ballpen', 'APPROVED', NULL, 12, 2, 'AS-2011-000061', 'A'),
(16, 6, ' General Description: 42, Screen Size: 42', 'APPROVED', NULL, 13, 4, 'AS-2011-000042', 'A'),
(17, 15, ' General Description: Ballpen', 'APPROVED', NULL, 13, 2, 'AS-2011-000061', 'A'),
(18, 1, ' General Description: 9', 'APPROVED', NULL, 14, 2, 'AS-2011-000004', 'A'),
(19, 1, ' General Description: 42, Screen Size: 42', 'APPROVED', NULL, 14, 4, 'AS-2011-000042', 'A'),
(20, 1, ' General Description: 9', 'APPROVED', NULL, 15, 2, 'AS-2011-000004', 'A'),
(21, 10, ' General Description: ddd, Screen Size: ddd, Resolution: ddd', 'APPROVED', NULL, 16, 4, 'CE-M-1', 'P'),
(22, 200, ' General Description: 9', 'APPROVED', NULL, 16, 2, 'AS-2011-000004', 'A'),
(23, 1, ' General Description: TEST', 'APPROVED', NULL, 16, 4, 'OS-B-000062', 'P'),
(24, 12, ' General Description: uyf', 'APPROVED', NULL, 16, 6, 'OS-B-000043', 'P'),
(25, 1, ' General Description: 42, Screen Size: 42', 'APPROVED', NULL, 17, 4, 'AS-2011-000042', 'A'),
(26, 21211, ' General Description: ddd, Screen Size: ddd, Resolution: ddd', 'APPROVED', NULL, 17, 4, 'CE-M-1', 'P'),
(27, 1, ' General Description: 9', 'APPROVED', NULL, 18, 2, 'AS-2011-000004', 'A'),
(28, 3232321, ' General Description: ddd, Screen Size: ddd, Resolution: ddd', 'APPROVED', NULL, 18, 4, 'CE-M-1', 'P'),
(29, 1, ' General Description: Asset Printer', 'APPROVED', NULL, 19, 4, 'AS-2011-000074', 'A'),
(30, 1, ' General Description: qwerty', 'APPROVED', NULL, 20, 4, 'AS-2011-000072', 'A'),
(31, 1, ' General Description: First', 'APPROVED', NULL, 21, 2, 'CE-D-000082', 'P'),
(32, 1, ' Resolution: 768x680', 'APPROVED', NULL, 22, 4, 'AS-2011-000078', 'A'),
(33, 1, ' General Description: qwerty', 'APPROVED', NULL, 24, 4, 'AS-2011-000072', 'A'),
(34, 1, ' General Description: Asset Printer', 'APPROVED', NULL, 24, 4, 'AS-2011-000074', 'A'),
(35, 27, ' General Description: dvorak', 'APPROVED', NULL, 25, 4, 'AS-2011-000072', 'A'),
(36, 2, ' General Description: 456456', 'APPROVED', NULL, 26, 4, 'AS-2011-000103', 'A'),
(37, 3, ' General Description: First', 'APPROVED', NULL, 27, 2, 'CE-D-000082', 'P'),
(38, 1, ' General Description: qwert', 'APPROVED', NULL, 28, 2, 'CE-K-000005', 'P'),
(39, 1, ' General Description: Monitor, Screen Size: 17 inches, Resolution: 640x480', 'APPROVED', NULL, 28, 2, 'CE-M-000001', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `pr_header`
--

CREATE TABLE IF NOT EXISTS `pr_header` (
  `PR_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PR_HDR_NO` varchar(20) DEFAULT NULL,
  `PR_HDR_DATE_REQUESTED` date DEFAULT NULL,
  `PR_HDR_DATE_NEEDED` date DEFAULT NULL,
  `PR_HDR_DATE_CREATED` date DEFAULT NULL,
  `PR_HDR_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `PR_HDR_REQUESTOR_ID` int(11) DEFAULT '0',
  `PR_HDR_CREATED_BY_ID` int(11) DEFAULT '0',
  `PR_HDR_APPROVED_BY_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`PR_HDR_ID`),
  KEY `PR_HDR_REQUESTOR_ID` (`PR_HDR_REQUESTOR_ID`),
  KEY `PR_HDR_CREATED_BY_ID` (`PR_HDR_CREATED_BY_ID`),
  KEY `PR_HDR_APPROVED_BY_ID` (`PR_HDR_APPROVED_BY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `pr_header`
--

INSERT INTO `pr_header` (`PR_HDR_ID`, `PR_HDR_NO`, `PR_HDR_DATE_REQUESTED`, `PR_HDR_DATE_NEEDED`, `PR_HDR_DATE_CREATED`, `PR_HDR_REMARKS`, `IS_DELETED`, `PR_HDR_REQUESTOR_ID`, `PR_HDR_CREATED_BY_ID`, `PR_HDR_APPROVED_BY_ID`) VALUES
(1, '1', '2011-09-15', '2011-09-24', '2011-09-30', NULL, 0, 1, 1, 1),
(2, 'PR-2011-000002', '2011-11-11', '2011-11-26', '2011-11-11', 'Try lang to!', 0, 1, 1, 1),
(3, 'PR-2011-000003', '2011-11-11', '2011-11-26', '2011-11-11', 'yay', 0, 1, 1, 1),
(4, 'PR-2011-000004', '2011-11-22', '2011-11-30', '2011-11-22', 'weeeeee', 0, 1, 1, 1),
(5, 'PR-2011-000005', '2011-11-22', '2011-11-30', '2011-11-22', 'sdgfdgdfgs', 0, 1, 1, 1),
(6, 'PR-2011-000006', '2011-11-23', '2011-11-30', '2011-11-23', 'aaaaaaaaa', 0, 1, 1, 1),
(7, 'PR-2011-000007', '2011-11-23', '2011-11-26', '2011-11-23', 'Wooohoooo', 0, 1, 1, 1),
(8, 'PR-2011-000008', '2011-11-23', '2011-11-26', '2011-11-23', 'ahihi', 0, 1, 1, 1),
(9, 'PR-2011-000009', '2011-11-23', '2011-11-25', '2011-11-23', 'cvcxvcx', 0, 1, 1, 1),
(10, 'PR-2011-000010', '2011-11-23', '2011-11-26', '2011-11-23', 'dsfsdfds', 0, 1, 1, 1),
(11, 'PR-2011-000011', '2011-11-23', '2011-11-26', '2011-11-23', 'ahihihihi', 0, 1, 1, 1),
(12, 'PR-2011-000012', '2011-12-01', '2011-12-31', '2011-12-01', 'receiving', 0, 15, 1, 1),
(13, 'PR-2011-000013', '2011-12-01', '2011-12-31', '2011-12-01', '', 0, 16, 1, 1),
(14, 'PR-2011-000014', '2011-12-01', '2011-12-31', '2011-12-01', 'gggg', 0, 16, 1, 1),
(15, 'PR-2011-000015', '2011-12-01', '2011-12-24', '2011-12-01', '123456', 0, 1, 1, 1),
(16, 'PR-2011-000016', '2011-12-06', '2011-12-07', '2011-12-06', 'Personal Items', 1, 1, 1, 1),
(17, 'PR-2011-000017', '2011-12-06', '2011-12-23', '2011-12-06', 'Personal Items', 1, 1, 1, 1),
(18, 'PR-2011-000018', '2011-12-06', '2011-12-31', '2011-12-06', 'Personal Items', 0, 1, 1, 1),
(19, 'PR-2011-000019', '2011-12-07', '2011-12-30', '2011-12-07', 'yeyey', 1, 1, 15, 15),
(20, 'PR-2011-000020', '2011-12-07', '2011-12-30', '2011-12-07', 'woooo', 1, 14, 15, 15),
(21, 'PR-2011-000021', '2011-12-07', '2011-12-29', '2011-12-07', '', 0, 16, 15, 15),
(22, 'PR-2011-000022', '2011-12-07', '2011-12-26', '2011-12-07', 'ghfg', 0, 27, 15, 15),
(23, 'PR-2011-000023', '2011-12-16', '2011-12-29', '2011-12-16', 'Woooooo!', 0, 1, 15, NULL),
(24, 'PR-2011-000024', '2011-12-16', '2011-12-31', '2011-12-16', 'huhuhu', 0, 1, 15, 27),
(25, 'PR-2011-000025', '2011-12-19', '2011-12-20', '2011-12-19', '', 0, 27, 27, 27),
(26, 'PR-2011-000026', '2011-12-20', '2011-12-21', '2011-12-20', '', 0, 1, 27, 27),
(27, 'PR-2011-000027', '2011-12-20', '2011-12-21', '2011-12-20', '', 0, 1, 27, 27),
(28, 'PR-2011-000028', '2011-12-20', '2011-12-21', '2011-12-20', '', 0, 1, 27, 27);

-- --------------------------------------------------------

--
-- Table structure for table `receive_item`
--

CREATE TABLE IF NOT EXISTS `receive_item` (
  `QTY` int(11) DEFAULT NULL,
  `UNIT_ID` int(11) DEFAULT '0',
  `ITEM_ID` int(11) DEFAULT '0',
  `REF_NO` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receiving_detail`
--

CREATE TABLE IF NOT EXISTS `receiving_detail` (
  `REC_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `REC_DTL_QTY` int(11) DEFAULT '0',
  `REC_DTL_ITEM_DESCRIPTION` text,
  `REC_HDR_ID` int(11) DEFAULT '0',
  `UNIT_ID` int(11) DEFAULT '0',
  `ITEM_CODE` varchar(20) DEFAULT NULL,
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`REC_DTL_ID`),
  KEY `REC_HDR_ID` (`REC_HDR_ID`),
  KEY `UNIT_ID` (`UNIT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `receiving_detail`
--

INSERT INTO `receiving_detail` (`REC_DTL_ID`, `REC_DTL_QTY`, `REC_DTL_ITEM_DESCRIPTION`, `REC_HDR_ID`, `UNIT_ID`, `ITEM_CODE`, `ITEM_FLAG`) VALUES
(8, 1, ' General Description: 9', 3, 2, 'AS-2011-000004', NULL),
(9, 1, ' General Description: 42, Screen Size: 42', 3, 2, 'AS-2011-000042', NULL),
(10, 1, ' General Description: TEST1, Size: TEST2, GSM: TEST3', 3, 4, 'AS-2011-000054', NULL),
(11, 1, ' General Description: 9', 4, 2, 'AS-2011-000004', NULL),
(12, 1, ' General Description: 42, Screen Size: 42', 4, 2, 'AS-2011-000042', NULL),
(13, 1, ' General Description: TEST1, Size: TEST2, GSM: TEST3', 4, 4, 'AS-2011-000054', NULL),
(14, 1, ' Screen Size: 34', 4, 4, 'AS-2011-000057', NULL),
(15, 1, ' General Description: Monitor', 4, 4, 'AS-2011-000058', NULL),
(16, 1, ' General Description: Ballpen', 4, 2, 'AS-2011-000061', NULL),
(17, 1, ' General Description: Monitor', 4, 4, 'AS-2011-000058', NULL),
(18, 2, ' General Description: TEST1, Size: TEST2, GSM: TEST3', 5, 4, 'AS-2011-000054', NULL),
(19, 1, ' General Description: 9', 5, 2, 'AS-2011-000004', NULL),
(20, 3, ' General Description: 42, Screen Size: 42', 5, 2, 'AS-2011-000042', NULL),
(21, 4, ' General Description: Monitor', 5, 4, 'AS-2011-000058', NULL),
(22, 5, ' General Description: Ballpen', 5, 2, 'AS-2011-000061', NULL),
(23, 4, ' Screen Size: 34', 5, 4, 'AS-2011-000057', NULL),
(24, 6, ' General Description: Ballpen', 5, 2, 'AS-2011-000061', NULL),
(25, 2, ' General Description: 42, Screen Size: 42', 5, 4, 'AS-2011-000042', NULL),
(26, 3, ' General Description: TEST1, Size: TEST2, GSM: TEST3', 6, 4, 'AS-2011-000054', NULL),
(27, 1, ' General Description: jhutf', 6, 6, 'CE-K-000056', NULL),
(28, 1, ' General Description: Monitor', 6, 4, 'AS-2011-000058', NULL),
(29, 1, ' General Description: Monitor', 6, 4, 'AS-2011-000058', NULL),
(30, 1, ' General Description: 9', 7, 2, 'AS-2011-000004', NULL),
(31, 1, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 7, 4, 'CE-M-1', NULL),
(32, 1, ' General Description: Acer Keyboard HKB.0013.002', 7, 4, 'CE-K-4', NULL),
(33, 2, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 7, 4, 'CE-M-1', NULL),
(34, 1, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 7, 4, 'CE-M-1', NULL),
(35, 1, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 7, 4, 'CE-M-1', NULL),
(36, 4, ' General Description: LG M22W7A, Screen Size: 21.5, Resolution: 1920x1080', 7, 4, 'CE-M-1', NULL),
(37, 8, ' General Description: Monitor', 8, 4, 'AS-2011-000058', NULL),
(38, 6, ' General Description: Monitor', 9, 4, 'AS-2011-000058', NULL),
(39, 5, ' General Description: Monitor', 10, 4, 'AS-2011-000058', NULL),
(40, 6, ' General Description: Monitor', 11, 4, 'AS-2011-000058', NULL),
(41, 5, ' General Description: Monitor', 12, 4, 'AS-2011-000058', NULL),
(42, 2, ' General Description: jhutf', 12, 6, 'CE-K-000056', NULL),
(43, 5, ' General Description: Monitor', 13, 4, 'AS-2011-000058', NULL),
(44, 3, ' General Description: jhutf', 13, 6, 'CE-K-000056', NULL),
(45, 8, ' General Description: 42, Screen Size: 42', 14, 4, 'AS-2011-000042', NULL),
(46, 9, ' General Description: 42, Screen Size: 42', 15, 4, 'AS-2011-000042', NULL),
(47, 3, ' General Description: 42, Screen Size: 42', 16, 4, 'AS-2011-000042', NULL),
(48, 10, ' General Description: Ballpen', 16, 2, 'AS-2011-000061', NULL),
(49, 15, ' General Description: 9', 16, 2, 'AS-2011-000004', NULL),
(50, 0, ' General Description: Monitor', 17, 4, 'AS-2011-000058', NULL),
(51, 0, ' General Description: 42, Screen Size: 42', 18, 4, 'AS-2011-000042', NULL),
(52, 1, ' General Description: .5 point', 19, 2, 'AS-2011-000076', NULL),
(53, 1, ' Resolution: 768x680', 19, 4, 'AS-2011-000078', NULL),
(54, 1, ' General Description: Asset Printer', 19, 4, 'AS-2011-000074', NULL),
(55, 1, ' General Description: HBW', 19, 2, 'AS-2011-000077', NULL),
(56, 1, ' General Description: qwerty', 19, 4, 'AS-2011-000072', NULL),
(57, 1, ' General Description: qwerty', 20, 4, 'AS-2011-000072', NULL),
(58, 200, '', 21, 2, 'AS-2011-000076', NULL),
(59, 1, ' General Description: qwerty', 22, 4, 'AS-2011-000072', NULL),
(60, 2, ' General Description: qwerty', 23, 4, 'AS-2011-000072', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `receiving_header`
--

CREATE TABLE IF NOT EXISTS `receiving_header` (
  `REC_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `REC_HDR_NO` varchar(20) DEFAULT NULL,
  `REC_HDR_DATE` date DEFAULT NULL,
  `REC_HDR_RECEIVED_REF_TYPE` varchar(10) DEFAULT NULL,
  `REC_HDR_RECEIVED_REF_NO` varchar(20) DEFAULT NULL,
  `REC_HDR_RECEIVED_REF` varchar(10) DEFAULT NULL,
  `REC_HDR_REMARKS` text,
  `REC_HDR_RECEIVED_FROM` varchar(20) NOT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `CONTACT_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`REC_HDR_ID`),
  KEY `REC_HDR_RECEIVED_FROM_ID` (`REC_HDR_RECEIVED_FROM`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `receiving_header`
--

INSERT INTO `receiving_header` (`REC_HDR_ID`, `REC_HDR_NO`, `REC_HDR_DATE`, `REC_HDR_RECEIVED_REF_TYPE`, `REC_HDR_RECEIVED_REF_NO`, `REC_HDR_RECEIVED_REF`, `REC_HDR_REMARKS`, `REC_HDR_RECEIVED_FROM`, `IS_DELETED`, `CONTACT_ID`) VALUES
(3, 'REC-2011-000001', '2011-11-23', 'Customer', 'WITH-2011-000002', 'WD', '', '20111202-00002', 0, 5),
(4, 'REC-2011-000004', '2011-11-24', 'Customer', 'WITH-2011-000005', 'WD', '', '20110209-00001', 0, 1),
(5, 'REC-2011-000005', '2011-11-28', 'Customer', 'WITH-2011-000007', 'WD', '', '20110412-00004', 0, 2),
(6, 'REC-2011-000006', '2011-11-28', 'Customer', 'WITH-2011-000004', 'WD', '', '20110612-00008', 0, 0),
(7, 'REC-2011-000007', '2011-12-01', 'Customer', 'WITH-2011-000004', 'WD', '', '20110612-00008', 0, 0),
(8, 'REC-2011-000008', '2011-12-01', 'Supplier', 'PO-2011-000011', 'PO', '', 'S1', 0, 0),
(9, 'REC-2011-000009', '2011-12-01', 'Supplier', 'PO-2011-000014', 'PO', '', 'SP-000009', 0, 0),
(10, 'REC-2011-000010', '2011-12-01', 'Supplier', 'PO-2011-000014', 'PO', '', 'SP-000009', 0, 0),
(11, 'REC-2011-000011', '2011-12-01', 'Supplier', 'PO-2011-000014', 'PO', '', 'SP-000009', 0, 0),
(12, 'REC-2011-000012', '2011-12-01', 'Supplier', 'PO-2011-000015', 'PO', '', 'S1', 0, 0),
(13, 'REC-2011-000013', '2011-12-01', 'Supplier', 'PO-2011-000015', 'PO', '', 'S1', 0, 0),
(14, 'REC-2011-000014', '2011-12-01', 'Supplier', 'PO-2011-000016', 'PO', '', 'SP-000009', 0, 0),
(15, 'REC-2011-000015', '2011-12-01', 'Supplier', 'PO-2011-000016', 'PO', '', 'SP-000009', 0, 0),
(16, 'REC-2011-000016', '2011-12-01', 'Supplier', 'PO-2011-000016', 'PO', '', 'SP-000009', 0, 0),
(17, 'REC-2011-000017', '2011-12-06', 'Supplier', 'PO-2011-000012', 'PO', '', 'S1', 0, 0),
(18, 'REC-2011-000018', '2011-12-06', 'Customer', 'WITH-2011-000002', 'WD', '', '20111202-00002', 0, 5),
(19, 'REC-2011-000019', '2011-12-07', 'Employee', 'WITH-2011-000023', 'WD', '', 'EMP-10-000001', 0, 0),
(20, 'REC-2011-000020', '2011-12-09', 'Employee', 'WITH-2011-000025', 'WD', '', 'EMP-2011FD-000027', 0, 0),
(21, 'REC-2011-000021', '2011-12-09', 'Customer', 'WITH-2011-000027', 'WD', '', '20110412-00004', 0, 2),
(22, 'REC-2011-000022', '2011-12-19', 'Customer', 'WITH-2011-000031', 'WD', 'haha', '20111202-00002', 0, 5),
(23, 'REC-2011-000023', '2011-12-19', 'Customer', 'WITH-2011-000031', 'WD', '', '20111202-00002', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `request_item`
--

CREATE TABLE IF NOT EXISTS `request_item` (
  `ITEM_CODE` varchar(20) DEFAULT NULL,
  `ITEM_QTY` int(11) DEFAULT NULL,
  `BRAND_ID` int(11) DEFAULT NULL,
  `CATEGORY_ID` int(11) DEFAULT NULL,
  `SUB_CATEGORY_ID` int(11) DEFAULT NULL,
  `ITEM_DESCRIPTION` text,
  `UNIT_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supplier_profile`
--

CREATE TABLE IF NOT EXISTS `supplier_profile` (
  `SUPPLIER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `SUPPLIER_CODE` varchar(20) DEFAULT NULL,
  `SUPPLIER_NAME` varchar(150) DEFAULT NULL,
  `SUPPLIER_EMAIL_ADDRESS` varchar(150) DEFAULT NULL,
  `SUPPLIER_PHONE_NO` varchar(100) DEFAULT NULL,
  `SUPPLIER_MOBILE_NO` varchar(100) DEFAULT NULL,
  `SUPPLIER_FAX_NO` varchar(100) DEFAULT NULL,
  `SUPPLIER_REMARKS` text,
  `IS_ACTIVE` tinyint(1) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `INDUSTRY_TYPE_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`SUPPLIER_ID`),
  KEY `INDUSTRY_TYPE_ID` (`INDUSTRY_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `supplier_profile`
--

INSERT INTO `supplier_profile` (`SUPPLIER_ID`, `SUPPLIER_CODE`, `SUPPLIER_NAME`, `SUPPLIER_EMAIL_ADDRESS`, `SUPPLIER_PHONE_NO`, `SUPPLIER_MOBILE_NO`, `SUPPLIER_FAX_NO`, `SUPPLIER_REMARKS`, `IS_ACTIVE`, `IS_DELETED`, `INDUSTRY_TYPE_ID`) VALUES
(1, 'S1', 'Happy Muñoz', 'yehey@yahoo.com', '123456789', '2312477898080', '43872467832', 'treter', 1, 0, 2),
(8, 'SP-000002', 'Mr. Supplier', 'supp@yahoo.com', '456', '231677', '123', 'ahuhuhu', 1, 0, 3),
(9, 'SP-000009', 'Mr. Supplier', 'supplier@yahoo.com', '8678674', '56456', '3453454', 'ahuhuh', 1, 0, 1),
(10, 'SP-000010', 'Baso', 'baso@yahoo.com', '', '( 63)9268418904', '', '', 1, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `task_reminder`
--

CREATE TABLE IF NOT EXISTS `task_reminder` (
  `TASK_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_ID` int(11) NOT NULL,
  `TASK_ALARM_DATE` date NOT NULL,
  `TASK_ALARM_TIME` time NOT NULL,
  `TASK_CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TASK_SUBJECT` varchar(300) NOT NULL,
  `TASK_REMARKS` varchar(500) DEFAULT NULL,
  `TASK_REPEAT_ID` int(10) unsigned NOT NULL,
  `IS_COMPLETED` tinyint(4) NOT NULL,
  PRIMARY KEY (`TASK_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `task_reminder`
--

INSERT INTO `task_reminder` (`TASK_ID`, `EMP_ID`, `TASK_ALARM_DATE`, `TASK_ALARM_TIME`, `TASK_CREATE_DATE`, `TASK_SUBJECT`, `TASK_REMARKS`, `TASK_REPEAT_ID`, `IS_COMPLETED`) VALUES
(1, 1, '2011-09-09', '16:44:07', '2011-09-11 02:25:12', 'Database Completion', 'Nothing', 1, 1),
(2, 1, '2011-09-15', '08:00:00', '2006-08-15 19:38:27', 'Buy Some stuff', 'This should be at the top of the priority', 2, 1),
(3, 1, '2011-09-09', '16:45:02', '2011-09-11 02:25:52', 'Adding Forms', 'Nothing', 1, 1),
(4, 1, '2011-09-09', '16:45:02', '2011-09-11 02:25:48', 'User Manual', 'Nothing', 1, 1),
(5, 1, '2011-09-10', '16:45:02', '2011-09-11 02:26:04', 'Printing of Necessary Documents', NULL, 1, 1),
(6, 1, '2011-09-10', '16:45:02', '2006-08-15 19:39:49', 'Preparation of Brochure', NULL, 2, 1),
(7, 2, '2011-09-10', '03:45:00', '2006-08-15 19:39:49', 'Printer Repair', '', 2, 1),
(8, 1, '2011-09-15', '08:00:00', '2006-08-15 19:38:27', 'Buy Some stuff', 'This should be at the top of the priority', 2, 1),
(9, 1, '2011-09-09', '16:45:00', '2006-08-15 19:37:01', 'Module Enhancement', 'Nothing', 2, 1),
(10, 1, '2011-09-21', '21:45:00', '2006-08-15 19:39:49', 'Repair PC 3', 'Urgent repair needed! :)', 3, 1),
(11, 1, '2011-09-26', '22:34:00', '2011-09-12 09:02:15', 'Pay bills', 'Money will be provided by Sir Pedraza :))) ', 3, 1),
(12, 1, '2011-09-10', '03:45:00', '2006-08-15 19:39:49', 'Printer Repair', '', 2, 1),
(13, 1, '2011-09-12', '00:00:00', '2006-08-15 19:39:49', 'Buy Laptop', 'Please refer to the brochure', 1, 1),
(14, 1, '2011-09-12', '17:21:00', '2006-08-15 19:39:49', 'Download license drivers', 'See papers on my desk', 1, 1),
(15, 2, '2006-08-03', '00:00:00', '2006-08-15 19:39:44', 'dfdf', 'fdf', 1, 1),
(16, 1, '2011-11-18', '17:14:00', '2011-11-24 09:34:06', '45', '45', 2, 1),
(17, 1, '2011-12-23', '00:00:00', '2011-12-06 07:40:38', 'asdf', 'asdf', 2, 0),
(18, 1, '2011-12-31', '00:00:00', '2011-12-06 07:41:13', 'ffff', 'ffff', 2, 0),
(19, 1, '2011-12-07', '10:05:00', '2011-12-07 02:04:12', 'haha', 'hehe', 1, 0),
(20, 1, '2011-12-21', '00:00:00', '2011-12-21 05:48:03', 'try', 'try', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `task_repeat`
--

CREATE TABLE IF NOT EXISTS `task_repeat` (
  `TASK_REPEAT_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_REPEAT_NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`TASK_REPEAT_ID`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `task_repeat`
--

INSERT INTO `task_repeat` (`TASK_REPEAT_ID`, `TASK_REPEAT_NAME`) VALUES
(1, 'Daily'),
(2, 'Monthly'),
(3, 'Yearly');

-- --------------------------------------------------------

--
-- Table structure for table `training_seminar`
--

CREATE TABLE IF NOT EXISTS `training_seminar` (
  `TRAINING_DATE_RANGE` varchar(100) DEFAULT NULL,
  `TRAINING_DESCRIPTION` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `WORK_EXP_ID` int(11) DEFAULT '0',
  KEY `WORK_EXP_ID` (`WORK_EXP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `UNIT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UNIT_NAME` varchar(100) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`UNIT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`UNIT_ID`, `UNIT_NAME`, `IS_DELETED`) VALUES
(1, 'Gallon', 1),
(2, 'Kilogram', 0),
(3, 'Pounds', 1),
(4, 'Pieces', 0),
(5, 'Box', 0),
(6, 'Liters', 0),
(7, 'Pints', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_level_position`
--

CREATE TABLE IF NOT EXISTS `user_access_level_position` (
  `POSITION_ID` int(11) NOT NULL DEFAULT '0',
  `FORM_ID` int(11) NOT NULL DEFAULT '0',
  `BUTTON_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`POSITION_ID`,`FORM_ID`,`BUTTON_ID`),
  KEY `POSITION_ID` (`POSITION_ID`),
  KEY `FORM_ID` (`FORM_ID`),
  KEY `BUTTON_ID` (`BUTTON_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access_level_position`
--

INSERT INTO `user_access_level_position` (`POSITION_ID`, `FORM_ID`, `BUTTON_ID`) VALUES
(1, 1, 1),
(1, 1, 2),
(2, 1, 1),
(8, 1, 1),
(8, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE IF NOT EXISTS `user_account` (
  `USER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(100) DEFAULT NULL,
  `USER_PASSWORD` text,
  `FORGOT_PASSWORD_QUESTION` varchar(100) DEFAULT NULL,
  `FORGOT_PASSWORD_ANSWER` varchar(100) DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `EMP_ID` int(11) DEFAULT '0',
  `IS_ONLINE` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`USER_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`USER_ID`, `USER_NAME`, `USER_PASSWORD`, `FORGOT_PASSWORD_QUESTION`, `FORGOT_PASSWORD_ANSWER`, `IS_ACTIVE`, `IS_DELETED`, `EMP_ID`, `IS_ONLINE`) VALUES
(1, 'cezar_pedraza', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'What is your first pet''s name?', 'ShinChan', 1, 0, 1, 1),
(9, 'richard_peig', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'What is your favorite snack?', 'Oreo', 1, 0, 2, 0),
(10, 'carl', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'What is your favorite snack?', 'Piattos', 1, 0, 14, 1),
(11, 'ricky', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'What is your favorite snack?', '', 1, 0, 17, 0),
(12, 'janine', '5470719f1bc1fc6d6da720e61b609fe07de07503', 'What is your favorite snack?', 'Taiga', 1, 0, 16, 0),
(13, 'najkie', 'f407bb737d5d75b9b04bc2901f065dcba31f19cc', 'What is your favorite snack?', 'pocky', 1, 0, 15, 1),
(14, 'kaexer', 'bef11c15d125c66b946e133fdbba06946ab7345e', 'What is your pet''s name?', 'Budoy', 1, 0, 26, 0),
(15, 'jason', '68c46a606457643eab92053c1c05574abb26f861', 'What is your favorite snack?', 'batman', 1, 0, 27, 1),
(16, 'jerald_facun', 'ef1f54d85127b2f74e8c48c2a4679acf1b383afa', 'What is your favorite snack?', 'nothing', 1, 0, 36, 0),
(17, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'What is your favorite snack?', 'admin', 1, 0, 38, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_priviledges`
--

CREATE TABLE IF NOT EXISTS `user_priviledges` (
  `USER_ID` int(11) NOT NULL DEFAULT '0',
  `FORM_ID` int(11) NOT NULL DEFAULT '0',
  `BUTTON_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USER_ID`,`FORM_ID`,`BUTTON_ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `FORM_ID` (`FORM_ID`),
  KEY `BUTTON_ID` (`BUTTON_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_priviledges`
--

INSERT INTO `user_priviledges` (`USER_ID`, `FORM_ID`, `BUTTON_ID`) VALUES
(1, 1, 2),
(9, 1, 2),
(12, 1, 1),
(12, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `voucher_detail`
--

CREATE TABLE IF NOT EXISTS `voucher_detail` (
  `VCH_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `VCH_DTL_AMOUNT` double(15,3) DEFAULT '0.000',
  `VCH_DTL_ITEM_DESCRIPTION` text,
  `VCH_HDR_ID` int(11) DEFAULT '0',
  `ACCOUNT_ID` int(11) DEFAULT '0',
  `ACCOUNT_TYPE_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`VCH_DTL_ID`),
  KEY `VCH_HDR_ID` (`VCH_HDR_ID`),
  KEY `ACCOUNT_ID` (`ACCOUNT_ID`),
  KEY `ACCOUNT_TYPE_ID` (`ACCOUNT_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `voucher_header`
--

CREATE TABLE IF NOT EXISTS `voucher_header` (
  `VCH_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `VCH_HDR_NO` varchar(20) DEFAULT NULL,
  `VCH_HDR_DATE` date DEFAULT NULL,
  `VCH_HDR_PARTICULAR` varchar(200) DEFAULT NULL,
  `VCH_HDR_DESCRIPTION` text,
  `VCH_HDR_REF_NO` varchar(20) DEFAULT NULL,
  `VCH_HDR_REF_TYPE` varchar(10) DEFAULT NULL,
  `VCH_HDR_AMOUNT` double(15,3) DEFAULT '0.000',
  `VCH_HDR_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `VCH_HDR_CREATED_BY_ID` int(11) DEFAULT '0',
  `VCH_HDR_APPROVED_BY_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`VCH_HDR_ID`),
  KEY `VCH_HDR_CREATED_BY_ID` (`VCH_HDR_CREATED_BY_ID`),
  KEY `VCH_HDR_APPROVED_BY_ID` (`VCH_HDR_APPROVED_BY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `withdrawal_detail`
--

CREATE TABLE IF NOT EXISTS `withdrawal_detail` (
  `WITH_DTL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `WITH_DTL_QTY` int(11) DEFAULT '0',
  `WITH_DTL_ORIGINAL_QTY` int(11) DEFAULT '0',
  `WITH_DTL_ITEM_DESCRIPTION` text,
  `WITH_DTL_REMARKS` text,
  `WITH_HDR_ID` int(11) DEFAULT '0',
  `UNIT_ID` int(11) DEFAULT '0',
  `ITEM_CODE` varchar(20) DEFAULT NULL,
  `ITEM_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`WITH_DTL_ID`),
  KEY `WITH_HDR_ID` (`WITH_HDR_ID`),
  KEY `UNIT_ID` (`UNIT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `withdrawal_detail`
--

INSERT INTO `withdrawal_detail` (`WITH_DTL_ID`, `WITH_DTL_QTY`, `WITH_DTL_ORIGINAL_QTY`, `WITH_DTL_ITEM_DESCRIPTION`, `WITH_DTL_REMARKS`, `WITH_HDR_ID`, `UNIT_ID`, `ITEM_CODE`, `ITEM_FLAG`) VALUES
(1, 0, 1, ' General Description: Ballpen', NULL, 1, 2, 'AS-2011-000061', NULL),
(2, 0, 1, ' General Description: Monitor', NULL, 1, 4, 'AS-2011-000058', NULL),
(3, 0, 1, ' General Description: 9', NULL, 2, 2, 'AS-2011-000004', NULL),
(4, 0, 1, ' General Description: 42, Screen Size: 42', NULL, 2, 2, 'AS-2011-000042', NULL),
(5, 0, 1, ' General Description: TEST1, Size: TEST2, GSM: TEST3', NULL, 2, 4, 'AS-2011-000054', NULL),
(6, 1, 1, ' Screen Size: 34', NULL, 3, 4, 'AS-2011-000057', NULL),
(7, 0, 1, ' General Description: Monitor', NULL, 3, 4, 'AS-2011-000058', NULL),
(8, 1, 1, ' General Description: Ballpen', NULL, 3, 2, 'AS-2011-000061', NULL),
(9, 0, 2, ' General Description: 42, Screen Size: 42', NULL, 4, 2, 'AS-2011-000042', NULL),
(10, 0, 1, ' General Description: 9', NULL, 4, 2, 'AS-2011-000004', NULL),
(11, 0, 3, ' General Description: TEST1, Size: TEST2, GSM: TEST3', NULL, 4, 4, 'AS-2011-000054', NULL),
(12, 0, 4, ' Screen Size: 34', NULL, 4, 4, 'AS-2011-000057', NULL),
(13, 5, 5, ' General Description: Monitor', NULL, 4, 4, 'AS-2011-000058', NULL),
(14, 0, 6, ' General Description: Ballpen', NULL, 4, 2, 'AS-2011-000061', NULL),
(15, 0, 1, ' General Description: 9', NULL, 5, 2, 'AS-2011-000004', NULL),
(16, 0, 1, ' General Description: 42, Screen Size: 42', NULL, 5, 2, 'AS-2011-000042', NULL),
(17, 0, 1, ' General Description: TEST1, Size: TEST2, GSM: TEST3', NULL, 5, 4, 'AS-2011-000054', NULL),
(18, 0, 1, ' Screen Size: 34', NULL, 5, 4, 'AS-2011-000057', NULL),
(19, 0, 1, ' General Description: Monitor', NULL, 5, 4, 'AS-2011-000058', NULL),
(20, 0, 1, ' General Description: Ballpen', NULL, 5, 2, 'AS-2011-000061', NULL),
(21, 1, 1, ' General Description: 42, Screen Size: 42', NULL, 6, 2, 'AS-2011-000042', NULL),
(22, 2, 2, ' General Description: 9', NULL, 6, 2, 'AS-2011-000004', NULL),
(23, 0, 2, ' General Description: TEST1, Size: TEST2, GSM: TEST3', NULL, 7, 4, 'AS-2011-000054', NULL),
(24, 0, 1, ' General Description: 9', NULL, 7, 2, 'AS-2011-000004', NULL),
(25, 0, 3, ' General Description: 42, Screen Size: 42', NULL, 7, 2, 'AS-2011-000042', NULL),
(26, 0, 4, ' General Description: Monitor', NULL, 7, 4, 'AS-2011-000058', NULL),
(27, 0, 5, ' General Description: Ballpen', NULL, 7, 2, 'AS-2011-000061', NULL),
(28, 1, 1, ' General Description: 42, Screen Size: 42', NULL, 7, 4, 'AS-2011-000042', NULL),
(29, 1, 1, ' General Description: 9', NULL, 9, 2, 'AS-2011-000004', NULL),
(30, 1, 1, ' General Description: 9', NULL, 9, 2, 'AS-2011-000004', NULL),
(31, 2, 2, ' General Description: 42, Screen Size: 42', NULL, 11, 4, 'AS-2011-000042', NULL),
(32, 5, 5, ' General Description: Ballpen', NULL, 11, 2, 'AS-2011-000061', NULL),
(33, 1, 1, ' General Description: Ballpen', NULL, 13, 2, 'AS-2011-000061', NULL),
(34, 1, 1, ' General Description: Ballpen', NULL, 14, 2, 'AS-2011-000061', NULL),
(35, 3, 3, ' General Description: Ballpen', NULL, 15, 2, 'AS-2011-000061', NULL),
(36, 9, 9, ' General Description: Ballpen', NULL, 16, 2, 'AS-2011-000061', NULL),
(37, 5, 5, ' General Description: Ballpen', NULL, 17, 2, 'AS-2011-000061', NULL),
(38, 11, 11, ' General Description: Ballpen', NULL, 18, 2, 'AS-2011-000061', NULL),
(39, 4, 4, ' General Description: 9', NULL, 19, 2, 'AS-2011-000004', NULL),
(40, 1, 1, ' General Description: 9', NULL, 20, 2, 'AS-2011-000004', NULL),
(41, 27, 27, ' General Description: 42, Screen Size: 42', NULL, 20, 4, 'AS-2011-000042', NULL),
(42, 9, 9, ' General Description: 42, Screen Size: 42', NULL, 21, 4, 'AS-2011-000042', NULL),
(43, 1, 1, ' General Description: TEST1, Size: TEST2, GSM: TEST3', NULL, 22, 4, 'AS-2011-000054', NULL),
(44, 0, 1, ' General Description: .5 point', NULL, 23, 2, 'AS-2011-000076', NULL),
(45, 0, 1, ' General Description: qwerty', NULL, 23, 4, 'AS-2011-000072', NULL),
(46, 0, 1, ' General Description: Asset Printer', NULL, 23, 4, 'AS-2011-000074', NULL),
(47, 0, 1, ' Resolution: 768x680', NULL, 23, 4, 'AS-2011-000078', NULL),
(48, 0, 1, ' General Description: HBW', NULL, 23, 2, 'AS-2011-000077', NULL),
(49, 1, 1, ' General Description: .5 point', NULL, 24, 2, 'AS-2011-000076', NULL),
(50, 1, 1, ' General Description: Asset Printer', NULL, 24, 4, 'AS-2011-000074', NULL),
(51, 1, 1, ' General Description: .5 point', NULL, 25, 2, 'AS-2011-000076', NULL),
(52, 0, 1, ' General Description: qwerty', NULL, 25, 4, 'AS-2011-000072', NULL),
(53, 1, 1, ' General Description: Asset Printer', NULL, 25, 4, 'AS-2011-000074', NULL),
(54, 3, 3, '', NULL, 26, 2, 'AS-2011-000076', NULL),
(55, 2, 2, '', NULL, 26, 4, 'AS-2011-000074', NULL),
(56, 4, 4, '', NULL, 26, 2, 'AS-2011-000077', NULL),
(57, 5, 5, '', NULL, 26, 2, 'AS-2011-000078', NULL),
(58, 1, 1, '', NULL, 26, 4, 'AS-2011-000072', NULL),
(59, 6, 6, '', NULL, 26, 4, 'CE-P-000073', NULL),
(60, 0, 200, '', NULL, 27, 2, 'AS-2011-000076', NULL),
(61, 11, 11, '', NULL, 28, 2, 'AS-2011-000076', NULL),
(62, 3, 3, ' General Description: .5 point', NULL, 29, 2, 'AS-2011-000076', NULL),
(63, 2, 2, ' General Description: .5 point', NULL, 30, 2, 'AS-2011-000076', NULL),
(64, 2, 5, ' General Description: qwerty', NULL, 31, 4, 'AS-2011-000072', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `withdrawal_header`
--

CREATE TABLE IF NOT EXISTS `withdrawal_header` (
  `WITH_HDR_ID` int(11) NOT NULL AUTO_INCREMENT,
  `WITH_HDR_NO` varchar(20) DEFAULT NULL,
  `WITH_HDR_DATE_ISSUED` date DEFAULT NULL,
  `WITH_HDR_TYPE` varchar(10) DEFAULT NULL,
  `WITH_HDR_PURPOSE` varchar(20) DEFAULT NULL,
  `WITH_HDR_REMARKS` text,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `WITH_HDR_ISSUED_BY_ID` int(11) DEFAULT NULL,
  `WITH_HDR_ISSUED_TO` varchar(20) DEFAULT NULL,
  `LOCATION_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`WITH_HDR_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `withdrawal_header`
--

INSERT INTO `withdrawal_header` (`WITH_HDR_ID`, `WITH_HDR_NO`, `WITH_HDR_DATE_ISSUED`, `WITH_HDR_TYPE`, `WITH_HDR_PURPOSE`, `WITH_HDR_REMARKS`, `IS_DELETED`, `WITH_HDR_ISSUED_BY_ID`, `WITH_HDR_ISSUED_TO`, `LOCATION_ID`) VALUES
(1, 'WITH-2011-000001', '2011-11-23', 'Customer', 'Dispose', '', 0, 1, '20110610-00005', 5),
(2, 'WITH-2011-000002', '2011-11-23', 'Customer', 'Dispose', '', 0, 1, '20111202-00002', 2),
(3, 'WITH-2011-000003', '2011-11-23', 'Employee', 'Dispose', '', 0, 1, 'EMP-10-000001', NULL),
(4, 'WITH-2011-000004', '2011-11-24', 'Customer', 'Dispose', '', 0, 1, '20110612-00008', 8),
(5, 'WITH-2011-000005', '2011-11-24', 'Customer', 'Dispose', '', 0, 1, '20110209-00001', 1),
(6, 'WITH-2011-000006', '2011-11-28', 'Customer', 'Issue Item', '', 0, 1, '20110412-00004', 4),
(7, 'WITH-2011-000007', '2011-11-28', 'Customer', 'Dispose', '', 0, 1, '20110412-00004', 4),
(8, 'WITH-2011-000008', '2011-11-29', 'Supplier', 'Issue Item', 'Ahihi', 0, 1, 'SP-000009', NULL),
(9, 'WITH-2011-000009', '2011-11-29', 'Supplier', 'Issue Item', 'hdthdghg', 0, 1, 'S1', NULL),
(10, 'WITH-2011-000010', '2011-11-29', 'Supplier', 'Dispose', 'ahuhuhu', 0, 1, 'SP-000009', NULL),
(11, 'WITH-2011-000011', '2011-11-29', 'Employee', 'Dispose', '', 0, 1, 'EMP-2011FD-000014', NULL),
(12, 'WITH-2011-000012', '2011-11-29', 'Customer', 'Dispose', '', 0, 1, '20111202-00002', 2),
(13, 'WITH-2011-000013', '2011-11-29', 'Customer', 'Dispose', '', 0, 1, '20110412-00004', 4),
(14, 'WITH-2011-000014', '2011-11-29', 'Customer', 'Dispose', '', 0, 1, '20110612-00008', 8),
(15, 'WITH-2011-000015', '2011-11-29', 'Supplier', 'Issue Item', '', 0, 1, 'SP-000009', NULL),
(16, 'WITH-2011-000016', '2011-12-01', 'Customer', 'Issue Item', '', 0, 1, '20110412-00004', 4),
(17, 'WITH-2011-000017', '2011-12-06', 'Customer', 'Issue Item', '', 0, 1, '20110412-00004', 4),
(18, 'WITH-2011-000018', '2011-12-06', 'Supplier', 'Repair', '', 0, 1, 'S1', NULL),
(19, 'WITH-2011-000019', '2011-12-06', 'Employee', 'Dispose', '', 0, 1, 'EMP-11-000002', NULL),
(20, 'WITH-2011-000020', '2011-12-06', 'Employee', 'Dispose', '', 0, 1, 'EMP-10-000001', NULL),
(21, 'WITH-2011-000021', '2011-12-06', 'Customer', 'Issue Item', '', 0, 1, '20111202-00002', 2),
(22, 'WITH-2011-000022', '2011-12-06', 'Employee', 'Repair', '', 0, 1, 'EMP-10-000001', NULL),
(23, 'WITH-2011-000023', '2011-12-07', 'Employee', 'Dispose', '', 0, 26, 'EMP-10-000001', NULL),
(24, 'WITH-2011-000024', '2011-12-08', 'Customer', 'Issue Item', '', 0, 1, '20110209-00001', 1),
(25, 'WITH-2011-000025', '2011-12-09', 'Employee', 'Dispose', '', 0, 27, 'EMP-2011FD-000027', NULL),
(26, 'WITH-2011-000026', '2011-12-09', 'Employee', 'Dispose', '', 0, 1, 'EMP-2011FD-000017', NULL),
(27, 'WITH-2011-000027', '2011-12-09', 'Customer', 'Dispose', '', 0, 27, '20110412-00004', 4),
(28, 'WITH-2011-000028', '2011-12-09', 'Customer', 'Dispose', '', 0, 27, '20110101-00007', 7),
(29, 'WITH-2011-000029', '2011-12-09', 'Customer', 'Dispose', '', 0, 27, '20111202-00002', 2),
(30, 'WITH-2011-000030', '2011-12-09', 'Customer', 'Dispose', '', 0, 27, '20111202-00002', 2),
(31, 'WITH-2011-000031', '2011-12-19', 'Customer', 'Issue Item', '', 0, 27, '20111202-00002', 2);

-- --------------------------------------------------------

--
-- Table structure for table `work_experience`
--

CREATE TABLE IF NOT EXISTS `work_experience` (
  `WORK_EXP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `WORK_EXP_DESCRIPTION` text,
  `WORK_COMPANY_NAME` varchar(100) DEFAULT NULL,
  `WORK_EXP_FROM_DATE` date DEFAULT NULL,
  `WORK_EXP_TO_DATE` date DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `EMP_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`WORK_EXP_ID`),
  KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `work_experience`
--

INSERT INTO `work_experience` (`WORK_EXP_ID`, `WORK_EXP_DESCRIPTION`, `WORK_COMPANY_NAME`, `WORK_EXP_FROM_DATE`, `WORK_EXP_TO_DATE`, `IS_DELETED`, `EMP_ID`) VALUES
(34, 'Programmer', 'IBM', '2011-12-01', '2011-12-07', 0, 36),
(35, '234234', '234', '2011-06-15', '2011-12-15', 0, 37),
(36, 'dsa', 'fdash', '2011-12-07', '2011-12-21', 0, 38);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account_listing`
--
ALTER TABLE `account_listing`
  ADD CONSTRAINT `account_listing_ibfk_1` FOREIGN KEY (`ACCOUNT_TYPE_ID`) REFERENCES `account_type` (`ACCOUNT_TYPE_ID`),
  ADD CONSTRAINT `account_listing_ibfk_2` FOREIGN KEY (`ACCOUNT_ID`) REFERENCES `account` (`ACCOUNT_ID`),
  ADD CONSTRAINT `account_listing_ibfk_3` FOREIGN KEY (`PAYMENT_ID`) REFERENCES `payment` (`PAYMENT_ID`);

--
-- Constraints for table `account_sub_category`
--
ALTER TABLE `account_sub_category`
  ADD CONSTRAINT `account_sub_category_ibfk_1` FOREIGN KEY (`ACCOUNT_CATEGORY_ID`) REFERENCES `account_category` (`ACCOUNT_CATEGORY_ID`),
  ADD CONSTRAINT `account_sub_category_ibfk_2` FOREIGN KEY (`ACCOUNT_TYPE_ID`) REFERENCES `account_type` (`ACCOUNT_TYPE_ID`);

--
-- Constraints for table `adjustment_detail`
--
ALTER TABLE `adjustment_detail`
  ADD CONSTRAINT `adjustment_detail_ibfk_1` FOREIGN KEY (`ADJ_HDR_ID`) REFERENCES `adjustment_header` (`ADJ_HDR_ID`);

--
-- Constraints for table `adjustment_header`
--
ALTER TABLE `adjustment_header`
  ADD CONSTRAINT `adjustment_header_ibfk_1` FOREIGN KEY (`ADJ_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `approvers_list`
--
ALTER TABLE `approvers_list`
  ADD CONSTRAINT `approvers_list_ibfk_1` FOREIGN KEY (`APPROVAL_ID`) REFERENCES `approval_list` (`APPROVAL_ID`),
  ADD CONSTRAINT `approvers_list_ibfk_2` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `ap_detail`
--
ALTER TABLE `ap_detail`
  ADD CONSTRAINT `ap_detail_ibfk_1` FOREIGN KEY (`AP_HDR_ID`) REFERENCES `ap_header` (`AP_HDR_ID`),
  ADD CONSTRAINT `ap_detail_ibfk_2` FOREIGN KEY (`ACCOUNT_ID`) REFERENCES `account` (`ACCOUNT_ID`);

--
-- Constraints for table `ap_header`
--
ALTER TABLE `ap_header`
  ADD CONSTRAINT `ap_header_ibfk_1` FOREIGN KEY (`AP_HDR_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `asset`
--
ALTER TABLE `asset`
  ADD CONSTRAINT `asset_ibfk_1` FOREIGN KEY (`BRAND_ID`) REFERENCES `brand` (`BRAND_ID`),
  ADD CONSTRAINT `asset_ibfk_2` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `asset_ibfk_3` FOREIGN KEY (`SUB_CATEGORY_ID`) REFERENCES `category_sub_category` (`SUB_CATEGORY_ID`),
  ADD CONSTRAINT `asset_ibfk_4` FOREIGN KEY (`UNIT_ID`) REFERENCES `unit` (`UNIT_ID`);

--
-- Constraints for table `audit_trail`
--
ALTER TABLE `audit_trail`
  ADD CONSTRAINT `audit_trail_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `bank_account`
--
ALTER TABLE `bank_account`
  ADD CONSTRAINT `bank_account_ibfk_1` FOREIGN KEY (`BANK_ID`) REFERENCES `bank` (`BANK_ID`);

--
-- Constraints for table `bank_deposit_detail`
--
ALTER TABLE `bank_deposit_detail`
  ADD CONSTRAINT `bank_deposit_detail_ibfk_1` FOREIGN KEY (`BANK_DEPOSIT_HDR_ID`) REFERENCES `bank_deposit_header` (`BANK_DEPOSIT_ID`);

--
-- Constraints for table `bank_deposit_header`
--
ALTER TABLE `bank_deposit_header`
  ADD CONSTRAINT `bank_deposit_header_ibfk_1` FOREIGN KEY (`BANK_ACCOUNT_ID`) REFERENCES `bank_account` (`BANK_ACCOUNT_ID`),
  ADD CONSTRAINT `bank_deposit_header_ibfk_2` FOREIGN KEY (`BANK_DEPOSIT_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `bank_deposit_header_ibfk_3` FOREIGN KEY (`BANK_ID`) REFERENCES `bank` (`BANK_ID`);

--
-- Constraints for table `bank_withdrawal`
--
ALTER TABLE `bank_withdrawal`
  ADD CONSTRAINT `bank_withdrawal_ibfk_1` FOREIGN KEY (`BANK_ID`) REFERENCES `bank` (`BANK_ID`),
  ADD CONSTRAINT `bank_withdrawal_ibfk_2` FOREIGN KEY (`BANK_ACCOUNT_ID`) REFERENCES `bank_account` (`BANK_ACCOUNT_ID`),
  ADD CONSTRAINT `bank_withdrawal_ibfk_3` FOREIGN KEY (`BANK_WITH_WITHDRAWN_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `barangay`
--
ALTER TABLE `barangay`
  ADD CONSTRAINT `barangay_ibfk_1` FOREIGN KEY (`CITY_ID`) REFERENCES `city` (`CITY_ID`);

--
-- Constraints for table `brand`
--
ALTER TABLE `brand`
  ADD CONSTRAINT `brand_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `brand_ibfk_2` FOREIGN KEY (`SUB_CATEGORY_ID`) REFERENCES `category_sub_category` (`SUB_CATEGORY_ID`);

--
-- Constraints for table `category_sub_category`
--
ALTER TABLE `category_sub_category`
  ADD CONSTRAINT `category_sub_category_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`);

--
-- Constraints for table `character_references`
--
ALTER TABLE `character_references`
  ADD CONSTRAINT `character_references_ibfk_1` FOREIGN KEY (`WORK_EXP_ID`) REFERENCES `work_experience` (`WORK_EXP_ID`);

--
-- Constraints for table `check_profile`
--
ALTER TABLE `check_profile`
  ADD CONSTRAINT `check_profile_ibfk_4` FOREIGN KEY (`BANK_ID`) REFERENCES `bank` (`BANK_ID`),
  ADD CONSTRAINT `check_profile_ibfk_5` FOREIGN KEY (`CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `contact_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Constraints for table `customer_profile`
--
ALTER TABLE `customer_profile`
  ADD CONSTRAINT `customer_profile_ibfk_3` FOREIGN KEY (`CUSTOMER_TYPE_ID`) REFERENCES `customer_type` (`CUSTOMER_TYPE_ID`);

--
-- Constraints for table `dr_header`
--
ALTER TABLE `dr_header`
  ADD CONSTRAINT `dr_header_ibfk_12` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customer_profile` (`CUSTOMER_ID`),
  ADD CONSTRAINT `dr_header_ibfk_13` FOREIGN KEY (`DR_HDR_BILL_TO_ID`) REFERENCES `location` (`LOCATION_ID`),
  ADD CONSTRAINT `dr_header_ibfk_14` FOREIGN KEY (`DR_HDR_SHIP_TO_ID`) REFERENCES `location` (`LOCATION_ID`),
  ADD CONSTRAINT `dr_header_ibfk_15` FOREIGN KEY (`DR_HDR_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `educational_background`
--
ALTER TABLE `educational_background`
  ADD CONSTRAINT `educational_background_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `employee_cash_advance`
--
ALTER TABLE `employee_cash_advance`
  ADD CONSTRAINT `employee_cash_advance_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `employee_cash_advance_ibfk_2` FOREIGN KEY (`EMP_CASH_APPROVED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `employee_profile`
--
ALTER TABLE `employee_profile`
  ADD CONSTRAINT `employee_profile_ibfk_1` FOREIGN KEY (`EMP_STATUS_ID`) REFERENCES `emp_status` (`EMP_STATUS_ID`),
  ADD CONSTRAINT `employee_profile_ibfk_2` FOREIGN KEY (`DEPT_ID`) REFERENCES `department` (`DEPT_ID`),
  ADD CONSTRAINT `employee_profile_ibfk_3` FOREIGN KEY (`POSITION_ID`) REFERENCES `position` (`POSITION_ID`);

--
-- Constraints for table `employee_schedule`
--
ALTER TABLE `employee_schedule`
  ADD CONSTRAINT `employee_schedule_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `employee_time_sheet_record`
--
ALTER TABLE `employee_time_sheet_record`
  ADD CONSTRAINT `employee_time_sheet_record_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `form_button`
--
ALTER TABLE `form_button`
  ADD CONSTRAINT `form_button_ibfk_1` FOREIGN KEY (`FORM_ID`) REFERENCES `form` (`FORM_ID`),
  ADD CONSTRAINT `form_button_ibfk_2` FOREIGN KEY (`BUTTON_ID`) REFERENCES `button` (`BUTTON_ID`);

--
-- Constraints for table `general_ledger`
--
ALTER TABLE `general_ledger`
  ADD CONSTRAINT `general_ledger_ibfk_1` FOREIGN KEY (`ACCOUNT_CATEGORY_ID`) REFERENCES `account_category` (`ACCOUNT_CATEGORY_ID`),
  ADD CONSTRAINT `general_ledger_ibfk_2` FOREIGN KEY (`ACCOUNT_SUB_CATEGORY_ID`) REFERENCES `account_sub_category` (`ACCOUNT_SUB_CATEGORY_ID`),
  ADD CONSTRAINT `general_ledger_ibfk_3` FOREIGN KEY (`ACCOUNT_TYPE_ID`) REFERENCES `account_type` (`ACCOUNT_TYPE_ID`);

--
-- Constraints for table `leaves`
--
ALTER TABLE `leaves`
  ADD CONSTRAINT `leaves_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `leaves_ibfk_2` FOREIGN KEY (`LEAVE_TYPE_ID`) REFERENCES `leave_type` (`LEAVE_TYPE_ID`);

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_6` FOREIGN KEY (`AREA_ID`) REFERENCES `area` (`AREA_ID`),
  ADD CONSTRAINT `location_ibfk_7` FOREIGN KEY (`CITY_ID`) REFERENCES `city` (`CITY_ID`),
  ADD CONSTRAINT `location_ibfk_8` FOREIGN KEY (`BARANGAY_ID`) REFERENCES `barangay` (`BARANGAY_ID`),
  ADD CONSTRAINT `location_ibfk_9` FOREIGN KEY (`LOCATION_TYPE_ID`) REFERENCES `location_type` (`LOCATION_TYPE_ID`);

--
-- Constraints for table `os_detail`
--
ALTER TABLE `os_detail`
  ADD CONSTRAINT `os_detail_ibfk_1` FOREIGN KEY (`OS_HDR_ID`) REFERENCES `os_header` (`OS_HDR_NO`);

--
-- Constraints for table `os_header`
--
ALTER TABLE `os_header`
  ADD CONSTRAINT `os_header_ibfk_1` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customer_profile` (`CUSTOMER_ID`),
  ADD CONSTRAINT `os_header_ibfk_2` FOREIGN KEY (`OS_HDR_BILL_TO_ID`) REFERENCES `location` (`LOCATION_ID`),
  ADD CONSTRAINT `os_header_ibfk_3` FOREIGN KEY (`AREA_ID`) REFERENCES `area` (`AREA_ID`),
  ADD CONSTRAINT `os_header_ibfk_4` FOREIGN KEY (`SALES_PERSON_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `os_header_ibfk_5` FOREIGN KEY (`CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `overtime`
--
ALTER TABLE `overtime`
  ADD CONSTRAINT `overtime_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`PAYMENT_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `payroll`
--
ALTER TABLE `payroll`
  ADD CONSTRAINT `payroll_ibfk_1` FOREIGN KEY (`DEPT_ID`) REFERENCES `department` (`DEPT_ID`),
  ADD CONSTRAINT `payroll_ibfk_2` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `payroll_deduction`
--
ALTER TABLE `payroll_deduction`
  ADD CONSTRAINT `payroll_deduction_ibfk_1` FOREIGN KEY (`PAYROLL_ID`) REFERENCES `payroll` (`PAYROLL_ID`);

--
-- Constraints for table `payroll_earning`
--
ALTER TABLE `payroll_earning`
  ADD CONSTRAINT `payroll_earning_ibfk_1` FOREIGN KEY (`PAYROLL_ID`) REFERENCES `payroll` (`PAYROLL_ID`);

--
-- Constraints for table `po_detail`
--
ALTER TABLE `po_detail`
  ADD CONSTRAINT `po_detail_ibfk_5` FOREIGN KEY (`PR_DTL_ID`) REFERENCES `pr_detail` (`PR_DTL_ID`),
  ADD CONSTRAINT `po_detail_ibfk_6` FOREIGN KEY (`PO_HDR_ID`) REFERENCES `po_header` (`PO_HDR_ID`),
  ADD CONSTRAINT `po_detail_ibfk_7` FOREIGN KEY (`UNIT_ID`) REFERENCES `unit` (`UNIT_ID`);

--
-- Constraints for table `po_header`
--
ALTER TABLE `po_header`
  ADD CONSTRAINT `po_header_ibfk_3` FOREIGN KEY (`PO_HDR_SOLD_TO_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `po_header_ibfk_4` FOREIGN KEY (`PO_HDR_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `po_header_ibfk_5` FOREIGN KEY (`SUPPLIER_ID`) REFERENCES `supplier_profile` (`SUPPLIER_ID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`BRAND_ID`) REFERENCES `brand` (`BRAND_ID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `product_ibfk_3` FOREIGN KEY (`SUB_CATEGORY_ID`) REFERENCES `category_sub_category` (`SUB_CATEGORY_ID`),
  ADD CONSTRAINT `product_ibfk_4` FOREIGN KEY (`UNIT_ID`) REFERENCES `unit` (`UNIT_ID`);

--
-- Constraints for table `product_field`
--
ALTER TABLE `product_field`
  ADD CONSTRAINT `product_field_ibfk_1` FOREIGN KEY (`SUB_CATEGORY_ID`) REFERENCES `category_sub_category` (`SUB_CATEGORY_ID`);

--
-- Constraints for table `product_information`
--
ALTER TABLE `product_information`
  ADD CONSTRAINT `product_information_ibfk_1` FOREIGN KEY (`PRODUCT_FIELD_ID`) REFERENCES `product_field` (`PRODUCT_FIELD_ID`);

--
-- Constraints for table `pr_detail`
--
ALTER TABLE `pr_detail`
  ADD CONSTRAINT `pr_detail_ibfk_1` FOREIGN KEY (`PR_HDR_ID`) REFERENCES `pr_header` (`PR_HDR_ID`),
  ADD CONSTRAINT `pr_detail_ibfk_2` FOREIGN KEY (`UNIT_ID`) REFERENCES `unit` (`UNIT_ID`);

--
-- Constraints for table `pr_header`
--
ALTER TABLE `pr_header`
  ADD CONSTRAINT `pr_header_ibfk_1` FOREIGN KEY (`PR_HDR_REQUESTOR_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `pr_header_ibfk_2` FOREIGN KEY (`PR_HDR_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `pr_header_ibfk_3` FOREIGN KEY (`PR_HDR_APPROVED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `receiving_detail`
--
ALTER TABLE `receiving_detail`
  ADD CONSTRAINT `receiving_detail_ibfk_1` FOREIGN KEY (`REC_HDR_ID`) REFERENCES `receiving_header` (`REC_HDR_ID`),
  ADD CONSTRAINT `receiving_detail_ibfk_2` FOREIGN KEY (`UNIT_ID`) REFERENCES `unit` (`UNIT_ID`);

--
-- Constraints for table `supplier_profile`
--
ALTER TABLE `supplier_profile`
  ADD CONSTRAINT `supplier_profile_ibfk_1` FOREIGN KEY (`INDUSTRY_TYPE_ID`) REFERENCES `industry_type` (`INDUSTRY_TYPE_ID`);

--
-- Constraints for table `task_reminder`
--
ALTER TABLE `task_reminder`
  ADD CONSTRAINT `task_reminder_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `training_seminar`
--
ALTER TABLE `training_seminar`
  ADD CONSTRAINT `training_seminar_ibfk_1` FOREIGN KEY (`WORK_EXP_ID`) REFERENCES `work_experience` (`WORK_EXP_ID`);

--
-- Constraints for table `user_access_level_position`
--
ALTER TABLE `user_access_level_position`
  ADD CONSTRAINT `user_access_level_position_ibfk_2` FOREIGN KEY (`FORM_ID`) REFERENCES `form` (`FORM_ID`),
  ADD CONSTRAINT `user_access_level_position_ibfk_3` FOREIGN KEY (`BUTTON_ID`) REFERENCES `button` (`BUTTON_ID`),
  ADD CONSTRAINT `user_access_level_position_ibfk_4` FOREIGN KEY (`POSITION_ID`) REFERENCES `position` (`POSITION_ID`);

--
-- Constraints for table `user_account`
--
ALTER TABLE `user_account`
  ADD CONSTRAINT `user_account_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `user_priviledges`
--
ALTER TABLE `user_priviledges`
  ADD CONSTRAINT `user_priviledges_ibfk_2` FOREIGN KEY (`FORM_ID`) REFERENCES `form` (`FORM_ID`),
  ADD CONSTRAINT `user_priviledges_ibfk_3` FOREIGN KEY (`BUTTON_ID`) REFERENCES `button` (`BUTTON_ID`),
  ADD CONSTRAINT `user_priviledges_ibfk_4` FOREIGN KEY (`USER_ID`) REFERENCES `user_account` (`USER_ID`);

--
-- Constraints for table `voucher_detail`
--
ALTER TABLE `voucher_detail`
  ADD CONSTRAINT `voucher_detail_ibfk_1` FOREIGN KEY (`VCH_HDR_ID`) REFERENCES `voucher_header` (`VCH_HDR_ID`),
  ADD CONSTRAINT `voucher_detail_ibfk_2` FOREIGN KEY (`ACCOUNT_ID`) REFERENCES `account` (`ACCOUNT_ID`),
  ADD CONSTRAINT `voucher_detail_ibfk_3` FOREIGN KEY (`ACCOUNT_TYPE_ID`) REFERENCES `account_type` (`ACCOUNT_TYPE_ID`);

--
-- Constraints for table `voucher_header`
--
ALTER TABLE `voucher_header`
  ADD CONSTRAINT `voucher_header_ibfk_1` FOREIGN KEY (`VCH_HDR_CREATED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`),
  ADD CONSTRAINT `voucher_header_ibfk_2` FOREIGN KEY (`VCH_HDR_APPROVED_BY_ID`) REFERENCES `employee_profile` (`EMP_ID`);

--
-- Constraints for table `withdrawal_detail`
--
ALTER TABLE `withdrawal_detail`
  ADD CONSTRAINT `withdrawal_detail_ibfk_1` FOREIGN KEY (`WITH_HDR_ID`) REFERENCES `withdrawal_header` (`WITH_HDR_ID`),
  ADD CONSTRAINT `withdrawal_detail_ibfk_2` FOREIGN KEY (`UNIT_ID`) REFERENCES `unit` (`UNIT_ID`);

--
-- Constraints for table `work_experience`
--
ALTER TABLE `work_experience`
  ADD CONSTRAINT `work_experience_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee_profile` (`EMP_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
