<!--div container for user guide -->
<div id="quick-view-container" class="modal cheat-sheet">
<div class="handle">
<a href="#" id="close">x</a>
</div>
<div style="overflow:auto">
		<div id='CSLeftPane'>
		<style>
		label:hover{
		background:#F7F0F2;
		padding:3px;
		border-radius:2px;
		}
		</style>
		<h4>Home</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/smiley-icon.png"/>
					<label>Active Customer</label>
				</li>
				<li>
					<img src="/ebms/images/icons/inactive.png"/>
					<label>Inactive Customer</label>
				</li>
				<li>
					<img src="/ebms/images/icons/order-icon.png"/>
					<label>Order Entry/Total Orders</label>
				</li>
				<li>
					<img src="/ebms/images/icons/money-icon.png"/>
					<label>Total Collected</label>
				</li>
				<li>
					<img src="/ebms/images/icons/hand-icon.png"/>
					<label>Total Cash On Hand</label>
				</li>
				<li>
					<img src="/ebms/images/icons/sales-icon.png"/>
					<label>Total Sales/Sales Monitoring</label>
				</li>
				<li>
					<img src="/ebms/images/icons/voucher-icon.png"/>
					<label>Total Expense Voucher</label>
				</li>
				<li>
					<img src="/ebms/images/icons/acct-pay-icon.png"/>
					<label>Total Expense A/P</label>
				</li>
				<li>
					<img src="/ebms/images/icons/crm-icon.png"/>
					<label>Customer Relations Management</label>
				</li>
				<li>
					<img src="/ebms/images/icons/project-icon.png"/>
					<label>Sales Forecasting</label>
				</li>
			</ul>
			
		<h4>CRUD Options</h4>
			<ul>
				<li>
					<img src="/ebms/images/crudIcons/newIcon.png"/>
					<label>Add New Record</label>
				</li>
				<li>
					<img src="/ebms/images/crudIcons/editIcon.png"/>
					<label>Edit Existing Record</label>
				</li>
				<li>
					<img src="/ebms/images/crudIcons/deleteIcon.png"/>
					<label>Delete Record</label>
				</li>
				<li>
					<img src="/ebms/images/crudIcons/restoreIcon.png"/>
					<label>Restore Deleted Record</label>
				</li>
				<li>
					<img src="/ebms/images/crudIcons/multipleEditIcon.png"/>
					<label>Edit Multiple Record [Employee Schedule]</label>
				</li>
				<li>
					<img src="/ebms/images/crudIcons/importIcon.png"/>
					<label>Import Record</label>
				</li>
				<li>
					<img src="/ebms/images/crudIcons/transferIcon.png"/>
					<label>Transfer Asset/Product [Vice Versa]</label>
				</li>
			</ul>
			
		<h4>Other CRUD Options</h4>
		<ul>
			<li>
				<img src="/ebms/images/icons/addSmall.png"/>
				<label>Add Record</label>
			</li>
			<li>
				<img src="/ebms/images/icons/editSmall.png"/>
				<label>Edit Record</label>
			</li>
			<li>
				<img src="/ebms/images/icons/deleteSmall.png"/>
				<label>Delete Record</label>
			</li>
			<li>
				<img src="/ebms/images/icons/restoreSmall.png"/>
				<label>Restore Record</label>
			</li>
		</ul>
		
		<h4>CRM</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/location.png"/>
					<label>Location Icon</label>
				</li>
				<li>
					<img src="/ebms/images/icons/Phone-icon.png"/>
					<label>Contact per Location Icon</label>
				</li>
			</ul>
			
			<h4>Sales/Purchasing/Personnel</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/approved_icon.png"/>
					<label>Pending Icon</label>
				</li>
				<li>
					<img src="/ebms/images/icons/checkIcon.png"/>
					<label>Approved</label>
				</li>
			</ul>
		</div>
		
		<div id='CSCenterPane'>	
		
			
			<h4>Accounting</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/ARWithoutCheque.png"/>
					<label>No Pending Cheques</label>
				</li>
				<li>
					<img src="/ebms/images/icons/ARWithCheque.png"/>
					<label>With Pending Cheques [Not yet posted]</label>
				</li>
				<li>
					<img src="/ebms/images/icons/warning.png"/>
					<label>AR Not yet paid</label>
				</li>
				<li>
					<img src="/ebms/images/icons/checkIcon.png"/>
					<label>Cash Payment</label>
				</li>
				<li>
					<img src="/ebms/images/icons/posted-checks.png"/>
					<label>Cheques that are already posted</label>
				</li>
				<li>
					<img src="/ebms/images/icons/approved_icon.png"/>
					<label>Cheques that are not yet posted</label>
				</li>
				<li>
					<img src="/ebms/images/icons/cheque.png"/>
					<label>Cheque Icon</label>
				</li>
				<li>
					<img src="/ebms/images/icons/hand-icon.png"/>
					<label>Expenses Icon</label>
				</li>
				<li>
					<img src="/ebms/images/icons/include.png"/>
					<label>Included cheques to be posted</label>
				</li>
				<li>
					<img src="/ebms/images/icons/add.png"/>
					<label>Add Cheque</label>
				</li>
				<li>
					<img src="/ebms/images/icons/addCS.png"/>
					<label>Add Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/post.png"/>
					<label>Post selected Cheques</label>
				</li>
				<li>
					<img src="/ebms/images/icons/clear.png"/>
					<label>Clear selected Cheques</label>
				</li>
				<li>
					<img src="/ebms/images/icons/generalLedger.png"/>
					<label>Bank Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/deposit.png"/>
					<label>Bank Deposit Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/withdraw.png"/>
					<label>Bank Withdrawal Record</label>
				</li>
			</ul>
			
			<h4>Purchasing</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/orderIcon.png"/>
					<label>Purchase Order Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/suppliersIcon.png"/>
					<label>Supplier Record</label>
				</li>
			</ul>
			
			<h4>Personnel</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/empBoyIcon.png"/>
					<label>Male Employee</label>
				</li>
				<li>
					<img src="/ebms/images/icons/empGirlIcon.png"/>
					<label>Female Employee</label>
				</li>
				<li>
					<img src="/ebms/images/icons/fileLeave.png"/>
					<label>File Leave Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/overtime.png"/>
					<label>Employee Overtime Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/workExp.png"/>
					<label>Employee Work Experience</label>
				</li>
				<li>
					<img src="/ebms/images/icons/educBackground.png"/>
					<label>Educational Background Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/empsched-icon.png"/>
					<label>Employee Icon</label>
				</li>
				<li>
					<img src="/ebms/images/icons/schedule-icon.png"/>
					<label>Day Schedule Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/timesheetrecord-icon.png"/>
					<label>Time Sheet Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/acct-pay-icon.png"/>
					<label>Payroll Record</label>
				</li>
			</ul>
		</div>
		
		<div id='CSRightPane'>
			<ul>
				<li>
					<img src="/ebms/images/icons/select-icon.png"/>
					<label>Add Records Shortcut for Payroll</label>
				</li>
			</ul>
			
			<h4>Inventory</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/inventory.png"/>
					<label>Product/Asset Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/maintenance.png"/>
					<label>Maintenance Record</label>
				</li>
			</ul>
			
			<h4>Other Icons</h4>
			<ul>
				<li>
					<img src="/ebms/images/icons/pdf-icon.png"/>
					<label>Open/View Report</label>
				</li>
				<li>
					<img src="/ebms/images/icons/deleted-icon.png"/>
					<label>Deleted Record</label>
				</li>
				<li>
					<img src="/ebms/images/icons/notifIcon.png"/>
					<label>Notifications</label>
				</li>
				<li>
					<img src="/ebms/images/icons/taskComplete.png"/>
					<label>Completed Task</label>
				</li>
				<li>
					<img src="/ebms/images/icons/taskIncomplete.png"/>
					<label>Incomplete Task</label>
				</li>
			</ul>
		</div>
	</div>
			
			
</div>

<!--div container for user guide -->
<div id="quick-view-container" class="modal user-guide">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<div id='userGuideLeftPane'>
			
			<div id='userGuideSearch'>
				<input type='text' id='userGuideSearchBox' value='Search...'>
			</div>
			
			<div id='userGuideModule' style="height: 450px;overflow-x:hidden;overflow-y:auto;">
				<ul class='userGuideModuleNav'>
				
					<li id='userGuideModuleList'>
						<a href="#" id='userGuideModuleLink'>
							Welcome User
						</a>
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#login-logout" class='login-logout' id='userGuideModuleLink'>
							User Login / Logout
						</a>
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#homeScreen" class='homeScreen' id='userGuideModuleLink'>
							Home Screen
						</a>
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#crm" class='crm' id='userGuideModuleLink'>
							Customer Records Management
						</a>
					</li>
					<li id='userGuideModuleList'>
						<a href="#crmAdd" class='crmAdd' id='userGuideModuleLink'>
						Adding New Record
						</a>
					</li>
					<li id='userGuideModuleList'>
						<a href="#crmEdit" class='crmEdit' id='userGuideModuleLink'>
						Editing a Record
						</a>
					</li>
					<li id='userGuideModuleList'>
						<a href="#crmDelete" class='crmDelete' id='userGuideModuleLink'>
						Deleting a Record
						</a>
					</li>
					<li id='userGuideModuleList'> 
						<a href="#crmRestore" class='crmRestore' id='userGuideModuleLink'>
							Restoring a Record
						</a>						
					</li>
					
					<li id='userGuideModuleList'> 
						<a href="#approvePR" class='approvePR' id='userGuideModuleLink'>
							Approving a Purchase Request
						</a>						
					</li>
					
					<li id='userGuideModuleList'> 
						<a href="#approveCA" class='approveCA' id='userGuideModuleLink'>
							Approving a Cash Advance
						</a>						
					</li>
					
					<li id='userGuideModuleList'> 
						<a href="#transfer" class='transfer' id='userGuideModuleLink'>
							Transfer Asset to Product/Product to Asset
						</a>						
					</li>
					
					<li id='userGuideModuleList'> 
						<a href="#postPayment" class='postPayment' id='userGuideModuleLink'>
							Posting of Payments
						</a>						
					</li>
					
					<li id='userGuideModuleList'> 
						<a href="#dtr" class='dtr' id='userGuideModuleLink'>
							Daily Time Record
						</a>						
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#systemRecords" class='systemRecords' id='userGuideModuleLink'>
							System Records
						</a>
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#accounting" class='accounting' id='userGuideModuleLink'>
							Accounting
						</a>
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#personnelProfile" class='personnelProfile' id='userGuideModuleLink'>
							Personnel Profile
						</a>
					</li>
					
					<li id='userGuideModuleList'>
						<a href="#report" class='report' id='userGuideModuleLink'>
							Reports
						</a>
					</li>
				</ul>	
			</div>
			
		</div>
		
		<div id='userGuideRightPane'  >
			
			<div id='userGuideModuleDisplay' style="height: 550px;overflow-x:hidden;overflow-y:auto;">
			
				<div id='home'>
					<img id='userGuideHome' src='/ebms/images/userGuide/userguidehome.png' />
				</div>
			
				<div id='login-logout'>
					<img id='login-logoutimg' src='/ebms/images/userGuide/login-logout.png' />
				</div>
				
				<div id='homeScreen' >
					<img id='ebmsHomeScreen' src='/ebms/images/userGuide/homescreen.png' />
				</div>
				
				<div id='crm' >
					<img id='ebmsCrm' src='/ebms/images/userGuide/crm.png' />
				</div>
				
				<div id='crmAdd' >
					<img id='ebmsCrmAdd' src='/ebms/images/userGuide/crmadd.png' />
				</div>
				
				<div id='crmEdit' >
					<img id='ebmsCrmEdit' src='/ebms/images/userGuide/crmedit.png' />
				</div>
				
				<div id='crmDelete' >
					<img id='ebmsCrmDelete' src='/ebms/images/userGuide/crmdelete.png' />
				</div>
				
				<div id='crmRestore' >
					<img id='ebmsCrmRestore' src='/ebms/images/userGuide/crmrestore.png' />
				</div>
				
				<div id='crmAddLoc' >
					<img id='ebmsCrmAddLoc' src='/ebms/images/userGuide/crmlocadd.png' />
				</div>
				
				<div id='crmEditLoc' >
					<img id='ebmsCrmEditLoc' src='/ebms/images/userGuide/crmlocedit.png' />
				</div>
				
				<div id='crmDeleteLoc' >
					<img id='ebmsCrmDeleteLoc' src='/ebms/images/userGuide/crmdeleteloc.png' />
				</div>
				
				<div id='crmRestoreLoc' >
					<img id='ebmsCrmRestoreLoc' src='/ebms/images/userGuide/crmrestoreloc.png' />
				</div>
				
				<div id='crmAddContact' >
					<img id='ebmsCrmAddContact' src='/ebms/images/userGuide/crmaddcontact.png' />
				</div>
				
				<div id='crmEditContact' >
					<img id='ebmsCrmEditContact' src='/ebms/images/userGuide/crmcontactedit.png' />
				</div>
				
				<div id='crmDeleteContact' >
					<img id='ebmsCrmDeleteContact' src='/ebms/images/userGuide/crmdeletecontact.png' />
				</div>
				
				<div id='crmRestoreContact' >
					<img id='ebmsCrmRestoreContact' src='/ebms/images/userGuide/crmrestorecontact.png' />
				</div>
				
				<div id='systemRecords'>
					<img id='ebmsSystemRecords' src='/ebms/images/userGuide/systemrecord.png' />
				</div>
				
				<div id='personnelProfile' >
					<img id='ebmsPersonnelPage' src='/ebms/images/userGuide/emppage.png' />
				</div>
				
				<div id='empAdd' >
					<img id='ebmsEmpAdd' src='/ebms/images/userGuide/empadd.png' />
				</div>
				
				<div id='empEdit' >
					<img id='ebmsEmpEdit' src='/ebms/images/userGuide/empedit.png' />
				</div>
				
				<div id='empDelete' >
					<img id='ebmsEmpDelete' src='/ebms/images/userGuide/empdelete.png' />
				</div>
				
				<div id='empRestore' >
					<img id='ebmsEmpRestore' src='/ebms/images/userGuide/emprestore.png' />
				</div>
				
				<div id='approvePR' >
					<img id='ebmsApprovePR' src='/ebms/images/userGuide/approvepr.png' />
				</div>
				
				<div id='approveCA' >
					<img id='ebmsApproveCA' src='/ebms/images/userGuide/approveca.png' />
				</div>
				
				<div id='dtr' >
					<img id='ebmsdtr' src='/ebms/images/userGuide/dtr.png' />
				</div>
				
				<div id='transfer' >
					<img id='ebmstransfer' src='/ebms/images/userGuide/transfer.png' />
				</div>
				
				<div id='postPayment' >
					<img id='ebmsPostPayment' src='/ebms/images/userGuide/postpayment.png' />
				</div>
				
				<div id='accounting'>
					<img id='ebmsAccounting' src='/ebms/images/userGuide/accounting.png' />
				</div>
				
				<div id='reports'>
					<img id='ebmsReports' src='/ebms/images/userGuide/report.png' />
				</div>
			
			</div>
			
		</div>
			
			
</div>

			<script>
			
				function hide()
				{
					$("#login-logoutimg").hide();
					$("#ebmsHomeScreen").hide();
					$("#ebmsReports").hide();
					$("#ebmsSystemRecords").hide();
					$("#ebmsCrm").hide();
					$("#ebmsCrmAdd").hide();
					$("#ebmsCrmEdit").hide();
					$("#ebmsCrmDelete").hide();
					$("#ebmsCrmRestore").hide();
					$("#ebmsCrmAddLoc").hide();
					$("#ebmsCrmEditLoc").hide();
					$("#ebmsCrmDeleteLoc").hide();
					$("#ebmsCrmRestoreLoc").hide();
					$("#ebmsCrmAddContact").hide();
					$("#ebmsCrmEditContact").hide();
					$("#ebmsCrmDeleteContact").hide();
					$("#ebmsCrmRestoreContact").hide();
					$("#ebmsPersonnelPage").hide();
					$("#ebmsEmpAdd").hide();
					$("#ebmsEmpEdit").hide();
					$("#ebmsEmpDelete").hide();
					$("#ebmsEmpRestore").hide();
					$("#ebmsAccounting").hide();
					$("#ebmsApprovePR").hide();
					$("#ebmsApproveCA").hide();
					$("#ebmsdtr").hide();
					$("#ebmstransfer").hide();
					$("#ebmsPostPayment").hide();
					$("#userGuideHome").hide();
				}
				
					hide();
					$("#userGuideHome").show();
					
					$('.login-logout').click(function(){
						hide();
						$("#login-logoutimg").show();
						return false;
					});
					
					$('.homeScreen').click(function(){
						hide();
						$("#ebmsHomeScreen").show();
						return false;
					});
					
					$('.crm').click(function(){
						hide();
						$("#ebmsCrm").show();
						return false;
					});
					
					$('.crmAdd').click(function(){
						hide();
						$("#ebmsCrmAdd").show();
						return false;
					});
					
					$('.crmEdit').click(function(){
						hide();
						$("#ebmsCrmEdit").show();
						return false;
					});
					
					$('.crmDelete').click(function(){
						hide();
						$("#ebmsCrmDelete").show();
						return false;
					});
					
					$('.crmRestore').click(function(){
						hide();
						$("#ebmsCrmRestore").show();
						return false;
					});
					
					$('.approvePR').click(function(){
						hide();
						$("#ebmsApprovePR").show();
						return false;
					});
					
					$('.approveCA').click(function(){
						hide();
						$("#ebmsApproveCA").show();
						return false;
					});
					
					$('.crmAddLoc').click(function(){
						hide();
						$("#ebmsCrmAddLoc").show();
						return false;
					});
					
					$('.crmEditLoc').click(function(){
						hide();
						$("#ebmsCrmEditLoc").show();
						return false;
					});
					
					$('.crmDeleteLoc').click(function(){
						hide();
						$("#ebmsCrmDeleteLoc").show();
						return false;
					});
					
					$('.crmRestoreLoc').click(function(){
						hide();
						$("#ebmsCrmRestoreLoc").show();
						return false;
					});
					
					$('.dtr').click(function(){
						hide();
						$("#ebmsdtr").show();
						return false;
					});
					
					$('.transfer').click(function(){
						hide();
						$("#ebmstransfer").show();
						return false;
					});
					
					$('.postPayment').click(function(){
						hide();
						$("#ebmsPostPayment").show();
						return false;
					});
					
					$('.crmAddContact').click(function(){
						hide();
						$("#ebmsCrmAddContact").show();
						return false;
					});
					
					$('.crmEditContact').click(function(){
						hide();
						$("#ebmsCrmEditContact").show();
						return false;
					});
					
					$('.crmDeleteContact').click(function(){
						hide();
						$("#ebmsCrmDeleteContact").show();
						return false;
					});
					
					$('.crmRestoreContact').click(function(){
						hide();
						$("#ebmsCrmRestoreContact").show();
						return false;
					});
					
					$('.personnelProfile').click(function(){
						hide();
						$("#ebmsPersonnelPage").show();
						return false;
					});
					
					$('.empAdd').click(function(){
						hide();
						$("#ebmsEmpAdd").show();
						return false;
					});
					
					$('.empEdit').click(function(){
						hide();
						$("#ebmsEmpEdit").show();
						return false;
					});
					
					$('.empDelete').click(function(){
						hide();
						$("#ebmsEmpDelete").show();
						return false;
					});
					
					$('.empRestore').click(function(){
						hide();
						$("#ebmsEmpRestore").show();
						return false;
					});
					
					$('.systemRecords').click(function(){
						hide();
						$("#ebmsSystemRecords").show();
						return false;
					});
					
					$('.accounting').click(function(){
						hide();
						$("#ebmsAccounting").show();
						return false;
					});
					
					$('.report').click(function(){
						hide();
						$("#ebmsReports").show();
						return false;
					});
					
					$('.handle a#close').click(function(){
						hide();
						$("#userGuideHome").show();
						return false;
					});
			</script>
<script>
$(document).ready(function(){
		
		var windowHeight = $("#slider-window").height();
		var numSlides = $(".modal-slider li").length;
		var num = 0,numHeight = 0;
		var href;
		
		var slideHeight = windowHeight * numSlides;
				
				
		function next(obj)
			{
			//unset activeSlider class to all anchors
			$(".modal-slider li#slider-li a").removeClass("activeSlider");
			//now set activeSlider class on the clicked anchor
			obj.addClass("activeSlider");
			num += 1;
				if(num >= (numSlides+1))
				{
				num = 1;
				}	
			numHeight = (Number(num)-1) * windowHeight;
			slide();
			}
			
			
			function slide()
			{
			$("#slider-window").stop().animate({scrollTop:Number(numHeight)},"slow");
			}
		
		$(".modal-slider li#slider-li a").bind("click mouseover",function(){
			href = $(this).attr("href").substring(1);		
			var rel = $(this).attr("rel");
			num = Number(rel)-1;
			next($(this));
			
		return false;
		});
	});
</script>
<!--div container for About us -->
<div id="quick-view-container" class="modal about-us">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<div id="slider-window">
		<div id='whoWeAre' class='sliders'>
		<div id="imageContLeft">
		<img src="/ebms/images/whoWeAre.png">
		</div>
		<h4>Who We Are?</h4>
		<p>
		SME Soft Incorporated (SME Soft Inc.) is the result of the four- year collaboration between experienced IT resources and entrepreneurs. The company offers customized business intelligence solutions which are made available as part of our initial offerings.
		From its humble beginnings, SME Soft Inc. has secured the trust and confidence of one of the biggest names in business upon partnering with Global Quality Waters and Environment Solution Incorporated (GQWEST Inc.) as their exclusive technology provider.
		</p>
		</div>
		
		<div id='missionVision' class='sliders'> 
		<div id="imageContRight">
		<img src="/ebms/images/missionVision.png">
		</div>
		<h4>Mission</h4>
		<p>
		<ul>
			<li>
			"To be the primary provider of cost-effective, quality IT software solutions for small to medium enterprises in the Philippines"
			</li>
			
			<li>
			"To train and retain IT talents who will excel in every aspect of Information Technology and partner with us to bring success for the company"
			</li>
		</ul>
		</p>
		
		<h4>Vision</h4>
		<p>
		<ul>
			<li>
			"We seek to partner with small to medium enterprises to help them optimize their business operation by providing quality and cost-effective software and IT solutions coupled with superb customer service"
			</li>
			
			<li>
			"We will reach out to less fortunate students by sharing our time, resources, experience and talents to mould them to be industry experts."
			</li>
		</ul>
		</p>
		</div>
		
		<div id='coreValues' class='sliders'>
		
		<div id="imageContLeft">
		<img src="/ebms/images/core.jpg">
		</div>
		
		<h4>Our Core Values</h4>
		<ul>
			<li>
			<b>Humility</b> - we will remain as how we started, not in the size of our business - but the way we treat it. We take pride in what we do, but still keep our foot to the ground to reach out for the needs of our customers, just like how we did in our initial steps.
			</li>
			
			<li>
			<b>Responsibility</b> - we take our job seriously and keep our promises to the best of our abilities.
			</li>
			
			<li>
			<b>Punctuality</b> - we value time. In today's business environment, urgency is not secondary. To the best of our abilities, we will deliver on the agreed submission date.
			</li>
			
			<li>
			<b>Respect</b> - we respect your views. Tell us what you think, and upon analysing it, we will express ours which will suit your needs.
			</li>
			
			<li>
			<b>Organized</b> - "a place for everything, everything on its place", not just for materials things but through our thoughts and approach we make it a point to be organized.
			</li>
		</ul>
		</p>
		</div>
			
		</div>
		
		<ul class='modal-slider'>
			<li id='slider-li'>
				<a rel=1 href='#whoWeAre' class='activeSlider'>Who We Are?</a>
			</li>
			<li id='slider-li'>
				<a rel=2 href='#missionVision'>Mission & Vission</a>
			</li>
			<li id='slider-li'>
				<a rel=3 href='#coreValues'>Core Values</a>
			</li>
		</ul>	
</div>

<!--div container for Contact us -->
<div id="quick-view-container" class="modal contact-us">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<div id="slider-window">
		<div id='contactUs' class='sliders'>
		<div id="imageContLeft">
		<img src="/ebms/images/whoWeAre.png">
		</div>
		<h4>Contact Details</h4>
		<p>
		SME Soft Inc.
		</p>
			
		<p>	
		1517 2nd Street <br/>
		Fabie Subdivision <br/>
		Paco, Manila Philippines 1007<br/>
		</p>
		
		<p>
		Mobile: 0918.926.4935 - Smart<br/>
            0917.391.0876 - Globe<br/>
            0933.150.4772 – Sun<br/>
		Landline: (02) 545.2485<br/>
		</p>
		
		<p>
		Email: inquire@smesoft.com.ph<br/>
		Website: www.smesoft.com.ph<br/>
		</p>
		
		</div>
		</div>
		
		<ul class='modal-slider'>
			<li id='slider-li'>
				<a rel=1 href='#contactUs' class='activeSlider'>Let's put in the missing piece</a>
			</li>
		</ul>	
</div>


<!--div container for quickButton--> 
<div id="quick-view-container" class="modal quickButton">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<ul class="quick-view-menu">
			<li id="quick-view-list">
				
				<a href="#Badger Meter" id="quick-view-a">
				<img src="/EBMS/images/icons/createOSIcon.png">
				Create OS
				</a>
			</li>
			<li id="quick-view-list">
				<a href="#Sales Monitoring" id="quick-view-a">
				<img src="/EBMS/images/icons/createVoucherIcon.png">
				Create Voucher
				</a>
			</li>
			<li id="quick-view-list">
				<a href="#Sales Forecasting" id="quick-view-a">
				<img src="/EBMS/images/icons/dtrIcon.png">
				Daily Time Record
				</a>
			</li>
		</ul>
			
			
</div>


<!-- div container for Reports -->
<div id="quick-view-container"  class="modal reports">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<ul class="quick-view-menu sortable">
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/employee/employeeMasterList.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Employee Profile List
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/timeSheet/timeSheetRecord.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Employee Time Sheet Record
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/crm/crmMasterList.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Customer Master List
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/crm/customerStatus.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Customer Status Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/crm/customerType.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Customer Type Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/crm/industryType.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Industry Type Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/crm/customerPerArea.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Customer Per Area Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/sales/sales.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Sales Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/product/productList.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Product List Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/product/productStock.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Product Stock Report
				</a>
			</li>	
			<li id="quick-view-list">
				<a href="#CRM" id="quick-view-a">
				<a href="/ebms/apps/view/reports/product/productPriceList.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Product Price List Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/product/suppliesList.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Supplies List Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/product/suppliesStock.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Supplies Stock Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/accounting/accountsReceivable.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Accounts Receivable Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/accounting/companyPayables.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Company Payables Report
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/accounting/arSummary.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Accounts Receivable Summary
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/sales/salesProjection.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Sales Projection
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/sales/salesForecasting.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Sales Forecasting
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/accounting/incomeStatement.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Income Statement
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/accounting/balanceSheet.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Balance Sheet
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/ebms/apps/view/reports/accounting/cashFlow.php" id="quick-view-a" target="_blank">
				<img src="/EBMS/images/icons/report-icon.png">
				Cash Flow
				</a>
			</li>	
		</ul>
</div>

<!-- div container for Reminders -->
<div id="quick-view-container" class="modal reminders">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<ul class="quick-view-menu">
			<li id="quick-view-list">
				<a href="/ebms/apps/view/systemRecords/reminders/criticalStockLevel/?page=systemRecords&menu=critical-stock-level" id="quick-view-a">
				<img src="/EBMS/images/icons/stocks-icon.png">
				Critical Level Stock
				</a>
			</li>
			<li id="quick-view-list">
				<a href="#taskReminder" id="quick-view-a">
				<img src="/EBMS/images/icons/task-icon.png">
				Task Reminder
				</a>
			</li>
			<script>
			$(document).ready(function(){	
				$("#quick-view-list a[href='#taskReminder']").click(function(){
				window.open( "/ebms/apps/view/systemRecords/reminders/taskReminder/", "Task Reminder", 
				"status = 1, height = 600, width = 800, resizable = 0" );
				return false;
				});
			});
			</script>
			<li id="quick-view-list">
				<a href="/EBMS/apps/view/systemRecords/purchaseRequest/?page=systemRecords&menu=purchase-request" id="quick-view-a">
				<img src="/EBMS/images/icons/approval-icon.png">
				Purchase Request Approval
				</a>
			</li>
			<li id="quick-view-list">
				<a href="/EBMS/apps/view/systemRecords/purchaseOrder/?page=systemRecords&menu=purchase-order" id="quick-view-a">
				<img src="/EBMS/images/icons/purchase-deliveries-icon.png">
				Purchase Order Approval
				</a>
			</li>		
			<li id="quick-view-list">
				<a href="/EBMS/apps/view/accounting/companyReceivables/?page=accounting&menu=company-receivables" id="quick-view-a">
				<img src="/EBMS/images/icons/receivables-icon.png">
				Receivables
				</a>
			</li>		
			<li id="quick-view-list">
				<a href="/EBMS/apps/view/accounting/companyPayables/?page=accounting&menu=company-payables" id="quick-view-a">
				<img src="/EBMS/images/icons/payables-icon.png">
				Payables
				</a>
			</li>
		</ul>
</div>
