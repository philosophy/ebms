<?php 
if(!isset($_SESSION['login']))
	{
	echo "<script>window.open('/ebms/apps/view/login/login-view.php','_self');</script>";
	}
?>
<div id="nav-top-pane">
<script>
	$(document).ready(function(){
	
	
	$(".callModalForm").click(function(){
		callModal($(this));
	return false;
	});
	
	
	$("#modalTabList a").click(function(){
	var href = $(this).attr("href");
		
		$("div.modalFormTabCont").hide();
		$("div"+href+".modalFormTabCont").show();
	
	$("#modalTabList a").removeClass("modalTabActive");
	$(this).addClass("modalTabActive");
	
	return false;
	});
	
		$("a#notif-link").toggle(function(){
			$(".notif-nav").slideToggle();
			$(this).addClass("active");
			
			},
			function(){
			$(this).removeClass("active");
			$(".notif-nav").slideToggle();
			}
			);
			
			if($.cookie("ebmsCustBal") == "true")
				{
				$.post("/ebms/apps/view/accounting/companyReceivables/customerBalance.php",
				function(response)
				{
				if(response != "")
				{
				$("body").append("<div id='dialog-modal' title='Customer With Balance' style='font-size:13px'>"+response+"</div>");
				$( "#dialog:ui-dialog" ).dialog( "destroy" );
				$( "#dialog-modal").dialog({
				height: 140,
				modal: true,
				close:
					function(event,ui)
					{
					$.cookie("ebmsCustBal",null);
					}
				});
				}
				
				
				});
				}
			
				
				$("#notif-list a[ref='taskReminder']").click(function(){
				window.open( "/ebms/apps/view/systemRecords/reminders/taskReminder/", "Task Reminder", 
				"status = 1, height = 600, width = 800, resizable = 0" );
				return false;
				});
			
		
		
		});
</script>

<div id="notif-cont">
<ul class="notif">
	<li id="notif-pre-list">
	<a id="notif-link" href="#" rel="notifCnt"><img title='0 Notification' src='/ebms/images/icons/notifIcon.png'></a>
		<ul class="notif-nav">
		<!--<li id='notif-list'><a id='notif-a' href='/EBMS/apps/view/crm/?page=CRM'><img src="/ebms/images/icons/about-icon.png"><b>CRM</b><span id='cnt' title='No new record'>0</span></a></li>-->
		<li id='notif-list'><a id='notif-a' ref="payables" href='/EBMS/apps/view/accounting/companyPayables/?page=accounting&menu=company-payables'><img src="/ebms/images/icons/about-icon.png"><b>Payables</b><span id='cnt' ref="payables" title='No new record'>0</span></a></li>
		<li id='notif-list'><a id='notif-a' href='/EBMS/apps/view/accounting/companyReceivables/?page=accounting&menu=company-receivables' ref="receivables"><img src="/ebms/images/icons/about-icon.png"><b>Receivables</b><span id='cnt' ref="receivables" title='No new record'>0</span></a></li>
		<li id='notif-list'><a id='notif-a' href='#' ref='taskReminder'><img src="/ebms/images/icons/about-icon.png"><b>Task Reminder</b><span id='cnt' title='No new record' ref="taskReminder">0</span></a></li>
		<li id='notif-list'><a id='notif-a' href='/EBMS/apps/view/systemRecords/approvalList/?page=systemRecords&menu=approval-list' ><img src="/ebms/images/icons/about-icon.png"><b>Approvals</b><span id='cnt' title='No new record' ref="approvers_list">0</span></a></li>
		<li id='notif-list'><a id='notif-a' ref="criticalStockLevel" href='/EBMS/apps/view/systemRecords/reminders/criticalStockLevel/?page=systemRecords&menu=critical-stock-level'><img src="/ebms/images/icons/about-icon.png"><b>Critical Stock Level</b><span id='cnt' ref="criticalStockLevel" title='No new record'>0</span></a></li>
		
			<script>
				function reloadNotif(role,ref)
				{
				
				$.ajax({
					url:"/ebms/apps/view/notifications/notifications.php",
					type:"POST",
					data:"role="+role+"&ref="+ref,
					cache:false,
					success:
						function(response)
						{
						var obj = JSON.parse(response);
							
						if(obj.data['taskTotal'] > 0)
						{
							$("a[rel=notifCnt]").html("<b id='notif'>"+obj.data["notifTotal"]+"</b><img title='Notifications' src='/ebms/images/icons/notifIcon.png'>");
							$("span[ref='taskReminder']").html("<b>"+obj.data["taskTotal"]+"</b>");
							$("span[ref='payables']").html("<b>"+obj.data["payables"]+"</b>");
							$("span[ref='receivables']").html("<b>"+obj.data["receivables"]+"</b>");
							$("span[ref='criticalStockLevel']").html("<b>"+obj.data["criticalStockLevel"]+"</b>");
						}
						else
						{	
						$("a[rel=notifCnt]").html("<a id=\"notif-link\" href=\"#\" rel=\"notifCnt\" ><img style='margin-left:-110px' title='0 Notification' src='/ebms/images/icons/notifIcon.png'></a>");
						}
						
						}
				});
				}
				
				setInterval("reloadNotif('view','')",1000);
				
				$(document).ready(function(){
				$("li#notif-list a").click(function(){
					
				$.ajax({
					url:"/ebms/apps/view/notifications/notifications.php",
					type:"POST",
					data:"role=update&ref="+$(this).attr("ref"),
					cache:false,
					success:
						function()
						{
						reloadNotif('view','');
						$(this).attr("ref");
						}
					});
				});
				});
			</script>	
				
			<!--
			<li id="notif-list">
				<a id="notif-a" rel="zero-notif" href="#">No new notifications</a>
			</li>
			-->
			
		</ul>
	</li>
</ul>


</div>


<div id="orb-cont">
	<ul class="main-orb">
	<li id="main-orb-list">
		<img id="orb" src="/EBMS/images/orb.png">
		<ul class="orb-nav">
			<li id="orb-nav-list">
				<a href="#" id="orb-nav-a" class="quick-view" rel="user-guide" name="630"><img src="/ebms/images/icons/guide-icon.png">User Guide</a>
			</li>
			
			<li id="orb-nav-list">
				<a href="#" id="orb-nav-a" class="quick-view" rel="cheat-sheet" name="800"><img src="/ebms/images/icons/cheatSheet.png">Cheat Sheet</a>
			</li>
			
			<li id="orb-nav-list">
				<a href="#" id="orb-nav-a" class="quick-view" rel="about-us" name="500"><img src="/ebms/images/icons/about-icon.png">About Us</a>
			</li>
			
			<li id="orb-nav-list">
				<a href="#" id="orb-nav-a" class="quick-view" rel="contact-us" name="500"><img src="/ebms/images/icons/contact-icon.png">Contact Us</a>
			</li>
			
			<li id="orb-nav-list">
				<a href="#" id="orb-nav-a" class="logout"><img src="/ebms/images/icons/logout-icon.png">Logout</a>
			</li>
	
	
		</ul>
	</li>
	</ul>
</div>
	<ul class="main-nav">
		<script>
		
			var on = gup("page");
			window.onload = function() {
				onTopNavLoad();
				load_orb();
				}
					
			function onTopNavLoad()
					{
					
					if(on!="")
					{
					$("#main-nav-list #main-nav-a").removeClass("onThisPage");
					$("#main-nav-a[rel='"+on+"']").addClass("onThisPage");
					}
					
					}
				

		</script>
		
		<li id="main-nav-list" class="separate">
			<a href="/EBMS/apps/view/Home/?page=Home" id="main-nav-a" rel="Home">Home</a>
		</li>
		
		<li id="main-nav-list" class="separate">
			<a href="/EBMS/apps/view/crm/?page=CRM" id="main-nav-a" rel="crm">CRM</a>
		</li>
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="salesManagement">Sales ▼</a>
				<ul class="sub-nav">
					<li id="sub-nav-list">
					<a href="/EBMS/apps/view/sales/orderSlip/?page=salesManagement&menu=order-slip-records" id="sub-nav-a">Order Slip Records</a>
					</li>
					<li id="sub-nav-list">
					<a href="/EBMS/apps/view/sales/deliveryReceipt/?page=salesManagement&menu=delivery-receipt-records" id="sub-nav-a">Delivery Receipt Records</a>
					</li>
				</ul>
		</li>
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="accounting">Accounting ▼</a>
				<ul class="sub-nav">
				
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/companyReceivables/?page=accounting&menu=accounts-receivable" id="sub-nav-a">Accounts Receivable</a>
					</li>	
					<!--
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/companyExpenses/?page=accounting&menu=company-expenses" id="sub-nav-a">Company Expenses</a>
					</li>	
					-->
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/companyPayables/?page=accounting&menu=company-payables" id="sub-nav-a">Company Payables</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/ownersEquity/?page=accounting&menu=owners-equity" id="sub-nav-a">Owner's Equity</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/checkRecords/?page=accounting&menu=check-records" id="sub-nav-a">Check Records</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/expenses/?page=accounting&menu=expenses" id="sub-nav-a">Expenses</a>
					</li>				
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/generalLedger/?page=accounting&menu=general-ledger" id="sub-nav-a">General Ledger</a>
					</li>		
					<li id="sub-nav-list">
						<a href="http://192.168.0.100/ebms/apps/view/reports/accounting/cashFlow.php" target="_new" id="sub-nav-a">Cash Flow</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/incomeStatement.php" id="sub-nav-a" target="_new">Income Statement</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/balanceSheet.php" id="sub-nav-a" target="_new">Balance Sheet</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/postingOfChecks/?page=accounting&menu=posting-of-checks" id="sub-nav-a">Posting of Checks</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/clearingOfChecks/?page=accounting&menu=clearing-of-checks" id="sub-nav-a">Clearing of Checks</a>
					</li>		
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/accounting/bankRecords/?page=accounting&menu=bank-records" id="sub-nav-a">Bank Records and Transactions</a>
					</li>		
			
					
				</ul>
			
		</li>
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="purchasing">Purchasing ▼</a>
				<ul class="sub-nav">
					<li id="sub-nav-list">
					<a href="/EBMS/apps/view/purchasing/purchaseRequest/?page=purchasing&menu=purchase-request" id="sub-nav-a">Purchase Requisition</a>
					</li>
					<li id="sub-nav-list">
					<a href="/EBMS/apps/view/purchasing/purchaseOrder/?page=purchasing&menu=purchase-order" id="sub-nav-a">Purchase Order</a>
					</li>
					<li id="sub-nav-list">
					<a href="/EBMS/apps/view/purchasing/suppliersManagement/?page=purchasing&menu=suppliers-management" id="sub-nav-a">Suppliers Management</a>
					</li>
				</ul>
		</li>
		
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="personnel">Personnel ▼</a>
				<ul class="sub-nav">
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/personnel/employeeProfile/?page=Personnel" id="sub-nav-a">Employee Profile</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/personnel/employeeSchedule/?page=Personnel" id="sub-nav-a">Employee Schedule</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/personnel/employeeTimeSheetRecords/?page=Personnel" id="sub-nav-a">Employee Time Sheet Records</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/personnel/employeePayroll/?page=Personnel" id="sub-nav-a">Employee Payroll</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/personnel/employeeDTR/?page=Personnel" id="sub-nav-a">Employee Daily Time Records</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/personnel/employeeCashAdvance/?page=Personnel" id="sub-nav-a">Employee Cash Advance</a>
					</li>
			</ul>
		</li>
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="inventory">Inventory ▼</a>
			<ul class="sub-nav">
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/inventory/productList/?page=inventory&menu=product-list" id="sub-nav-a">Product/Asset List</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/inventory/itemReceiving/?page=inventory&menu=item-receiving" id="sub-nav-a">Item Receiving</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/inventory/itemWithdrawal/?page=inventory&menu=item-withdrawal" id="sub-nav-a">Item Withdrawal</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/inventory/itemAdjustment/?page=inventory&menu=item-adjustment" id="sub-nav-a">Item Adjustment</a>
					</li>
			</ul>
		</li>
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="reports">Reports ▼</a>
			<ul class="sub-nav">
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/employee/employeeMasterList.php" id="sub-nav-a" target="_blank">
						Employee Profile List
						</a>		
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/timeSheet/timeSheetRecord.php" id="sub-nav-a" target="_blank">
						Employee Time Sheet Record
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/crm/crmMasterList.php" id="sub-nav-a" target="_blank">
						Customer Master List
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/crm/customerStatus.php" id="sub-nav-a" target="_blank">
						Customer Status Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/crm/customerType.php" id="sub-nav-a" target="_blank">
						Customer Type Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/crm/industryType.php" id="sub-nav-a" target="_blank">
						Industry Type Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/crm/customerPerArea.php" id="sub-nav-a" target="_blank">
						Customer Per Area Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/sales/sales.php" id="sub-nav-a" target="_blank">
						Sales Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/product/productList.php" id="sub-nav-a" target="_blank">
						Product List Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/product/productStock.php" id="sub-nav-a" target="_blank">
						Product Stock Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/product/productPriceList.php" id="sub-nav-a" target="_blank">
						Product Price List Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/product/suppliesList.php" id="sub-nav-a" target="_blank">
						Supplies List Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/product/suppliesStock.php" id="sub-nav-a" target="_blank">
						Supplies Stock Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/accountsReceivable.php" id="sub-nav-a" target="_blank">
						Accounts Receivable Report
						</a>
					</li><li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/arSummary.php" id="sub-nav-a" target="_blank">
						Accounts Receivable Summary
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/companyPayables.php" id="sub-nav-a" target="_blank">
						Company Payables Report
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/sales/salesProjection.php" id="sub-nav-a" target="_blank">
						Sales Projection
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/sales/salesForecasting.php" id="sub-nav-a" target="_blank">
						Sales Forecasting
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/incomeStatement.php" id="sub-nav-a" target="_blank">
						Income Statement
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/balanceSheet.php" id="sub-nav-a" target="_blank">
						Balance Sheet
						</a>
					</li>
					<li id="sub-nav-list">
						<a href="/ebms/apps/view/reports/accounting/cashFlow.php" id="sub-nav-a" target="_blank">
						Cash Flow
						</a>
					</li>
			</ul>
		</li>
		
		
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="systemRecords">System Records ▼</a>
				<ul class="sub-nav">
					<li id="sub-nav-list">
					<a href="#" id="sub-nav-a">File Maintenance</a>
						<ul class="inner-nav">
				            <li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/companyInformation/index.php',480,600)" id="sub-inner-a">
								Company Information
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/accountsManager/index.php',570,630)" id="sub-inner-a">
								Accounts Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/accountSubCategoryManager/index.php',570,630)" id="sub-inner-a">
						     	Account Sub Category Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/employeeStatusManager/index.php',490,630)" id="sub-inner-a">
						       Employee Status Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/employeePositionManager/index.php',570,630)" id="sub-inner-a">
						        Employee Position Manager
								</a>
							</li>
							<li id="sub-inner-list">
							    <a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/departmentManager/index.php',500,630)" id="sub-inner-a">
						       Department Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/areaTypeManager/index.php',570,630)" id="sub-inner-a">
						      	Area Type Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/locationTypeManager/index.php',500,630)" id="sub-inner-a">
						     	Location Type Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/customerTypeManager/index.php',490,630)" id="sub-inner-a">
						     	Customer Type Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/industryTypeManager/index.php',490,630)" id="sub-inner-a">
						        Industry Type Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/categoryManager/index.php',490,630)" id="sub-inner-a">
						        Category Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/subCategoryManager/index.php',530,630)" id="sub-inner-a">
						        Sub Category Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/brandManager/index.php',530,630)" id="sub-inner-a">
						        Brand Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/itemFieldManager/index.php',530,630)" id="sub-inner-a">
						        Item Field Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/employeeLeaveManager/index.php',500,630)" id="sub-inner-a">
						        Employee Leave Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/unitManager/index.php',500,630)" id="sub-inner-a">
						        Unit Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/cityManager/index.php',490,630)" id="sub-inner-a">
						        City Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/deductionManager/index.php',570,630)" id="sub-inner-a">
						        Deduction Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/earningManager/index.php',570,630)" id="sub-inner-a">
						        Earning Manager
								</a>
							</li>
							<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/currencyManager/index.php',570,630)" id="sub-inner-a">
						        Currency Manager
								</a>
							</li>
						</ul>
					</li>
					<li id="sub-nav-list">
						<a href="#" id="sub-nav-a">User Management </a>
							<ul class="inner-nav">
								<li id="sub-inner-list">
								<a href="Javascript:newPopup('/EBMS/apps/view/systemRecords/userManagement/userControlManager/?page=systemRecords&menu=user-control-manager',600,600)" id="sub-inner-a">User Control Manager</a>
								</li>
								<li id="sub-inner-list">
								<a href="/EBMS/apps/view/systemRecords/userManagement/auditTrail/?page=systemRecords&menu=audit-trail" id="sub-inner-a">Audit Trail</a>
								</li>
								<li id="sub-inner-list">
								<a href="/EBMS/apps/view/systemRecords/userManagement/approvalList/?page=systemRecords&menu=approval-list" id="sub-inner-a">Approval's List</a>
								</li>
							</ul>
					</li>
				</ul>
		</li>
		
		<!--
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="userManagement">User Management ▼</a>
				<ul class="sub-nav">
					<li id="sub-nav-list">
					<a href="/EBMS/apps/view/userManagement/auditTrail/?page=userManagement&menu=audit-trail" id="sub-nav-a">Audit Trail</a>
					</li>
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/userManagement/approvalList/?page=userManagement&menu=approval-list" id="sub-nav-a">Approval's List</a>
					</li>
				</ul>
		</li>
		-->
		
		<!--
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" rel="systemRecords">System Records ▼</a>
				<ul class="sub-nav">
					<li id="sub-nav-list">
						<a href="/EBMS/apps/view/systemRecords/approvalList/?page=systemRecords&menu=approval-list" id="sub-nav-a">Approval's List</a>
					</li>

					<li id="sub-nav-list">
						<a href="#" id="sub-nav-a" class="quick-view" rel="reminders" name="600">Reminders</a>
					</li>	
					
				</ul>
		</li>
		-->
		<!--
		<li id="main-nav-list">
			<a href="#" id="main-nav-a" class="quick-view" rel="dashboard" name="800">Dashboard</a>
		</li>
		-->
		
	</ul>
</div>
<script>
	$(function(){
		$(".quick-view").click(function(){
		var title = $(this).attr("rel");
		var ref = title;
		var size = $(this).attr("name");
			modal(size,title,ref);
			return false;
			});
			
		$("a#close").click(function(){
			var ref =$(".quick-view").attr("rel");
			close_modal(ref);
			});
			});
</script>
<?php 
include("orb-top-nav-modal-containers.php");  
?>


