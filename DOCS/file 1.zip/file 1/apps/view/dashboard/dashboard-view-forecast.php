<?php include("../doctype-standard.php"); ?>
<head> 
	<?php include("../standard-js-css.php"); ?>
  	<link rel="stylesheet" type="text/css" href="/EBMS/css/dashboard-graph-stylesheet.css" />
	
	<?php
	include("../graph-js-css.php");
	include("../../controller/dashboard/dashboardControllerForecast.php");
	?>
  </head> 
  <body>
  <div id="graph-tab-header-title">Dashboard for Sales Forecasting</div>  
  
  
  <?php include("../settings-toolbar/settings-toolbar-datepicker.php"); ?> 
  
	<div id="graph-parent">
		<?php include("../settings-toolbar/appendDatepicker.php"); ?>
		<div id="dailyForecast" ref="graphPlot"></div>
		<div id="monthlyForecast" ref="graphPlot"></div>
		<div id="weeklyForecast" ref="graphPlot"></div>
	</div>

  </body> 
</html>