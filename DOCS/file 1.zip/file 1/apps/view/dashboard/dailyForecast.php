<?php 
session_start();
include("../../../config/config.php");

//default values
$monthNum = date("m");
$dayNum = date("d")+1;
$year = date("Y");
$endDay = cal_days_in_month(CAL_GREGORIAN, $monthNum,$year);
$param = @$_POST['param'];
$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];
$output[]="";
$dateToday = "2011-".$monthNum."-".$dayNum;

	if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
	{
		$dateFrom = "2011-".$monthNum."-01";
		$dateTo = "2011-".$monthNum."-".$endDay;
	}

	else
	{
		$dateFrom = $dateFrom;
		$dateTo = $dateTo;
	}

	$diff = floor((abs(strtotime($dateFrom) - strtotime($dateToday)))/(60*60*24));

	if($diff > 30)
	{
		echo "exceed";
	}

	else
	{	

		for($i=0;$i<=$diff;$i++)
		{
		$query = mysql_query("
		SELECT DATE_FORMAT( os_hdr_date,  '%M %d, %Y' ) as 'date', SUM( os_hdr_gross_amount ) as 'sum' 
			FROM os_header
			WHERE  os_hdr_date >='".$dateFrom."' and os_hdr_date<='".$dateFrom."' GROUP BY os_hdr_date
		");
		
			if(mysql_num_rows($query)>0)
			{
			$arrResult = mysql_fetch_array($query);
			$dateVal = $arrResult['date'];
			$salesVal = (float)$arrResult['sum'];
			}
				
			else
			{
			$dateVal = $dateFrom;
			$salesVal = (float)0.00;
			}
		
		$output[$i] = array($dateVal,$salesVal);
		$dateFrom = date("Y/m/d",strtotime($dateFrom."+1 Days"));
		}
		
			$resultDay=mysql_query("SELECT DATE_FORMAT( os_hdr_date,  '%M %d, %Y' ) as 'date', SUM( os_hdr_gross_amount ) as 'sum' 
			FROM os_header
			WHERE os_hdr_date
			IN (
			DATE_SUB( CURDATE( ) , INTERVAL 1 
		    DAY ) , CURDATE( )
			)
			GROUP BY os_hdr_date");
			$numRows=mysql_num_rows($resultDay);
		    if($numRows<2)
			{
			   echo "part&&";
			}
			else
			{
				while($row = mysql_fetch_array($resultDay))
				{
				$day[]=$row['date'];
				$sum[]=$row['sum'];
				}
				
				$pg = (($sum[1]-$sum[0])/$sum[0])*100;
				$amtpg = $sum[0]*(round($pg,2)*0.01);
				$amtpg1 = $sum[0]*(round($pg,2)*0.01);
				$amtpg = $amtpg + $sum[1];
				
				$fg=$diff;
				for($ctr=1;$ctr<=date("t")-(date("j"));$ctr++)
				{
					$dateF=date('Y/m/d',strtotime("+".$ctr." days"));
					$output[$fg] = array($dateF,$amtpg);
					$fg=$fg+1;
					$amtpg=$amtpg+$amtpg1;
				}
			}

	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray."&&"."daily";

	mysql_free_result($query);
	}

