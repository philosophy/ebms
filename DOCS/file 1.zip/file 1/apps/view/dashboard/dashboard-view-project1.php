<?php include("../doctype-standard.php"); ?>
<head> 
	<?php include("../standard-js-css.php"); ?>
  	<link rel="stylesheet" type="text/css" href="/EBMS/css/dashboard-graph-stylesheet.css" />
	<?php include("../graph-js-css.php"); ?>
<!------------------------------Functions to call in order to apply Graph----------------------------------------->
	<script type="text/javascript" language="javascript"> 
	$(document).ready(function(){
	
	var bar = [10,34,45,04];
	var ticks = ['Sales A', 'Sales B', 'Sales C', 'Sales D'];
 
  var plot1 = $.jqplot('sales-project', [bar], {
    title: 'Based on Projected Deliveries',
    series:[{renderer:$.jqplot.BarRenderer}],
    axesDefaults: {
        tickOptions: {
          angle: -30,
          fontSize: '10pt'
        }
    },
    axes: {
      xaxis: {
        renderer: $.jqplot.CategoryAxisRenderer,
		ticks:ticks
      }
    }
  });

	});
	</script> 
	
<!------------------------------------end function call----------------------------------------------------------->
	
  </head> 
  <body>
    <div id="graph-tab-header-title">Dashboard for Sales Projection</div>
	<?php include("../settings-toolbar/appendDatepicker.php"); ?>
    <div id="graph-container"><div id="sales-project">
    </div></div>
  </body> 
</html>