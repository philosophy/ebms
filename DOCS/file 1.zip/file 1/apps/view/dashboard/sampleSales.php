<?php 
session_start();
include("../../../config/config.php");

$output[]="";
		
		for($i=0;$i<12;$i++)
		{
		$output[$i] = array(date("M",mktime(0, 0, 0, $i+1)),300);
		}

	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray."&&"."monthly";

