﻿<?php 
session_start();
include("../../../config/config.php");

//default values
$monthNum = date("m");
$year = date("Y");
$endDay = cal_days_in_month(CAL_GREGORIAN, $monthNum,$year);
$param = @$_POST['param'];
$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];
$output[]="";

	if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
	{
		$dateFrom = $year."-".$monthNum."-01";
		$dateTo = $year."-".$monthNum."-".$endDay;
	}

	else
	{
		$dateFrom = $dateFrom;
		$dateTo = $dateTo;
	}

	$diff = floor((abs(strtotime($dateFrom) - strtotime($dateTo)))/(60*60*24));

	if($diff > 30)
	{
		echo "exceed";
	}

	else
	{	
		for($i=0;$i<=$diff;$i++)
		{
		$query = mysql_query("
		SELECT AP_HDR_AMOUNT ,  AP_HDR_DATE
		FROM  ap_header  
			inner join employee_profile on  AP_HDR_CREATED_BY_ID =emp_id 
		where  AP_HDR_REF_TYPE ='Expense' and (ap_hdr_date >='".$dateFrom."' and ap_hdr_date<='".$dateFrom."')
		");
	
		
			if(mysql_num_rows($query)>0)
			{
			$arrResult = mysql_fetch_array($query);
			$dateVal = $arrResult['os_hdr_date'];
			$salesVal = (float)$arrResult['sum'];
			}
				
			else
			{
			$dateVal = $dateFrom;
			$salesVal = (float)0.00;
			}
		
		$output[$i] = array($dateVal,$salesVal);
		$dateFrom = date("Y/m/d",strtotime($dateFrom."+1 Days"));
		}

	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray."&&"."daily";

	mysql_free_result($query);
	}

