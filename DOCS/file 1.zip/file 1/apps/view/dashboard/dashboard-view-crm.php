<?php include("../doctype-standard.php"); ?>
<head> 
  <?php include("../standard-js-css.php"); ?>
  <?php 
	include("../graph-js-css.php"); 
	include("../../controller/dashboard/dashboardControllerCRM.php");
  ?>
<link rel="stylesheet" type="text/css" href="/EBMS/css/dashboard-graph-stylesheet.css" />
</head> 
<body>
<style>
.jqplot-target {
    color: #333;
}

.jqplot-data-label
{
color:#fff;
text-shadow:1px 1px 1px #333,0px 0px 1px #333;
}

.jqplot-title {
    color: #333;
	text-shadow:1px 1px 1px #fff,0px 0px 1px #fff;
}
</style>
  
	<div id="graph-tabs"> 
		<div id="graph-tab-header-title">Dashboard for Customer Record Management</div>
	
	<?php include("../settings-toolbar/appendDatepicker.php"); ?>
				
	<ul class="graph-nav"> 
		<li><a href="#customer-type" class="tabOnDisplay" rel=1>Customer Type</a></li> 
		<li><a href="#industry-type" rel=2>Industry Type</a></li> 
		<li><a href="#customer-stat" rel=3>Customer Status</a></li> 
		<li><a href="#customer-area" rel=4>Customer per Area</a></li> 
		
	</ul> 
	
	<div id="graph-window">
	<div class="graph-slider">
	<ul class="slider-nav">
	<li>
	<div class="graph-cont" ref="customer-type" rel=1>
	<div id="customer-type" class="graph"> 
	</div>
	</div>
	</li>
	
	<li>
	<div class="graph-cont" ref="industry-type" rel=2>
	<div id="industry-type" class="graph"> 
	
	</div> 
	</div>
	</li>
	
	<li>
	<div class="graph-cont" ref="customer-stat" rel=3>
	<div id="customer-stat" class="graph"> 
	</div>
	</div> 
	</li>
	
	<li>
	<div class="graph-cont" ref="customer-area" rel=4>
	<div id="customer-area" class="graph"> 
	</div>
	</div>
	</li>
	
	</ul>
	
	</div>
	</div>

  <script type="text/javascript" src="../../../js/crmTabBehavior.js"></script>
</div> 
  </body> 
</html>