<?php 
session_start();
include("../../../config/config.php");

for($i=0;$i<12;$i++)
$output[$i] = array("Feb",(float)($i+340.50));
			

	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray;

	mysql_free_result($query);
	

