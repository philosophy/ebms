<?php 
session_start();
include("../../../config/config.php");

$output[]="";
$year = date("Y");
$weekFrom = @$_POST['weekFrom'];
$weekTo = @$_POST['weekTo'];
$diff = @$_POST['diff'];

	for($i=0;$i<=$diff;$i++)
	{
	$date = date("Y-m-d",strtotime($year."-01-01 + ".$weekFrom." weeks"));
	$newdate = strtotime ( '-5 day' , strtotime ( $date ) ) ;
	$from = date ( 'Y-m-d' , $newdate );	
	$to = date("Y-m-d",strtotime($from."+6 Days"));
	
	$query = mysql_query("
		SELECT COALESCE(SUM( os_hdr_net_amount ),0.00) AS  'sum'
		FROM os_header
		WHERE os_hdr_date between '$from' and '$to'
		GROUP BY os_hdr_date
		");
		
		if(mysql_num_rows($query))
		{
		$arrResult = mysql_fetch_array($query);
		}
	
		else
		{
		$arrResult['sum'] = 0;
		}

	$output[$i] = array("Week ".$weekFrom,(float)$arrResult['sum']);
	$weekFrom +=1;
	}

	
	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray."&&"."weekly";

	mysql_free_result($query);


