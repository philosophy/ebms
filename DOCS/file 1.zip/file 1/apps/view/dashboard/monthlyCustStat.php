﻿<?php 
session_start();
include("../../../config/config.php");
$output[] = "";
$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];		
$year = date("Y");		

		if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
		{
		$dateFrom = $year."-01-01";
		$dateTo = $year."-12-31";
		}
		
		else
		{
		$dateFrom = date("Y-m-d",strtotime($dateFrom));
		$dateTo = date("Y-m-d",strtotime($dateTo));
		}
		
$query = mysql_query("
			SELECT c.is_active as 'Stat',COUNT(c.customer_type_id) as 'cnt',monthname('date_created') as 'month'
			FROM customer_profile c 
			WHERE c.date_created between '$dateFrom' and '$dateTo'
			GROUP BY month
			ORDER BY Stat 
			");
$i=0;
	if(mysql_num_rows($query)>0)
	{
		while($row = mysql_fetch_array($query))
		{
		$output[$i] = array((($row['Stat']==0)?"Active= ".$row['cnt']:"Inactive= ".$row['cnt']),(int)$row['cnt']);
		$i++;
		}
		}
		
	else 
	{
		$output[0] = array("No records found for this date (<b>".date("M Y",strtotime("January".date("Y")))." - ".date("M Y",strtotime("December".date("Y")))."</b>)<br/><b style='color:#06f'>Please select a date on the datepickers above</b>",0);
	}
		
	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray;

	mysql_free_result($query);


