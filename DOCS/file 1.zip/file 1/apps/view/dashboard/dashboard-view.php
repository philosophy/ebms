<?php include("../doctype-standard.php"); ?>

<head>
<title><?php echo $_REQUEST['page']." Window"; ?></title>
<?php include("../standard-js-css.php"); ?>
<script type="text/javascript" src="../../../js/dashboard-view-datepicker.js"></script>	
</head>

<body>

<div id="header">
	<div id="header_title"><?php echo "Dashboard for ".$_REQUEST['page']; ?></div>
	
	<div id="dash-badger-container">
	
	<label id="date_label">From</label><input type="text" id="from">
	<label id="date_label">To</label><input type="text" id="to">
		
	</div>
</div>
	
</body>
</html>