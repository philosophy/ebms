<?php 
session_start();
include("../../../config/config.php");
$i=0;
$output[]="";
$exp[]="";

$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];		
		
		if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
		{
			$dateFrom = 'January '.date("Y");
			$dateTo = 'December '.date("Y");
		}
		else
		{
			$dateFrom = $dateFrom;
			$dateTo = $dateTo;
		}
		
		$monthDiff = (date("m",strtotime($dateTo))-date("m",strtotime($dateFrom)));
		$yearDiff = (date("Y",strtotime($dateTo))-date("Y",strtotime($dateFrom)));
		
		if($yearDiff == 0)
		{
		for($i=0;$i<=$monthDiff;$i++)
		{
		$startDate = (date("Y",strtotime($dateFrom)))."-".(date("m",strtotime($dateFrom)))."-01";
		$endDate = (date("Y",strtotime($dateFrom)))."-".(date("m",strtotime($dateFrom)))."-".(date("t",strtotime($dateFrom)));
		
		$query = mysql_query("
		SELECT SUM(os_hdr_net_amount) as 'sum',monthname(os_hdr_date) as 'month'
		FROM OS_HEADER
		WHERE os_hdr_date between '".$startDate."' and '".$endDate."'
		GROUP BY month desc
		");
	
		
		$dateVal = date('F', mktime(0, 0, 0, date("m",strtotime($dateFrom))));
		if(mysql_num_rows($query)>0)
			{
			$arrResult = mysql_fetch_array($query);
			$salesVal = (float)$arrResult['sum'];
			}
			else
			{
			$salesVal = (float)0.00;
			}
		$output[$i] = array($dateVal,$salesVal);
		$dateFrom = date("Y-m-d",strtotime($dateFrom."+1 Month"));
		
		}
		
		
		//expenses
		
		$dateFrom = @$_POST['dateFrom'];
		$dateTo = @$_POST['dateTo'];		
		
		if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
		{
			$dateFrom = 'January '.date("Y");
			$dateTo = 'December '.date("Y");
		}
		else
		{
			$dateFrom = $dateFrom;
			$dateTo = $dateTo;
		}
		
		$monthDiff = (date("m",strtotime($dateTo))-date("m",strtotime($dateFrom)));
		$yearDiff = (date("Y",strtotime($dateTo))-date("Y",strtotime($dateFrom)));
		
		for($i=0;$i<=$monthDiff;$i++)
		{
		$startDate = (date("Y",strtotime($dateFrom)))."-".(date("m",strtotime($dateFrom)))."-01";
		$endDate = (date("Y",strtotime($dateFrom)))."-".(date("m",strtotime($dateFrom)))."-".(date("t",strtotime($dateFrom)));
		
		$query = mysql_query("
		SELECT sum(ap_hdr_amount) as 'sum',  monthname(ap_hdr_date) as 'month' 
		FROM  ap_header  
			inner join employee_profile on ap_hdr_created_by_id =emp_id 
		WHERE AP_HDR_REF_TYPE ='Expense'
			and ap_hdr_date between '".$startDate."' and '".$endDate."'
		GROUP BY month desc
		");
	
		
		$dateVal = date('F', mktime(0, 0, 0, date("m",strtotime($dateFrom))));
		if(mysql_num_rows($query)>0)
			{
			$arrResult = mysql_fetch_array($query);
			$expVal = (float)$arrResult['sum'];
			}
			else
			{
			$expVal = (float)0.00;
			}
		$exp[$i] = array($dateVal,$expVal);
		$dateFrom = date("Y-m-d",strtotime($dateFrom."+1 Month"));
		}
		
		}
		
		else 
		echo "";

	$dataArray = json_encode(array("data"=>$output,"exp"=>$exp));
	
	echo $dataArray."&&"."monthly";

