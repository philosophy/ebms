<?php 

session_start();
include("../../../config/config.php");

$query = mysql_query("
	SELECT COUNT(notif_ref_id) as 'cnt', notif_ref_table
	FROM notifications
	GROUP BY notif_ref_table
	");

	while($result = mysql_fetch_array($query))
	{
		/*
			$getTableName = mysql_query("
								SELECT *
								FROM ".$result['notif_ref_table']."
								AS Task
								");
			$setTableName = mysql_field_table($getTableName, 0);
		*/
		
		echo "<b>".$result['notif_ref_table']."</b> ".$result['cnt']." new record/s <br/>";
	}
	
mysql_free_result($query);

?>
