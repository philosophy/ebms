﻿

<?php 
session_start();
include("../../../config/config.php");
$output[] = "";
$monthNum = date("m");
$year = date("Y");
$endDay = cal_days_in_month(CAL_GREGORIAN, $monthNum,$year);

$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];
	
	
	if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
	{
		$dateFrom = $year."-".$monthNum."-01";
		$dateTo = $year."-".$monthNum."-".$endDay;
	}
	
	else
	{
	$dateFrom = $dateFrom;
	$dateTo = $dateTo;
	}
	
$query = mysql_query("
			SELECT a.area_name as 'Type',count(l.customer_id) as 'cnt'
			FROM location l
				inner join area a on a.area_id = l.area_id
				inner join customer_profile c on c.customer_id = l.customer_id
			WHERE c.date_created between '$dateFrom' and '$dateTo'
			GROUP by area_name
			ORDER BY Type;
			");
$i=0;
	if(mysql_num_rows($query)>0)
	{
		while($row = mysql_fetch_array($query))
		{
		$output[$i] = array($row['Type']." = ".$row['cnt'],(int)$row['cnt']);
		$i++;
		}
	
	}

	else 
	{
		$output[0] = array("No records found for these dates (<b>$dateFrom - $dateTo</b>)<br/><b style='color:#06f'>Please select a date on the datepickers above</b>",0);
	}
	
		
	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray;

	mysql_free_result($query);


