<?php 
session_start();
include("../../../config/config.php");
$i=0;
$output[]="";

$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];		
		
		if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
		{
		$dateFrom = 'January '.date("Y");
		$dateTo = 'December '.date("Y");
		}
		
		else
		{
		$dateFrom = $dateFrom;
		$dateTo = $dateTo;
		}
	
		$monthDiff = (date("m",strtotime($dateTo))-(date("m",strtotime($dateTo))-date("m"))-1);
		$yearDiff = (date("Y",strtotime($dateTo))-date("Y",strtotime($dateFrom)));
		
		if($yearDiff == 0)
		{
		for($i=0;$i<=$monthDiff;$i++)
		{
		$startDate = (date("Y",strtotime($dateFrom)))."-".(date("m",strtotime($dateFrom)))."-01";
		$endDate = (date("Y",strtotime($dateFrom)))."-".(date("m",strtotime($dateFrom)))."-".(date("t",strtotime($dateFrom)));
		
		$query = mysql_query("
		SELECT SUM(os_hdr_net_amount) as 'sum',monthname(os_hdr_date) as 'month'
		FROM OS_HEADER
		WHERE os_hdr_date between '$startDate' and '$endDate'
		GROUP BY month desc
		");
		
		$dateVal = date('F', mktime(0, 0, 0, date("m",strtotime($dateFrom))));
		if(mysql_num_rows($query)>0)
			{
			$arrResult = mysql_fetch_array($query);
			$salesVal = (float)$arrResult['sum'];
			}
				
			else
			{
			$salesVal = (float)0.00;
			}
		$output[$i] = array($dateVal,$salesVal);
		$dateFrom = date("Y-m-d",strtotime($dateFrom."+1 Month"));
		}

		$resultMonth=mysql_query("SELECT DATE_FORMAT( os_hdr_date,  '%M' ) AS  'date', SUM( os_hdr_gross_amount ) AS  'sum'
										FROM os_header
										WHERE DATE_FORMAT( os_hdr_date,  '%c' ) 
										IN (
										DATE_FORMAT( CURDATE( ) ,  '%c' ) -1, DATE_FORMAT( CURDATE( ) ,  '%c' )
										)
										GROUP BY DATE_FORMAT( os_hdr_date,  '%M' ) 
										Order by os_hdr_date asc");
		$numRows=mysql_num_rows($resultMonth);
		    if($numRows<2)
			{
			   echo "part1&&";
			}
			else
			{
			while($row = mysql_fetch_array($resultMonth)){
			$month[]=$row['date'];
			$sumM[]=$row['sum'];
			}
			
			$pg = (($sumM[1]-$sumM[0])/$sumM[0])*100;
			$amtpg = $sumM[0]*(round($pg,2)*0.01);
			$amtpg1 = $sumM[0]*(round($pg,2)*0.01);
			$amtpg = $amtpg + $sumM[1];
			
		$fg=$monthDiff+1;
		
		for($ctr=1;$ctr<=12-date("m");$ctr++)
		{
			$dateF=date('F',strtotime("+".$ctr." months"));
			$output[$fg] = array($dateF,$amtpg);
			$fg=$fg+1;
			$amtpg=$amtpg+$amtpg1;
		}
        }
		}
		

	$dataArray = json_encode(array("data"=>$output));
	
	echo $dataArray."&&"."monthly";

