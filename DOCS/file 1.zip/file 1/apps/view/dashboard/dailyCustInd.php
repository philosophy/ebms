﻿<?php 
session_start();
include("../../../config/config.php");
$output[] = "";

$monthNum = date("m");
$year = date("Y");
$endDay = cal_days_in_month(CAL_GREGORIAN, $monthNum,$year);

$dateFrom = @$_POST['dateFrom'];
$dateTo = @$_POST['dateTo'];
	
	
	if((!isset($dateFrom) && !isset($dateTo)) || ($dateFrom == "" && $dateTo == ""))
	{
		$dateFrom = $year."-".$monthNum."-01";
		$dateTo = $year."-".$monthNum."-".$endDay;
	}
	
	else
	{
	$dateFrom = $dateFrom;
	$dateTo = $dateTo;
	}
	
$query = mysql_query("
			SELECT i.industry_type_name as 'Type',COUNT(c.industry_type_id) as 'cnt'
			FROM customer_profile c 
				inner join industry_type i on c.industry_type_id = i.industry_type_id
			WHERE c.date_created between '$dateFrom' and '$dateTo'
			GROUP BY Type
			ORDER BY Type desc
			");
$i=0;
	if(mysql_num_rows($query)>0)
	{
		while($row = mysql_fetch_array($query))
		{
		$output[$i] = array($row['Type']." = ".$row['cnt'],(int)$row['cnt']);
		$i++;
		}
	}
	else 
	{
		$output[0] = array("No records found for these dates (<b>$dateFrom - $dateTo</b>)<br/><b style='color:#06f'>Please select a date on the datepickers above</b>",0);
	}
	
			
	$dataArray = json_encode(array("data"=>$output));
	echo $dataArray;

	mysql_free_result($query);


