﻿<?php include("../doctype-standard.php"); ?>
<head> 
	<?php include("../standard-js-css.php"); ?>
	<link rel="stylesheet" type="text/css" href="/EBMS/css/dashboard-graph-stylesheet.css" />
	<?php
	include("../graph-js-css.php");
	include("../../controller/dashboard/dashboardControllerSales.php");
	?>
  </head> 
  <body>
  <div id="graph-tab-header-title">Dashboard for Sales Monitoring</div>  
  
  
  <?php include("../settings-toolbar/settings-toolbar-datepicker.php"); ?> 
  
	<div id="graph-parent">
		<?php include("../settings-toolbar/appendDatepicker.php"); ?>
		<div id="dailySales" ref="graphPlot"></div>
		<div id="weeklySales" ref="graphPlot"></div>
		<div id="monthlySales" ref="graphPlot"></div>
	</div>
  
</body> 
</html>