
<?php

include("../../../../config/config.php");
$outputData = "";

include "../../accounting/currency.php";

$osCode = @$_POST['osCode'];
	$outputData .= "<table>
		<th>Quantity</th>
		<th>Unit</th>
		<th>Description</th>
		<th>Unit Price (".$symbol.")</th>
		<th>Total Amount (".$symbol.")</th>";
		
$query = mysql_query("Select distinct OS_DTL_ID, OS_DTL_QTY, u.UNIT_NAME,
OS_DTL_ITEM_DESCRIPTION,
p.PRODUCT_UNIT_PRICE,
(os_dtl_qty * p.product_unit_price) as ' Total Amount'
From os_detail, os_header ,unit u, product p
Where p.unit_id = u.unit_id AND
p.PRODUCT_CODE = os_detail.item_id
and os_detail.os_hdr_id = '$osCode' ");
				
	
	if(mysql_num_rows($query) > 0)
	{
	while($arrResult = mysql_fetch_array($query))
	{	
		$outputData .= "<tr a='".$arrResult['OS_DTL_ID']."'>";
		$outputData .=	"<td>".$arrResult['OS_DTL_QTY']."</td>";
		$outputData .=	"<td>".$arrResult['UNIT_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['OS_DTL_ITEM_DESCRIPTION']."</td>";
		$outputData .=	"<td align=right>".number_format($arrResult['PRODUCT_UNIT_PRICE'],2)."</td>";
		$outputData .=	"<td align=right>".number_format($arrResult['Total Amount'],2)."</td>";
		$outputData .= "</tr>";
	}
	
	
	$outputData .= "</table>";
	}
	else
	{
	$outputData = "No records found.";
	}

	
echo $outputData;
	
mysql_free_result($query);