<?php 
session_start();
include("../../../../config/config.php");

$customerId = @$_POST['custId']; 
$locationId = @$_POST['locId'];
$remarks = @$_POST['remarks'];
$terms = @$_POST['terms'];
$deposit = @$_POST['deposit'];
$grossAmount = @$_POST['grossAmount'];
$netAmount = @$_POST['netAmount'];
$discountPercent = @$_POST['discountPercent'];
$isAR = @$_POST['isAR'];
$areaId = "";
$osCode = "";
if($discountPercent == "")
$discountPercent = 0;



	$max = 0;
    $zeros = "000000";
	$query = mysql_query("Select max(OS_HDR_ID) From os_header");
    
	if(mysql_num_rows($query) > 0)
		{	
			while($id= mysql_fetch_array($query))
			{
				$max = $id[0];
			}
			
            $max += 1;
			$my_t= date('Y');
            $osCode = "OS-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
		}
		
	$_SESSION['os'] = $osCode;
	echo $_SESSION['os'];
	$query = mysql_query("Select area_id from location where location_id = '$locationId'");
    
	if(mysql_num_rows($query) > 0)
		{	
			while($id= mysql_fetch_array($query))
			{
				$areaId = $id[0];
			}
		}	

	$query = mysql_query("Insert into os_header(os_hdr_no, os_hdr_date, os_hdr_gross_amount, os_hdr_net_amount, os_hdr_discount_percent, os_hdr_discount_amount, os_hdr_remarks, customer_id, os_hdr_bill_to_id, area_id, sales_person_id, created_by_id, is_ar, os_hdr_deposit, os_hdr_terms) values('$osCode', curdate(), '$grossAmount', '$netAmount', '$discountPercent', $grossAmount - $netAmount, '$remarks', '$customerId', '$locationId', '$areaId', '".$_SESSION['emp_id']."', '".$_SESSION['emp_id']."', '$isAR', '$deposit', '$terms')")or die(mysql_error());

	$query = mysql_query("update customer_profile set is_active = '1' where customer_id = '$customerId'");
	
$paymentNo = "";
$max = 0;
$zeros = "000000";
$payment = mysql_query("Select max(payment_id) From payment");
    
if(mysql_num_rows($payment) > 0)
{	
	while($id= mysql_fetch_array($payment))
	{
		$max = $id[0];
	}
			
    $max += 1;
	$my_t= date('Y');
    $paymentNo = "PN-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
}
	
	
	if($isAR == 1)
	{
		mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$osCode."', ".$netAmount.", 1, 5, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());
		
		mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$osCode."', ".$netAmount.", 1, 3, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());		
	}
	
?>	