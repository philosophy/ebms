<?php 
include("../../../../config/config.php");
$customer = "";

$get = mysql_query("Select customer_id, customer_name, customer_code from customer_profile where is_deleted = 0");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $customer .= "<option code='".$array["customer_code"]."' value='".$array["customer_id"]."'>".$array["customer_name"]."</option>";
		}
	}
	echo $customer;
	
	
?>