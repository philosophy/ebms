<?php
include("../../../../config/config.php");
$qty = @$_POST['qty'];
$itemCode = @$_POST['itemCode'];
$stock = @$_POST['stock'];
$query = mysql_query("Update product set product_qty = product_qty+$qty where product_code = '$itemCode'");
?>