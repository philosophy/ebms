<?php 
include("../../../../config/config.php");
$osId = @$_POST['osCode']; 
$query = mysql_query("delete from os_detail where os_hdr_id = '$osId'");
?>