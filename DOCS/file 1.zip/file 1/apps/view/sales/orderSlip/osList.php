
<?php

include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "and (customer_name LIKE '%".$searchQuery."%' or os_hdr_no LIKE '%".$searchQuery."%' or location_name LIKE '%".$searchQuery."%' or location_address LIKE '%".$searchQuery."%' or area_name LIKE '%".$searchQuery."%' or os_hdr_date LIKE '%".$searchQuery."%' or os_hdr_gross_amount LIKE '%".$searchQuery."%') ";
	}

elseif ($searchQuery == "")
	$condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 7;

$start = $page * $per_page;

include "../../accounting/currency.php";

	$outputData .= "<table>
		<th></th>
		<th>OS. #</th>
		<th>Date Created</th>
		<th>Sold To</th>
		<th>Location</th>
		<th>Address</th>
		<th>Area</th>
		<th>Amount Due (".$symbol.")</th>";
		
$query = "SELECT OS_HDR_NO, OS_HDR_DATE,
c.CUSTOMER_NAME, l.LOCATION_NAME,
l.LOCATION_ADDRESS, a.AREA_NAME, OS_HDR_GROSS_AMOUNT,
OS_HDR_REMARKS, os.IS_DELETED, IS_CLEARED
FROM os_header os, customer_profile c, location l, area a
WHERE c.CUSTOMER_ID = os.CUSTOMER_ID
AND L.LOCATION_ID = os.OS_HDR_BILL_TO_ID
AND a.AREA_ID = os.AREA_ID 
".$condition."
ORDER BY os.IS_DELETED asc, OS_HDR_ID desc";
		
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arr = mysql_query($query." limit $start,$per_page");
	
	
	if(mysql_num_rows($arr) > 0)
	{
	while($arrResult = mysql_fetch_array($arr))
	{	
		
	if($arrResult['IS_DELETED'] == 1)
		$custStatusWidget = "<img title='Deleted' src='../../../../images/icons/deleted-icon.png' width=20 height=20 />";
	else
		$custStatusWidget = "<img src='../../../../images/icons/approved_icon.png' width=20 height=20 />";
		$x = (($arrResult['IS_DELETED']==1)?"deleted=true":"deleted=false");
		$y = (($arrResult['IS_CLEARED']==1)?"cleared=true":"cleared=false");
		
		$outputData .= "<tr ".$x." ".$y." a='".$arrResult['OS_HDR_NO']."'>";
		$outputData .= "<td>".$custStatusWidget."</td>";
		$outputData .=	"<td>".$arrResult['OS_HDR_NO']."</td>";
		$outputData .=	"<td>".date("D M d, Y",strtotime($arrResult['OS_HDR_DATE']))."</td>";
		$outputData .=	"<td>".$arrResult['CUSTOMER_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['LOCATION_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['LOCATION_ADDRESS']."</td>";
		$outputData .=	"<td>".$arrResult['AREA_NAME']."</td>";
		$outputData .=	"<td align=right>".number_format($arrResult['OS_HDR_GROSS_AMOUNT'],2)."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	else
	{
	include("../../noResults.php");
	$cur_page = 0;
	}

	echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
	
