﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Order Slip</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Order Slip Records");
		datagridMenu("OS","new;edit;import;delete;restore");
		datagrid("osList",false);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php 
include("../../modalForms/sales/index.php"); 
include("../../modalForms/accounting/index.php"); 
?>
<div id="updateItems">
	<script>
		$('#updateItems').load('../../../controller/sales/updateItems.php');
	</script>
</div>
<div id='orderSlipController'>
	<script>
		$('#orderSlipController').load('../../../controller/orderSlip/orderSlipController.php');
	</script>
</div>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="osList" class="datagrid-container">
	<script>
		$('#osList').load('../../../controller/sales/orderItemsController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#orderDetails">Order Details</a></li>
	</ul>
	<div id="orderDetails"> 
	Please select an Order Slip above	
	</div> 
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

