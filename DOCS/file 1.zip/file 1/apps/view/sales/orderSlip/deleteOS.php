<?php 
include("../../../../config/config.php");

$osCode = @$_POST['osCode'];
$query = mysql_query("Update os_header set is_deleted = 1 where os_hdr_no = '$osCode'");

?>
