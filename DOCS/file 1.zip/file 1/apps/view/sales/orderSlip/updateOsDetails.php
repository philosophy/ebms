<?php 
include("../../../../config/config.php");

$code = @$_POST['itemCode']; 
$qty = @$_POST['qty'];
$desc = @$_POST['desc'];
$osId = @$_POST['osHdrId'];


$query = mysql_query("Insert into os_detail(os_dtl_qty, os_dtl_item_description, os_hdr_id, item_id) values('$qty', '$desc', '$osId', '$code')");

?>