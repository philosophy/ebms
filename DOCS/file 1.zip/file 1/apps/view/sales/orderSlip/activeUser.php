<?php 
session_start();
include("../../../../config/config.php");
$name = "";
$get = mysql_query("Select Concat(emp_first_name, ' ' , emp_last_name) as 'emp_name' from employee_profile where is_deleted = 0 and emp_id = '".$_SESSION['emp_id']."'");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		  $name = $array["emp_name"];
		}
	}
	echo $name;
?>