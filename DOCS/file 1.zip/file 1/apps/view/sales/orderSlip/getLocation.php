<?php 
include("../../../../config/config.php");
$location = "";
$customerId = @$_POST['customer'];

$get = mysql_query("Select location_id, location_name from location where is_deleted = 0 and customer_id = '$customerId'");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $location .= "<option value='".$array["location_id"]."'>".$array["location_name"]."</option>";
		}
	}
	echo $location;

?>