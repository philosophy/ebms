<?php 
session_start();
include("../../../../config/config.php");
$osCode = @$_POST['osCode']; 
$customerId = @$_POST['custId']; 
$locationId = @$_POST['locId'];
$remarks = @$_POST['remarks'];
$terms = @$_POST['terms'];
$deposit = @$_POST['deposit'];
$grossAmount = @$_POST['grossAmount'];
$netAmount = @$_POST['netAmount'];
$discountPercent = @$_POST['discountPercent'];
$isAR = @$_POST['isAR'];
$areaId = "";
if($discountPercent == "")
$discountPercent = 0;

	$query = mysql_query("Select area_id from location where location_id = '$locationId'");
    
	if(mysql_num_rows($query) > 0)
		{	
			while($id= mysql_fetch_array($query))
			{
				$areaId = $id[0];
			}
		}	
		
		$_SESSION['os'] = $osCode;
		echo $osCode;
		
	$query =  mysql_query("Update os_header set os_hdr_bill_to_id = '$locationId', os_hdr_remarks = '$remarks', os_hdr_gross_amount = '$grossAmount', os_hdr_net_amount = '$netAmount', os_hdr_discount_percent = '$discountPercent', is_ar = '$isAR', area_id = '$areaId' where os_hdr_no = '$osCode'");	
?>