<?php
include("../../../../config/config.php");

$osCode = @$_POST['osCode'];
$query = mysql_query("Select c.customer_id, l.location_id, os_hdr_remarks, os_hdr_gross_amount, os_hdr_net_amount, os_hdr_discount_percent, os_hdr_terms, os_hdr_deposit from os_header os, location l, customer_profile c where os_hdr_no  = '$osCode' and c.customer_id = os.customer_id  and l.location_id = os.os_hdr_bill_to_id");

$data[] = "";
if(mysql_num_rows($query) > 0)
		{	
			while($arrOS= mysql_fetch_array($query))
			{
			$data["name"] = $arrOS["customer_id"];
			$data["location"] = $arrOS["location_id"];
			$data["remarks"] = $arrOS["os_hdr_remarks"];
			$data["gross"] = $arrOS["os_hdr_gross_amount"];
			$data["net"] = $arrOS["os_hdr_net_amount"];
			$data["discount"] = $arrOS["os_hdr_discount_percent"];
			//$data['deposit'] = $arrOs["os_hdr_deposit"];
			//$data['terms'] = $arros["os_hdr_terms"];
			}
		}

$query = mysql_query("Select item_id, os_dtl_qty from os_detail where os_hdr_id = '$osCode'");		
$item[] = "";
if(mysql_num_rows($query) > 0)
		{	
			$x = 0;
			while($arrItem= mysql_fetch_array($query))
			{
			 $item[$x] = $arrItem["item_id"].",".$arrItem["os_dtl_qty"];
			 $x++;
			}
		}		
		
	$dataArray = json_encode(array("values"=>$data, "item"=>$item));
	echo $dataArray;
?>