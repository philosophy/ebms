<?php 
include("../../../../config/config.php");
$get = mysql_query("Select city_id, city_name from city where is_deleted = 0");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $customer .= "<option value='".$array["city_id"]."'>".$array["city_name"]."</option>";
		}
	}
	echo $customer;
?>
	