<?php 
include("../../../../config/config.php");
$shipToId = @$_POST['shipToId'];
$remarks = @$_POST['remarks'];
$deliver = @$_POST['deliver'];
$area = @$_POST['area'];
$contact = @$_POST['contact'];
$dr = @$_POST['drNo'];

$query = mysql_query("update dr_header set dr_hdr_ship_to_id = '$shipToId', dr_hdr_remarks = '$remarks', dr_hdr_delivered_by_id = '$deliver', area_id = '$area',  dr_hdr_ship_contact_id = '$contact' where dr_hdr_no = '$dr'")or die(mysql_error());

?>