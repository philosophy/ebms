<?php 
include("../../../../config/config.php");
$city_id = @$_POST['cityId'];
$get = mysql_query("Select barangay_id, barangay_name from barangay where is_deleted = 0 and city_id= '$city_id'");
 $customer = "";
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $customer .= "<option value='".$array["barangay_id"]."'>".$array["barangay_name"]."</option>";
		}
	}

	echo $customer;
?>
	