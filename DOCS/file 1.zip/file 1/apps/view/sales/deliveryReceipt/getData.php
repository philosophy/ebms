<?php 
include("../../../../config/config.php");
$drCode = @$_POST['drCode'];
$location = "";

$query= mysql_query("select dr_hdr_ship_to_id, area_id, dr_hdr_remarks, dr_hdr_delivered_by_id, dr_hdr_ship_contact_id from dr_header where dr_hdr_no = '$drCode'")or die(mysql_error());
$data[] = "";

if(mysql_num_rows($query) > 0)
		{	
			while($arrDr= mysql_fetch_array($query))
			{
			$data["shipToId"] = $arrDr["dr_hdr_ship_to_id"];	
			$location = $data["shipToId"];
			$data["remarks"] = $arrDr["dr_hdr_remarks"];
			$data["deliver"] = $arrDr["dr_hdr_delivered_by_id"];
			$data["area"] = $arrDr["area_id"];
			$data["contact"] = $arrDr["dr_hdr_ship_contact_id"];
			}
		}

$query= mysql_query("select location_address from location where location_id = '$location'");
if(mysql_num_rows($query) > 0)
		{	
			while($arrDr= mysql_fetch_array($query))
			{
			$data["address"] = $arrDr["location_address"];
			}
		}
		
	$dataArray = json_encode(array("values"=>$data));
	echo $dataArray;


?>