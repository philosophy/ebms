<?php 
include("../../../../config/config.php");

$code = @$_POST['itemCode']; 
$qty = @$_POST['qty'];
$desc = @$_POST['desc'];
$osId = @$_POST['drHdrId'];
echo $code;
$query = mysql_query("Insert into dr_detail(dr_dtl_qty, dr_dtl_item_description, dr_hdr_id, item_id) values('$qty', '$desc', '$osId', '$code')")or die(mysql_error());

?>