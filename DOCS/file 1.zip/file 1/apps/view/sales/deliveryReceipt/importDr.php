<?php
session_start();
include("../../../../config/config.php");

$osCode = @$_POST['osCode']; 


	$max = 0;
    $zeros = "000000";
	$query = mysql_query("Select max(DR_HDR_ID) From dr_header");
    
	if(mysql_num_rows($query) > 0)
		{	
			while($id= mysql_fetch_array($query))
			{
				$max = $id[0];
			}
			
            $max += 1;
			$my_t= date('Y');
            $drCode = "DR-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
		}

$query = mysql_query("SELECT `OS_HDR_ID`, `OS_HDR_NO`, `OS_HDR_DATE`, `OS_HDR_GROSS_AMOUNT`, `OS_HDR_NET_AMOUNT`, `OS_HDR_DISCOUNT_PERCENT`, `OS_HDR_DISCOUNT_AMOUNT`, `OS_HDR_REMARKS`, os.`IS_DELETED`, os.`CUSTOMER_ID`, l.location_address, l.barangay_id, l.city_id, `OS_HDR_BILL_TO_ID`, os.`AREA_ID`, emp_first_name, emp_last_name, `CREATED_BY_ID`, `IS_AR` FROM os_header os, employee_profile e, location l WHERE OS_HDR_NO = '$osCode' and e.emp_id = '".$_SESSION['emp_id']."' and os_hdr_bill_to_id = location_id")or die(mysql_error());

$data[] = "";
if(mysql_num_rows($query) > 0)
		{	
			while($arrCustomer = mysql_fetch_array($query))
			{
			$data["city"] = $arrCustomer["city_id"];
			$data["grossAmount"] = number_format($arrCustomer["OS_HDR_GROSS_AMOUNT"], 2);
			$data["netAmount"] = number_format($arrCustomer["OS_HDR_NET_AMOUNT"],2);
			$data["customerId"] = $arrCustomer["CUSTOMER_ID"];
			$data["billToId"] = $arrCustomer["OS_HDR_BILL_TO_ID"];
			$data["areaId"] = $arrCustomer["AREA_ID"];
			$data["empName"] = $arrCustomer["emp_first_name"].' '.$arrCustomer["emp_last_name"];
			$data["address"] = $arrCustomer["location_address"];
			$data["barangay"] = $arrCustomer["barangay_id"];
			$data["discount"] = $arrCustomer["OS_HDR_DISCOUNT_PERCENT"];
			}
		}

$dataArray = json_encode(array("values"=>$data));
echo $dataArray;


		
?>