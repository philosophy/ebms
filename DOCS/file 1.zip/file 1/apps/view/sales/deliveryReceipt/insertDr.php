<?php 
session_start();
include("../../../../config/config.php");

$drRefNo = @$_POST['drRefNo'];
$customerId = @$_POST['customerId']; 
$shipToId = @$_POST['shipToId'];
$area = @$_POST['area'];
$contact = @$_POST['contact'];
$grossAmount = @$_POST['grossAmount'];
$netAmount = @$_POST['netAmount'];
$discount = @$_POST['discount'];
$deliveredBy = @$_POST['deliveredBy'];
$remarks = @$_POST['remarks'];

	$max = 0;
    $zeros = "000000";
	$query = mysql_query("Select max(DR_HDR_ID) From dr_header");
    
	if(mysql_num_rows($query) > 0)
		{	
			while($id= mysql_fetch_array($query))
			{
				$max = $id[0];
			}
			
            $max += 1;
			$my_t= date('Y');
            $osCode = "DR-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
		}
	else
		$osCode = "DR-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . '1';
		echo $osCode;
		$_SESSION['dr_code'] = $osCode;
		
$query = mysql_query("Select os_hdr_bill_to_id from os_header where os_hdr_no ='$drRefNo'");
$id = mysql_fetch_array($query);
$billToId = $id['os_hdr_bill_to_id'];	


mysql_query("INSERT INTO `dr_header`(`DR_HDR_NO`, `DR_HDR_DATE`, `DR_HDR_REF_NO`, `CUSTOMER_ID`, `DR_HDR_BILL_TO_ID`, `DR_HDR_SHIP_TO_ID`, `AREA_ID`, `DR_HDR_SHIP_CONTACT_ID`, `DR_HDR_DELIVERED_BY_ID`, `DR_HDR_CREATED_BY_ID`, dr_hdr_gross_amount, dr_hdr_net_amount, dr_hdr_discount_percent, dr_hdr_remarks) VALUES ('$osCode',curdate(),'$drRefNo', '$customerId','$billToId','$shipToId','$area','$contact','$deliveredBy','".$_SESSION['emp_id']."', REPLACE('$grossAmount', ',', ''), REPLACE('$netAmount', ',', ''), '$discount', '$remarks')")or die(mysql_error());

mysql_query("update os_header set is_cleared = 1 where os_hdr_no = '$drRefNo'");
		
?>