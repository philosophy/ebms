<?php 
include("../../../../config/config.php");

$get = mysql_query("Select emp_id, emp_first_name, emp_last_name from employee_profile where is_deleted = 0");
$customer = "";
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $customer .= "<option value='".$array["emp_id"]."'>".$array["emp_first_name"].' '.$array["emp_last_name"]."</option>";
		}
	}
	echo $customer;
?>
	