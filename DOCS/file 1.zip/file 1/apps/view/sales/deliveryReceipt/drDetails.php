
<?php

include("../../../../config/config.php");
$outputData = "";

$drCode = @$_POST['drCode'];
	$outputData .= "<table>
		<th>Quantity</th>
		<th>Unit</th>
		<th>Description</th>";
		
$query = mysql_query("Select distinct DR_DTL_ID, DR_DTL_QTY, u.UNIT_NAME,
DR_DTL_ITEM_DESCRIPTION,
p.PRODUCT_UNIT_PRICE,
(dr_dtl_qty * p.product_unit_price) as ' Total Amount'
From dr_detail, dr_header ,unit u, product p
Where p.unit_id = u.unit_id AND
p.PRODUCT_CODE = dr_detail.item_id
and dr_detail.dr_hdr_id = '$drCode'")or die(mysql_error());
				
	
	if(mysql_num_rows($query) > 0)
	{
		while($arrResult = mysql_fetch_array($query))
		{	
			$outputData .= "<tr a='".$arrResult['DR_DTL_ID']."'>";
			$outputData .=	"<td style='text-align:center'>".$arrResult['DR_DTL_QTY']."</td>";
			$outputData .=	"<td style='text-align:center'>".$arrResult['UNIT_NAME']."</td>";
			$outputData .=	"<td>".$arrResult['DR_DTL_ITEM_DESCRIPTION']."</td>";
			$outputData .= "</tr>";
		}
	
		$outputData .= "</table>";
	}
	else
	{
	$outputData = "No records found.";
	}
	

	
echo $outputData;
	
mysql_free_result($query);