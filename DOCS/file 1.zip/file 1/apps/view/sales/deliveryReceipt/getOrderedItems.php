<?php 
include("../../../../config/config.php");
$osCode = @$_POST['osCode'];
	$query = mysql_query("Select os_dtl_qty, item_id, p.product_unit_price, os_dtl_item_description from os_detail os, product p where os_hdr_id = '$osCode' and item_id = p.product_code");
	
$data[] = "";
if(mysql_num_rows($query) > 0)
		{	
			$x = 0;
			while($arrCustomer = mysql_fetch_array($query))
			{
			$data[$x] = $arrCustomer["os_dtl_qty"]."~".$arrCustomer["item_id"]."~".$arrCustomer["os_dtl_item_description"]."~".number_format($arrCustomer["product_unit_price"],2);
			$x++;
			}
		}

$dataArray = json_encode(array("values"=>$data));
echo $dataArray;

?>