
<?php

include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " and (dr_hdr_no LIKE '%".$searchQuery."%' or dr_hdr_date LIKE '%".$searchQuery."%' or dr_hdr_ref_no LIKE '%".$searchQuery."%' or customer_name LIKE '%".$searchQuery."%' or l.location_name LIKE '%".$searchQuery."%' or l.location_address LIKE '%".$searchQuery."%' or r.location_address LIKE '%".$searchQuery."%' or b.area_name LIKE '%".$searchQuery."%'  or r.location_name LIKE '%".$searchQuery."%'  or r.location_address LIKE '%".$searchQuery."%' or CONCAT(e.EMP_LAST_NAME, ' ' , e.EMP_MIDDLE_NAME, ' ' , e.EMP_FIRST_NAME) LIKE '%".$searchQuery."%' or CONCAT(emp.EMP_LAST_NAME, ' ' , emp.EMP_MIDDLE_NAME, ' ' , emp.EMP_FIRST_NAME) LIKE '%".$searchQuery."%')";
	}

elseif ($searchQuery == "")
	$condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 10;

$start = $page * $per_page;

	$outputData .= "<table>
		<th></th>
		<th>DR. #</th>
		<th>Ref. No</th>
		<th>Date</th>
		<th>Sold To</th>
		<th>Billing Location</th>
		<th>Billing Address</th>
		<th>Billing Area</th>
		<th>Shipping Location</th>
		<th>Shipping Address</th>
		<th>Shipping Area</th>
		<th>Sales Person</th>
		<th>Delivered By</th>";
		
$query = "Select DR_HDR_ID, DR_HDR_NO, DR_HDR_DATE, DR_HDR_REF_NO,
c.CUSTOMER_NAME, l.LOCATION_NAME as 'Billing Location', l.LOCATION_ADDRESS as 'Billing Address',
a.AREA_NAME as 'Billing Area', r.LOCATION_NAME as 'Shipping Location', r.LOCATION_ADDRESS as 'Shipping Address',
b.AREA_NAME  as 'Shipping Area', CONCAT(e.EMP_LAST_NAME, ' ' , e.EMP_MIDDLE_NAME, ' ' , e.EMP_FIRST_NAME) as 'Sales Person',
CONCAT(emp.EMP_LAST_NAME, ' ' , emp.EMP_MIDDLE_NAME, ' ' , emp.EMP_FIRST_NAME) as 'Delivered By', dr.IS_DELETED
FROM dr_header dr, customer_profile c, location l, location r, area a, area b, employee_profile e, employee_profile emp
WHERE c.CUSTOMER_ID = dr.CUSTOMER_ID AND l.LOCATION_ID = dr.DR_HDR_BILL_TO_ID AND r.LOCATION_ID = dr.DR_HDR_SHIP_TO_ID
AND e.EMP_ID = dr.DR_HDR_DELIVERED_BY_ID AND emp.EMP_ID = dr.DR_HDR_CREATED_BY_ID and a.area_id = l.area_id and b.`AREA_ID` = r.`AREA_ID` ".$condition." ORDER BY dr.IS_DELETED asc, dr_hdr_id";

	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arr = mysql_query($query." limit $start,$per_page");
	
				
	if(mysql_num_rows($arr) > 0)
	{
	while($arrResult = mysql_fetch_array($arr))
	{	
		if($arrResult['IS_DELETED'] == 1)
		$custStatusWidget = "<img title='Deleted' src='../../../../images/icons/deleted-icon.png' width=20 height=20 />";
	else
		$custStatusWidget = "<img src='../../../../images/icons/approved_icon.png' width=20 height=20 />";
		$x = (($arrResult['IS_DELETED']==1)?"deleted=true":"deleted=false");
	
	
		$outputData .= "<tr ".$x." a='".$arrResult['DR_HDR_NO']."' y='".$arrResult['DR_HDR_REF_NO']."'>";
		$outputData .= "<td>".$custStatusWidget."</td>";
		$outputData .=	"<td>".$arrResult['DR_HDR_NO']."</td>";
		$outputData .=	"<td>".$arrResult['DR_HDR_REF_NO']."</td>";
		$outputData .=	"<td>".date("D M d, Y",strtotime($arrResult['DR_HDR_DATE']))."</td>";
		$outputData .=	"<td>".$arrResult['CUSTOMER_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['Billing Location']."</td>";
		$outputData .=	"<td>".$arrResult['Billing Address']."</td>";
		$outputData .=	"<td>".$arrResult['Billing Area']."</td>";
		$outputData .=	"<td>".$arrResult['Shipping Location']."</td>";
		$outputData .=	"<td>".$arrResult['Shipping Address']."</td>";
		$outputData .=	"<td>".$arrResult['Shipping Area']."</td>";
		$outputData .=	"<td>".$arrResult['Sales Person']."</td>";
		$outputData .=	"<td>".$arrResult['Delivered By']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	
	
	else
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
 
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
	
