<?php 
include("../../../../config/config.php");
$city_id = @$_POST['locationId'];
$get = mysql_query("Select contact_id, contact_name from contact c, location l where c.is_deleted = 0 and c.location_id = l.location_id and c.location_id = '$city_id'")or die(mysql_error());
$customer = "";
$address = "";
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $customer .= "<option value='".$array["contact_id"]."'>".$array["contact_name"]."</option>";
		}
	}
	
$get = mysql_query("select location_address from location where location_id = '$city_id'")or die(mysql_error());
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $address = $array["location_address"];
		}
	}

	echo $customer.",".$address;
?>