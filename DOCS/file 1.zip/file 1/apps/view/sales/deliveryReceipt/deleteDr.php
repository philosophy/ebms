<?php 
include("../../../../config/config.php");

$osCode = @$_POST['drCode'];
$query = mysql_query("Update dr_header set is_deleted = 1 where dr_hdr_no = '$osCode'");

?>
