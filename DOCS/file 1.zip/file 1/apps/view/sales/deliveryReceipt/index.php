﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Delivery Receipt</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Delivery Receipt Records");
		datagridMenu("dr","edit;delete;restore");
		datagrid("drList",false);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php 
include("../../modalForms/sales/index.php"); 
?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="drList" class="datagrid-container">
	<script>
		$('#drList').load('../../../controller/deliveryReceipt/deliveryReceiptController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#drDetails">Delivery Receipt Details</a></li>
	</ul>
	<div id="drDetails"> 
	Please select a Delivery Receipt above	
	</div> 
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

