<?php 
include("../../../../config/config.php");
$get = mysql_query("Select area_id, area_name from area where is_deleted = 0");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $customer .= "<option value='".$array["area_id"]."'>".$array["area_name"]."</option>";
		}
	}
	echo $customer;
?>
	