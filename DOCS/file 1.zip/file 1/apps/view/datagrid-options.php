<script type="text/javascript" src="/EBMS/js/checkTaskAlarm.js"></script>

<div id="datagrid-options">
	<div id="head-title"></div>
	
	<div id="datepickers">
		<label class="datepickerLabel">From</label>
			<input type="text" id="from" class="datepickerInput">
		<label class="datepickerLabel">To</label>
			<input type="text" id="to" class="datepickerInput">
		<button type="button" id="go">Go</button>
	</div>
	
	<div id="listType">
		<select id="productAssetList">
			<option value="product">Product</option>
			<option value="asset">Asset</option>
		</select>
	</div>
	
	<div id="options">
	<img src="/EBMS/images/icons/pdf-icon.png" alt="View in PDF"  title="View in PDF" id="pdf">
	</div>
	
	<div id="options-box">
	<ul class="options-dropdown">
		<li>
			<img src="/EBMS/images/icons/pdf-icon.png" alt="View in PDF"  title="View in PDF">
			<a href="#" id="pdf">View in PDF</a>
		</li>
		<li>
			<img src="/EBMS/images/icons/printer-icon.png" alt="Print" title="Print this document">
			<a href="#">Print this Document</a>
		</li>
		<li>
			<img src="/EBMS/images/icons/popout-icon.png" alt="Popout" title="View in popup window">
			<a href="#">View in Popup Window</a>
		</li>
	</ul>
	</div>
	
	<script>
	
		$(document).ready(function(){
			$("#search-btn").click(function(){
				loadData(1,"");
				});
				
			
				
			$("#datagrid-search-box").bind("keyup paste keypress keydown change",function(){
					
					loadData(1,"");
					
				});
		});
	</script>
	
	
	<input type="text" id="datagrid-search-box" name="search-box" class="search-box">
	<button type="submit" id="search-btn"></button>
	
	<div id="pagination">
		<div id="pageno"></div>
		<ul class="page-nav">
			<li><button id="First" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;" title="Jump to first page"></button></li>
			<li><button id="Prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;" title="Go to previous page"></button></li>
			<li><button id="Next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;" title="Go to next page"></button></li>
			<li><button id="Last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;" title="Jump to last page"></button></li>
		</ul>
	</div>
</div>

<script>
	$(function(){
		
	//view in pdf
	
	/*
	$("#datagrid-options .datagrid-widget li").hover(function(){
		$(this).find("img").stop().animate({marginTop:"-10px"},"slow");
		},function(){
		$(this).find("img").stop().animate({marginTop:"0px"},"slow");
		});
	*/
	inputMask("datagrid-search-box","Search...");
	});	
</script>


<div id='loading'><h3>Loading...<img src="/ebms/images/icons/pageLoading.gif"></h3></div>
