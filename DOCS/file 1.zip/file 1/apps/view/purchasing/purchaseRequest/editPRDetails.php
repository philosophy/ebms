<?php
include("../../../../config/config.php");

$code = $_POST['code'];
$prID = $_POST['id'];
$qty = $_POST['qty'];

mysql_query("UPDATE pr_detail SET PR_DTL_QTY='$qty' WHERE PR_HDR_ID='".$prID."' AND ITEM_CODE='".$code."'");
?>