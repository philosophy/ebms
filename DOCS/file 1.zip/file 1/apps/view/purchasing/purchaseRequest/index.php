﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Purchase Request Approval</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(function(){
		headTitle("Purchase Request Approval");
		datagrid("purchase-request",true);
		datagridMenu("pr","new;edit;delete;restore");
		$("#tabbed-grid").tabs();
		});
		
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
</div>
<?php 
include("../../../controller/purchaseRequest/itemListController.php");
include("../../modalForms/purchasing/index.php"); 
include("../../../controller/purchaseRequest/requestorController.php");
?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="purchase-request" class="datagrid-container">
	<!-- Purchase Request List -->
	<script>
		$('#purchase-request').load('../../../controller/purchaseRequest/purchaseRequestController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#request-item">Request Item</a></li> 
	</ul>
	
	<div id="request-item">
		<!-- Purchase Request Details -->
	</div>
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

