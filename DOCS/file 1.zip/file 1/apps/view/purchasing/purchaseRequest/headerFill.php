<?php
session_start();
include("../../../../config/config.php");

$prID = $_POST['prID'];
$editPR[] = "";

$query = "SELECT PR_HDR_NO, PR_HDR_DATE_NEEDED, PR_HDR_DATE_CREATED, PR_HDR_REMARKS, CONCAT(EMP_FIRST_NAME, ' ', EMP_LAST_NAME) as 'Requestor' FROM pr_header pr INNER JOIN employee_profile e ON  pr.PR_HDR_REQUESTOR_ID = e.EMP_ID WHERE PR_HDR_ID='".$prID."'";

$result = mysql_query($query);

while($arrPR = mysql_fetch_array($result))
{
	$editPR['code'] = $arrPR['PR_HDR_NO'];
	$editPR['dateNeeded'] = $arrPR['PR_HDR_DATE_NEEDED'];
	$editPR['dateCreated'] = $arrPR['PR_HDR_DATE_CREATED'];
	$editPR['remarks'] = $arrPR['PR_HDR_REMARKS'];
	$editPR['requestor'] = $arrPR['Requestor'];
}
$dataPR = json_encode(array("values"=>$editPR));
echo $dataPR;
?>