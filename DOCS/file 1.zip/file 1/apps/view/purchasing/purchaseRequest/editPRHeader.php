<?php
session_start();
include("../../../../config/config.php");

$prID = $_POST['id'];
$dateNeeded = $_POST['dateNeeded'];
$remarks = $_POST['remarks'];

mysql_query("UPDATE pr_header SET PR_HDR_DATE_NEEDED='$dateNeeded', PR_HDR_REMARKS='$remarks' WHERE PR_HDR_ID='".$prID."'");
?>