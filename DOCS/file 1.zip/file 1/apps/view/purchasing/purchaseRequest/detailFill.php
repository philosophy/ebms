<?php
session_start();
include("../../../../config/config.php");

$prID = $_POST['prID'];
$outputData = "";

$query = "SELECT pr.PR_DTL_QTY, u.UNIT_NAME, pr.ITEM_CODE, p.PRODUCT_UNIT_PRICE, c.CATEGORY_NAME, pr.PR_DTL_ITEM_DESCRIPTION  FROM pr_detail pr
INNER JOIN unit u ON pr.UNIT_ID = u.UNIT_ID
INNER JOIN product p ON pr.ITEM_CODE = p.PRODUCT_CODE
INNER JOIN category c ON p.CATEGORY_ID = c.CATEGORY_ID
WHERE PR_HDR_ID='".$prID."'";

$result = mysql_query($query);

while($arrResult = mysql_fetch_array($result))
{
	$outputData .= "<tr>";
	$outputData .=	"<td><input type='number' id='qty' value='".$arrResult['PR_DTL_QTY']."' />;</td>";
	$outputData .=	"<td>".$arrResult['UNIT_NAME'].";</td>";
	$outputData .=	"<td>".$arrResult['ITEM_CODE'].";</td>";
	$outputData .=	"<td>".$arrResult['PRODUCT_UNIT_PRICE'].";</td>";
	$outputData .=	"<td>".$arrResult['CATEGORY_NAME'].";</td>";
	$outputData .=	"<td>".$arrResult['PR_DTL_ITEM_DESCRIPTION'].";</td>";
	$outputData .= "</tr>";
}
echo $outputData;
?>