<?php
include("../../../../config/config.php");

$unit = $_POST['unit'];
$code = $_POST['code'];
$cat = $_POST['cat'];
$desc = $_POST['desc'];
$qty = $_POST['qty'];

	$maxQuery = "SELECT MAX(PR_HDR_ID) as 'max' FROM pr_header";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	
	$unitQuery = "SELECT UNIT_ID as 'unit' FROM UNIT WHERE UNIT_NAME='".$unit."'";
	$unitResult = mysql_query($unitQuery);
	$unitId = mysql_fetch_array($unitResult);
	
	$isAsset = substr($code,0,2);
	
	if ($isAsset == "AS")
	{
		$flag = "A";
	}
	else
	{
		$flag = "P";
	}
	

$query = "INSERT INTO pr_detail(PR_DTL_QTY, PR_DTL_ITEM_DESCRIPTION, PR_HDR_ID, UNIT_ID, ITEM_CODE, ITEM_FLAG) VALUES('$qty', '$desc', '".$max['max']."', '".$unitId['unit']."', '$code', '$flag')";
$result = mysql_query($query);
?>