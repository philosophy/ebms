<?php
session_start();
include("../../../../config/config.php");

$dateNeeded = $_POST['dateNeeded'];
$requestorId = $_POST['requestorId'];
$remarks = $_POST['remarks'];
$user = $_SESSION['login'];

$zeros = "000000";

$countQuery = "SELECT COUNT(PR_HDR_ID) FROM pr_header";
$countResult = mysql_query($countQuery);
//$records = mysql_fetch_array($countResult)

if (mysql_num_rows($countResult) == 0)
{
	$prCode = "PR-".date("Y")."-000001";
}
else
{
	$maxQuery = "SELECT MAX(PR_HDR_ID) as 'max' FROM pr_header";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	$max['max'] += 1;
	$prCode = "PR-".date("Y")."-".substr($zeros, 0, 6 - strlen($max['max'])).$max['max'];
	//$prCode = "PR-".date("Y")."-000001";
}

$query = "INSERT INTO pr_header(PR_HDR_NO, PR_HDR_DATE_REQUESTED, PR_HDR_DATE_NEEDED, PR_HDR_DATE_CREATED, PR_HDR_REMARKS, IS_DELETED, PR_HDR_REQUESTOR_ID, PR_HDR_CREATED_BY_ID) VALUES('$prCode', curdate(), '$dateNeeded', curdate(), '$remarks', '0','$requestorId', '$user')";
$result = mysql_query($query);

?>