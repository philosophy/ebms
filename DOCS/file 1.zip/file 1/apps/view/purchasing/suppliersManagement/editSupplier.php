<?php
session_start();
include("../../../../config/config.php");

$suppName = $_POST['suppName'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$phone = $_POST['phone'];
$fax = $_POST['fax'];
$remarks = $_POST['remarks'];
$industry = $_POST['industry'];
$code = $_POST['code'];

$query = mysql_query("UPDATE supplier_profile SET SUPPLIER_NAME='$suppName', SUPPLIER_EMAIL_ADDRESS='$email', SUPPLIER_PHONE_NO='$phone' ,SUPPLIER_MOBILE_NO='$mobile', SUPPLIER_FAX_NO='$fax', SUPPLIER_REMARKS='$remarks', INDUSTRY_TYPE_ID='$industry' WHERE SUPPLIER_CODE='$code'");
?>