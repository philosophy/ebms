<?php
include("../../../../config/config.php");

$query = "SELECT POSITION_ID, POSITION_NAME FROM position WHERE IS_DELETED = 0";
$result = mysql_query($query);
$jobList = '';
while($record = mysql_fetch_array($result))
{
    $jobList .= "<option value='".$record['POSITION_ID']."'>".$record['POSITION_NAME']."</option>";
}
echo $jobList;
?>