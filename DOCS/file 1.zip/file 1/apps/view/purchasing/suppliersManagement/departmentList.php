<?php
include("../../../../config/config.php");

$jobID = @$_POST['jobid'];

$query = "SELECT d.DEPT_ID, DEPT_NAME FROM department d
INNER JOIN position p ON p.DEPT_ID = d.DEPT_ID
WHERE POSITION_ID = '".$jobID."'";
$result = mysql_query($query);
$departmentList = '';
while($record = mysql_fetch_array($result))
{
    $departmentList .= "<option value='".$record['DEPT_ID']."'>".$record['DEPT_NAME']."</option>";
}
echo $departmentList;
?>