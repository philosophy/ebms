<?php
session_start();
include("../../../../config/config.php");

$locName = $_POST['locName'];
$locType = $_POST['locType'];
$city = $_POST['city'];
$brgy = $_POST['brgy'];
$area = $_POST['area'];
$address = $_POST['address'];
$phone = $_POST['lphone'];
$fax = $_POST['lfax'];


	$maxQuery = "SELECT MAX(SUPPLIER_ID) as 'max' FROM supplier_profile";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);


$query = "INSERT INTO location(LOCATION_NAME, LOCATION_ADDRESS, LOCATION_PHONE_NO, LOCATION_FAX_NO, IS_DELETED, AREA_ID, CITY_ID, BARANGAY_ID, CUSTOMER_ID, LOCATION_TYPE_ID, FLAG) VALUES ('$locName','$address','$phone','$fax','0','$area','$city','$brgy','".$max['max']."','$locType','S')";
$result = mysql_query($query);
?>