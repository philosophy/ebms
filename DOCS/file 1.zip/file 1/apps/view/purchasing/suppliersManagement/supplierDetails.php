<?php
session_start();
include("../../../../config/config.php");

$suppCode = $_POST['suppCode'];
$editSupplier[] = "";
$editContact[] = "";
$editLocation[] = "";

$query = "SELECT SUPPLIER_ID, SUPPLIER_CODE, SUPPLIER_NAME, SUPPLIER_EMAIL_ADDRESS, SUPPLIER_PHONE_NO, SUPPLIER_MOBILE_NO, SUPPLIER_FAX_NO, SUPPLIER_REMARKS, INDUSTRY_TYPE_ID FROM supplier_profile WHERE SUPPLIER_CODE = '".$suppCode."'";
$result = mysql_query($query);


$arrSupplier = mysql_fetch_array($result);

	$editSupplier['sID'] = $arrSupplier['SUPPLIER_ID'];
	$editSupplier['sCode'] = $arrSupplier['SUPPLIER_CODE'];
	$editSupplier['sName'] = $arrSupplier['SUPPLIER_NAME'];
	$editSupplier['sMail'] = $arrSupplier['SUPPLIER_EMAIL_ADDRESS'];
	$editSupplier['sPhone'] = $arrSupplier['SUPPLIER_PHONE_NO'];
	$editSupplier['sMobile'] = $arrSupplier['SUPPLIER_MOBILE_NO'];
	$editSupplier['sFax'] = $arrSupplier['SUPPLIER_FAX_NO'];
	$editSupplier['sRemarks'] = $arrSupplier['SUPPLIER_REMARKS'];
	$editSupplier['sIndustryID'] = $arrSupplier['INDUSTRY_TYPE_ID'];
	
$query2 = mysql_query("SELECT LOCATION_ID, LOCATION_NAME, LOCATION_ADDRESS, LOCATION_PHONE_NO, LOCATION_FAX_NO, LOCATION_REMARKS, AREA_ID, CITY_ID, BARANGAY_ID, LOCATION_TYPE_ID  FROM `location` WHERE FLAG = 'S' AND  CUSTOMER_ID = '".$editSupplier['sID']."'");
$arrSupplier = mysql_fetch_array($query2);

	$editLocation['lID'] = $arrSupplier['LOCATION_ID'];
	$editLocation['lName'] = $arrSupplier['LOCATION_NAME'];
	$editLocation['lAddress'] = $arrSupplier['LOCATION_ADDRESS'];
	$editLocation['lPhone'] = $arrSupplier['LOCATION_PHONE_NO'];
	$editLocation['lFax'] = $arrSupplier['LOCATION_FAX_NO'];
	$editLocation['lRemarks'] = $arrSupplier['LOCATION_REMARKS'];
	$editLocation['lAreaID'] = $arrSupplier['AREA_ID'];
	$editLocation['lCityID'] = $arrSupplier['CITY_ID'];
	$editLocation['lBrgyID'] = $arrSupplier['BARANGAY_ID'];
	$editLocation['lLocID'] = $arrSupplier['LOCATION_TYPE_ID'];

$query3 = mysql_query("SELECT CONTACT_ID, CONTACT_NAME, CONTACT_EMAIL_ADDRESS, CONTACT_PHONE_NO, CONTACT_MOBILE_NO, CONTACT_FAX_NO, POSITION_ID, DEPARTMENT_ID FROM contact WHERE LOCATION_ID = '".$editLocation['lID']."'");
$arrSupplier = mysql_fetch_array($query3);

	$editContact['cID'] = $arrSupplier['CONTACT_ID'];
	$editContact['cName'] = $arrSupplier['CONTACT_NAME'];
	$editContact['cMail'] = $arrSupplier['CONTACT_EMAIL_ADDRESS'];
	$editContact['cPhone'] = $arrSupplier['CONTACT_PHONE_NO'];
	$editContact['cMobile'] = $arrSupplier['CONTACT_MOBILE_NO'];
	$editContact['cFax'] = $arrSupplier['CONTACT_FAX_NO'];
	$editContact['dept'] = $arrSupplier['DEPARTMENT_ID'];
	$editContact['jobTitle'] = $arrSupplier['POSITION_ID'];
	

$dataSupplier = json_encode(array("values"=>$editSupplier, "loc"=>$editLocation, "contact"=>$editContact));
echo $dataSupplier;
?>