<?php
session_start();
include("../../../../config/config.php");

$contactName = $_POST['contactName'];
$job = $_POST['job'];
$dept = $_POST['dept'];
$email = $_POST['cemail'];
$mobile = $_POST['cmobile'];
$phone = $_POST['cphone'];
$fax = $_POST['cfax'];


	$maxQuery = "SELECT MAX(LOCATION_ID) as 'max' FROM location";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	
	$deptQuery = mysql_query("SELECT DEPT_NAME as 'deptName' FROM department WHERE DEPT_ID='".$dept."'");
	$deptName = mysql_fetch_array($deptQuery);
	
	$jobQuery = mysql_query("SELECT POSITION_NAME as 'jobName' FROM position WHERE POSITION_ID='".$job."'");
	$jobName = mysql_fetch_array($jobQuery);


$query = "INSERT INTO contact(CONTACT_NAME, CONTACT_DEPARTMENT, CONTACT_JOB_TITLE, CONTACT_EMAIL_ADDRESS, CONTACT_PHONE_NO, CONTACT_MOBILE_NO, CONTACT_FAX_NO, IS_DELETED, LOCATION_ID, POSITION_ID, DEPARTMENT_ID) VALUES ('$contactName','".$deptName['deptName']."','".$jobName['jobName']."','$email','$phone','$mobile','$fax ','0','".$max['max']."','$job','$dept')";
$result = mysql_query($query);
?>