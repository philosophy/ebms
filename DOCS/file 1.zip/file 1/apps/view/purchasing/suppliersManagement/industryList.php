<?php
include("../../../../config/config.php");

$industry = "";

$query = "SELECT INDUSTRY_TYPE_ID, INDUSTRY_TYPE_NAME FROM industry_type WHERE IS_DELETED = 0";
$result = mysql_query($query);
$industryList = '';
while($record = mysql_fetch_array($result))
{
    $industryList .= "<option value='".$record['INDUSTRY_TYPE_ID']."'>".$record['INDUSTRY_TYPE_NAME']."</option>";
}
echo $industryList;
?>