<?php
session_start();
include("../../../../config/config.php");

$contactName = $_POST['contactName'];
$job = $_POST['job'];
$dept = $_POST['dept'];
$email = $_POST['cemail'];
$mobile = $_POST['cmobile'];
$phone = $_POST['cphone'];
$fax = $_POST['cfax'];
$code = $_POST['code'];

$locName = $_POST['locName'];
$locType = $_POST['locType'];
$city = $_POST['city'];
$brgy = $_POST['brgy'];
$area = $_POST['area'];
$address = $_POST['address'];
$lphone = $_POST['lphone'];
$lfax = $_POST['lfax'];


	$idQuery = "SELECT SUPPLIER_ID as 'suppid' FROM supplier_profile WHERE SUPPLIER_CODE='".$code."'";
	$result = mysql_query($idQuery);
	$id = mysql_fetch_array($result);
	
	$locQuery = "SELECT LOCATION_ID as 'locid' FROM location WHERE CUSTOMER_ID='".$id['suppid']."' AND FLAG='S'";
	$locResult = mysql_query($locQuery);
	$locID = mysql_fetch_array($locResult);
	
	$deptQuery = mysql_query("SELECT DEPT_NAME as 'deptName' FROM department WHERE DEPT_ID='".$dept."'");
	$deptName = mysql_fetch_array($deptQuery);
	
	$jobQuery = mysql_query("SELECT POSITION_NAME as 'jobName' FROM position WHERE POSITION_ID='".$job."'");
	$jobName = mysql_fetch_array($jobQuery);

$query = mysql_query("UPDATE location SET LOCATION_NAME='$locName',LOCATION_ADDRESS='$address',LOCATION_PHONE_NO='$lphone',LOCATION_FAX_NO='$lfax',AREA_ID='$area',CITY_ID='$city',BARANGAY_ID='$brgy',LOCATION_TYPE_ID='$locType'  WHERE FLAG='S' AND CUSTOMER_ID='".$id['suppid']."'");

$query2 = mysql_query("UPDATE contact SET CONTACT_NAME='$contactName', CONTACT_DEPARTMENT='".$deptName['deptName']."', CONTACT_JOB_TITLE='".$jobName['jobName']."', CONTACT_EMAIL_ADDRESS='$email', CONTACT_PHONE_NO='$phone', CONTACT_MOBILE_NO='$mobile', CONTACT_FAX_NO='$fax', POSITION_ID='$job', DEPARTMENT_ID='$dept' WHERE LOCATION_ID='".$locID['locid']."'");

//echo $contactName." + ".$job." + ".$dept." + ".$email." + ".$mobile." + ".$phone." + ".$fax." + ".$code." + ".$jobName['jobName']." + ".$deptName['deptName'];

//echo $locName." + ".$locType." + ".$city." + ".$brgy." + ".$area." + ".$address." + ".$lphone." + ".$lfax." + ".$id['suppid'];
?>