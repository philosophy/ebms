<?php
include("../../../../config/config.php");

$cityID = @$_POST['cityid'];

$query = "SELECT b.BARANGAY_ID, BARANGAY_NAME
FROM barangay b
WHERE b.IS_DELETED =0
AND b.CITY_ID ='".$cityID."'";
$result = mysql_query($query);
$barangayList = '';
while($record = mysql_fetch_array($result))
{
    $barangayList .= "<option value='".$record['BARANGAY_ID']."'>".$record['BARANGAY_NAME']."</option>";
}
echo $barangayList;
?>