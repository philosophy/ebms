<?php
session_start();
include("../../../../config/config.php");

$suppName = $_POST['suppName'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$phone = $_POST['phone'];
$fax = $_POST['fax'];
$remarks = $_POST['remarks'];
$industry = $_POST['industry'];
$zeros = "000000";

$countQuery = "SELECT COUNT(SUPPLIER_ID) FROM supplier_profile";
$countResult = mysql_query($countQuery);

if (mysql_num_rows($countResult) == 0)
{
	$suppCode = "SP-000001";
}
else
{
	$maxQuery = "SELECT MAX(SUPPLIER_ID) as 'max' FROM supplier_profile";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	$max['max'] += 1;
	$suppCode = "SP-".substr($zeros, 0, 6 - strlen($max['max'])).$max['max'];
}

$query = "INSERT INTO `supplier_profile`(SUPPLIER_CODE, SUPPLIER_NAME, SUPPLIER_EMAIL_ADDRESS, SUPPLIER_PHONE_NO, SUPPLIER_MOBILE_NO, SUPPLIER_FAX_NO, SUPPLIER_REMARKS, IS_ACTIVE, IS_DELETED, INDUSTRY_TYPE_ID) VALUES ('$suppCode','$suppName','$email','$phone','$mobile','$fax','$remarks','1','0','$industry')";
$result = mysql_query($query);
?>