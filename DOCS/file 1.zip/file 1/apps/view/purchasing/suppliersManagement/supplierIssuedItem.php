<?php

include("../../../../config/config.php");
$outputData = "";

$suppCode = @$_POST['suppCode'];

$result = mysql_query("SELECT WITH_DTL_ID, WITH_DTL_QTY, UNIT_NAME, ITEM_CODE, WITH_DTL_ITEM_DESCRIPTION, WITH_DTL_REMARKS FROM withdrawal_detail wd
INNER JOIN withdrawal_header wh ON wd.WITH_HDR_ID = wh.WITH_HDR_ID
INNER JOIN unit u ON wd.UNIT_ID = u.UNIT_ID
WHERE wh.WITH_HDR_TYPE = 'Supplier' AND wh.WITH_HDR_PURPOSE = 'Issue Item' OR wh.WITH_HDR_PURPOSE = 'Repair' AND wh.WITH_HDR_ISSUED_TO = '".$suppCode."'");
						
if(mysql_num_rows($result) > 0)
{
	$outputData .= "<table>
		<th>Qty</th>
		<th>Unit</th>
		<th>Item Code</th>
		<th>Item Description</th>
		<th>Remarks</th>";
		
	while($arrResult = mysql_fetch_array($result))
	{	
		$outputData .= "<tr a='".$arrResult['WITH_DTL_ID']."'>";
		$outputData .= "<td>".$arrResult['WITH_DTL_QTY']."</td>";
		$outputData .=	"<td>".$arrResult['UNIT_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['ITEM_CODE']."</td>";
		$outputData .=	"<td>".$arrResult['WITH_DTL_ITEM_DESCRIPTION']."</td>";
		$outputData .=	"<td>".$arrResult['WITH_DTL_REMARKS']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData .= "No results found";
}

echo $outputData;

?>