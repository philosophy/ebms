<?php
include("../../../../config/config.php");

$query = "SELECT LOCATION_TYPE_ID, LOCATION_TYPE_NAME FROM location_type WHERE IS_DELETED = 0";
$result = mysql_query($query);
$locTypeList = '';
while($record = mysql_fetch_array($result))
{
    $locTypeList .= "<option value='".$record['LOCATION_TYPE_ID']."'>".$record['LOCATION_TYPE_NAME']."</option>";
}
echo $locTypeList;
?>