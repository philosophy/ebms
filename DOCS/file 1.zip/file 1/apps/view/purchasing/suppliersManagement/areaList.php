<?php
include("../../../../config/config.php");

$area = "";

$query = "SELECT AREA_ID, AREA_NAME FROM area WHERE IS_DELETED = 0";
$result = mysql_query($query);
$areaList = '';
while($record = mysql_fetch_array($result))
{
    $areaList .= "<option value='".$record['AREA_ID']."'>".$record['AREA_NAME']."</option>";
}
echo $areaList;
?>