﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Suppliers Management</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Suppliers Management");
		datagridMenu("supplier","new;edit;delete;restore");
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php 
	include("../../modalForms/purchasing/index.php"); 
	include("../../../controller/suppliersManagement/cboListController.php");
?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="supplierList" class="datagrid-container">
	<script>
		$('#supplierList').load('../../../controller/suppliersManagement/supplierManagementController.php');
		
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul>
		<li><a href="#supplierIssuedItem">Issued Item</a></li>
		<li><a href="#supplierPurchasedItem">Purchase Summary</a></li>
		<li><a href="#supplierPurchaseHistory">Purchase History</a></li>
	</ul> 
	<div id="supplierIssuedItem"> 
		Please select supplier record above
		<!-- issued item will be displayed here-->
	</div>
	<div id="supplierPurchasedItem"> 
		Please select supplier record above
		<!-- purchased item will be displayed here-->
	</div>
	<div id="supplierPurchaseHistory"> 
		Please select supplier record above
		<!-- purchased item will be displayed here-->
	</div>
</div> 
</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

