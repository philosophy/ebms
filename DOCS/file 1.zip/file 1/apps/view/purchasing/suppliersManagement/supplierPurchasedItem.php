<?php

include("../../../../config/config.php");
$outputData = "";

$suppCode = @$_POST['suppCode'];

$result = mysql_query("SELECT REC_DTL_ID, SUM(REC_DTL_QTY) as 'qty', UNIT_NAME, ITEM_CODE, REC_DTL_ITEM_DESCRIPTION FROM receiving_detail rd INNER JOIN receiving_header rh ON rd.REC_HDR_ID = rh.REC_HDR_ID INNER JOIN unit u ON rd.UNIT_ID = u.UNIT_ID WHERE REC_HDR_RECEIVED_REF_TYPE =  'Supplier' AND REC_HDR_RECEIVED_FROM = '".$suppCode."' GROUP BY ITEM_CODE, REC_DTL_ITEM_DESCRIPTION");
						
if(mysql_num_rows($result) > 0)
{
	$outputData .= "<table>
		<th>Qty</th>
		<th>Unit</th>
		<th>Item Code</th>
		<th>Item Description</th>";
		
	while($arrResult = mysql_fetch_array($result))
	{	
		$outputData .= "<tr a='".$arrResult['REC_DTL_ID']."'>";
		$outputData .= "<td>".$arrResult['qty']."</td>";
		$outputData .=	"<td>".$arrResult['UNIT_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['ITEM_CODE']."</td>";
		$outputData .=	"<td>".$arrResult['REC_DTL_ITEM_DESCRIPTION']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData .= "No results found";
}

echo $outputData;

?>