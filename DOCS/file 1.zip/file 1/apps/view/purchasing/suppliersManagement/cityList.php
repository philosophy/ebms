<?php
include("../../../../config/config.php");

$query = "SELECT CITY_ID, CITY_NAME FROM city WHERE IS_DELETED = 0";
$result = mysql_query($query);
$cityList = '';
while($record = mysql_fetch_array($result))
{
    $cityList .= "<option value='".$record['CITY_ID']."'>".$record['CITY_NAME']."</option>";
}
echo $cityList;
?>