<?php

include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE customer_name LIKE '%".$searchQuery."%' or customer_code LIKE '%".$searchQuery."%' or customer_type_name LIKE '%".$searchQuery."%' or customer_phone_no LIKE '%".$searchQuery."%' or customer_mobile_no LIKE '%".$searchQuery."%' or industry_type_name LIKE '%".$searchQuery."%'  or customer_email_address LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	$condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 9;

$start = $page * $per_page;


	$outputData .= "<table>
		<th class=icon></th>
		<th>Supplier Code</th>
		<th>Name</th>
		<th>Industry Type</th>
		<th>E-mail Address</th>
		<th>Phone #</th>
		<th>Mobile #</th>
		<th>Fax #</th>";
		
$query = "SELECT SUPPLIER_CODE, SUPPLIER_NAME, SUPPLIER_EMAIL_ADDRESS, INDUSTRY_TYPE_NAME, SUPPLIER_PHONE_NO, SUPPLIER_MOBILE_NO, SUPPLIER_FAX_NO, s.IS_DELETED
FROM  `supplier_profile` s
INNER JOIN industry_type i ON s.INDUSTRY_TYPE_ID = i.INDUSTRY_TYPE_ID";
	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arr = mysql_query($query." limit $start,$per_page");
	
	
	if(mysql_num_rows($arr) > 0)
	{
	while($arrResult = mysql_fetch_array($arr))
	{	
		$x = (($arrResult['IS_DELETED']==1)?"deleted=true":"deleted=false");
		if($arrResult['IS_DELETED'] == 0)
					{	
						$icon = "<img src='/ebms/images/icons/suppliersIcon.png' title='Supplier'>";
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
		$outputData .= "<tr ".$x." a='".$arrResult['SUPPLIER_CODE']."'>";
		$outputData .=	"<td class=icon>".$icon."</td>";
		$outputData .=	"<td>".$arrResult['SUPPLIER_CODE']."</td>";
		$outputData .=	"<td>".$arrResult['SUPPLIER_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['INDUSTRY_TYPE_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['SUPPLIER_EMAIL_ADDRESS']."</td>";
		$outputData .=	"<td>".$arrResult['SUPPLIER_PHONE_NO']."</td>";
		$outputData .=	"<td>".$arrResult['SUPPLIER_MOBILE_NO']."</td>";
		$outputData .=	"<td>".$arrResult['SUPPLIER_FAX_NO']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}

else
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
 
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
	

?>