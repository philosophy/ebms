<?php

include("../../../../config/config.php");
$outputData = "";

$refNo = $_POST['cboRefNo'];

$query = mysql_query("SELECT pr.PR_DTL_QTY AS  'qty', u.UNIT_NAME AS  'unit_name', prh.PR_HDR_NO AS  'refno', pr.ITEM_CODE AS  'code', p.PRODUCT_UNIT_PRICE AS 'unit_price', c.CATEGORY_NAME AS  'category_name', pr.PR_DTL_ITEM_DESCRIPTION AS  'desc', product_image AS  'img'
FROM pr_detail pr
INNER JOIN pr_header prh ON pr.PR_HDR_ID = prh.PR_HDR_ID
INNER JOIN unit u ON pr.UNIT_ID = u.UNIT_ID
INNER JOIN product p ON pr.ITEM_CODE = p.PRODUCT_CODE
INNER JOIN category c ON p.CATEGORY_ID = c.CATEGORY_ID
WHERE pr.PR_HDR_ID =  '".$refNo."' AND PR_DTL_ID NOT IN (SELECT PR_DTL_ID FROM po_detail)");


						
	if(mysql_num_rows($query) > 0)
	{
		while($arr = mysql_fetch_array($query))
		{
			$outputData .= "<li id='gridViewList'>
							<a href='#' id='gridViewLink' qty='".$arr['qty']."' refno='".$arr['refno']."' desc='".$arr['desc']."' code='".$arr['code']."' unitPrice='".number_format($arr['unit_price'],2)."' unit='".$arr['unit_name']."' cat='".$arr['category_name']."'>
								<div id='itemMenu'>
									<button class='addItem' title='Add Item'>✚</button>
									<button class='removeItem' title='Remove Item'>✖</button>
									<button class='selectedItem' title='Selected Item'>✔</button>
								</div>
								<img src='/ebms/images/stock/".(($arr['img']=='')?'default.png':$arr['img'])."'>
							</a>
							</li>";
		}
	}
	
	else
	{
	$outputData = "No items found. Item/s already in Purchase Order.";
	}
	
	echo $outputData;