<?php
include("../../../../config/config.php");

$requestor = "";

$query = "SELECT SUPPLIER_ID AS  'id', SUPPLIER_NAME AS  'name' FROM supplier_profile";
$result = mysql_query($query);
$supplierList = '';
while($record = mysql_fetch_array($result))
{
    $supplierList .= "<option value='".$record['id']."'>".$record['name']."</option>";
}
echo $supplierList;
?>