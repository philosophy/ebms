<?php

include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "and (ph.po_hdr_no LIKE '%".$searchQuery."%' or concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) LIKE '%".$searchQuery."%' or date_format(ph.po_hdr_date_needed,'%b-%d-%Y') LIKE '%".$searchQuery."%' or d.dept_name LIKE '%".$searchQuery."%' or p.position_name LIKE '%".$searchQuery."%' or s.supplier_name LIKE '%".$searchQuery."%' or ph.po_hdr_contact_name LIKE '%".$searchQuery."%' or concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) LIKE '%".$searchQuery."%')  ";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 7;

$start = $page * $per_page;
	$outputData .= "<table>
		<th class=icon></th>
		<th>PO. #</th>
		<th>Supplier Name</th>
		<th>PO Date Needed</th>
		<th>Sold To</th>
		<th>Department</th>
		<th>Job Title</th>
		<th>Net Amount</th>
		<th>Discount</th>
		<th>Status</th>";
		
$query = "SELECT ph.po_hdr_id, ph.po_hdr_no, date_format(ph.po_hdr_date_needed,'%b-%d-%Y') as 'po_hdr_date_needed', ph.po_hdr_date_requested, 
						ph.po_hdr_contact_name, ph.po_hdr_discount_amount, ph.po_hdr_remarks, ph.supplier_id, ph.po_hdr_sold_to_id, concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'empname', d.dept_name, p.position_name, s.supplier_name, ep.dept_id,
						ep.position_id, ph.po_hdr_net_amount as 'net', ph.is_deleted, ph.is_received as 'isReceived'
						FROM po_header ph INNER JOIN supplier_profile s ON ph.supplier_id = s.supplier_id
						INNER JOIN employee_profile ep ON ep.emp_id = ph.po_hdr_sold_to_id
						INNER JOIN department d ON d.dept_id = ep.dept_id
						INNER JOIN position p ON p.position_id = ep.position_id
						".$condition." Order By ph.po_hdr_no desc
						";
				
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	$arrRows = mysql_query($query." limit $start,$per_page");

	
	if(mysql_num_rows($arrRows) > 0)
	{
	while($arrResult = mysql_fetch_array($arrRows))
	{	
		$x = (($arrResult['is_deleted']==1)?"deleted=true":"deleted=false");
	if($arrResult['is_deleted'] == 0)
					{	
						$icon = "<img src='/ebms/images/icons/orderIcon.png'>";
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
		$outputData .= "<tr ".$x." a='".$arrResult['po_hdr_id']."' b='".$arrResult['isReceived']."'>";
		$outputData .=	"<td class=icon>".$icon."</td>";
		$outputData .=	"<td>".$arrResult['po_hdr_no']."</td>";
		$outputData .=	"<td>".$arrResult['supplier_name']."</td>";
		$outputData .=	"<td>".date("D M d, Y",strtotime($arrResult['po_hdr_date_needed']))."</td>";
		$outputData .=	"<td>".$arrResult['empname']."</td>";
		$outputData .=	"<td>".$arrResult['dept_name']."</td>";
		$outputData .=	"<td>".$arrResult['position_name']."</td>";
		$outputData .=	"<td align='right'>".number_format($arrResult['net'], 2)."</td>";
		$outputData .=	"<td align='right'>".number_format($arrResult['po_hdr_discount_amount'], 2)."</td>";
		if ($arrResult['isReceived'] == "0")
		{
			$arrResult['isReceived'] = "PENDING";
		}
		else if ($arrResult['isReceived'] == "1")
		{
			$arrResult['isReceived'] = "PARTIALLY RECEIVED";
		}
		else if ($arrResult['isReceived'] == "2")
		{
			$arrResult['isReceived'] = "FULLY RECEIVED";
		}
		$outputData .=	"<td>".$arrResult['isReceived']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	
else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrRows);