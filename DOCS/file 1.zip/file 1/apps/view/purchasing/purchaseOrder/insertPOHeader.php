<?php
session_start();
include("../../../../config/config.php");

$user = $_SESSION['login'];
$dateNeeded = $_POST['dateNeeded'];
$soldToId = $_POST['soldToId'];
$supplier = $_POST['supplier'];
$paymentType = $_POST['paymentType'];
$terms = $_POST['terms'];
$disc = $_POST['disc'];
$gross = $_POST['gross'];
$net = $_POST['net'];
$remarks = $_POST['remarks'];
$suppname = $_POST['suppname'];

$zeros = "000000";

$contactQuery = mysql_query("SELECT CONTACT_NAME as 'contact' from contact c
INNER JOIN location l ON c.LOCATION_ID = l.LOCATION_ID 
INNER JOIN supplier_profile s ON l.CUSTOMER_ID = s.SUPPLIER_ID
WHERE SUPPLIER_ID = '".$supplier."' AND FLAG = 'S'");
$contactName = mysql_fetch_array($contactQuery);

$countQuery = "SELECT COUNT(PO_HDR_ID) FROM po_header";
$countResult = mysql_query($countQuery);
//$records = mysql_fetch_array($countResult)

if (mysql_num_rows($countResult) == 0)
{
	$poCode = "PO-".date("Y")."-000001";
}
else
{
	$maxQuery = "SELECT MAX(PO_HDR_ID) as 'max' FROM po_header";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	$max['max'] += 1;
	$poCode = "PO-".date("Y")."-".substr($zeros, 0, 6 - strlen($max['max'])).$max['max'];
}

$query = "INSERT INTO po_header(PO_HDR_NO, PO_HDR_DATE_NEEDED, PO_HDR_REMARKS, IS_DELETED, PO_HDR_SOLD_TO_ID, PO_HDR_CREATED_BY_ID, SUPPLIER_ID, PO_HDR_GROSS_AMOUNT, PO_HDR_DISCOUNT_AMOUNT, PO_HDR_NET_AMOUNT, PO_HDR_CONTACT_NAME, PO_HDR_DATE_REQUESTED, PO_HDR_PAYMENT_TYPE) VALUES('$poCode', '$dateNeeded', '$remarks', '0','$soldToId', '$user', '$supplier', '$gross', '$disc', '$net', '".$contactName['contact']."', curdate(), '$paymentType')";
$result = mysql_query($query);
?>