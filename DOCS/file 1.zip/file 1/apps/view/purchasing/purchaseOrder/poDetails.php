<?php

include("../../../../config/config.php");
$outputData = "";

$poCode = @$_POST['poCode'];

$result = mysql_query("SELECT pd.po_dtl_qty, u.unit_name, pd.pr_hdr_no, pd.item_code, pd.po_dtl_item_description as 'desc', pd.is_received as 'isReceived' FROM po_detail pd INNER JOIN unit u ON pd.unit_id = u.unit_id WHERE pd.po_hdr_id ='".$poCode."'");
						
if(mysql_num_rows($result) > 0)
{
	$outputData .= "<table>
		<th>Qty</th>
		<th>Unit</th>
		<th>Reference No</th>
		<th>Item Code</th>
		<th>Item Description</th>
		<th>Item Status</th>";
		
	while($arrResult = mysql_fetch_array($result))
	{	
		$outputData .= "<tr>";
		$outputData .= "<td>".$arrResult['po_dtl_qty']."</td>";
		$outputData .=	"<td>".$arrResult['unit_name']."</td>";
		$outputData .=	"<td>".$arrResult['pr_hdr_no']."</td>";
		$outputData .=	"<td>".$arrResult['item_code']."</td>";
		$outputData .=	"<td>".$arrResult['desc']."</td>";
		if ($arrResult['isReceived'] == "0")
		{
			$arrResult['isReceived'] = "PENDING";
		}
		else if ($arrResult['isReceived'] == "1")
		{
			$arrResult['isReceived'] = "PARTIALLY RECEIVED";
		}
		else if ($arrResult['isReceived'] == "2")
		{
			$arrResult['isReceived'] = "FULLY RECEIVED";
		}
		$outputData .=	"<td>".$arrResult['isReceived']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData .= "No results found";
}

echo $outputData;

?>