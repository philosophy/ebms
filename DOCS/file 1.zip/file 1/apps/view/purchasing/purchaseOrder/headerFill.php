<?php
session_start();
include("../../../../config/config.php");

$poCode = $_POST['poCode'];
$editPO[] = "";

$query = "SELECT PO_HDR_NO, PO_HDR_DATE_NEEDED, PO_HDR_DATE_REQUESTED, PO_HDR_REMARKS, CONCAT(EMP_FIRST_NAME, ' ', EMP_LAST_NAME) as 'soldTo', SUPPLIER_NAME as 'supp', PO_HDR_TERMS, PO_HDR_GROSS_AMOUNT, PO_HDR_NET_AMOUNT, PO_HDR_DISCOUNT_AMOUNT FROM po_header ph INNER JOIN employee_profile e ON  ph.PO_HDR_SOLD_TO_ID = e.EMP_ID INNER JOIN supplier_profile s ON ph.SUPPLIER_ID = s.SUPPLIER_ID WHERE PO_HDR_ID='".$poCode."'";

$result = mysql_query($query);

while($arrPO = mysql_fetch_array($result))
{
	$editPO['code'] = $arrPO['PO_HDR_NO'];
	$editPO['dateNeeded'] = $arrPO['PO_HDR_DATE_NEEDED'];
	$editPO['dateRequested'] = $arrPO['PO_HDR_DATE_REQUESTED'];
	$editPO['remarks'] = $arrPO['PO_HDR_REMARKS'];
	$editPO['soldTo'] = $arrPO['soldTo'];
	$editPO['supp'] = $arrPO['supp'];
	$editPO['terms'] = $arrPO['PO_HDR_TERMS'];
	$editPO['gross'] = $arrPO['PO_HDR_GROSS_AMOUNT'];
	$editPO['net'] = $arrPO['PO_HDR_NET_AMOUNT'];
	$editPO['discAmount'] = $arrPO['PO_HDR_DISCOUNT_AMOUNT'];
	$editPO['discPercent'] = (((($arrPO['PO_HDR_GROSS_AMOUNT'])-($arrPO['PO_HDR_NET_AMOUNT']))*100)/($arrPO['PO_HDR_GROSS_AMOUNT']));
}
$dataPO = json_encode(array("values"=>$editPO));
echo $dataPO;
?>