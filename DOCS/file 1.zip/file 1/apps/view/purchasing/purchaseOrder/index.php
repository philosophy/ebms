﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Purchase Order Approval</title>
<?php include("../../standard-js-css.php"); 
?>
<script>
	$(function(){
		headTitle("Purchase Order Approval");
		datagrid("purchaseOrder",true);
		datagrid("itemDetails",false);
		datagridMenu("po","new;edit;delete;restore");
		$("#tabbed-grid").tabs();
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<?php 
include("../../modalForms/purchasing/index.php"); 
include("../../../controller/purchaseOrder/itemListController.php");
include("../../../controller/purchaseOrder/cboListController.php");
?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="purchaseOrder" class="datagrid-container">
	<script>
		$('#purchaseOrder').load('../../../controller/purchaseOrder/purchaseOrderController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#itemDetails">Item Details</a></li> 
	</ul> 
	<div id="itemDetails"> 

		
	</div> 
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

