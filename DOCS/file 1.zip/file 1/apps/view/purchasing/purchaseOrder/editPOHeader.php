<?php
session_start();
include("../../../../config/config.php");

$poCode = $_POST['id'];
$dateNeeded = $_POST['dateNeeded'];
$remarks = $_POST['remarks'];
$terms = $_POST['terms'];
$gross = $_POST['gross'];
$net = $_POST['net'];
$disc = $_POST['disc'];
$payment = $_POST['paymentType'];

mysql_query("UPDATE po_header SET PO_HDR_DATE_NEEDED='$dateNeeded', PO_HDR_REMARKS='$remarks', PO_HDR_TERMS='$terms', PO_HDR_DISCOUNT_AMOUNT='$disc', PO_HDR_NET_AMOUNT='$net', PO_HDR_GROSS_AMOUNT='$gross', PO_HDR_PAYMENT_TYPE='$payment' WHERE PO_HDR_ID='".$poCode."'");

?>