<?php
include("../../../../config/config.php");

$requestor = "";

$query = "SELECT EMP_ID, CONCAT(EMP_FIRST_NAME, ' ', EMP_LAST_NAME) as 'Name' FROM employee_profile";
$result = mysql_query($query);
$requestorList = '';
while($record = mysql_fetch_array($result))
{
    $requestorList .= "<option value='".$record['EMP_ID']."'>".$record['Name']."</option>";
}
echo $requestorList;
?>