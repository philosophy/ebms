<?php
include("../../../../config/config.php");

$unit = $_POST['unit'];
$code = $_POST['code'];
$refno = $_POST['refno'];
$desc = $_POST['desc'];
$qty = $_POST['qty'];

	$maxQuery = "SELECT MAX(PO_HDR_ID) as 'max' FROM po_header";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	
	$unitQuery = "SELECT UNIT_ID as 'unit' FROM UNIT WHERE UNIT_NAME='".$unit."'";
	$unitResult = mysql_query($unitQuery);
	$unitId = mysql_fetch_array($unitResult);
	
	$prDetailQuery = "SELECT PR_DTL_ID as 'id' FROM pr_detail prd INNER JOIN pr_header prh ON prd.PR_HDR_ID = prh.PR_HDR_ID WHERE ITEM_CODE='".$code."' AND PR_HDR_NO='".$refno."'";
	$prDetailResult = mysql_query($prDetailQuery);
	$prDetailId = mysql_fetch_array($prDetailResult);
	
	$isAsset = substr($code,0,2);
	
	if ($isAsset == "AS")
	{
		$flag = "A";
	}
	else
	{
		$flag = "P";
	}

$query = "INSERT INTO po_detail(PO_DTL_QTY, PO_DTL_ORIGINAL_QTY, PO_DTL_ITEM_DESCRIPTION, PO_HDR_ID, UNIT_ID, ITEM_CODE, PR_HDR_NO, PR_DTL_ID, ITEM_FLAG) VALUES('$qty', '$qty', '$desc', '".$max['max']."', '".$unitId['unit']."', '$code', '$refno', '".$prDetailId['id']."', '$flag')";
$result = mysql_query($query);


?>