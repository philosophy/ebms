<?php
include("../../../../config/config.php");

$code = $_POST['code'];
$poCode= $_POST['id'];
$qty = $_POST['qty'];

mysql_query("UPDATE po_detail SET PO_DTL_QTY='$qty', PO_DTL_ORIGINAL_QTY='$qty' WHERE PO_HDR_ID='".$poCode."' AND ITEM_CODE='".$code."'");
?>