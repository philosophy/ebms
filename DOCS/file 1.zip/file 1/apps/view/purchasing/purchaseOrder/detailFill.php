<?php
session_start();
include("../../../../config/config.php");

$poCode = $_POST['poCode'];
$outputData = "";

$query = "SELECT po.PO_DTL_ID, po.PO_DTL_QTY, PR_HDR_NO, u.UNIT_NAME, po.ITEM_CODE, p.PRODUCT_UNIT_PRICE, c.CATEGORY_NAME, po.PO_DTL_ITEM_DESCRIPTION  FROM po_detail po
INNER JOIN unit u ON po.UNIT_ID = u.UNIT_ID
INNER JOIN product p ON po.ITEM_CODE = p.PRODUCT_CODE
INNER JOIN category c ON p.CATEGORY_ID = c.CATEGORY_ID
WHERE PO_HDR_ID='".$poCode."'";

$result = mysql_query($query);

while($arrResult = mysql_fetch_array($result))
{
	$outputData .= "<tr a='".$arrResult['PO_DTL_ID']."'>";
	$outputData .=	"<td><input type='number' id='qty' select='".$arrResult['ITEM_CODE'].$arrResult['PR_HDR_NO']."' value='".$arrResult['PO_DTL_QTY']."' /></td>";
	$outputData .=	"<td>".$arrResult['UNIT_NAME']."</td>";
	$outputData .=	"<td refno='".$arrResult['PR_HDR_NO']."'>".$arrResult['PR_HDR_NO']."</td>";
	$outputData .=	"<td code='".$arrResult['ITEM_CODE']."'>".$arrResult['ITEM_CODE']."</td>";
	$outputData .=	"<td id='itemPrice'>".$arrResult['PRODUCT_UNIT_PRICE']."</td>";
	$outputData .=	"<td>".$arrResult['CATEGORY_NAME']."</td>";
	$outputData .=	"<td>".$arrResult['PO_DTL_ITEM_DESCRIPTION']."</td>";
	$outputData .= "</tr>";
}
echo $outputData;
?>