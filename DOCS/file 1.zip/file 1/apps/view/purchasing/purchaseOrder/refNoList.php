<?php
include("../../../../config/config.php");

$requestor = "";

$query = "SELECT DISTINCT prh.PR_HDR_ID AS  'id', PR_HDR_NO AS  'refno'
FROM pr_header prh
INNER JOIN pr_detail prd ON prd.PR_HDR_ID = prh.PR_HDR_ID
WHERE is_deleted =0
AND PR_HDR_APPROVED_BY_ID IS NOT NULL 
AND PR_DTL_ID NOT IN (SELECT PR_DTL_ID FROM po_detail)";
$result = mysql_query($query);
$prNoList = '';

if(mysql_num_rows($result) > 0)
{
	while($record = mysql_fetch_array($result))
	{
		$prNoList .= "<option value='".$record['id']."'>".$record['refno']."</option>";
	}
}
else
{
	$prNoList .= "<option value='0'>No PR approved</option>";
}
echo $prNoList;
?>