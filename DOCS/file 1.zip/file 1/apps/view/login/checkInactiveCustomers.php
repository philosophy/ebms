<?php
require("../../../config/config.php");
$query = mysql_query("select customer_id from customer_profile");
$customer = 0;
while($arr = mysql_fetch_array($query))
{
	$customer = $arr[0];
	$checkDate = mysql_query("Select max(os_hdr_date) from os_header where customer_id = '$customer'")or die(mysql_error);
	$maxDate = "";
	while($date = mysql_fetch_array($checkDate))
	{
		$maxDate = $date[0];
	}
	$update = mysql_query("Select os.customer_id from os_header os where datediff(curdate(), '".$maxDate."') >= 21 and os.customer_id = '$customer'")or die(mysql_error);
	if(mysql_num_rows($update) > 0)
	{
	mysql_query("update customer_profile set is_active = 0 where customer_id = '$customer'")or die(mysql_error);
	}
	echo $customer;
}
?>