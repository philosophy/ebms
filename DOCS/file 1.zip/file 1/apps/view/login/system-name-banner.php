<div id="co-name">
	<img src="images/ebms.png">
	<div id="subtitle">Manage your business in just a click</div>
</div>