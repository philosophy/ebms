﻿<?php include("../doctype-standard.php"); 
if(isset($_SESSION['login']))
	header("Location: /ebms/apps/view/home/?page=home");
?>
<head>
<?php 
	include("../login/login-view-styles-scripts.php");
	// include("../../controller/login/deleteCookie.php");
	include("../../controller/login/checkCookie.php");
?>
</head>
<body>
	<div class="login-main-content">
	<div id="co-name">
	<img src="../../../images/ebms.png">
	<div id="subtitle">Manage your business in just a click</div>
	</div>
	<?php include("login-form-ui.php"); ?>
	<div id="building-container">
	<img id="building-silhouette" src="../../../images/building.png">
	</div></div>
	<?php require("../login-footer-view.php"); ?>
</body>
</html>
		