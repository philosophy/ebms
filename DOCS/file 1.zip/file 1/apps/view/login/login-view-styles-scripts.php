	<title>EBMS: A whole new way of managing your business</title>
	<link type="text/css" href="/EBMS/css/login-form-stylesheet.css" rel="stylesheet" />
	<link type="text/css" href="/EBMS/css/forgot-pword-stylesheet.css" rel="stylesheet" />
	<link type="text/css" href="/EBMS/css/login-footer-stylesheet.css" rel="stylesheet" />
	<?php include ("../standard-js-css.php"); ?>
	<script type="text/javascript" src="/EBMS/js/forgot-pword-function.js"></script>
	<script type="text/javascript" src="/EBMS/js/login-auth-function.js"></script>
	<script type="text/javascript" src="/EBMS/js/login-submit-function.js"></script>

	