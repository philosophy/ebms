

<div id="forgot-pword-container" class="modal forgot-password">
<div class="handle">
<a href="#" id="close">x</a>
</div>
		<form>
		
		
		<script>
			$(document).ready(function(){
			var cont = 1;
			
			$(".stepsNav li a").click(function(){
				if($(this).attr("href") == "#forward")
					{
						if(cont <= 2)
						{
						++cont;
						}
					}
					
				else if($(this).attr("href") == "#back")
					{
					--cont;
					}
					
				return false;
			});
			
			});
		</script>
		
			<!-- element for Step 1 -->
			<div id="security_question_uname_finder">
			<label>Please type your full name here</label>
			<input type="text" id="user_fullname" name="user_fullname" value="">
			
			<label>Type your username here</label>
			<input type="text" id="uname_fetch" name="uname_fetch" value=""><button id="uname_box_finder">Search</button>
			</div>
			<!-- //Step 1 -->
			
			<!-- element for Step 2 -->
			<div id="security_question">
			<label>Security Question</label>
			<input type="text" class="question" id="sec_q1" name="sec_q1" value="<?php echo 'Sample?'; ?>" disabled>
			<input type="text" class="ans" id="ans">
			
			
			<ul class="btn-list">
			<li>
			<button type="submit" id="btn-normal" class="ans-submit">Submit</button>
			</li>
			</ul>
			</div>
			<!-- //Step 2 -->
			
			<!-- element for step 3-->
			<div id="new_password_container">
			<label>Change your password</label>
			<input type="password" id="new_pword" name="new_pword" value="">
			
			<label>Verify new password</label>
			<input type="password" id="verify_new_pword" name="verify_new_pword" value="">
			
			<ul class="btn-list">
			<li>
			<button type="submit" id="btn-normal" class="change-pword-submit">Change my password</button>
			</li>
			</ul>
			
			</div>
			<!-- //Step 3 -->
			
		</form>
</div>