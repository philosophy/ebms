
<?php 
//include form for forgot password feature
include("forgot-pword-ui.php");
?>
<div id="login-form">
			<form action="" method="POST" name="loginForm">
				<label id="normal">Username</label>
				<input type="text" name="uname" id="uname" class="uname" maxlength=30>

				
				<label "normal">Password</label>
				<input type="password" name="pword" id="pword" maxlength=30>
				
				<div id="remember-user-container">
				<input type="checkbox" name="rememberUser" id="rememberUser" value="true">
				<label id="minified">Remember username</label>
				</div>
				
				<ul class="btn-list">
				
				<li>
				<button type="submit" id="btn-submit">Login</button> 
				</li>
				
				</ul>
				<p><a href="#" id="forgot" rel="forgot-password" name="530">Forgot Password?</a></p>
				
			</form>
			
			<!--element container for login error and success messages-->
			<div id="log-info"></div>
</div>
