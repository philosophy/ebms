<?php
session_start();

$_SESSION['productCode'] = $_POST['productCode'];
?>