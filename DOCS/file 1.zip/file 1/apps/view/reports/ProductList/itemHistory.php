<?php

session_start();
$productCode = $_SESSION['productCode'];

include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");


//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");


//withdrawal [EMPLOYEE, CUSTOMER] 
$result=mysql_query("SELECT wh.with_hdr_no, wh.with_hdr_date_issued, wh.with_hdr_type, 
						wh.with_hdr_purpose, wd.with_dtl_qty, WITH_HDR_ISSUED_TO 
						FROM withdrawal_header wh 
						INNER JOIN withdrawal_detail wd ON wh.with_hdr_id = wd.with_hdr_id
						WHERE wd.item_code = '".$productCode."'");

//receiving [EMPLOYEE, CUSTOMER, SUPPLIER]
$rec=mysql_query("SELECT rh.rec_hdr_no, rh.rec_hdr_date, rh.REC_HDR_RECEIVED_REF_TYPE, 
						rh.REC_HDR_RECEIVED_REF, rd.REC_DTL_QTY, REC_HDR_RECEIVED_FROM
						FROM receiving_header rh 
						INNER JOIN receiving_detail rd ON rh.rec_hdr_id = rd.rec_hdr_id
						WHERE rd.item_code= '".$productCode."'");
						
$number_of_audit = mysql_num_rows($result);
$recList = mysql_num_rows($rec);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Item History Report',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
//Fields Name position
$Y_Fields_Name_position = 60;
//Table position, under Fields Name
$Y_Table_Position = 66;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',9);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(10);
$pdf->Cell(30,6,'Header No.',1,0,'C',1);
$pdf->SetX(40);
$pdf->Cell(25,6,'Date Issued',1,0,'C',1);
$pdf->SetX(65);
$pdf->Cell(30,6,'Type',1,0,'C',1);
$pdf->SetX(95);
$pdf->Cell(40,6,'Purpose',1,0,'C',1);
$pdf->SetX(135);
$pdf->Cell(20,6,'Quantity',1,0,'C',1);
$pdf->SetX(155);
$pdf->Cell(45,6,'Person Name',1,0,'C',1);
$pdf->SetX(95);
$pdf->Ln();

$i = 0;
$pdf->SetY($Y_Table_Position);

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',8);

//RECEIVING
if($recList > 0)
{
	$fill = 0;
	while($row = mysql_fetch_array($rec))
	{
		$pdf->SetX(10);
		$pdf->Cell(30,6,$row["rec_hdr_no"],1,0,'L',$fill);
		$pdf->Cell(25,6,$row["rec_hdr_date"],1,0,'L',$fill);
		$pdf->Cell(30,6,$row["REC_HDR_RECEIVED_REF_TYPE"],1,0,'L',$fill);
		$pdf->Cell(40,6,$row["REC_HDR_RECEIVED_REF"],1,0,'L',$fill);
		$pdf->Cell(20,6,$row["REC_DTL_QTY"],1,0,'L',$fill);
		if(mysql_num_rows($emp = mysql_query("SELECT emp_first_name, emp_middle_name, emp_last_name
										FROM employee_profile WHERE emp_code = '".$row['REC_HDR_RECEIVED_FROM']."'")))
		{
			$empRow = mysql_fetch_row($emp);
			$pdf->Cell(45,6,$empRow[0]." ".$empRow[1]." ".$empRow[2],1,0,'L',$fill);
		}
		elseif(mysql_num_rows($cust = mysql_query("SELECT customer_name
										FROM customer_profile WHERE customer_code = '".$row['REC_HDR_RECEIVED_FROM']."'")))
		{
			$custRow = mysql_fetch_row($cust);
			$pdf->Cell(45,6,$custRow[0],1,0,'L',$fill);
		}
		elseif(mysql_num_rows($sup = mysql_query("SELECT supplier_name
										FROM supplier_profile WHERE supplier_code = '".$row['REC_HDR_RECEIVED_FROM']."'")))
		{
			$supRow = mysql_fetch_row($sup);
			$pdf->Cell(45,6,$supRow[0],1,0,'L',$fill);
		}
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
	}
}

//WITHDRAWAL
if($number_of_audit>0)
{	
    $fill = 0;
	while($row = mysql_fetch_array($result))
	{
		$pdf->SetX(10);
		$pdf->Cell(30,6,$row["with_hdr_no"],1,0,'L',$fill);
		$pdf->Cell(25,6,$row["with_hdr_date_issued"],1,0,'L',$fill);
		$pdf->Cell(30,6,$row["with_hdr_type"],1,0,'L',$fill);
		$pdf->Cell(40,6,$row["with_hdr_purpose"],1,0,'L',$fill);
		$pdf->Cell(20,6,$row["with_dtl_qty"],1,0,'L',$fill);
		if(mysql_num_rows($emp = mysql_query("SELECT emp_first_name, emp_middle_name, emp_last_name
										FROM employee_profile WHERE emp_code = '".$row['WITH_HDR_ISSUED_TO']."'")))
		{
			$empRow = mysql_fetch_row($emp);
			$pdf->Cell(45,6,$empRow[0]." ".$empRow[1]." ".$empRow[2],1,0,'L',$fill);
		}
		elseif(mysql_num_rows($cust = mysql_query("SELECT customer_name
										FROM customer_profile WHERE customer_code = '".$row['WITH_HDR_ISSUED_TO']."'")))
		{
			$custRow = mysql_fetch_row($cust);
			$pdf->Cell(45,6,$custRow[0],1,0,'L',$fill);
		}
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
	}
}

if($number_of_audit == 0 && $recList == 0)
{
	$pdf->SetX(10);
	$pdf->Cell(190, 6,'No results found...', 1, 0, 'L');
	$pdf->Ln();
}

$pdf->Output();
?>