<?php
require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
$number_of_audit = mysql_num_rows($company_info);
//Initialize the 3 columns and the total

$result_type=mysql_query
     ("
	 SELECT distinct os.customer_id, cust.customer_name
	 FROM os_header os, customer_profile cust
	 WHERE cust.customer_id = os.customer_id order by os_hdr_id;
	 ");

$number_of_type = mysql_num_rows($result_type);

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Accounts Receivable List',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
$pdf->SetXY(16,52);
$pdf->SetTextColor(139,137,137);
$pdf->Cell(175,5,'____________________________________________________________________________________________');
$pdf->Ln();

while($type = mysql_fetch_array($result_type))
{ $cid[] = $type["customer_id"];
  $ctypename[] = $type["customer_name"];
}
for($x=1; $x<=$number_of_type; $x++)
{
		$result=mysql_query
			("
			SELECT os.os_hdr_no,date_format(os.os_hdr_date,'%b-%d-%Y') as 'os_hdr_date',os_hdr_net_amount,os.customer_id,cust.customer_name,pay.payment_amount
			FROM os_header os left outer join payment pay on os.os_hdr_id = pay.os_hdr_id, customer_profile cust  
            WHERE cust.customer_id = os.customer_id
			");
		
		$result_tot=mysql_query
			("
			SELECT *
			FROM os_header
			WHERE customer_id=".$cid[$x-1].";");
		
		$number_of_tot = mysql_num_rows($result_tot);
			
        $pdf->Ln();
		$pdf->SetX(20);
		$pdf->SetTextColor(70,130,180);
		$pdf->SetFont('Arial','',12);
		$pdf->Cell(50,10,'Customer Name: '.$ctypename[$x-1]);
		$pdf->SetTextColor(0,0,0);
		$pdf->Ln();

		/*--------------field name---------------------*/
		$pdf->SetDrawColor(139,134,130);
		$pdf->SetFillColor(193,205,193);
		$pdf->SetFont('Arial','B',12);
		$pdf->SetX(20);
		$pdf->Cell(40,6,'O.S. No.',1,0,'C',1);
		$pdf->SetX(60);
		$pdf->Cell(25,6,'Date',1,0,'C',1);
		$pdf->SetX(85);
		$pdf->Cell(40,6,'Amount Due',1,0,'C',1);
		$pdf->SetX(125);
		$pdf->Cell(35,6,'Balance',1,0,'C',1);
		$pdf->SetX(160);
		$pdf->Cell(35,6,'Amount Paid',1,0,'C',1);
		$pdf->Ln();

		$pdf->SetFillColor(240,247,245);
		$pdf->SetFont('Arial','',11);
		
        if($number_of_tot>0)
		{	
			$fill = 0;
			
			while($row = mysql_fetch_array($result))
			{
			    if($cid[$x-1]==$row["customer_id"]){
				$pdf->SetX(20);
				$pdf->Cell(40,6,$row["os_hdr_no"],1,0,'L',$fill);
				$pdf->Cell(25,6,$row["os_hdr_date"],1,0,'L',$fill);
				$pdf->Cell(40,6,number_format($row["os_hdr_net_amount"],2),1,0,'R',$fill);
				$pdf->Cell(35,6,number_format(($row["os_hdr_net_amount"]-$row["payment_amount"]),2),1,0,'R',$fill);
				$pdf->Cell(35,6,number_format($row["payment_amount"],2),1,0,'R',$fill);
				$pdf->Ln();
				if($fill==0)
				{$fill=1;}
				else
				{$fill = 0;}
				}
			}
		}
		else
		{
			$pdf->Ln();
			$pdf->SetX(20);
			$pdf->Cell(175,6,'No Record found . . .',0,'L');
		}
		$amtPaidBal=mysql_query
			("
			SELECT sum(pay.payment_amount) as 'sum', sum(os.os_hdr_net_amount) as 'sum1'
            FROM os_header os  left outer join payment pay on os.os_hdr_id = pay.os_hdr_id
			WHERE  os.customer_id = ".$cid[$x-1].";" 
			);
		while($bal = mysql_fetch_array($amtPaidBal))
		{
			$pdf->Ln();
			$pdf->SetX(20);
			$pdf->SetFont('Arial','',12);
			$pdf->Cell(50,10,'Amount Paid: '.number_format($bal['sum'],2));
			$pdf->Ln();
			$pdf->SetX(20);
			$pdf->Cell(50,10,'Amount Balance: '.number_format(($bal['sum1']-$bal['sum']),2));
			$pdf->Ln();
		}
			$pdf->SetX(16);
			$pdf->SetTextColor(139,137,137);
			$pdf->SetFont('Arial','',10);
			$pdf->Cell(175,5,'____________________________________________________________________________________________');
			$pdf->Ln();
}
$pdf->Output();
?>