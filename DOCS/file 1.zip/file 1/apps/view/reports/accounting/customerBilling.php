<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
$result=mysql_query("select emp_no,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, emp_status_name from employee_profile ep, position pos, emp_status es, department dept where ep.emp_status_id=es.emp_status_id and ep.position_id=pos.position_id and ep.dept_id=dept.dept_id");
$number_of_audit = mysql_num_rows($company_info);
//Initialize the 3 columns and the total

$empno = "";
$name = "";
$dept = "";
$pos = "";
$stat = "";
$cname = "";
$caddrs = "";
$cpno = "";
$cmno = "";
$cmail = "";
$csite = "";
$clogo = "";

//For each row, add the field to the corresponding column
/*while($row = mysql_fetch_array($result))
{
    $empno_t = $row["emp_no"];
    $name_t = $row["user"];
    $dept_t = $row["dept_name"];
    $pos_t = $row["position_name"];
	$stat_t = $row["emp_status_name"];

    $empno = $empno.$empno_t."\n";
    $name = $name.$name_t."\n";
	$dept = $dept.$dept_t."\n";
	$pos = $pos.$pos_t."\n";
    $stat = $stat.$stat_t."\n";
}*/
while($header = mysql_fetch_array($company_info))
{
    $cname = $header["company_name"];
	$caddrs = $header["company_address"];
	$cpno = $header["company_phone_no"];
	$cmno = $header["company_mobile_no"];
	$cmail = $header["company_email_address"];
	$csite = $header["company_website"];
	$clogo = $header["company_logo"];
}

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Statement of Accounts',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
$pdf->SetXY(16,52);
$pdf->SetTextColor(139,137,137);
$pdf->Cell(175,5,'____________________________________________________________________________________________');
$pdf->SetTextColor(70,130,180);
$pdf->SetXY(19,60);
$pdf->SetFont('Arial','',12);
$pdf->Cell(50,10,'Customer Name:');
$pdf->SetTextColor(0,0,0);
//Fields Name position
$Y_Fields_Name_position = 70;
//Table position, under Fields Name
$Y_Table_Position = 76;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(35,6,'O.S. No.',1,0,'C',1);
$pdf->SetX(55);
$pdf->Cell(30,6,'Date',1,0,'C',1);
$pdf->SetX(85);
$pdf->Cell(40,6,'Amount Due',1,0,'C',1);
$pdf->SetX(125);
$pdf->Cell(35,6,'Balance',1,0,'C',1);
$pdf->SetX(160);
$pdf->Cell(35,6,'Amount Paid',1,0,'C',1);
$pdf->Ln();

$i = 0;
$pdf->SetY($Y_Table_Position);

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,255,255);
$fill = false;
while ($i < $number_of_audit)
{
    $pdf->SetX(20);
    $pdf->MultiCell(175,6,'',1,'LR',$fill);
    $i = $i +1;
	$fill = !$fill;
}

/*--------------data---------------------*/
$pdf->SetFont('Helvetica','',12);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(20);
$pdf->MultiCell(35,6,$empno,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(55);
$pdf->MultiCell(30,6,$name,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(85);
$pdf->MultiCell(40,6,$dept,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(125);
$pdf->MultiCell(35,6,$pos,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(160);
$pdf->MultiCell(35,6,$stat,1,'L');
$pdf->SetXY(20,88);
$pdf->SetFont('Arial','',12);
$pdf->Cell(50,10,'Amount Paid:');
$pdf->SetXY(20,94);
$pdf->Cell(50,10,'Amount Balance:');
$pdf->SetXY(16,100);
$pdf->SetTextColor(139,137,137);
$pdf->SetFont('Arial','',10);
$pdf->Cell(175,5,'____________________________________________________________________________________________');
$pdf->Output();
?>