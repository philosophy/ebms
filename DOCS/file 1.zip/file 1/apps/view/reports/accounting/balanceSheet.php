﻿<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");
include("../../accounting/currency.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");

//$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',14);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Balance Sheet',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->Ln(20);
$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Asset',0,0,'L',0);
$pdf->Ln(10);

$sumassets=0;
$sales=0;
$balance_sheet=mysql_query("SELECT gl.account_sub_category_id,gl.account_type_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id and gl_deleted = 0 
group by at.account_sub_category_id ");
while($row = mysql_fetch_array($balance_sheet)){
if($row["account_type_id"]==1 && $row["sum"]!=0 && $row["account_sub_category_id"]!=7 &&  $row["account_sub_category_id"]!=8 && $row["account_sub_category_id"]!=5 && $row["account_sub_category_id"]!=9 && $row["account_sub_category_id"]!=10)
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row["sum"],2),0,0,'R',0);
$pdf->Ln(8);
$sumassets=$sumassets+$row["sum"];
}
if($row["account_sub_category_id"]==5){
$sales=$row["sum"];
}
}

$pdf->SetX(20);
$pdf->Cell(130,6,'Total Assets:',0,0,'L',1);
$pdf->Cell(45,6,$symbol.' '.number_format($sumassets,2),0,0,'R',1);
$pdf->Ln(15);

$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Liability',0,0,'L',0);
$pdf->Ln(10);

$balance_sheet1=mysql_query("SELECT gl.account_sub_category_id,gl.account_type_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id and gl_deleted = 0
group by at.account_sub_category_id");
$sumliability=0;
while($row1 = mysql_fetch_array($balance_sheet1)){
if($row1["account_type_id"]==2 && $row1["sum"]!=0 )
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row1["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row1["sum"],2),0,0,'R',0);
$pdf->Ln(8);
$sumliability=$sumliability+$row1["sum"];
}
}

$pdf->SetFillColor(240,247,245);
$pdf->SetTextColor(0,0,0);
$pdf->SetX(20);
$pdf->Cell(130,6,'Total Liability:',0,0,'L',1);
$pdf->Cell(45,6,number_format($sumliability,2),0,0,'R',1);
$pdf->Ln(15);

$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Owner\'s Equity',0,0,'L',0);
$pdf->Ln(10);

$balance_sheet2=mysql_query("SELECT gl.account_sub_category_id,gl.account_type_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id and  gl_deleted = 0
group by at.account_sub_category_id ");
$sumequity=0;
$expenses=0;
while($row2 = mysql_fetch_array($balance_sheet2)){
if($row2["account_type_id"]==3 && $row2["sum"]!=0&&$row2["account_sub_category_id"]!=6 )
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row2["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row2["sum"],2),0,0,'R',0);
$pdf->Ln(8);
$sumequity=$sumequity+$row2["sum"];
}
if($row2["account_sub_category_id"]==6){
$expenses=$row2["sum"];
}
}
$pdf->SetX(30);
$pdf->Cell(120,6,'Net Income',0,0,'L',0);
$pdf->Cell(45,6,number_format($sales-$expenses,2),0,0,'R',0);
$pdf->Ln(8);

$pdf->SetFillColor(240,247,245);
$pdf->SetTextColor(0,0,0);
$pdf->SetX(20);
$pdf->Cell(130,6,'Total Equity:',0,0,'L',1);
$pdf->Cell(45,6,number_format(($sales-$expenses)+$sumequity,2),0,0,'R',1);
$pdf->Ln(10);

$pdf->SetFillColor(193,205,193);
$pdf->SetX(20);
$pdf->Cell(130,6,'Total Liability & Equity:',0,0,'L',1);
$pdf->Cell(45,6,$symbol.' '.number_format(($sales-$expenses)+$sumliability+$sumequity,2),0,0,'R',1);
$pdf->Ln(15);

$pdf->Output();

?>