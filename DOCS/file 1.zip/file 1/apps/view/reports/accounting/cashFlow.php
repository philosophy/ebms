﻿<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
$result=mysql_query("select emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, emp_status_name from employee_profile ep, position pos, emp_status es, department dept where ep.emp_status_id=es.emp_status_id and ep.position_id=pos.position_id and ep.dept_id=dept.dept_id");
$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',14);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Cash Flow Statement',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->Ln(20);
$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Cash Receipt',0,0,'L',0);
$pdf->Ln(10);

$totalinflow=0;
$cash_flow=mysql_query("SELECT gl.account_sub_category_id,gl.account_category_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id
group by at.account_sub_category_id");
while($row = mysql_fetch_array($cash_flow)){
if($row["account_category_id"]==1 && $row["sum"]!=0&& $row["account_sub_category_id"]!=7 && $row["account_sub_category_id"]!=5 && $row["account_sub_category_id"]!=2 && $row["account_sub_category_id"]!=3)
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row["sum"],2),0,0,'R',0);
$pdf->Ln(8);
$totalinflow=$totalinflow+$row["sum"];
}
}

$pdf->SetX(20);
$pdf->Cell(130,6,'Total Inflow:',0,0,'L',1);
$pdf->Cell(45,6,'Php '.number_format($totalinflow,2),0,0,'R',1);
$pdf->Ln(15);

$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Cash Disbursement',0,0,'L',0);
$pdf->Ln(10);

$totaloutflow=0;
$cash_flow1=mysql_query("SELECT gl.account_sub_category_id,gl.account_category_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id
group by at.account_sub_category_id");
while($row1 = mysql_fetch_array($cash_flow1)){
if($row1["account_category_id"]==2 && $row1["sum"]!=0)
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row1["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row1["sum"],2),0,0,'R',0);
$pdf->Ln(8);
$totaloutflow=$totaloutflow+$row1["sum"];
}
}

$pdf->SetTextColor(0,0,0);
$pdf->SetX(20);
$pdf->Cell(130,6,'Total Outflow:',0,0,'L',1);
$pdf->Cell(45,6,'Php '.number_format($totaloutflow,2),0,0,'R',1);
$pdf->Ln(10);

$pdf->SetFillColor(230,215,200);
$pdf->SetX(20);
$pdf->Cell(130,6,'Total Net Cash Flow:',0,0,'L',1);
$pdf->Cell(45,6,'Php '.number_format($totalinflow-$totaloutflow,2),0,0,'R',1);
$pdf->Ln(15);

$pdf->Output();
?>