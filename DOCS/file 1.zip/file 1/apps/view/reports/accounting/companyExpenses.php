<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
//$result=mysql_query("select * from payments where");
$number_of_audit = mysql_numrows($company_info);
//Initialize the 3 columns and the total

$transno = "";
$doctype = "";
$refno = "";
$particular = "";
$date = "";
$duedate = "";
$amtdue = "";
$balance = "";
$amtpaid = "";

$cname = "";
$caddrs = "";
$cpno = "";
$cmno = "";
$cmail = "";
$csite = "";
$clogo = "";

//For each row, add the field to the corresponding column
/*while($row = mysql_fetch_array($result))
{
    $tansno_t = $row["trans_no"];
    $doctype_t = $row["doctype"];
    $refno_t = $row["refno"];
    $particular_t = $row["particular"];
	$date_t = $row["date"];
	$duedate_t = $row["duedate"];
	$amtdue_t = $row["amtdue"];
	$balance_t = $row["balance"];
	$amtpaid_t = $row["amtpaid"];
	
    $transno = $transno.$transno_t."\n";
    $doctype = $doctype.$doctype_t."\n";
	$refno = $refno.$refno_t."\n";
	$particular = $particular.$particular_t."\n";
	$date = $date.$date_t."\n";
	$duedate = $duedate.$duedate_t."\n";
	$amtdue = $amtdue.$amtdue_t."\n";
	$balance = $balance.$balance_t."\n";
	$amtpaid = $amtpaid.$amtpaid_t."\n";
}
*/
while($header = mysql_fetch_array($company_info))
{
    $cname = $header["company_name"];
	$caddrs = $header["company_address"];
	$cpno = $header["company_phone_no"];
	$cmno = $header["company_mobile_no"];
	$cmail = $header["company_email_address"];
	$csite = $header["company_website"];
	$clogo = $header["company_logo"];
}


//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage('L');

//for the header of report
include('../reportHeaderL.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Company Expenses',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->SetXY(235,45);
$pdf->Cell(40,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(11,120,156);
$pdf->SetXY(20,60);
$pdf->Cell(60,10,'Vendor Name: __________________',0,0,'L');
$pdf->SetTextColor(0,0,0);
//Fields Name position
$Y_Fields_Name_position = 74;
//Table position, under Fields Name
$Y_Table_Position = 80;

/*--------------field name---------------------*/$transno = "";
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(25,6,'Trans. No.',1,0,'C',1);
$pdf->SetX(45);
$pdf->Cell(25,6,'Doc. Type',1,0,'C',1);
$pdf->SetX(70);
$pdf->Cell(25,6,'Ref. No.',1,0,'C',1);
$pdf->SetX(95);
$pdf->Cell(50,6,'Particulars',1,0,'C',1);
$pdf->SetX(145);
$pdf->Cell(25,6,'Date',1,0,'C',1);
$pdf->SetX(170);
$pdf->Cell(25,6,'Due Date',1,0,'C',1);
$pdf->SetX(195);
$pdf->Cell(25,6,'Amount Due',1,0,'C',1);
$pdf->SetX(220);
$pdf->Cell(25,6,'Balance',1,0,'C',1);
$pdf->SetX(245);
$pdf->Cell(30,6,'Amount Paid',1,0,'C',1);
$pdf->Ln();

$i = 0;
$pdf->SetY($Y_Table_Position);

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(248,248,255);
$fill = false;
while ($i < $number_of_audit)
{
    $pdf->SetX(20);
    $pdf->MultiCell(255,6,'',1,'LR',$fill);
    $i = $i +1;
	$fill = !$fill;
}

/*--------------data---------------------*/
$pdf->SetFont('Helvetica','',10);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(20);
$pdf->MultiCell(25,6,$transno,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(45);
$pdf->MultiCell(25,6,$doctype,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(70);
$pdf->MultiCell(25,6,$refno,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(95);
$pdf->MultiCell(50,6,$particular,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(145);
$pdf->MultiCell(25,6,$date,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(170);
$pdf->MultiCell(25,6,$duedate,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(195);
$pdf->MultiCell(25,6,$amtdue,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(220);
$pdf->MultiCell(25,6,$balance,1,'L');
$pdf->SetY($Y_Table_Position);
$pdf->SetX(245);
$pdf->MultiCell(30,6,$amtpaid,1,'L');

$pdf->SetXY(19,90);
$pdf->Cell(255,10,'__________________________________________________________________________________________________________________________________',0,0,'L');
$pdf->SetFont('Arial','B',10);
$pdf->SetXY(20,100);
$pdf->Cell(60,10,'Total Expenses: __________________',0,0,'L');

$pdf->Output();
?>