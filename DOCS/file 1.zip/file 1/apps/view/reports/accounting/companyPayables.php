<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");

//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage('L');


include('../reportHeaderL.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(13,45);
$pdf->Cell(139,10,'Account Payables',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->SetXY(247,45);
$pdf->Cell(40,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
$pdf->Ln(12);

$payables=mysql_query("SELECT ah.ap_hdr_code, s.supplier_name, ah.ap_hdr_ref_type, 
                        ah.ap_hdr_ref_no,ah.ap_hdr_particular,
						ah.ap_hdr_date, ah.ap_hdr_due_date, ah.ap_hdr_amount 
						FROM ap_header ah 
							INNER JOIN supplier_profile s
							ON s.supplier_id = ah.supplier_id");
$ind = mysql_num_rows($payables);
if($ind==0)
{
  $pdf->SetFont('Arial','',13);
  $pdf->SetX(20);
  $pdf->Cell(255,6,'No Payables Found . . .',0,0,'L',1);
}
else
{ 
    $pdf->SetX(13);
	$pdf->SetDrawColor(139,134,130);
	$pdf->SetFillColor(193,205,193);
	$pdf->SetFont('Arial','B',12);
	$pdf->Cell(25,6,'Trans. No.',1,0,'C',1);
	$pdf->Cell(25,6,'Vendor',1,0,'C',1);
	$pdf->Cell(25,6,'Doc. Type',1,0,'C',1);
	$pdf->Cell(28,6,'Ref. No.',1,0,'C',1);
	$pdf->Cell(22,6,'Status',1,0,'C',1);
	$pdf->Cell(30,6,'Date',1,0,'C',1);
	$pdf->Cell(30,6,'Due Date',1,0,'C',1);
	$pdf->Cell(30,6,'Amount Due',1,0,'C',1);
	$pdf->Cell(30,6,'Amount Paid',1,0,'C',1);
	$pdf->Cell(25,6,'Balance',1,0,'C',1);
	$pdf->Ln();

	$f=0;
	while($row = mysql_fetch_array($payables))
	{
	$pdf->SetX(13);
	$pdf->SetFillColor(240,247,245);
	$pdf->SetFont('Arial','',10);
    $pdf->Cell(25,6,$row["ap_hdr_code"],1,0,'C',$f);
	$pdf->Cell(25,6,utf8_decode($row["supplier_name"]),1,0,'C',$f);
	$pdf->Cell(25,6,$row["ap_hdr_ref_type"],1,0,'C',$f);
	$pdf->Cell(28,6,$row["ap_hdr_ref_no"],1,0,'C',$f);
	$pdf->Cell(22,6,$row["ap_hdr_particular"],1,0,'C',$f);
	$pdf->Cell(30,6,$row["ap_hdr_date"],1,0,'C',$f);
	$pdf->Cell(30,6,$row["ap_hdr_due_date"],1,0,'C',$f);
	$pdf->Cell(30,6,number_format($row["ap_hdr_amount"],2),1,0,'R',$f);
	
	
	$totalAmount = 0;
	$paid = mysql_query("SELECT payment_amount FROM payment WHERE payment_ref_type = 'AP'
									AND payment_ref_no = '".$row['ap_hdr_code']."'");
									
	        if(mysql_num_rows($paid) > 0)
			{
				while($amountPaid = mysql_fetch_array($paid))
				{
					$totalAmount += $amountPaid['payment_amount'];
				}
				$pdf->Cell(30,6,number_format($totalAmount,2),1,0,'R',$f);
			}
			else
			{
				$pdf->Cell(30,6,'0.00',1,0,'R',$f);
			}
			
			//PAYMENT BALANCE
			$balance = $row['ap_hdr_amount'] - $totalAmount;
			$pdf->Cell(25,6,number_format($balance,2),1,0,'R',$f);
	
	$pdf->Ln();
	}
	if($f==0)
	{$f=1;}
	else
	{$f = 0;}
}

$pdf->Output();
?>

