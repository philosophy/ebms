<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");


//Select the Products you want to show in your PDF file
$company_info=mysql_query("
	select company_name,company_address,company_phone_no,
		company_mobile_no,company_fax_no,company_email_address,
		company_website,company_logo 
	from company_information");
	
$result=mysql_query
			("
			select c.customer_code, c.customer_name, sum(os_hdr_net_amount) , sum(os_balance) as 'balance', sum(pay.payment_amount) as 'payment' from os_header os left outer join payment pay on os.os_hdr_id = pay.os_hdr_id, customer_profile c  WHERE c.customer_id = os.customer_id group by os.customer_id "
);

$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');


$pdf->SetFont('Arial','',16);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,40);
$pdf->Cell(175,10,'Accounts Receivable Summary',0,0,'C');
$pdf->SetFont('Arial','',10);
$pdf->SetXY(20,45);
$pdf->Cell(175,11,'Date Printed:'.' '.date("m/d/Y"),0,0,'C');
$pdf->Ln();
$pdf->SetX(20);
$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,51,153);
//Fields Name position
$Y_Fields_Name_position = 75;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(30,6,'Customer Code',1,0,'C',1);
$pdf->SetX(50);
$pdf->Cell(60,6,'Customer Name',1,0,'C',1);
$pdf->SetX(110);
$pdf->Cell(30,6,'Amount Due',1,0,'C',1);
$pdf->SetX(140);
$pdf->Cell(30,6,'Balance',1,0,'C',1);
$pdf->SetX(170);
$pdf->Cell(30,6,'Amount Paid',1,0,'C',1);
$pdf->Ln();

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',8);

if($number_of_audit>0)
{
	$fill = 0;
	while($row = mysql_fetch_array($result))
    {
		$pdf->SetX(20);
		$pdf->Cell(30,6,$row["customer_code"],1,0,'C',$fill);
		$pdf->Cell(60,6,utf8_decode($row["customer_name"]),1,0,'L',$fill);
		$pdf->Cell(30,6,number_format($row["sum(os_hdr_net_amount)"],2),1,0,'R',$fill);
		$pdf->Cell(30,6,number_format($row["balance"],2),1,0,'R',$fill);
		$pdf->Cell(30,6,number_format($row["payment"],2),1,0,'R',$fill);
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
    }
}
else
{
    $pdf->SetY(70);
	$pdf->SetX(20);
    $pdf->Cell(175,6,'No Record found . . .',0,'L');
}
		
		$amtPaidBal=mysql_query
			("
			select sum(os_hdr_net_amount) , sum(os_balance) as 'balance', sum(pay.payment_amount) from os_header os left outer join payment pay on os.os_hdr_id = pay.os_hdr_id"
			);
		while($bal = mysql_fetch_array($amtPaidBal))
		{
			$pdf->Ln();
			$pdf->SetX(20);
			$pdf->SetFont('Arial','',12);
			$pdf->SetFillColor(193,205,193);
			$pdf->Cell(175,6,'Total Amount Due: '.$currency.' '.number_format($bal['sum(os_hdr_net_amount)'],2),0,0,'L',1);
			$pdf->Ln(8);
			$pdf->SetX(20);
			$pdf->Cell(175,6,'Total Balance: '.$currency.' '.number_format(($bal['balance']),2),0,0,'L',1);
			$pdf->Ln(8);
			$pdf->SetX(20);
			$pdf->Cell(175,6,'Total Collected: '.$currency.' '.number_format(($bal['sum(pay.payment_amount)']),2),0,0,'L',1);
			$pdf->Ln();
		}
$pdf->Output();


?>