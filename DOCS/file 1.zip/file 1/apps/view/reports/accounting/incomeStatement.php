﻿<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',14);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Income Statement',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');


/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->Ln(20);
$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Income',0,0,'L',0);
$pdf->Ln(10);

$sumincome=0;
$income_statement=mysql_query("SELECT gl.account_sub_category_id,gl.account_type_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id
group by at.account_sub_category_id");
while($row = mysql_fetch_array($income_statement)){
if($row["account_type_id"]==1 && $row["sum"]!=0 && $row["account_sub_category_id"]==5)
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row["sum"],2),0,0,'R',0);
$pdf->Ln(10);
$sumincome=$sumincome+$row["sum"];
}
}

$pdf->SetTextColor(0,255,0);
$pdf->SetX(20);
$pdf->Cell(130,6,'Gross Profit:',0,0,'L',0);
$pdf->Cell(45,6,number_format($sumincome,2),0,0,'R',0);
$pdf->Ln(15);

$pdf->SetTextColor(0,51,153);
$pdf->SetX(20);
$pdf->Cell(130,6,'Less Operating Expenses',0,0,'L',0);
$pdf->Ln(10);

$sumexpenses=0;
$income_statement1=mysql_query("SELECT gl.account_sub_category_id,gl.account_type_id,at.account_sub_category_name, sum(gl.gl_amount) as 'sum'
FROM account_sub_category at, general_ledger gl
WHERE gl.account_sub_category_id = at.account_sub_category_id
group by at.account_sub_category_id");
while($row1 = mysql_fetch_array($income_statement1)){
if( $row1["account_type_id"]==3 && $row1["sum"]!=0 && $row1["account_sub_category_id"]==6)
{
$pdf->SetTextColor(0,0,0);
$pdf->SetX(30);
$pdf->Cell(120,6,$row1["account_sub_category_name"],0,0,'L',0);
$pdf->Cell(45,6,number_format($row1["sum"],2),0,0,'R',0);
$pdf->Ln(10);
$sumexpenses=$sumexpenses+$row1["sum"];
}
}

$pdf->SetFillColor(240,247,245);
$pdf->SetTextColor(255,0,0);
$pdf->SetX(20);
$pdf->Cell(130,6,'Total Expenses:',0,0,'L',0);
$pdf->Cell(45,6,number_format($sumexpenses,2),0,0,'R',0);
$pdf->Ln(15);

$pdf->SetFillColor(193,205,193);
$pdf->SetTextColor(0,0,0);
$pdf->SetX(20);
$pdf->Cell(130,6,'Net Income:',0,0,'L',1);
$pdf->Cell(45,6,'Php '.number_format($sumincome-$sumexpenses,2),0,0,'R',1);
$pdf->Ln(15);

$pdf->Output();
?>