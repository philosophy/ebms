<?php
$pdf->SetFont('Arial','B',16);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,10);
$pdf->Cell(175,10,$cname,0,0,'C');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,16);
$pdf->Cell(175,10,$caddrs,0,0,'C');

$pdf->SetFont('Arial','',10);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,21);
$pdf->Cell(175,10,$cmail.' / '.$csite,0,0,'C');
$pdf->SetFont('Arial','',10);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,26);
$pdf->Cell(175,10,$cpno.' / '.$cmno,0,0,'C');
$pdf->Image('../../../../images/companyInfo/'.$clogo,49,12,20,20);
?>