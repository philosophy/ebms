<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
$result=mysql_query("select emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, emp_status_name from employee_profile ep, position pos, emp_status es, department dept where ep.emp_status_id=es.emp_status_id and ep.position_id=pos.position_id and ep.dept_id=dept.dept_id");
$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Employee Profile List',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
//Fields Name position
$Y_Fields_Name_position = 60;
//Table position, under Fields Name
$Y_Table_Position = 66;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(35,6,'Employee No.',1,0,'C',1);
$pdf->SetX(55);
$pdf->Cell(40,6,'Name',1,0,'C',1);
$pdf->SetX(95);
$pdf->Cell(40,6,'Department',1,0,'C',1);
$pdf->SetX(135);
$pdf->Cell(35,6,'Position',1,0,'C',1);
$pdf->SetX(170);
$pdf->Cell(25,6,'Status',1,0,'C',1);
$pdf->Ln();

$i = 0;
$pdf->SetY($Y_Table_Position);

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',9);
if($number_of_audit>0)
{
	$fill = 0;
	while($row = mysql_fetch_array($result))
    {
		$pdf->SetX(20);
		$pdf->Cell(35,6,$row["emp_code"],1,0,'L',$fill);
		$pdf->Cell(40,6,$row["user"],1,0,'L',$fill);
		$pdf->Cell(40,6,$row["dept_name"],1,0,'L',$fill);
		$pdf->Cell(35,6,$row["position_name"],1,0,'L',$fill);
		$pdf->Cell(25,6,$row["emp_status_name"],1,0,'L',$fill);
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
    }
}
else
{
    $pdf->SetY(70);
	$pdf->SetX(20);
    $pdf->Cell(175,6,'No Record found . . .',0,'L');
}

$pdf->Output();
?>