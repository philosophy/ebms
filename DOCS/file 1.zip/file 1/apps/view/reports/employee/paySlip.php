<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");

$result=mysql_query("select pay.payroll_id,pay.payroll_daily_rate,pay.payroll_hourly_rate,pay.payroll_minutes_rate	,pay.payroll_overtime_rate,pay.payroll_overtime_minutes,pay.payroll_regular_holiday,pay.payroll_allowance,pay.payroll_days_work,pay.payroll_hours_work,pay.payroll_minutes_work,pay.is_deleted,ep.emp_id,ep.emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, date_format(pay.payroll_date,'%b-%d-%Y') as 'payroll_date', date_format(pay.payroll_date_from,'%b-%d-%Y') as 'payroll_date_from', date_format(pay.payroll_date_to,'%b-%d-%Y') as 'payroll_date_to',pay.payroll_basic_salary,pay.payroll_witholding_tax,pay.payroll_witholding_percent,pay.
payroll_total_leave,pay.payroll_total_earnings,pay.payroll_total_deductions,pay.payroll_cash_advance_deductions,pay.payroll_company_loan,pay.payroll_net_pay from employee_profile ep, payroll pay, position pos, department dept where ep.position_id=pos.position_id and ep.dept_id=dept.dept_id and pay.emp_id=ep.emp_id and pay.payroll_id=".$_SESSION['payrollIdReport']);

$ded = mysql_query("select payroll_deduction_desc,payroll_deduction_amount from payroll_deduction where payroll_id=".$_SESSION['payrollIdReport']);
$earn = mysql_query("select payroll_earning_desc,payroll_earning_amount from payroll_earning where payroll_id=".$_SESSION['payrollIdReport']);
$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->Ln();
$pdf->SetFont('Arial','',14);
$pdf->SetFillColor(232,232,232);
$pdf->Cell(190,5,'Pay Slip',0,0,'C');
$pdf->Ln();


$dedArry =  array();
$earnArry =  array();
$dedAmtArry =  array();
$earnAmtArry =  array();
$dedTmp = "";
$earnTmp = "";
$dedAmt = "";
$earnAmt = "";
//Fields Name position
	while($d = mysql_fetch_array($ded))
    {
	$dedTmp .= $d['payroll_deduction_desc']."|";
	$dedAmt .= $d['payroll_deduction_amount']."|";
	}
	while($e = mysql_fetch_array($earn))
    {
	$earnTmp .= $e['payroll_earning_desc']."|";
	$earnAmt .= $e['payroll_earning_amount']."|";
	}
	
	$dedTmp = substr($dedTmp,0,-1);		
	$earnTmp = substr($earnTmp,0,-1);	
	$dedAmt = substr($dedAmt,0,-1);		
	$earnAmt = substr($earnAmt,0,-1);
	

		


while($row = mysql_fetch_array($result))
{
$pdf->SetFont('Arial','',10);
$pdf->Cell(190,5,'for '.$row['payroll_date_from']." to ".$row['payroll_date_to'],0,0,'C');
$pdf->Ln(15);
	$pdf->SetFont('Arial','',11);
	$pdf->SetX(15);

	$pdf->Cell(90,7,'Employee Name: |      '.$row['user'],1,0,'L',1);
	$pdf->Cell(90,7,'Department:       |      '.$row['dept_name'],1,0,'L',1);
	$pdf->Ln();
	$pdf->SetX(15);
	$pdf->Cell(90,7,'Employee No:      |      '.$row['emp_code'],1,0,'L',1);
	$pdf->Cell(90,7,'Date Issued:       |      '.date("F j, Y"),1,0,'L',1);
	$pdf->Ln();
	$pdf->SetX(15);
	$pdf->Cell(90,7,'Position:               |      '.$row['position_name'],1,0,'L',1);
	$pdf->Cell(90,7,'Approved By:      |',1,0,'L',1);
	$netPay = $row['payroll_net_pay'];
	$totEarn = $row['payroll_total_earnings'];
	$totDed = $row['payroll_total_deductions'];
	$bPay = $row['payroll_basic_salary'];
	$taxPer = $row['payroll_witholding_percent'];
	$taxAmt = $row['payroll_witholding_tax'];
	$totWork = $row['payroll_minutes_rate']*$row['payroll_minutes_work'];
	$cAdvance = $row['payroll_cash_advance_deductions'];
	$totLeave = $row['payroll_total_leave'];
	$cLoan = $row['payroll_company_loan'];
	$overTime = $row['payroll_overtime_rate'];
	$allow = $row['payroll_allowance'];
	$regHol = $row['payroll_regular_holiday'];
}

$pdf->Ln(15);
$pdf->SetFillColor(232,232,232);
$pdf->SetFont('Arial','B',11);
$pdf->SetX(15);
$pdf->Cell(50,8,"Earnings",1,0,'C',1);
$pdf->Cell(40,8,"Amount",1,0,'C',1);
$pdf->Cell(50,8,"Deductions",1,0,'C',1);
$pdf->Cell(40,8,"Amount",1,0,'C',1);
$pdf->Ln();

$earnTmp = "Allowance|".$earnTmp;
$earnAmt = $allow."|".$earnAmt;
$earnTmp = "Regular Holiday|".$earnTmp;
$earnAmt = $regHol."|".$earnAmt;
$earnTmp = "Total Overtime|".$earnTmp;
$earnAmt = $overTime."|".$earnAmt;
$earnTmp = "Total Leave/s|".$earnTmp;
$earnAmt = $totLeave."|".$earnAmt;
$earnTmp = "Total Work Rate|".$earnTmp;
$earnAmt = $totWork."|".$earnAmt;
$earnTmp = "Regular Pay|".$earnTmp;
$earnAmt = $bPay."|".$earnAmt;

$dedTmp = "Company Loan|".$dedTmp;
$dedAmt = $cLoan."|".$dedAmt;
$dedTmp = "Cash Advance|".$dedTmp;
$dedAmt = $cAdvance."|".$dedAmt;
$dedTmp = "Witholding Tax (".$taxPer."%)|".$dedTmp;
$dedAmt = $taxAmt."|".$dedAmt;

$dedArry = explode("|",$dedTmp);
$earnArry = explode("|",$earnTmp);
$dedAmtArry = explode("|",$dedAmt);
$earnAmtArry = explode("|",$earnAmt);
	
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','',10);

	for($ctr=0;$ctr<count($dedArry) || $ctr<count($earnArry);$ctr++)
    {
		if($ctr<count($dedArry)&&$ctr>=count($earnArry))
		{
		$pdf->SetX(15);
		$pdf->Cell(50,8,"",1,0,'L');
		$pdf->Cell(40,8,"",1,0,'R');
		$pdf->Cell(50,8,$dedArry[$ctr],1,0,'L');
		$pdf->Cell(40,8,number_format($dedAmtArry[$ctr],2),1,0,'R');
		$pdf->Ln();
		}
		else if($ctr<count($earnArry)&&$ctr>=count($dedArry))
		{
		$pdf->SetX(15);
		$pdf->Cell(50,8,$earnArry[$ctr],1,0,'L');
		$pdf->Cell(40,8,number_format($earnAmtArry[$ctr],2),1,0,'R');
		$pdf->Cell(50,8,"",1,0,'L');
		$pdf->Cell(40,8,"",1,0,'R');
		$pdf->Ln();
		}
		else
		{
		$pdf->SetX(15);
		$pdf->Cell(50,8,$earnArry[$ctr],1,0,'L');
		$pdf->Cell(40,8,number_format($earnAmtArry[$ctr],2),1,0,'R');
		$pdf->Cell(50,8,$dedArry[$ctr],1,0,'L');
		$pdf->Cell(40,8,number_format($dedAmtArry[$ctr],2),1,0,'R');
		$pdf->Ln();
		}
    }
	$pdf->SetFillColor(232,232,232);
	$pdf->SetFont('Arial','B',11);
	$pdf->SetX(15);
	$pdf->Cell(50,8,"Total Earnings",1,0,'L',1);
	$pdf->Cell(40,8,number_format($totEarn,2),1,0,'R',0);
	$pdf->Cell(50,8,"Total Deductions",1,0,'L',1);
	$pdf->Cell(40,8,number_format($totDed,2),1,0,'R',0);
	$pdf->Ln(15);

$pdf->SetX(15);
$pdf->Cell(180,8,"Net Pay  |     ".number_format($netPay,2),0,0,'L',1);

$pdf->Output();
?>