<?php
require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');
//Connect to your database
include("../../../../config/config.php");



$os = $_SESSION['os'];


//Select the Products you want to show in your PDF file
$company_info=mysql_query("
	select company_name,company_address,company_phone_no,
		company_mobile_no,company_fax_no,company_email_address,
		company_website,company_logo 
	from company_information");
	
$result=mysql_query
			("
			Select distinct os_dtl_qty, u.unit_name, os_dtl_item_description, p.product_unit_price, os_dtl_qty * p.product_unit_price From os_detail, os_header ,unit u, product p Where   p.unit_id = u.unit_id AND p.`PRODUCT_CODE` = `os_detail`.item_id and os_detail.os_hdr_id = '$os'");

$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$header=mysql_query("Select pr_hdr_no, concat(e.emp_first_name, ' ', e.emp_last_name) as 'name', pr_hdr_date_requested, pr_hdr_date_needed  from pr_header os, employee_profile e where e.emp_id = os.pr_hdr_requestor_id and pr_hdr_no = 'PR-2011-000002'");	
while($rec = mysql_fetch_array($header))
		{
			$pdf->SetFont('Arial','',12);
			
			$pdf->SetXY(20,52);
			$pdf->Cell(139,10,$rec['pr_hdr_no'],0,0,'L');
			$pdf->SetXY(20,52);
			$pdf->Cell(139,20,'Requestor:',0,0,'L');
			$pdf->SetXY(45,52);
			$pdf->Cell(139,20,$rec['name'],0,0,'L');
			$pdf->SetXY(20,52);
			$pdf->Cell(139,30,'Date requested:',0,0,'L');
			$pdf->SetXY(55,52);
			$pdf->Cell(139,30,date('D, M. d, Y', strtotime($rec['pr_hdr_date_requested'])),0,0,'L');
			$pdf->SetXY(20,52);
			$pdf->Cell(139,40,'Date needed:',0,0,'L');
			$pdf->SetXY(50,52);
			$pdf->Cell(139,40,date('D, M. d, Y', strtotime($rec['pr_hdr_date_needed'])),0,0,'L');
			
			
			
				
		}

$pdf->SetFont('Arial','',16);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,40);
$pdf->Cell(175,10,'Purchase Request',0,0,'C');
$pdf->SetFont('Arial','',10);
$pdf->SetXY(20,45);
$pdf->Cell(175,11,'Date Printed:'.' '.date("m/d/Y"),0,0,'C');
$pdf->Ln();
$pdf->SetX(20);
$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,51,153);
//Fields Name position
$Y_Fields_Name_position = 80;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(15,6,'Qty',1,0,'C',1);
$pdf->SetX(35);
$pdf->Cell(20,6,'Unit',1,0,'C',1);
$pdf->SetX(55);
$pdf->Cell(100,6,'Description',1,0,'C',1);
$pdf->SetX(155);
$pdf->Cell(20,6,'Unit Price',1,0,'C',1);
$pdf->SetX(175);
$pdf->Cell(20,6,'Amount',1,0,'C',1);
$pdf->Ln();

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',8);

if($number_of_audit>0)
{
	$fill = 0;
	while($row = mysql_fetch_array($result))
    {
		$pdf->SetX(20);
		$pdf->Cell(15,6,$row["os_dtl_qty"],1,0,'L',$fill);
		$pdf->Cell(20,6,utf8_decode($row["unit_name"]),1,0,'C',$fill);
		$pdf->Cell(100,6,($row["os_dtl_item_description"]),1,0,'L',$fill);
		$pdf->Cell(20,6,number_format($row["product_unit_price"],2),1,0,'R',$fill);
		$pdf->Cell(20,6,number_format(($row["product_unit_price"] * $row["os_dtl_qty"]),2),1,0,'R',$fill);
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
    }
}
else
{
    $pdf->SetY(75);
	$pdf->SetX(20);
    $pdf->Cell(175,6,'No Record found . . .',0,'L');
}
$query = mysql_query("Select cur_symbol from currency where is_flag = 1");
		$c = mysql_fetch_array($query);
		$currency = $c['cur_symbol'];

		$amtPaidBal=mysql_query
			("
			SELECT concat(e.emp_first_name, ' ', e.emp_last_name) as 'name', pr_hdr_remarks from pr_header pr inner join employee_profile e on e.emp_id = pr.pr_hdr_approved_by_id where pr_hdr_no = 'PR-2011-000002'"
			);
		while($bal = mysql_fetch_array($amtPaidBal))
		{
			$pdf->Ln();
			$pdf->SetX(20);
			$pdf->SetFont('Arial','',12);
			$pdf->SetFillColor(193,205,193);
			$pdf->Cell(175,6,'Approved by: '.$bal['name'],0,0,'L',1);
			$pdf->Ln(8);
			$pdf->SetX(20);
			$pdf->Cell(175,6,'Remarks: '.$bal['pr_hdr_remarks'],0,0,'L',1);
			$pdf->Ln();
		}
$pdf->Output();
?>