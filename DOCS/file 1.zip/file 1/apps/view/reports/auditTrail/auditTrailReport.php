<?php

session_start();
$from = $_SESSION['from'];
$to = $_SESSION['to'];

if($from != "" && $to !== "")
	$dateRange = " and at.audit_date between '".$from."' and '".$to."'";
else 
	$dateRange = "";
	
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
$result=mysql_query("select concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'User', audit_action_taken, audit_date, audit_time from audit_trail at, employee_profile ep where ep.emp_id=at.emp_id".$dateRange." order by at.audit_date desc,at.audit_time desc");
$number_of_audit = mysql_num_rows($result);

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Audit Trail',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
//Fields Name position
$Y_Fields_Name_position = 60;
//Table position, under Fields Name
$Y_Table_Position = 66;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(45,6,'User',1,0,'C',1);
$pdf->SetX(65);
$pdf->Cell(70,6,'Action Taken',1,0,'C',1);
$pdf->SetX(135);
$pdf->Cell(30,6,'Date',1,0,'C',1);
$pdf->SetX(165);
$pdf->Cell(30,6,'Time',1,0,'C',1);
$pdf->Ln();

$pdf->SetY($Y_Table_Position);

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',11);
if($number_of_audit>0)
{	
    $fill = 0;
	while($row = mysql_fetch_array($result))
	{
		$pdf->SetX(20);
		$pdf->Cell(45,6,$row["User"],1,0,'L',$fill);
		$pdf->Cell(70,6,$row["audit_action_taken"],1,0,'L',$fill);
		$pdf->Cell(30,6,$row["audit_date"],1,0,'L',$fill);
		$pdf->Cell(30,6,date("g:i a", strtotime($row["audit_time"])),1,0,'L',$fill);
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
	}
}
else
{
    $pdf->SetY(70);
	$pdf->SetX(20);
    $pdf->Cell(175,6,'No Record found . . .',0,'L');
}


$pdf->Output();
?>