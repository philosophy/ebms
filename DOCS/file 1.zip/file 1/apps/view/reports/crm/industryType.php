<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");

$result_type=mysql_query
     ("
	 SELECT industry_type_id, industry_type_name
	 FROM industry_type order by industry_type_id;
	 ");

$number_of_type = mysql_num_rows($result_type);

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(15,45);
$pdf->Cell(148,10,'Industry Type Report',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
//Fields Name position
$Y_Fields_Name_position = 64;
//Table position, under Fields Name
$Y_Table_Position = 70;
$pdf->Ln();

while($type = mysql_fetch_array($result_type))
{ $ctype[] =  $type["industry_type_id"];
$ctypename[] =  $type["industry_type_name"];
}
			
for($x=1; $x<=$number_of_type; $x++)
{
		$result=mysql_query
			("
			SELECT cp.customer_code,cp.customer_name,cp.customer_mobile_no,cp.customer_phone_no,cp.customer_email_address,cp.industry_type_id,it.industry_type_name
			FROM customer_profile cp, industry_type it
			WHERE cp.industry_type_id = it.industry_type_id;
			");
		
		$result_tot=mysql_query
			("
			SELECT *
			FROM customer_profile
			WHERE industry_type_id=".$x.";");
			
		$number_of_tot = mysql_num_rows($result_tot);
		$pdf->SetFont('Arial','',11);
		$pdf->SetX(15);
		$pdf->SetTextColor(0,51,153);
		$pdf->Cell(134,10,$ctypename[$x-1].' (Total = '.$number_of_tot.')',0,0,'L');
        $pdf->Ln();
		/*--------------field name---------------------*/
		$pdf->SetTextColor(0,0,0);
		$pdf->SetDrawColor(139,134,130);
		$pdf->SetFillColor(193,205,193);
		$pdf->SetFont('Arial','B',10);
		$pdf->SetX(15);
		$pdf->Cell(35,6,'Customer Code',1,0,'C',1);
		$pdf->SetX(50);
		$pdf->Cell(45,6,'Customer Name',1,0,'C',1);
		$pdf->SetX(95);
		$pdf->Cell(30,6,'Mobile No',1,0,'C',1);
		$pdf->SetX(125);
		$pdf->Cell(25,6,'Phone No',1,0,'C',1);
		$pdf->SetX(150);
		$pdf->Cell(50,6,'E-mail Address',1,0,'C',1);

		$pdf->Ln();

		$i = 0;

		/*----------no. of lines & fill---------------------*/
		$pdf->SetFillColor(240,247,245);
		$pdf->SetFont('Arial','',10);

		if($number_of_tot>0)
		{	
			$fill = 0;
			
			while($row = mysql_fetch_array($result))
			{
			    if($ctype[$x-1]==$row["industry_type_id"]){
				$pdf->SetX(15);
				$pdf->Cell(35,6,$row["customer_code"],1,0,'L',$fill);
				$pdf->Cell(45,6,utf8_decode($row["customer_name"]),1,0,'L',$fill);
				$pdf->Cell(30,6,$row["customer_mobile_no"],1,0,'L',$fill);
				$pdf->Cell(25,6,$row["customer_phone_no"],1,0,'L',$fill);
				$pdf->Cell(50,6,utf8_decode($row["customer_email_address"]),1,0,'L',$fill);
				$pdf->Ln();
				if($fill==0)
				{$fill=1;}
				else
				{$fill = 0;}
				}
			}
		}
		else
		{
			$pdf->Ln();
			$pdf->SetX(15);
			$pdf->Cell(175,6,'No Record found . . .',0,'L');
		}

		$pdf->Ln();
		$pdf->SetX(14);
		$pdf->Cell(150,6,'______________________________________________________________________________________________',0,0,'LR');
		$pdf->Ln();
}

$pdf->Output();

?>