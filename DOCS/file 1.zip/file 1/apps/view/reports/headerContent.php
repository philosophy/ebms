<?php 
$cname = "";
$caddrs = "";
$cpno = "";
$cmno = "";
$cmail = "";
$csite = "";
$clogo = "";

while($header = mysql_fetch_array($company_info))
{
    $cname = $header["company_name"];
	$caddrs = $header["company_address"];
	$cpno = $header["company_phone_no"];
	$cmno = $header["company_mobile_no"];
	$cmail = $header["company_email_address"];
	$csite = $header["company_website"];
	$clogo = $header["company_logo"];
}
?>