<?php

include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");
$result=mysql_query("select product_code as 'productCode', GROUP_CONCAT(' ', pf.product_field_name, ': ', pi.product_description) as 'productDesc', p.product_unit_price as 'productUnitPrice', p.product_qty as 'productQty'
						from product p inner join product_information pi on pi.product_id = p.product_code 
						inner join product_field pf on pf.product_field_id = pi.product_field_id where p.is_deleted=0 and p.item_flag='P' group by p.product_code");
$number_of_audit = mysql_num_rows($result);

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage("L");

//for the header of report
include('../reportHeaderL.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Item Stock Inventory (Products)',0,0,'L');
$pdf->SetX(235);
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
//Fields Name position
$Y_Fields_Name_position = 60;
//Table position, under Fields Name
$Y_Table_Position = 66;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetFont('Arial','B',12);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(25);
$pdf->Cell(35,6,'Product Code',1,0,'C',1);
$pdf->SetX(60);
$pdf->Cell(125,6,'Description',1,0,'C',1);
$pdf->SetX(185);
$pdf->Cell(20,6,'Qty',1,0,'C',1);
$pdf->SetX(205);
$pdf->Cell(25,6,'Price',1,0,'C',1);
$pdf->SetX(230);
$pdf->Cell(35,6,'Amount',1,0,'C',1);
$pdf->SetX(95);
$pdf->Ln();

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',10);
if($number_of_audit>0)
{	
    $fill = 0;
	while($row = mysql_fetch_array($result))
	{
		$pdf->SetX(25);
		$pdf->Cell(35,6,$row["productCode"],1,0,'L',$fill);
		$pdf->Cell(125,6,$row["productDesc"],1,0,'L',$fill);
		$pdf->Cell(20,6,$row["productQty"],1,0,'R',$fill);
		$pdf->Cell(25,6,number_format($row["productUnitPrice"],2),1,0,'R',$fill);
		$pdf->Cell(35,6,number_format($row["productQty"]*$row["productUnitPrice"],2),1,0,'R',$fill);
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
	}
}
else
{
    $pdf->SetY(70);
	$pdf->SetX(20);
    $pdf->Cell(175,6,'No Record found . . .',0,'L');
}

$pdf->Output();
?>