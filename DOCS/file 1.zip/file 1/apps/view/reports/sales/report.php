<?php
session_start();
include("../../../../config/config.php");
$os = @$_POST['osNo'];
$_SESSION['os'] = $os;
$dr = @$_POST['drNo'];
$_SESSION['dr_code'] = $dr;
?>