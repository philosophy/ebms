<?php
require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');
//Connect to your database
include("../../../../config/config.php");

$os = $_SESSION['dr_code'];

//Select the Products you want to show in your PDF file
$company_info=mysql_query("
	select company_name,company_address,company_phone_no,
		company_mobile_no,company_fax_no,company_email_address,
		company_website,company_logo 
	from company_information");
	
$result=mysql_query
			("
			Select distinct DR_DTL_ID, DR_DTL_QTY, u.UNIT_NAME,
			DR_DTL_ITEM_DESCRIPTION,
			p.PRODUCT_UNIT_PRICE,
			(dr_dtl_qty * p.product_unit_price) as ' Total Amount'
			From dr_detail, dr_header ,unit u, product p
			Where p.unit_id = u.unit_id AND
			p.PRODUCT_CODE = dr_detail.item_id
			and dr_detail.dr_hdr_id = '$os'");

$number_of_audit = mysql_num_rows($result);
//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$header=mysql_query("Select dr_hdr_no, c.customer_name from dr_header os, customer_profile c where c.customer_id = os.customer_id and dr_hdr_no = '$os'");	
while($rec = mysql_fetch_array($header))
		{
			$pdf->SetFont('Arial','',12);
			$pdf->SetXY(20,52);
			$pdf->Cell(139,10,$rec['dr_hdr_no'],0,0,'L');
			$pdf->SetXY(20,52);
			$pdf->Cell(139,20,$rec['customer_name'],0,0,'L');
				
		}

$pdf->SetFont('Arial','',16);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,40);
$pdf->Cell(175,10,'Delivery Receipt',0,0,'C');
$pdf->SetFont('Arial','',10);
$pdf->SetXY(20,45);
$pdf->Cell(175,11,'Date Printed:'.' '.date("m/d/Y"),0,0,'C');
$pdf->Ln();
$pdf->SetX(20);
$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,51,153);
//Fields Name position
$Y_Fields_Name_position = 75;

/*--------------field name---------------------*/
$pdf->SetDrawColor(139,134,130);
$pdf->SetFillColor(193,205,193);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(15,6,'Qty',1,0,'C',1);
$pdf->SetX(35);
$pdf->Cell(20,6,'Unit',1,0,'C',1);
$pdf->SetX(55);
$pdf->Cell(100,6,'Description',1,0,'C',1);
$pdf->SetX(155);
$pdf->Cell(20,6,'Unit Price',1,0,'C',1);
$pdf->SetX(175);
$pdf->Cell(20,6,'Amount',1,0,'C',1);
$pdf->Ln();

/*----------no. of lines & fill---------------------*/
$pdf->SetFillColor(240,247,245);
$pdf->SetFont('Arial','',8);

if($number_of_audit>0)
{
	$fill = 0;
	while($row = mysql_fetch_array($result))
    {
		$pdf->SetX(20);
		$pdf->Cell(15,6,$row["DR_DTL_QTY"],1,0,'L',$fill);
		$pdf->Cell(20,6,utf8_decode($row["UNIT_NAME"]),1,0,'C',$fill);
		$pdf->Cell(100,6,($row["DR_DTL_ITEM_DESCRIPTION"]),1,0,'L',$fill);
		$pdf->Cell(20,6,number_format($row["PRODUCT_UNIT_PRICE"],2),1,0,'R',$fill);
		$pdf->Cell(20,6,number_format(($row["PRODUCT_UNIT_PRICE"] * $row["DR_DTL_QTY"]),2),1,0,'R',$fill);
		$pdf->Ln();
		if($fill==0)
		{$fill=1;}
		else
		{$fill = 0;}
    }
}
else
{
    $pdf->SetY(70);
	$pdf->SetX(20);
    $pdf->Cell(175,6,'No Record found . . .',0,'L');
}

		$amtPaidBal=mysql_query
			("
			SELECT dr_hdr_gross_amount, dr_hdr_net_amount, dr_hdr_discount_percent from dr_header where dr_hdr_no = '$os'"
			);
		while($bal = mysql_fetch_array($amtPaidBal))
		{
			$pdf->Ln();
			$pdf->SetX(20);
			$pdf->SetFont('Arial','',12);
			$pdf->SetFillColor(193,205,193);
			$pdf->Cell(175,6,'Gross Amount: P '.number_format($bal['dr_hdr_gross_amount'],2),0,0,'L',1);
			$pdf->Ln(8);
			$pdf->SetX(20);
			$pdf->Cell(175,6,'Discount: '.$bal['dr_hdr_discount_percent'].'%',0,0,'L',1);
			$pdf->Ln(8);
			$pdf->SetX(20);
			$pdf->Cell(175,6,'Net Amount: P '.number_format(($bal['dr_hdr_net_amount']),2),0,0,'L',1);
			$pdf->Ln();
		}
$pdf->Output();
?>