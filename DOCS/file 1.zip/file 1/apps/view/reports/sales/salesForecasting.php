﻿<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");

//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage();

//for the header of report
include('../reportHeaderP.php');

$pdf->SetFont('Arial','',14);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Sales Forecasting',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');

$resultDay=mysql_query("SELECT DATE_FORMAT( os_hdr_date,  '%M %d, %Y' ) as 'date', SUM( os_hdr_gross_amount ) as 'sum' 
										FROM os_header
										WHERE os_hdr_date
										IN (
										DATE_SUB( CURDATE( ) , INTERVAL 1 
										DAY ) , CURDATE( )
										)
										GROUP BY os_hdr_date");
										
$resultWeek=mysql_query("SELECT DATE_FORMAT( os_hdr_date,  '%u' ) AS  'date', SUM( os_hdr_gross_amount ) AS  'sum'
										FROM os_header
										WHERE DATE_FORMAT( os_hdr_date,  '%u' ) 
										IN (
										DATE_FORMAT( CURDATE( ) ,  '%u' ) -1, DATE_FORMAT( CURDATE( ) ,  '%u' )
										)
										GROUP BY DATE_FORMAT( os_hdr_date,  '%u' ) 
										Order by os_hdr_date asc");
										
$resultMonth=mysql_query("SELECT DATE_FORMAT( os_hdr_date,  '%M' ) AS  'date', SUM( os_hdr_gross_amount ) AS  'sum'
										FROM os_header
										WHERE DATE_FORMAT( os_hdr_date,  '%c' ) 
										IN (
										DATE_FORMAT( CURDATE( ) ,  '%c' ) -1, DATE_FORMAT( CURDATE( ) ,  '%c' )
										)
										GROUP BY DATE_FORMAT( os_hdr_date,  '%M' ) 
										Order by os_hdr_date asc");
$pIndicatorD = mysql_num_rows($resultDay);
$pIndicatorW = mysql_num_rows($resultWeek);
$pIndicatorM = mysql_num_rows($resultMonth);
if($pIndicatorD<2)
{
  $pdf->SetFont('Arial','',13);
  $pdf->Ln(15);
  $pdf->SetX(20);
  $pdf->SetFillColor(255,0,0);
  $pdf->SetTextColor(255,255,255);
  $pdf->Cell(175,6,'No Previous Day Record/s, cannot calculate Daily Sales Forecasting . . .',1,0,'C',1);
}
else
{
	/*--------------field name---------------------*/
	$pdf->SetDrawColor(139,134,130);
	$pdf->SetFillColor(193,205,193);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(15);
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Day',1,0,'C',1);
	$pdf->Cell(60,6,'Average Sales',1,0,'C',1);
	$pdf->Ln();

	while($row = mysql_fetch_array($resultDay)){
	$day[]=$row['date'];
	$sum[]=$row['sum'];
	}
	$pdf->SetFont('Arial','',12);
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Previous Day - '.$day[0],1,0,'C',0);
	$pdf->Cell(60,6,number_format($sum[0],2),1,0,'R',0);
	$pdf->Ln();
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Current Day - '.$day[1],1,0,'C',0);
	$pdf->Cell(60,6,number_format($sum[1],2),1,0,'R',0);
	$pdf->Ln(10);

	$pdf->SetFillColor(240,247,245);
	$pg = (($sum[1]-$sum[0])/$sum[0])*100;
	$amtpg = $sum[0]*(round($pg,2)*0.01);
	$amtpg1 = $sum[0]*(round($pg,2)*0.01);
	$amtpg = $amtpg + $sum[1];
	$pdf->SetX(30);
	$pdf->Cell(150,6,'Percentage Growth (%) = '.round($pg,2)."%",0,0,'L',1);
	$pdf->Ln(10);
	if($pg<0)
	{
	    $pdf->SetX(30);
		$pdf->Cell(150,6,'Sales Growth is negative, Daily Sales Forecast is invalid!',1,0,'C',0);
	    $pdf->Ln();
	}
	else
	{
		$pdf->SetFont('Arial','B',12);
		$pdf->SetFillColor(193,205,193);
		$pdf->SetX(30);
		$pdf->Cell(150,6,'Forecast Days',0,0,'C',1);
		$pdf->Ln(10);
		/*$tmpAmt = $sum[0]*(round($pg,2)*0.01);
		$tmpAmt1 = $sum[0]*(round($pg,2)*0.01);
		$tmpAmt=$tmpAmt  + $sum[1];
		for($ctr=2,$range=0;$ctr<=date("t")-(date("j"));$ctr++)
		{
			if($tmpAmt>$range)
			{
			$range=(round($tmpAmt,-3)+1000);
			}
			$tmpAmt=$tmpAmt+$tmpAmt1;
		}*/
		$pdf->SetX(30);
		$pdf->Cell(40,6,'Day',1,0,'C',1);
		$pdf->Cell(35,6,'Forecast Sales',1,0,'C',1);
		$pdf->Cell(75,6,'Graph '.' (0.00 - 10000000.00)',1,0,'C',1);
		$pdf->Ln();
		$pdf->SetFont('Arial','',12);
		$pdf->SetFillColor(0,106,137);
		for($ctr=1;$ctr<=date("t")-(date("j"));$ctr++)
		{
			$pdf->SetX(30);
			$pdf->Cell(40,6,date('F j, Y',strtotime("+".$ctr." days")),1,0,'C',0);
			$pdf->Cell(35,6,number_format($amtpg,2),1,0,'R',0);
			$pdf->Cell(($amtpg/100000000)*100,6,'',1,0,'L',1);
			$pdf->Cell(75-(($amtpg/100000000)*100),6,'',1,0,'L',0);
			$pdf->Ln();
			$amtpg=$amtpg+$amtpg1;
		}
	}
}
//----------------------------------------------------------------------------------------------------------------------
if($pIndicatorW<2)
{
  $pdf->SetFont('Arial','',13);
  $pdf->Ln(15);
  $pdf->SetX(20);
   $pdf->SetFillColor(255,0,0);
  $pdf->SetTextColor(255,255,255);
  $pdf->Cell(175,6,'No Previous Week Record/s, cannot calculate Weekly Sales Forecasting . . .',1,0,'C',1);
}

else
{
	/*--------------field name---------------------*/
	$pdf->SetDrawColor(139,134,130);
	$pdf->SetFillColor(193,205,193);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(15);
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Week',1,0,'C',1);
	$pdf->Cell(60,6,'Average Sales',1,0,'C',1);
	$pdf->Ln();

	while($row = mysql_fetch_array($resultWeek)){
	$week[]=$row['date'];
	$sumW[]=$row['sum'];
	}
	$pdf->SetFont('Arial','',12);
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Previous Week - Week '.$week[0],1,0,'C',0);
	$pdf->Cell(60,6,number_format($sumW[0],2),1,0,'R',0);
	$pdf->Ln();
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Current Week - Week '.$week[1],1,0,'C',0);
	$pdf->Cell(60,6,number_format($sumW[1],2),1,0,'R',0);
	$pdf->Ln(10);

	$pdf->SetFillColor(240,247,245);
	$pg = (($sumW[1]-$sumW[0])/$sumW[0])*100;
	$amtpg = $sumW[0]*(round($pg,2)*0.01);
	$amtpg1 = $sumW[0]*(round($pg,2)*0.01);
	$amtpg = $amtpg + $sumW[1];
	$pdf->SetX(30);
	$pdf->Cell(150,6,'Percentage Growth (%) = '.round($pg,2)."%",0,0,'L',1);
	$pdf->Ln(10);
	
	if($pg<0)
	{
     	$pdf->SetX(30);
		$pdf->Cell(150,6,'Sales Growth is negative, Weekly Sales Forecast is invalid!',1,0,'C',0);
	    $pdf->Ln();
	}
	else
	{
		$pdf->SetFont('Arial','B',12);
		$pdf->SetFillColor(193,205,193);
		$pdf->SetX(30);
		$pdf->Cell(150,6,'Forecast Weeks',0,0,'C',1);
		$pdf->Ln(10);
		/*$tmpAmt = $sumM[0]*(round($pg,2)*0.01);
		$tmpAmt1 = $sumM[0]*(round($pg,2)*0.01);
		$tmpAmt=$tmpAmt  + $sumM[1];
		for($ctr=2,$range=0;$ctr<=date("t")-(date("j"));$ctr++)
		{
			if($tmpAmt>$range)
			{
			$range=(round($tmpAmt,-3)+1000);
			}
			$tmpAmt=$tmpAmt+$tmpAmt1;
		}*/
		$pdf->SetX(30);
		$pdf->Cell(40,6,'Week',1,0,'C',1);
		$pdf->Cell(35,6,'Forecast Sales',1,0,'C',1);
		$pdf->Cell(75,6,'Graph '.' (0.00 - 25000000.00)',1,0,'C',1);
		$pdf->Ln();
		$pdf->SetFont('Arial','',12);
		$pdf->SetFillColor(34,139,34);
		for($ctr=($week[1]+1);$ctr<=($week[1]+3);$ctr++)
		{
			$pdf->SetX(30);
			$pdf->Cell(40,6,'Week '.$ctr,1,0,'C',0);
			$pdf->Cell(35,6,number_format($amtpg,2),1,0,'R',0);
			$pdf->Cell(($amtpg/25000000)*100,6,'',1,0,'L',1);
			$pdf->Cell(75-(($amtpg/25000000)*100),6,'',1,0,'L',0);
			$pdf->Ln();
			$amtpg=$amtpg+$amtpg1;
		}
	}
}
//----------------------------------------------------------------------------------------------------------------------
if($pIndicatorM<2)
{
  $pdf->SetFont('Arial','',13);
  $pdf->Ln(15);
  $pdf->SetX(20);
   $pdf->SetFillColor(255,0,0);
  $pdf->SetTextColor(255,255,255);
  $pdf->Cell(175,6,'No Previous Month Record/s, cannot calculate Monthly Sales Forecasting . . .',1,0,'C',1);
}
else
{
	/*--------------field name---------------------*/
	$pdf->SetDrawColor(139,134,130);
	$pdf->SetFillColor(193,205,193);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(15);
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Month',1,0,'C',1);
	$pdf->Cell(60,6,'Average Sales',1,0,'C',1);
	$pdf->Ln();

	while($row = mysql_fetch_array($resultMonth)){
	$month[]=$row['date'];
	$sumM[]=$row['sum'];
	}
	$pdf->SetFont('Arial','',12);
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Previous Month - '.$month[0],1,0,'C',0);
	$pdf->Cell(60,6,number_format($sumM[0],2),1,0,'R',0);
	$pdf->Ln();
	$pdf->SetX(30);
	$pdf->Cell(90,6,'Current Month - '.$month[1],1,0,'C',0);
	$pdf->Cell(60,6,number_format($sumM[1],2),1,0,'R',0);
	$pdf->Ln(10);

	$pdf->SetFillColor(240,247,245);
	$pg = (($sumM[1]-$sumM[0])/$sumM[0])*100;
	$amtpg = $sumM[0]*(round($pg,2)*0.01);
	$amtpg1 = $sumM[0]*(round($pg,2)*0.01);
	$amtpg = $amtpg + $sumM[1];
	$pdf->SetX(30);
	$pdf->Cell(150,6,'Percentage Growth (%) = '.round($pg,2)."%",0,0,'L',1);
	$pdf->Ln(10);
	if($pg<0)
	{
	    $pdf->SetX(30);
		$pdf->Cell(150,6,'Sales Growth is negative, Monthly Sales Forecast is invalid!',1,0,'C',0);
	    $pdf->Ln();
	}
	else
	{
		$pdf->SetFont('Arial','B',12);
		$pdf->SetFillColor(193,205,193);
		$pdf->SetX(30);
		$pdf->Cell(150,6,'Forecast Months',0,0,'C',1);
		$pdf->Ln(10);
		/*$tmpAmt = $sumM[0]*(round($pg,2)*0.01);
		$tmpAmt1 = $sumM[0]*(round($pg,2)*0.01);
		$tmpAmt=$tmpAmt  + $sumM[1];
		for($ctr=2,$range=0;$ctr<=date("t")-(date("j"));$ctr++)
		{
			if($tmpAmt>$range)
			{
			$range=(round($tmpAmt,-3)+1000);
			}
			$tmpAmt=$tmpAmt+$tmpAmt1;
		}*/
		$pdf->SetX(30);
		$pdf->Cell(40,6,'Month',1,0,'C',1);
		$pdf->Cell(35,6,'Forecast Sales',1,0,'C',1);
		$pdf->Cell(75,6,'Graph '.' (0.00 - 25000000.00)',1,0,'C',1);
		$pdf->Ln();
		$pdf->SetFont('Arial','',12);
		$pdf->SetFillColor(165,42,42);
		for($ctr=1;$ctr<=12-date("m");$ctr++)
		{
			$pdf->SetX(30);
			$pdf->Cell(40,6,date('F',strtotime("+".$ctr." months")),1,0,'C',0);
			$pdf->Cell(35,6,number_format($amtpg,2),1,0,'R',0);
			$pdf->Cell(($amtpg/25000000)*100,6,'',1,0,'L',1);
			$pdf->Cell(75-(($amtpg/25000000)*100),6,'',1,0,'L',0);
			$pdf->Ln();
			$amtpg=$amtpg+$amtpg1;
		}
	}
}
$pdf->Output();
?>