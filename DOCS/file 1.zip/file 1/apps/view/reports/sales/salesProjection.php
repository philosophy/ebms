﻿<?php

require('../checkSession.php');
include('../../../../plugin/fpdf/fpdf.php');

//Connect to your database
include("../../../../config/config.php");

//Select the Products you want to show in your PDF file
$company_info=mysql_query("select company_name,company_address,company_phone_no,company_mobile_no,company_fax_no,company_email_address,company_website,company_logo from company_information");

//Initialize the 3 columns and the total

include('../headerContent.php');

//Create a new PDF file
$pdf=new FPDF();

$pdf->AddPage('L');


include('../reportHeaderL.php');

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(232,232,232);
$pdf->SetXY(20,45);
$pdf->Cell(139,10,'Sales Projection',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->SetXY(238,45);
$pdf->Cell(40,10,'Date Printed:'.' '.date("y/m/d"),0,0,'L');
$pdf->Ln(15);

//	$pdf->Cell(175,6,'Projected Customer for Today',1,0,'L',1);

$projectedBasis = 15;
$projCust=mysql_query("SELECT cust.customer_id, cust.customer_code, 
                       cust.customer_name,ar.area_name,cust.customer_phone_no,
					   cust.customer_mobile_no,count(os.os_hdr_id) as 'numTrans'
					   FROM os_header os, customer_profile cust, area ar
					   WHERE os.customer_id = cust.customer_id
							and os.area_id = ar.area_id
							and os.os_hdr_date
							BETWEEN CURDATE( ) -".$projectedBasis."
							AND DATE_FORMAT( CURDATE( ) ,  '%y-%m-%d' )
							AND cust.customer_type_id !=1
							group by os.customer_id");
$ind = mysql_num_rows($projCust);
if($ind==0)
{
  $pdf->SetFont('Arial','',13);
  $pdf->SetX(20);
  $pdf->SetFillColor(0,0,255);
  $pdf->SetTextColor(255,255,255);
  $pdf->Cell(255,6,'No Active Customer, No Projected Sales . . .',1,0,'C',1);
}
else
{
	$pdf->SetDrawColor(139,134,130);
	$pdf->SetFillColor(193,205,193);
	$pdf->SetFont('Arial','B',12);
	$pdf->SetX(20);
	$pdf->Cell(35,6,'Customer Code',1,0,'C',1);
	$pdf->Cell(60,6,'Customer Name',1,0,'C',1);
	$pdf->Cell(30,6,'Area',1,0,'C',1);
	$pdf->Cell(45,6,'Contact No.',1,0,'C',1);
	$pdf->Cell(35,6,'Last Trans.',1,0,'C',1);
	$pdf->Cell(50,6,'Projected Sales',1,0,'C',1);
	$pdf->Ln();

	while($row = mysql_fetch_array($projCust))
	{
	$pdf->SetX(20);
	$pdf->SetFillColor(240,247,245);
	$pdf->SetFont('Arial','',10);
	$pdf->Cell(35,6,$row["customer_code"],1,0,'C',0);
	$pdf->Cell(60,6,$row["customer_name"],1,0,'C',0);
	$pdf->Cell(30,6,$row["area_name"],1,0,'C',0);
	$pdf->Cell(45,6,$row["customer_mobile_no"].'/'.$row["customer_phone_no"],1,0,'C',0);
	$compute = round($projectedBasis/$row["numTrans"],0);

	$lastTrans=mysql_query("SELECT os.os_hdr_date,os.os_hdr_gross_amount 
							FROM os_header os, customer_profile cust
							WHERE os.customer_id = cust.customer_id
							and os.os_hdr_date
							BETWEEN CURDATE( ) -15
							AND DATE_FORMAT( CURDATE( ) ,  '%y-%m-%d' )
							AND cust.customer_type_id !=1
							AND cust.customer_id=".$row["customer_id"]."
							order by os.os_hdr_date desc
							LIMIT 1");
	$trans = mysql_fetch_array($lastTrans);
							
	$pdf->Cell(35,6,date('F j, Y',strtotime($trans["os_hdr_date"])),1,0,'C',0);
	$projDate=date('F j, Y',strtotime($trans["os_hdr_date"]."+".$compute." days"));
	$pdf->Cell(50,6,$projDate." - ".number_format($trans["os_hdr_gross_amount"],2),1,0,'R',1);
	$pdf->Ln();
	}
}

$pdf->Output();
?>