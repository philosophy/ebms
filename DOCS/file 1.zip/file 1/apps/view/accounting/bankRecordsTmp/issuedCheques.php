<?php
include("../../../../config/config.php");

$outputData = "";
$bankId = $_POST['bankId'];

$query = mysql_query("select c.check_no, c.check_account_no, c.check_account_name, c.check_amount, b.bank_name, b.bank_address,
						c.check_date_issued, c.check_due_date, c.check_type from check_profile c inner join bank b on
						b.bank_id = c.bank_id where c.bank_id =".$bankId);
						
if(mysql_num_rows($query) > 0)
{
	$outputData .= "<table>
					<th>Cheque Number</th>
					<th>Account Number</th>
					<th>Account Name</th>
					<th>Cheque Amount</th>
					<th>Bank Name</th>
					<th>Bank Address</th>
					<th>Cheque Date Issued</th>
					<th>Cheque Due Date</th>
					<th>Cheque Type</th>";
					
	while($arrCheque = mysql_fetch_array($query))
	{
		$outputData .= "<tr>";
		$outputData .= "<td>".$arrCheque['check_no']."</td>";
		$outputData .= "<td>".$arrCheque['check_account_no']."</td>";
		$outputData .= "<td>".$arrCheque['check_account_name']."</td>";
		$outputData .= "<td>".$arrCheque['check_amount']."</td>";
		$outputData .= "<td>".$arrCheque['bank_name']."</td>";
		$outputData .= "<td>".$arrCheque['bank_address']."</td>";
		$outputData .= "<td>".$arrCheque['check_date_issued']."</td>";
		$outputData .= "<td>".$arrCheque['check_due_date']."</td>";
		$outputData .= "<td>".$arrCheque['check_type']."</td>";
		$outputData .= "</tr>";
	}
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
?>