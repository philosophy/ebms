<?php
include("../../../../config/config.php");

$outputData = "";
$bankId = $_POST['bankId'];

$query = mysql_query("select bw.bank_with_id, bw.bank_with_no, bw.bank_with_amount, bw.bank_with_date, bw.bank_with_remarks, 
						ba.bank_account_no, concat(e.emp_first_name, ' ', left(e.emp_middle_name, 1), '. ', e.emp_last_name) as
						'emp_name' from bank_withdrawal bw inner join bank_account ba on ba.bank_account_id = bw.bank_account_id
						inner join employee_profile e on e.emp_id = bw.bank_with_withdrawn_by_id where bw.bank_id=".$bankId);
						
if(mysql_num_rows($query) > 0)
{
	$outputData .= "<table>
					<th>Withdrawal Number</th>
					<th>Withdrawal Date</th>
					<th>Account Number</th>
					<th>Amount</th>
					<th>Withdrawn By</th>
					<th>Remarks</th>";
					
	while($arrWith = mysql_fetch_array($query))
	{
		$outputData .= "<tr>";
		$outputData .= "<td>".$arrWith['bank_with_no']."</td>";
		$outputData .= "<td>".$arrWith['bank_with_date']."</td>";
		$outputData .= "<td>".$arrWith['bank_account_no']."</td>";
		$outputData .= "<td>".$arrWith['bank_with_amount']."</td>";
		$outputData .= "<td>".$arrWith['emp_name']."</td>";
		$outputData .= "<td>".$arrWith['bank_with_remarks']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;

?>