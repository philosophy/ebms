<?php
include("../../../../config/config.php");

$outputData = "";

$query = mysql_query("select bank_id, bank_name, bank_address, bank_phone_no, bank_fax_no, bank_website, bank_email_address,
						bank_contact_person, bank_contact_position, bank_contact_department, bank_contact_phone_no,
						bank_contact_mobile_no, bank_contact_email_address, is_deleted from bank");
						
if(mysql_num_rows($query) > 0)
{
	$outputData .= "<table>
					<th>Bank Name</th>
					<th>Bank Address</th>
					<th>Bank Phone Number</th>
					<th>Bank Fax Number</th>
					<th>Bank Website</th>
					<th>Email Address</th>
					<th>Contact Person</th>
					<th>Contact Position</th>
					<th>Contact Department</th>
					<th>Contact Phone Number</th>
					<th>Contact Mobile Number</th>
					<th>Contact Email Address</th>";
					
	while($arrBank = mysql_fetch_array($query))
	{
		$outputData .= "<tr a=".$arrBank['bank_id'].">";
		$outputData .= "<td>".$arrBank['bank_name']."</td>";
		$outputData .= "<td>".$arrBank['bank_address']."</td>";
		$outputData .= "<td>".$arrBank['bank_phone_no']."</td>";
		$outputData .= "<td>".$arrBank['bank_fax_no']."</td>";
		$outputData .= "<td>".$arrBank['bank_website']."</td>";
		$outputData .= "<td>".$arrBank['bank_email_address']."</td>";
		$outputData .= "<td>".$arrBank['bank_contact_person']."</td>";
		$outputData .= "<td>".$arrBank['bank_contact_position']."</td>";
		$outputData .= "<td>".$arrBank['bank_contact_department']."</td>";
		$outputData .= "<td>".$arrBank['bank_contact_phone_no']."</td>";
		$outputData .= "<td>".$arrBank['bank_contact_mobile_no']."</td>";
		$outputData .= "<td>".$arrBank['bank_contact_email_address']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
	
?>