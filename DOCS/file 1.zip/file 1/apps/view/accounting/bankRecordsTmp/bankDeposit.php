<?php
include("../../../../config/config.php");

$outputData = "";
$bankId = $_POST['bankId'];

$query = mysql_query("select bd.bank_deposit_id, bd.bank_deposit_no, bd.bank_deposit_date, ba.bank_account_no, bd.bank_deposit_amount, CONCAT(e.emp_first_name,' ', left(e.emp_middle_name, 1), '. ', e.emp_last_name) as 'emp_name' from bank_deposit_header bd inner join bank_account ba on ba.bank_account_id = bd.bank_account_id inner join employee_profile e on e.emp_id = bd.bank_deposit_by_id where bd.bank_id=".$bankId) or die(mysql_error());
						
if(mysql_num_rows($query) > 0)
{
	$outputData .= "<table>
					<th>Deposit Number</th>
					<th>Deposit Date</th>
					<th>Account Number</th>
					<th>Amount</th>
					<th>Deposited By</th>";
					
	while($arrDep = mysql_fetch_array($query))
	{
		$outputData .= "<tr a=".$arrDep['bank_deposit_id'].">";
		$outputData .= "<td>".$arrDep['bank_deposit_no']."</td>";
		$outputData .= "<td>".$arrDep['bank_deposit_date']."</td>";
		$outputData .= "<td>".$arrDep['bank_account_no']."</td>";
		$outputData .= "<td>".number_format($arrDep['bank_deposit_amount'], 2)."</td>";
		$outputData .= "<td>".$arrDep['emp_name']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
?>