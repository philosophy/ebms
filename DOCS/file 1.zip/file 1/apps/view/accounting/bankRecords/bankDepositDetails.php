<?php
include("../../../../config/config.php");

$outputData = "";
$depositId = $_POST['depositId'];

$query = mysql_query("select bank_deposit_dtl_ref_type, bank_deposit_dtl_ref_no, bank_deposit_dtl_amount from 
						bank_deposit_detail where bank_deposit_hdr_id=".$depositId) or die(mysql_error());
						
if(mysql_num_rows($query) > 0)
{
	$outputData .= "<table>
					<th>Reference Type</th>
					<th>Reference Number</th>
					<th>Amount</th>";
					
	while($arrDepDetail = mysql_fetch_array($query))
	{
		$outputData .= "<tr>";
		$outputData .= "<td>".$arrDepDetail['bank_deposit_dtl_ref_type']."</td>";
		$outputData .= "<td>".$arrDepDetail['bank_deposit_dtl_ref_no']."</td>";
		$outputData .= "<td style='text-align:right'>".number_format($arrDepDetail['bank_deposit_dtl_amount'], 2)."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;

?>