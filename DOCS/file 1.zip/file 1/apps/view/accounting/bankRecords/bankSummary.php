<?php
include("../../../../config/config.php");

$bankId = $_POST['bankId'];
$bankName = $_POST['bankName'];
$outputData = "";
$type = "";
$depositAmount = 0.00;
$withdrawalAmount = 0.00;

//bank deposit per account
$deposit = mysql_query("select bdd.bank_deposit_dtl_ref_no, bdh.bank_deposit_date, 
						bdd.bank_deposit_dtl_amount, bdd.bank_deposit_dtl_ref_type from bank_deposit_header bdh inner 
						join bank_deposit_detail bdd on bdd.bank_deposit_hdr_id = bdh.bank_deposit_id 
						where bdh.bank_id = ".$bankId) or die(mysql_error());
		
//bank withdrawal per account
$withdrawal = mysql_query("select bank_with_amount, bank_with_date, bank_with_ref_type, bank_with_ref_no
							from bank_withdrawal where bank_id =".$bankId) or die(mysql_error());

if((mysql_num_rows($deposit) > 0) || (mysql_num_rows($withdrawal) > 0))
{
	$outputData .= "<table>
					<th>Bank Name</th>
					<th>Date</th>
					<th>Deposit</th>
					<th>Withdrawal</th> 
					<th>Description</th>";
					
	$outputData .= "<tr>";
	$outputData .= "<td style='border:none; font-weight:bold; padding:0' colspan=5>
						Bank Name: ".$bankName."</td>";
	$outputData .= "</tr>";
	
	while($arrDep = mysql_fetch_array($deposit))
	{
		$outputData .= "<tr>";
		$outputData .= "<td style='border:none; padding:0'></td>";
		$outputData .= "<td style='border:none; padding:0'>".$arrDep['bank_deposit_date']."</td>";
		$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>
							".number_format($arrDep['bank_deposit_dtl_amount'], 2)."</td>";
		$depositAmount += $arrDep['bank_deposit_dtl_amount'];
		$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>-</td>";
		if($arrDep['bank_deposit_dtl_ref_type'] == "Cheque")
		{
			$type = "Posted Cheque";
		}
		else
		{
			$type = $arrDep['bank_deposit_dtl_ref_type'];
		}
		$outputData .= "<td style='border:none; padding:0'>".$type.": ".$arrDep['bank_deposit_dtl_ref_no']."</td>";
		$outputData .= "</tr>";
	}
	
	while($arrWith = mysql_fetch_array($withdrawal))
	{
		$outputData .= "<tr>";
		$outputData .= "<td style='border:none; padding:0'></td>";
		$outputData .= "<td style='border:none; padding:0'>".$arrWith['bank_with_date']."</td>";
		$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>-</td>";
		$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>
							".number_format($arrWith['bank_with_amount'], 2)."</td>";
		$withdrawalAmount += $arrWith['bank_with_amount'];
		if($arrWith['bank_with_ref_type'] == "Cheque")
		{
			$type = "Cleared Cheque";
		}
		else
		{
			$type = $arrWith['bank_with_ref_type'];
		}
		$outputData .= "<td style='border:none; padding:0'>".$type.": ".$arrWith['bank_with_ref_no']."</td>";
		$outputData .= "</tr>";
	}
	
	//deposit total
	$outputData .= "<tr>";
	$outputData .= "<td style='border:none; padding:0; font-weight:bold' colspan=2>Total:</td>";
	$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px; font-weight:bold'>".number_format($depositAmount, 2)."</td>";
	$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px; font-weight:bold'>".number_format($withdrawalAmount, 2)."</td>";
	$outputData .= "<td style='border:none; padding:0'></td>";
	$outputData .= "</tr>";
	$outputData .= "<tr><td style='border:none; padding:0' colspan=5></td></tr>";
	
	$outputData .= "<tr>";
	$outputData .= "<td colspan=5 style='font-weight:bold; border:none;'>Cash on Bank: ".number_format(($depositAmount - $withdrawalAmount), 2)."</td>";
	$outputData .= "</tr>";
	$outputData .= "</table>";
		
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
?>