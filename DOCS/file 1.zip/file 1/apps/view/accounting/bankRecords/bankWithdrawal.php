<?php
include("../../../../config/config.php");

if(@$_POST['role']=="")
{
	$outputData = "";
	$bankId = @$_POST['bankId'];

	$query = mysql_query("select bw.bank_with_id, bw.bank_with_no, bw.bank_with_amount, bw.bank_with_date, bw.bank_with_remarks, 
							ba.bank_account_no, concat(e.emp_first_name, ' ', left(e.emp_middle_name, 1), '. ', e.emp_last_name) as
							'emp_name' from bank_withdrawal bw inner join bank_account ba on ba.bank_account_id = bw.bank_account_id
							inner join employee_profile e on e.emp_id = bw.bank_with_withdrawn_by_id where bw.bank_id= '$bankId'");
							
	if(mysql_num_rows($query) > 0)
	{
		$outputData .= "<table>
						<th></th>
						<th>Withdrawal Number</th>
						<th>Withdrawal Date</th>
						<th>Account Number</th>
						<th>Amount</th>
						<th>Withdrawn By</th>
						<th>Remarks</th>";
						
		while($arrWith = mysql_fetch_array($query))
		{
			$outputData .= "<tr>";
			$outputData .= "<td><img src='/EBMS/images/icons/withdraw.png'></td>";
			$outputData .= "<td>".$arrWith['bank_with_no']."</td>";
			$outputData .= "<td>".date("D M d, Y",strtotime($arrWith['bank_with_date']))."</td>";
			$outputData .= "<td>".$arrWith['bank_account_no']."</td>";
			$outputData .= "<td>".number_format($arrWith['bank_with_amount'], 2)."</td>";
			$outputData .= "<td>".$arrWith['emp_name']."</td>";
			$outputData .= "<td>".$arrWith['bank_with_remarks']."</td>";
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
	}
	else
	{
		$outputData = "No results found.";
	}

	echo $outputData;
}

elseif(@$_POST['role'] == "new")
{
	$bankID = $_POST['bankID'];
	$withDate = $_POST['withDate'];
	$withAcctID = $_POST['withAcctID'];
	$withAmount = $_POST['withAmount'];
	$withBy = $_POST['withBy'];
	$withRemarks = $_POST['withRemarks'];

	mysql_query("INSERT INTO bank_withdrawal(bank_with_no,bank_with_amount,bank_with_date,bank_with_remarks,bank_id,bank_account_id,bank_with_withdrawn_by_id,bank_with_ref_type,bank_with_ref_no) VALUES('','$withAmount','$withDate','$withRemarks','$bankID','$withAcctID','$withBy','','')");
	
	$id = mysql_insert_id();
	$withNo = "BANK-WITH-".date("Y")."-".str_pad($id, 6, "0", STR_PAD_LEFT); 
	
	mysql_query("UPDATE bank_withdrawal SET bank_with_no = '$withNo' WHERE bank_with_id = '$id'");
}

?>