<?php
include("../../../../config/config.php");

if(@$_POST['role'] == "")
{
	$outputData = "";
	$strSeparator = "&";

	$page = @$_POST['page'];
	$searchQuery = addslashes(@$_POST['searchQuery']);

	if($searchQuery!="")
		{
		$condition = " WHERE bank_name LIKE '%".$searchQuery."%' or bank_address LIKE '%".$searchQuery."%'";
		}

	elseif ($searchQuery == "")
		$condition = "";


	$cur_page = $page;
	$page -= 1;
	$per_page = 9;
	/*
	$previous_btn = true;
	$next_btn = true;
	$first_btn = true;
	$last_btn = true;
	*/
	$start = $page * $per_page;


		$outputData .= "<table>
						<th class=icon></th>
						<th>Bank Name</th>
						<th>Bank Address</th>
						<th>Bank Phone Number</th>
						<th>Bank Fax Number</th>
						<th>Bank Website</th>
						<th>Email Address</th>
						<th>Contact Person</th>
						<th>Contact Position</th>
						<th>Contact Department</th>
						<th>Contact Phone Number</th>
						<th>Contact Mobile Number</th>
						<th>Contact Email Address</th>";

	$query = "select bank_id, bank_name, bank_address, bank_phone_no, bank_fax_no, bank_website, bank_email_address,
							bank_contact_person, bank_contact_position, bank_contact_department, bank_contact_phone_no,
							bank_contact_mobile_no, bank_contact_email_address, is_deleted 
					from bank
					".$condition."
					order by is_deleted , bank_id desc";
							
			$count = mysql_num_rows(mysql_query($query));
			$no_of_paginations = ceil($count / $per_page);
		
			$arrResult = mysql_query($query." limit $start,$per_page");
							
	if(mysql_num_rows($arrResult) > 0)
	{
						
		while($arrBank = mysql_fetch_array($arrResult))
		{
			$x = (($arrBank['is_deleted']==1)?"deleted=true":"deleted=false");
						
						if($arrBank['is_deleted'] == 0)
						{
							$icon = "<img src='/ebms/images/icons/generalLedger.png'>";
						}
						
						else
						{
							$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
						}
		
			$outputData .= "<tr b='".$arrBank['bank_name']."' a=".$arrBank['bank_id']." ".$x." >";
			$outputData .= "<td class=icon>".$icon."</td>";
			$outputData .= "<td>".$arrBank['bank_name']."</td>";
			$outputData .= "<td>".$arrBank['bank_address']."</td>";
			$outputData .= "<td>".$arrBank['bank_phone_no']."</td>";
			$outputData .= "<td>".$arrBank['bank_fax_no']."</td>";
			$outputData .= "<td>".$arrBank['bank_website']."</td>";
			$outputData .= "<td>".$arrBank['bank_email_address']."</td>";
			$outputData .= "<td>".$arrBank['bank_contact_person']."</td>";
			$outputData .= "<td>".$arrBank['bank_contact_position']."</td>";
			$outputData .= "<td>".$arrBank['bank_contact_department']."</td>";
			$outputData .= "<td>".$arrBank['bank_contact_phone_no']."</td>";
			$outputData .= "<td>".$arrBank['bank_contact_mobile_no']."</td>";
			$outputData .= "<td>".$arrBank['bank_contact_email_address']."</td>";
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
	}
	else 
		{
		include("../../noResults.php");
		$cur_page = 0;
		}
		
	echo $outputData.
		$strSeparator.
			"Page $cur_page of $no_of_paginations".
		$strSeparator.
			@$cur_page.
		$strSeparator.
			@$no_of_paginations; 
			
	mysql_free_result($arrResult);
}

elseif(@$_POST['role'] == "new")
{
$bankName = $_POST['bankName'];
$bankAddress = $_POST['bankAddress'];

$website = $_POST['website'];
$email = $_POST['email'];
$phoneNo = $_POST['phoneNo'];
$faxNo = $_POST['faxNo'];

$contactPerson = $_POST['contactPerson'];
$position = $_POST['position'];
$department = $_POST['department'];

$contactEmail = $_POST['contactEmail'];
$contactPhoneNo = $_POST['contactPhoneNo'];
$contactMobileNo = $_POST['contactMobileNo'];

$acctDetails = json_decode($_POST['acctDetails']);

$result = mysql_query("INSERT INTO bank (bank_name,bank_address,bank_website,bank_email_address,bank_phone_no,bank_fax_no,bank_contact_person,bank_contact_position,bank_contact_department,bank_contact_email_address,bank_contact_phone_no,bank_contact_mobile_no,is_deleted) VALUES
('$bankName','$bankAddress','$website','$email','$phoneNo','$faxNo','$contactPerson','$position','$department','$contactEmail','$contactPhoneNo','$contactMobileNo',0)");

$id = mysql_insert_id();

$acctName = "";
$acctNo = "";
$acctType = "";

for($i=0;$i<sizeof($acctDetails);$i++)
{
		$acctName = addslashes($acctDetails[$i][0]);
		$acctNo = $acctDetails[$i][1];
		$acctType = addslashes($acctDetails[$i][2]);
		
		mysql_query("INSERT INTO bank_account(bank_account_no,bank_account_name,bank_account_type,bank_id) VALUES('$acctNo','$acctName','$acctType','$id')");

}
}

elseif(@$_POST['role'] == "edit")
{
$bankID = @$_POST['bankID'];
$bankName = $_POST['bankName'];
$bankAddress = $_POST['bankAddress'];

$website = $_POST['website'];
$email = $_POST['email'];
$phoneNo = $_POST['phoneNo'];
$faxNo = $_POST['faxNo'];

$contactPerson = $_POST['contactPerson'];
$position = $_POST['position'];
$department = $_POST['department'];

$contactEmail = $_POST['contactEmail'];
$contactPhoneNo = $_POST['contactPhoneNo'];
$contactMobileNo = $_POST['contactMobileNo'];
	
	mysql_query("UPDATE bank SET BANK_NAME='$bankName',BANK_ADDRESS='$bankAddress',BANK_PHONE_NO='$phoneNo',BANK_FAX_NO='$faxNo',BANK_WEBSITE='$website',BANK_EMAIL_ADDRESS='$email',BANK_CONTACT_PERSON='$contactPerson',BANK_CONTACT_POSITION='$position',BANK_CONTACT_DEPARTMENT='$department',BANK_CONTACT_PHONE_NO='$contactPhoneNo',BANK_CONTACT_MOBILE_NO='$contactMobileNo',BANK_CONTACT_EMAIL_ADDRESS='$contactEmail'
	WHERE bank_id = '$bankID'");

}

elseif(@$_POST['role'] == "fetchData")
{
$arr[] = "";
$arr2[] = "";
$bankID = @$_POST['bankID'];

	$query = mysql_query("
		SELECT bank_name , bank_address , bank_phone_no ,
				bank_fax_no , bank_website , bank_email_address , 
				bank_contact_person , bank_contact_position , bank_contact_department , 
				bank_contact_phone_no , bank_contact_mobile_no , 
				bank_contact_email_address 
		FROM bank 
		WHERE bank_id = '$bankID'");
		
		if(mysql_num_rows($query))
		{
			while($row = mysql_fetch_array($query))
			{
				$arr['bank_name'] = $row['bank_name'];
				$arr['bank_address'] = $row['bank_address'];
				$arr['bank_phone_no'] = $row['bank_phone_no'];
				$arr['bank_fax_no'] = $row['bank_fax_no'];
				$arr['bank_website'] = $row['bank_website'];
				$arr['bank_email_address'] = $row['bank_email_address'];
				$arr['bank_contact_person'] = $row['bank_contact_person'];
				$arr['bank_contact_position'] = $row['bank_contact_position'];
				$arr['bank_contact_department'] = $row['bank_contact_department'];
				$arr['bank_contact_phone_no'] = $row['bank_contact_phone_no'];
				$arr['bank_contact_mobile_no'] = $row['bank_contact_mobile_no'];
				$arr['bank_contact_email_address'] = $row['bank_contact_email_address'];
			}
			
			$data = json_encode(array("data"=>$arr));
			
			echo $data;
		}
}

elseif(@$_POST['role'] == "createAcctInfo")
{


$acctName = @$_POST['acctName'];
$acctNo = @$_POST['acctNo'];
$acctType = @$_POST['acctType'];
$bankID = @$_POST['bankID'];
		
		mysql_query("INSERT INTO bank_account(bank_account_no,bank_account_name,bank_account_type,bank_id) VALUES('$acctNo','$acctName','$acctType','$bankID')");

}

elseif(@$_POST['role'] == "editAcctInfo")
{


$acctName = @$_POST['acctName'];
$acctNo = @$_POST['acctNo'];
$acctType = @$_POST['acctType'];
$bankID = @$_POST['bankID'];
$acctID = @$_POST['acctID'];
		
		mysql_query("UPDATE bank_account SET bank_account_no = '$acctNo',bank_account_name = '$acctName', bank_account_type = '$acctType' WHERE bank_account_id = '$acctID' and bank_id = '$bankID'");

}

elseif(@$_POST['role'] == "fetchAcctInfo")
{
$bankID = @$_POST['bankID'];

$query = mysql_query("
		SELECT bank_account_no,bank_account_id,bank_account_type,bank_account_name 
		FROM bank_account 
		WHERE bank_id = '$bankID'");
		
		if(mysql_num_rows($query))
		{
			$outputData = "<table>
							<th>Bank Account Name</th>
							<th>Bank Account No</th>
							<th>Bank Account Type</th>
						";
			while($row = mysql_fetch_array($query))
			{
				$outputData .= "<tr bankAcctID='".$row['bank_account_id']."' bankAcctNo='".$row['bank_account_no']."' bankAcctType='".$row['bank_account_type']."' bankAcctName = '".$row['bank_account_name']."'>";
				$outputData .= "<td class='bankAcctName'>".$row['bank_account_name']."</td>";
				$outputData .= "<td class='bankAcctNo'>".$row['bank_account_no']."</td>";
				$outputData .= "<td class='bankAcctType'>".$row['bank_account_type']."</td></tr>";
			}
			$outputData .= "</table>";
			
			echo $outputData;
		}
}

elseif(@$_POST['role'] == "delete")
{
$bankID = $_POST['bankID'];
	
	mysql_query("UPDATE bank SET is_deleted = 1 WHERE bank_id = '$bankID'");
}

elseif(@$_POST['role'] == "restore")
{

$bankID = $_POST['bankID'];
	
	mysql_query("UPDATE bank SET is_deleted = 0 WHERE bank_id = '$bankID'");
}

