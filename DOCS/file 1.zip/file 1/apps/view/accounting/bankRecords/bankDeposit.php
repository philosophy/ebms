<?php
include("../../../../config/config.php");

if(@$_POST['role']=="")
{
$outputData = "";
$bankId = @$_POST['bankId'];

$query = mysql_query("select bd.bank_deposit_id, bd.bank_deposit_no, bd.bank_deposit_date, ba.bank_account_no, bd.bank_deposit_amount, CONCAT(e.emp_first_name,' ', left(e.emp_middle_name, 1), '. ', e.emp_last_name) as 'emp_name' from bank_deposit_header bd inner join bank_account ba on ba.bank_account_id = bd.bank_account_id inner join employee_profile e on e.emp_id = bd.bank_deposit_by_id where bd.bank_id= '$bankId'");
						
if(mysql_num_rows($query) > 0)
{
	$outputData .= "<table>
					<th></th>
					<th>Deposit Number</th>
					<th>Deposit Date</th>
					<th>Account Number</th>
					<th>Amount</th>
					<th>Deposited By</th>";
					
	while($arrDep = mysql_fetch_array($query))
	{
		$outputData .= "<tr a=".$arrDep['bank_deposit_id'].">";
		$outputData .= "<td><img src='/EBMS/images/icons/deposit.png'></td>";
		$outputData .= "<td>".$arrDep['bank_deposit_no']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrDep['bank_deposit_date']))."</td>";
		$outputData .= "<td>".$arrDep['bank_account_no']."</td>";
		$outputData .= "<td style='text-align:right'>".number_format($arrDep['bank_deposit_amount'], 2)."</td>";
		$outputData .= "<td>".$arrDep['emp_name']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
}

elseif(@$_POST['role'] == "new")
{
	$depAmount = @$_POST['depAmount'];
	$refType = @$_POST['refType'];
	$remarks = @$_POST['remarks'];
	$acctID = @$_POST['acctID'];
	$depBy = @$_POST['depBy'];
	$bankID = @$_POST['bankID'];
	$depDate = @$_POST['depDate'];

	mysql_query("INSERT INTO bank_deposit_header(BANK_DEPOSIT_NO, BANK_DEPOSIT_AMOUNT, REF_HDR_TYPE, BANK_DEPOSIT_HDR_REMARKS, BANK_ACCOUNT_ID, BANK_DEPOSIT_BY_ID, BANK_ID, BANK_DEPOSIT_DATE) VALUES ('','$depAmount','$refType','$remarks','$acctID','$depBy','$bankID','$depDate')");
	
	$id = mysql_insert_id();
	$depNo = "DEP-".date("Y")."-".str_pad($id, 6, "0", STR_PAD_LEFT); 
	
	mysql_query("UPDATE bank_deposit_header SET bank_deposit_no = '$depNo' WHERE bank_deposit_id = '$id'");
	
	mysql_query("INSERT INTO bank_deposit_detail(BANK_DEPOSIT_DTL_REF_NO, BANK_DEPOSIT_DTL_REF_TYPE, BANK_DEPOSIT_DTL_AMOUNT, BANK_DEPOSIT_HDR_ID) VALUES ('$depNo','$refType','$depAmount','$id')");
}
?>