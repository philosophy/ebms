<?php
include("../../../../config/config.php");

$bankId = $_POST['bankId'];
$outputData = "";
$type = "";
$depositAmount = 0.00;
$withdrawalAmount = 0.00;
$totalDepAmount = 0.00;
$totalWithAmount = 0.00;

//BANK ACCOUNT, BANK DEPOSIT, BANK WITHDRAWAL

//bank accounts
$accounts = mysql_query("select bank_account_id, bank_account_no from bank_account where bank_id =".$bankId);
						
//$query2 = mysql_query("select 
						
if(mysql_num_rows($accounts) > 0)
{
	$outputData .= "<table>
					<th>Account Number</th>
					<th>Date</th>
					<th>Deposit</th>
					<th>Withdrawal</th> 
					<th>Description</th>";
					
	while($arrAccounts = mysql_fetch_array($accounts))
	{	
		//bank deposit per account
		$deposit = mysql_query("select bdd.bank_deposit_dtl_ref_no, bdh.bank_deposit_date, 
						bdd.bank_deposit_dtl_amount, bdd.bank_deposit_dtl_ref_type from bank_account ba inner 
						join bank_deposit_header bdh on ba.bank_account_id = bdh.bank_account_id inner 
						join bank_deposit_detail bdd on bdd.bank_deposit_hdr_id = bdh.bank_deposit_id 
						where ba.bank_id = ".$bankId." and ba.bank_account_id =".$arrAccounts['bank_account_id']);
		
		//bank withdrawal per account
		$withdrawal = mysql_query("select bank_with_amount, bank_with_date, bank_with_ref_type, bank_with_ref_no
									from bank_withdrawal where bank_id =".$bankId." and 
									bank_account_id =".$arrAccounts['bank_account_id']);
									
		$outputData .= "<tr>";
		$outputData .= "<td style='border:none; font-weight:bold; padding:0' colspan=5>
							Account Number: ".$arrAccounts['bank_account_no']."</td>";
		$outputData .= "</tr>";
		
		if((mysql_num_rows($deposit) > 0) || (mysql_num_rows($withdrawal) > 0))
		{
			while($arrDep = mysql_fetch_array($deposit))
			{
				$outputData .= "<tr>";
				$outputData .= "<td style='border:none; padding:0'></td>";
				$outputData .= "<td style='border:none; padding:0'>".$arrDep['bank_deposit_date']."</td>";
				$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>
									".number_format($arrDep['bank_deposit_dtl_amount'], 2)."</td>";
				$depositAmount += $arrDep['bank_deposit_dtl_amount'];
				$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>-</td>";
				if($arrDep['bank_deposit_dtl_ref_type'] == "Cheque")
				{
					$type = "Posted Cheque";
				}
				else
				{
					$type = $arrDep['bank_deposit_dtl_ref_type'];
				}
				$outputData .= "<td style='border:none; padding:0'>".$type.": ".$arrDep['bank_deposit_dtl_ref_no']."</td>";
				$outputData .= "</tr>";
			}
			
			while($arrWith = mysql_fetch_array($withdrawal))
			{
				$outputData .= "<tr>";
				$outputData .= "<td style='border:none; padding:0'></td>";
				$outputData .= "<td style='border:none; padding:0'>".$arrWith['bank_with_date']."</td>";
				$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>-</td>";
				$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px'>
									".number_format($arrWith['bank_with_amount'], 2)."</td>";
				$withdrawalAmount += $arrWith['bank_with_amount'];
				if($arrWith['bank_with_ref_type'] == "Cheque")
				{
					$type = "Cleared Cheque";
				}
				else
				{
					$type = $arrWith['bank_with_ref_type'];
				}
				$outputData .= "<td style='border:none; padding:0'>".$type.": ".$arrWith['bank_with_ref_no']."</td>";
				$outputData .= "</tr>";
			}
		}
		else
		{
			$outputData .= "<tr><td style='border:none; padding:0' colspan=5>No results found.</tr></td>";
		}
		
		//deposit total
		$outputData .= "<tr>";
		$outputData .= "<td style='border:none; padding:0; font-weight:bold' colspan=2>Total:</td>";
		$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px; font-weight:bold'>".number_format($depositAmount, 2)."</td>";
		$outputData .= "<td style='border:none; padding:0; text-align:right; padding-right:10px; font-weight:bold'>".number_format($withdrawalAmount, 2)."</td>";
		$outputData .= "<td style='border:none; padding:0'></td>";
		$outputData .= "</tr>";
		$outputData .= "<tr><td style='border:none; padding:0' colspan=5></td></tr>";
		
		$totalDepAmount += $depositAmount;
		$totalWithAmount += $withdrawalAmount;
		$depositAmount = 0.00;
		$withdrawalAmount = 0.00;
	}
	
	$outputData .= "<tr>";
	$outputData .= "<td colspan=5 style='font-weight:bold; border:none;'>Cash on Bank: ".number_format(($totalDepAmount - $totalWithAmount), 2)."</td>";
	$outputData .= "</tr>";
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
?>