﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Bank Records</title>
<?php include("../../standard-js-css.php");  ?> 
<script>
	$(function(){
		headTitle("Bank Records");	
		datagridMenu("bank","new;edit;delete;restore");		
		datagrid("bank-records;bankDeposit;bankWithdrawal;cashOnBank;summary;issuedCheques",true);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	$("#pdf").click(function(){
		window.open("../../../view/reports/accounting/bankRecords.php","_new");
		});
});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<?php include("../../modalForms/accounting/bankRecords/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="bank-records" class="datagrid-container">
	<script>
	$("#bank-records").load("../../../controller/accounting/bankRecordsController.php");
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#bankDeposit">Bank Deposit</a></li>
		<li><a href="#bankWithdrawal">Bank Withdrawal</a></li>
		<li><a href="#cashOnBank">Cash on Bank by Account Number</a></li>
		<li><a href="#bankSummary">Summary</a></li>
		<li><a href="#issuedCheques">Issued Cheques</a></li>
	</ul> 
	
		<!-- Bank Deposit -->
		<div id="bankDeposit"> 
			<div id="subgrid-head-first" class="subgrid-head-pair">Deposit List<span class="name"></span>
				<div class = "tabButtonPanel" subgrid>	
					<button id="newBankDeposit" class="callModalForm" ref="new_bankDeposit" onclick="callModal('#new_bankDeposit')" title='New Bank Deposit'>✚</button>
				</div>	
			</div>		
			<div id="subgrid-head-second" class="subgrid-head-pair">Deposited Payments</div>
			
			<!-- Deposit List-->
			<div id="subgrid-first" class="subgrid-pair">
			</div>
			
			<!-- Deposit Details -->
			<div id="subgrid-second" class="subgrid-pair">
			</div>
		</div>
		
		<!-- Bank Withdrawal -->
		<div id="bankWithdrawal"> 
		<div class="tabButtonPanel">
			<button id="newBankWithdrawal" class="callModalForm" ref="new_bankWithdrawal" onclick="callModal('#newBankWithdrawal')" title='New Bank Withdrawal' disabled>✚</button>
		</div>
			<div id="bankWithdrawalGrid">
			</div>

		</div>
		
		<!-- Cash on Bank by Account Number -->
		<div id="cashOnBank" class="scrollable"> 

		</div>
		
		<!-- Bank Summary -->
		<div id="bankSummary" class="scrollable"> 

		</div>
		
		<!-- Issued Cheques -->
		<div id="issuedCheques" class="scrollable"> 

		</div>
	 
</div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

