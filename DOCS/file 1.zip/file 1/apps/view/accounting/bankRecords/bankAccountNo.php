﻿<?php
include("../../../../config/config.php");

$outputData = "";

$bankID = @$_POST['bankID'];
$acctType = @$_POST['acctType'];

$query = mysql_query("SELECT bank_account_id as 'id', bank_account_no as 'no' FROM bank_account WHERE bank_account_type = '$acctType' and bank_id = '$bankID'");

	if(mysql_num_rows($query) > 0)
	{
	
		while($row = mysql_fetch_array($query))
		{
			$outputData .= "<option value='".$row['id']."' >".$row['no']."</option>";
		}
		
	}
	
	else 
	{
		$outputData = "<option value=''>No accounts found</option>";
	}	
	echo $outputData;
	mysql_free_result($query);
	