﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Balance Sheet</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Balance Sheet");
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	
	?>
	
</div>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="balanceSheet" class="datagrid-container">
<script>
		$('#balanceSheet').load('../../../controller/accounting/balanceSheetController.php');
	</script>
	
</div>
</div>

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

