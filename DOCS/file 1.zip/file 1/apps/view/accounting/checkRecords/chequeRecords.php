<?php 
include("../../../../config/config.php");

$outputData = "";

$strSeparator = "&";

include "../../accounting/currency.php";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE cp.check_no LIKE '%".$searchQuery."%' or cp.check_account_no LIKE '%".$searchQuery."%' or cp.check_account_name LIKE '%".$searchQuery."%' or cp.check_amount LIKE '%".$searchQuery."%' or b.bank_name LIKE '%".$searchQuery."%' or b.bank_address LIKE '%".$searchQuery."%' or cp.check_type LIKE '%".$searchQuery."%' or cp.check_date_issued LIKE '%".$searchQuery."%' or cp.check_due_date LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 7;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;
$outputData .= "<table>
				<th></th>
				<th>Cheque Number</th>
				<th>Account Number</th>
				<th>Account Name</th>
				<th>Cheque Amount</th>
				<th>Bank Name</th>
				<th>Bank Address</th>
				<th>Cheque Type</th>
				<th>Date Issued</th>
				<th>Cheque Due Date</th>";
				
$query = "SELECT cp.check_no, cp.check_account_no, cp.check_account_name, cp.check_amount, b.bank_name, b.bank_address, cp.check_type, cp.check_date_issued, cp.check_due_date 
			FROM check_profile cp inner join bank b on cp.bank_id = b.bank_id
			".$condition;
						
				
$count = mysql_num_rows(mysql_query($query));
$no_of_paginations = ceil($count / $per_page);

$arrResult = mysql_query($query." limit $start,$per_page");

							
if(mysql_num_rows($arrResult) > 0)
{

					
	while($arrCheque = mysql_fetch_array($arrResult))
	{
		$outputData .= "<tr>";
		$outputData .= "<td><img src='/EBMS/images/icons/cheque.png'></td>";
		$outputData .= "<td>".$arrCheque['check_no']."</td>";
		$outputData .= "<td>".$arrCheque['check_account_no']."</td>";
		$outputData .= "<td>".$arrCheque['check_account_name']."</td>";
		$outputData .= "<td>".number_format($arrCheque['check_amount'], 2)."</td>";
		$outputData .= "<td>".$arrCheque['bank_name']."</td>";
		$outputData .= "<td>".$arrCheque['bank_address']."</td>";
		$outputData .= "<td>".$arrCheque['check_type']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrCheque['check_date_issued']))."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrCheque['check_due_date']))."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrResult);


?>