﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Cheque Records</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Cheque Records");
		datagrid("chequeList",true);
		
		$("#pdf").click(function(){
		window.open("../../view/reports/crm/crmMasterList.php","_new");
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/home/index.php"); ?>
<div id="body-pane" style="height:200px">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="chequeList" class="datagrid-container">
	<script>
		$("#chequeList").load("../../../controller/accounting/chequesController.php"); 
	</script>
</div>
</div>


</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

