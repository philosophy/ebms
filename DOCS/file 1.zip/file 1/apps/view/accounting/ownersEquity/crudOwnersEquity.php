<?php
include("../../../../config/config.php");
session_start();
$role=$_POST['role'];
$emp = $_SESSION['emp_id'];

if($role=="addCash")
{
	$amount = $_POST['amount'];
	$remarks = $_POST['remarks'];
	
	$id = 0;
	$result = mysql_query("SELECT MAX(OE_HDR_ID),YEAR( CURDATE( ) ) FROM owners_equity");

	while ($row = mysql_fetch_array($result))
	{
		$id = $row[0];
		$year = $row[1]; 
	}
	$ctrlNo = "OE-" . $year ."-" . substr("000000",0,strlen("000000") - strlen($id + 1)) . ($id +1);
	
	$ownersequity = "INSERT INTO `owners_equity`(`OE_HDR_DATE`, `OE_HDR_AMOUNT`, `OE_HDR_REMARKS`, `IS_DEPOSITED`, `IS_FLAG`, `OE_HDR_CTRL_NO`) VALUES (curdate(),'". $amount ."','". $remarks ."',0,0,'". $ctrlNo ."')";
	
	
	mysql_query($ownersequity);
	
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
	gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$ctrlNo."', ".$amount.", 1, 1, 'CAP',
	'".$ctrlNo."', 3, 0)") or die(mysql_error());

	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
	gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$ctrlNo."', ".$amount.", 1, 2, 'CAP',
	'".$ctrlNo."', 1, 0)") or die(mysql_error());
	
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
	gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$ctrlNo."', ".$amount.", 1, 7, 'CAP',
	'".$ctrlNo."', 1, 0)") or die(mysql_error());
}
else if($role =="addBank")
{
	$amount = $_POST['amount'];
	$remarks = $_POST['remarks'];
	$bankAccount = $_POST['bankAccountId'];
	$bankId = $_POST['bankId'];
	
	$id = 0;
	$result = mysql_query("SELECT MAX(OE_HDR_ID),YEAR( CURDATE( ) ) FROM owners_equity");

	while ($row = mysql_fetch_array($result))
	{
		$id = $row[0];
		$year = $row[1]; 
	}
	$ctrlNo = "OE-" . $year ."-" . substr("000000",0,strlen("000000") - strlen($id + 1)) . ($id +1);
	
	$ownersequity = "INSERT INTO `owners_equity`(`OE_HDR_DATE`, `OE_HDR_AMOUNT`, `OE_HDR_REMARKS`, `IS_DEPOSITED`, `IS_FLAG`, `OE_HDR_CTRL_NO`) VALUES (curdate(),'". $amount ."','". $remarks ."',1,0,'". $ctrlNo ."')";
	
	
	mysql_query($ownersequity);
	
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
	gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$ctrlNo."', ".$amount.", 1, 1, 'CAP',
	'".$ctrlNo."', 3, 0)") or die(mysql_error());

	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
	gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$ctrlNo."', ".$amount.", 1, 2, 'CAP',
	'".$ctrlNo."', 1, 0)") or die(mysql_error());
	
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
	gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$ctrlNo."', ".$amount.", 1, 8, 'CAP',
	'".$ctrlNo."', 1, 0)") or die(mysql_error());
	
	$max = 0;
	$currentyear=0;
	$dep = mysql_query("SELECT MAX(BANK_DEPOSIT_ID),YEAR( CURDATE( ) ) FROM bank_deposit_header");

	while ($res = mysql_fetch_array($dep))
	{
		$max = $res[0];
		$currentyear = $res[1]; 
	}
	$depNo = "DEP-" . $currentyear ."-" . substr("000000",0,strlen("000000") - strlen($max + 1)) . ($max +1);
	
	$bankHeader = "Insert into bank_deposit_header(bank_deposit_date,bank_deposit_no, bank_deposit_amount, ref_hdr_type, bank_deposit_hdr_remarks, bank_account_id, bank_deposit_by_id, bank_id) VALUES(curdate(),'" . $depNo . "','". $amount ."','Owners Equity','" . $remarks . "','" . $bankAccount . "','" . $emp . "','" . $bankId . "')";
	
	mysql_query($bankHeader);
	
	
	$depositID = mysql_query("Select bank_deposit_id from bank_deposit_header where bank_deposit_no ='". $depNo . "'");
	while ($row = mysql_fetch_array($depositID))
	{
		$depId = $row[0];
	}
	
	$bankDetail = "Insert into bank_deposit_detail (bank_deposit_dtl_ref_no, bank_deposit_dtl_ref_type, bank_deposit_hdr_id, bank_deposit_dtl_amount) values('". $ctrlNo ."','Owners Equity'," . $depId . ", " . $amount . ")";
	
	mysql_query($bankDetail);
	
	
	echo $bankDetail;
}
		
?>