﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Owner's Equity</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(function(){
		headTitle("Owner's Equity");
		datagridMenu("owners-equity","new");
		datagrid("owners-equity",true);
});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/accounting/ownersEquity/index.php"); ?>

<div id="body-pane" style="height:300px">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="owners-equity" class="datagrid-container">
	<script>
		$("#owners-equity").load('/EBMS/apps/controller/ownersEquity/ownersEquityDisplayController.php');
		
	</script>

</div>
</div>
<div id="totalEquity" style="margin-top:-40px;">TOTAL EQUITY: <p></p></div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

