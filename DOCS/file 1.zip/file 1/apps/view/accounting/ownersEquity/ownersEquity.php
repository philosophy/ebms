<?php 
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";
$totalEquity = 0;

$page = $_POST['page'];
$searchQuery = addslashes(@$_POST['searchQuery']);

include "../currency.php";
if($searchQuery != "")
	{
	$condition = "WHERE oe_hdr_date LIKE '%".$searchQuery."%' or oe_hdr_amount LIKE '%".$searchQuery."%' or oe_hdr_ctrl_no LIKE '%".$searchQuery."%' or oe_hdr_remarks LIKE '%".$searchQuery."%'";
	}

else $condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 9;

$start = $page * $per_page;

$index = 1;
 $outputData .="<table ref='equity'>
		<th>Control No.</th>
		<th>Date</th>
		<th>Amount (".$symbol.")</th>
		<th>Remarks</th>
		<th>Type</th>";

	$query = "select oe_hdr_ctrl_no, oe_hdr_date, oe_hdr_amount, oe_hdr_remarks,is_deposited
		from owners_equity ".$condition." order by 1 desc";
	
	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arrResult = mysql_query($query." limit $start,$per_page");
	
	if(mysql_num_rows($arrResult) > 0)
	{

	while($arrEquity = mysql_fetch_array($arrResult))
	{
	
	/*
	if($arrCustomer['is_active'] == 1)
		$custStatusWidget = "<img title='Active customer' src='../../../images/icons/smiley-icon.png' width=20 height=20 />";
	elseif($arrCustomer['is_active'] == 0)
		$custStatusWidget = "<img title='Inactive customer' src='../../../images/icons/inactive.png' width=20 height=20 />";
	*/
		$outputData .= "<tr>";
			//$outputData .= "<td>".$custStatusWidget."</td>";
			$outputData .= "<td>".$arrEquity['oe_hdr_ctrl_no']."</td>";
			$outputData .= "<td>".date("D M d, Y",strtotime($arrEquity['oe_hdr_date']))."</td>";
			$outputData .= "<td style='text-align:right'>".number_format($arrEquity['oe_hdr_amount'],2)."</td>";
			$outputData .= "<td>".$arrEquity['oe_hdr_remarks']."</td>";
			$outputData .= "<td>".(($arrEquity['is_deposited']=='0')?'Cash':'Deposited to Bank')."</td>";
		$outputData .= "</tr>";
		
	//$totalEquity += $arrEquity['oe_hdr_amount'];
	}
	
	$max = mysql_query("Select sum(oe_hdr_amount) from owners_equity");
	while($row = mysql_fetch_array($max))
	{
		$totalEquity = $row[0];
	}
	mysql_free_result($max); 
	mysql_free_result($arrResult); 
	
	$outputData .= "</table>";
	echo "
		<script>
		$(document).ready(function(){
		$('table[ref=equity]').attr('totalEquity','".$symbol." ".number_format($totalEquity,2)."');
		});
		</script>";
	}
	
	else
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
 
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 

?>