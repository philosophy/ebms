<?php
	include("../../../../config/config.php");
$role = $_POST['role'];
if($role=="add")
{	
	$ctr = $_POST['ctr'];
	$outputData = "";
	
	//$rowId = @$_POST['rowId'];
	$accountTypeId = @$_POST['accountTypeId'];
	$amount = @$_POST['amount'];
	$desc = @$_POST['desc'];
	
	$accountType = "";
	
	$query = mysql_query("Select ACCOUNT_SUB_CATEGORY_NAME From account_sub_category Where ACCOUNT_SUB_CATEGORY_ID = '" . $accountTypeId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$accountType = $arr[0];
	}
	
	//$outputData .= "<tr a=''>";
	$outputData .= "<tr rowNum='". $ctr ."'><td class='option'><img src='/ebms/images/remove.png' rowNum='". $ctr ."' amount='". $amount ."'></td><td a='" . $accountTypeId . "'>" . $accountType . "</td>";
	$outputData .= "<td>" . $desc . "</td>";
	$outputData .= "<td>" . $amount . "</td></tr>";
	
	echo $outputData;
}
else if($role=="selected")
{
	$ctr = $_POST['ctr'];
	$amount = @$_POST['amount'];
	$desc = @$_POST['desc'];
	$outputData = "";

	$query = mysql_query("Select ACCOUNT_SUB_CATEGORY_ID From account_sub_category Where ACCOUNT_SUB_CATEGORY_NAME = 'Accounts Payable'");
	while ($arr = mysql_fetch_array($query))
	{
		$accountTypeId = $arr['ACCOUNT_SUB_CATEGORY_ID'];
	}
	
	$outputData .= "<tr rowNum='". $ctr ."'><td class='option'><img src='/ebms/images/remove.png' rowNum='". $ctr ."' amount='". $amount ."'></td><td a='" . $accountTypeId . "'>Accounts Payable</td>";
	$outputData .= "<td>" . $desc . "</td>";
	$outputData .= "<td>" . $amount . "</td></tr>";
	
	echo $outputData;

}
?>