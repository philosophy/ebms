<?php
include("../../../../config/config.php");
$role = $_POST['role'];
	
if($role=="employee")
{
	$query = mysql_query("Select EMP_ID, concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME)
								From employee_profile
								Where IS_DELETED = 0");
								
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<option value='".$arr['EMP_ID']."'>".$arr[1]."</option>";
		}
		echo $outputData;
	}
}
else if ($role == "supplier")
{
	$query = mysql_query("Select SUPPLIER_ID, SUPPLIER_NAME
							From supplier_profile
							Where IS_DELETED = 0");
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<option value='".$arr['SUPPLIER_ID']."'>".$arr['SUPPLIER_NAME']."</option>";
		}
	}
	
	echo $outputData;
}
else if($role=="bankName")
{
	$get_cust_type = mysql_query("Select bank_id, bank_name from bank where is_deleted=0");
	$outputData ="";
	if(mysql_num_rows($get_cust_type) > 0)
	{
			while($row = mysql_fetch_array($get_cust_type))
			{
				$outputData .= "<option value='".$row['bank_id']."'>".$row['bank_name']."</option>";
			}
	}
	echo $outputData;
}

else if($role =="accountType")
{
	$bank = $_POST['bank'];
	$get_cust_type = mysql_query("Select distinct bank_account_type from bank_account where bank_id='" . $bank . "'");
	$outputData ="";
	if(mysql_num_rows($get_cust_type) > 0)
	{
			while($row = mysql_fetch_array($get_cust_type))
			{
				$outputData .= "<option value='".$row['bank_account_type']."'>".$row['bank_account_type']."</option>";
			}
	}
	echo $outputData;
}
else if($role =="accountNumber")
{
	$bank = $_POST['bank'];
	$type = $_POST['type'];
	$query = "Select bank_account_id,bank_account_no from bank_account where bank_id='" . $bank . "' and bank_account_type='" . $type . "'";
	$get_cust_type = mysql_query($query);
	$outputData ="";
	if(mysql_num_rows($get_cust_type) > 0)
	{
			while($row = mysql_fetch_array($get_cust_type))
			{
				$outputData .= "<option value='".$row['bank_account_id']."'>".$row['bank_account_no']."</option>";
			}
	}
	echo $outputData;
}
else if($role =="accountName")
{
	$acctId = $_POST['acctId'];
	$query = "Select bank_account_name from bank_account where bank_account_id='" . $acctId . "'";
	$get_cust_type = mysql_query($query);
	$outputData ="";
	if(mysql_num_rows($get_cust_type) > 0)
	{
			while($row = mysql_fetch_array($get_cust_type))
			{
				$outputData = $row['bank_account_name'];
			}
	}
	echo $outputData;
}
		
		
?>