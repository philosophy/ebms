<?php
	include("../../../../config/config.php");
	$role=$_POST['role'];
	
	if($role=="PO")
	{
		$outputData = "";
		$query = mysql_query("Select PO_HDR_ID, PO_HDR_NO, PO_HDR_DATE_NEEDED, PO_HDR_PAYMENT_TYPE, format(PO_HDR_NET_AMOUNT,2), supplier_name, po_header.supplier_id From po_header inner join supplier_profile on po_header.supplier_id=supplier_profile.supplier_id");
		
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<tr a='" . $arr[0] . "' amount='" . $arr[4] . "' hdrNo='". $arr[1] ."' supplierID='" . $arr[6] . "'>";
				$outputData .= "<td>" . $arr[1] . "</td>";
				$outputData .= "<td>" . $arr[2] . "</td>";
				$outputData .= "<td>" . $arr[3] . "</td>";
				$outputData .= "<td>" . $arr[4] . "</td>";			
				$outputData .= "<td>" . $arr[5] . "</td>";			
			}
		}
		else
		{
			$outputData = "No record(s) found";
		}
		
		echo $outputData;
	}
	
	if($role=="image")
	{
		$id = $_POST['id'];
		$outputData = "";
		
		
		$query = mysql_query("Select PO_DTL_QTY as 'qty', 
									 ITEM_CODE as 'itemCode', 
									 PO_DTL_ITEM_DESCRIPTION as 'desc',
									 PRODUCT_IMAGE as 'img'
							  From product p, po_header ph, po_detail pd 
							  Where ph.PO_HDR_ID = pd.PO_HDR_ID and 
									P.PRODUCT_CODE = pd.ITEM_CODE and 
									pd.PO_HDR_ID = '" . $id . "'");
									
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<tr a='" . $arr[1] . "'>";
				$outputData .= "<td>" . $arr[1] . "</td>";
				$outputData .= "<td>" . $arr[0] . "</td>";
				$outputData .= "<td>" . $arr[2] . "</td>";		
			}
		}
		else
		{
			$outputData = "No record(s) found";
		}
		
		echo $outputData;

	}
?>