<?php
include("../../../../config/config.php");
include "../currency.php";
$role = $_POST['role'];
if($role=="addExpense")
{
	$amount = $_POST['amount'];
	$particular = $_POST['particular'];
	$refNo = $_POST['refNo'];
	$suppId = $_POST['suppId'];
	$empId = $_POST['empId'];
	
	$id = 0;
	$result = mysql_query("SELECT MAX(AP_HDR_ID),YEAR( CURDATE( ) ) FROM ap_header");

	while ($row = mysql_fetch_array($result))
	{
		$id = $row[0];
		$year = $row[1]; 
	}
	$expCode = "EXP-" . $year ."-" . substr("000000",0,strlen("000000") - strlen($id + 1)) . ($id +1);
	
	//echo "expCode:" . $expCode . ", amount:" . $amount . ", particular:" . $particular . ", refNo:" . $refNo . ", suppId:" . $suppId . ", empId:" . $empId;
	
	$query = "INSERT INTO ap_header(AP_HDR_CODE, AP_HDR_AMOUNT, AP_HDR_DATE, AP_HDR_DUE_DATE, AP_HDR_PARTICULAR, AP_HDR_REF_NO, AP_HDR_REF_TYPE, AP_HDR_CREATED_BY_ID, SUPPLIER_ID, IS_DELETED) VALUES ('". $expCode ."','". $amount ."',curdate(),curdate(),'". $particular ."','". $refNo ."','Expense','". $empId ."','". $suppId ."',0)";
	mysql_query($query);

	echo $expCode;
}
else if($role=="addDetail")
{
	$expCode = $_POST['exp'];
	$acctTypeId = $_POST['accountId'];
	$desc = $_POST['description'];
	$amount = $_POST['amount'];
	
	$result = mysql_query("SELECT AP_HDR_ID FROM ap_header where ap_hdr_code='" . $expCode . "'");
	$id=0;
	while ($row = mysql_fetch_array($result))
	{
		$id = $row[0];
	}
	
	$result = mysql_query("SELECT account_type_id FROM account_type where account_type_name='Liability'");
	$accountId=0;
	while ($row = mysql_fetch_array($result))
	{
		$acctId = $row[0];
	}
	
	$query = "INSERT INTO `ap_detail`(`AP_DTL_AMOUNT`, `AP_DTL_DESCRIPTION`, `AP_HDR_ID`, `ACCOUNT_ID`, `ACCOUNT_TYPE_ID`) VALUES ('". $amount ."','". $desc ."','". $id ."','". $acctId ."','". $acctTypeId ."')";
	mysql_query($query);
	echo $query;
	
	//echo $id . " " . $acctId . " " . $desc . " " . $amount;
	//echo $acctId;
}
else if($role=="view")
{
	$id = @$_POST['id'];
	
	$query = mysql_query("Select AP_DTL_ID, AP_DTL_AMOUNT, AP_DTL_DESCRIPTION, ACCOUNT_TYPE_NAME, ACCOUNT_SUB_CATEGORY_NAME 
							From ap_detail AD, ap_header AH, account_type AT, account_sub_category ACSC 
							Where AD.AP_HDR_ID = AH.AP_HDR_ID and 
									AD.ACCOUNT_ID = AT.ACCOUNT_TYPE_ID and 
									AD.ACCOUNT_TYPE_ID = ACSC.ACCOUNT_SUB_CATEGORY_ID and 
									AD.AP_HDR_ID = '" . $id . "'");
	
	$outputData = "<table>
					<th>Account Type
					<th>Description</th>
					<th>Amount (".$symbol.")</th>";
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<tr a='" . $arr['AP_DTL_ID'] . "'>";
			$outputData .= 		"<td>" . $arr['ACCOUNT_SUB_CATEGORY_NAME'] . "</td>";
			$outputData .= 		"<td>" . $arr['AP_DTL_DESCRIPTION'] . "</td>";
			$outputData .= 		"<td align=right>" . number_format($arr['AP_DTL_AMOUNT'], 2) . "</td>";
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
	}
	else
	{
		$outputData = "No results found.";
	}
	
	echo $outputData;
	
}

else if($role=="cashOnHand")
{ 
	$cash = 0;
	$result = mysql_query("SELECT cash_on_hand_amount FROM cash_on_hand");
	if (mysql_num_rows($result) > 0)
	{
		while ($arr = mysql_fetch_array($result))
		{
			$cash = $arr[0];
		}
	}
	echo $cash;
}

else if($role=="insertPayment")
{
	$particular = $_POST['particular'];
	$paymentType = $_POST['paymentType'];
	$amount = $_POST['amount'];
	$emp = $_POST['emp'];
	$refNo = $_POST['refNo']; // expcode
	
	$paymentNo = "";
	$max = 0;
	$zeros = "000000";
	$payment = mysql_query("Select max(payment_id) From payment");
		
	if(mysql_num_rows($payment) > 0)
	{	
		while($id= mysql_fetch_array($payment))
		{
			$max = $id[0];
		}
				
		$max += 1;
		$my_t= date('Y');
		$paymentNo = "PN-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
	}
	
	
	$query = "insert into payment(payment_no, payment_date, payment_ref_type, payment_particular, payment_type, payment_amount, 
		is_from_collection, payment_created_by_id, payment_ref_no,os_hdr_id) values('".$paymentNo."',CURDATE(),'Expense','".
	$particular."','".$paymentType."',".$amount.",0,".$emp.",'".$refNo."',0)";
	
	// //minus on accounts payable [GENERAL LEDGER]
		mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
					gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', -".$amount.", 2, 4, 'AP',
					'".$paymentNo."', 2, 0)") or die(mysql_error());
					
	// //add on accounts payable [GENERAL LEDGER]
		mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
					gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."',".$amount.", 2, 4, 'AP',
					'".$paymentNo."', 2, 0)") or die(mysql_error());				
	
	// //add on expenses [GENERAL LEDGER]
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
					gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."',".$amount.", 2, 6, 'AP',
					'".$paymentNo."', 3, 0)") or die(mysql_error());
		
		
	// //minus on cash [GENERAL LEDGER]
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
					gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', -".$amount.", 2, 2, 'AP',
					'".$paymentNo."', 3, 0)") or die(mysql_error());
	
	if($paymentType == "cash")
	{
	// //minus on cash on hand [GENERAL LEDGER]
		mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
					gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', -".$amount.", 2, 7, 'AP',
					'".$paymentNo."', 3, 0)") or die(mysql_error());
	} 
	else if($paymentType == "check")
	{
	// //minus on cash on bank [GENERAL LEDGER]
		mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
					gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', -".$amount.", 2, 8, 'AP',
					'".$paymentNo."', 3, 0)") or die(mysql_error());
	}
	
	
	mysql_query($query);
	echo $paymentNo;
}

else if($role =="checkProfile")
{
	$emp = $_POST['emp'];
	$pmntNo = $_POST['pmntNo'];
	$refNo = $_POST['refNo'];
	$checkNo = $_POST['checkNo'];
	$checkDueDate = $_POST['checkDueDate'];
	$checkDateIssue = $_POST['checkDateIssue'];
	$amount = $_POST['amount'];
	$checkType = $_POST['checkType'];
	$accountNo = $_POST['accountNo'];
	$accountName = $_POST['accountName'];
	$bankId = $_POST['bankId'];
	
	$query = "insert into check_profile(check_no, check_due_date, check_date_issued, check_amount, check_type,
	check_account_no, check_account_name, check_ref_hdr_type, check_ref_no, bank_id, customer_id, flag, created_by_id, 
	check_ref_hdr_no) values('".$checkNo."','".date('Y-m-d', strtotime($checkDueDate))."',
	'".date('Y-m-d', strtotime($checkDateIssue))."',".$amount.",'".$checkType."','".$accountNo."','".$accountName."'
	,'Expense','".$refNo."',".$bankId.",0, 'B', ".$emp.",'".$pmntNo."')";
	
	mysql_query($query);
	echo $query;
	
}
else if($role =="render")
{
	$code = $_POST['id'];
	$getdata = mysql_query("SELECT  `AP_HDR_CODE` ,  `AP_HDR_AMOUNT` ,  `AP_HDR_PARTICULAR` ,  `AP_HDR_REF_NO` , `AP_HDR_REF_TYPE` ,  `AP_HDR_CREATED_BY_ID` ,  `SUPPLIER_ID` , AP_HDR_CREATED_BY_ID, bank_name,bank_account_type, bank_account_name, bank_account_no, c.check_no, check_type, check_due_date, check_date_issued
FROM  `ap_header` ap
left outer JOIN check_profile c ON c.check_ref_no = ap.ap_hdr_code
INNER JOIN bank b ON c.bank_id = b.bank_id
INNER JOIN bank_account ba ON c.check_account_no = ba.bank_account_no
WHERE AP_HDR_ID =  '".$code."'");
	$data[] = "";
	if(mysql_num_rows($getdata) > 0)
		{	
			while($arrProduct = mysql_fetch_array($getdata))
			{
				$data["code"] = $arrProduct["AP_HDR_CODE"];
				$data["amount"] = $arrProduct["AP_HDR_AMOUNT"];
				$data["particular"] = $arrProduct["AP_HDR_PARTICULAR"];
				$data["refNo"] = $arrProduct["AP_HDR_REF_NO"];
				$data["emp"] = $arrProduct["AP_HDR_CREATED_BY_ID"];
				$data["suppId"] = $arrProduct["SUPPLIER_ID"];
				$data["bankName"] = $arrProduct["bank_name"];
				$data["accountName"] = $arrProduct["bank_account_name"];
				$data["accountType"] = $arrProduct["bank_account_type"];
				$data["accountNo"] = $arrProduct["bank_account_no"];
				$data["checkNo"] = $arrProduct["check_no"];
				$data["checkType"] = $arrProduct["check_type"];
				$data["dueDate"] = $arrProduct["check_due_date"];
				$data["dateIssued"] = $arrProduct["check_date_issued"];
			}
		}
	 $dataArray= json_encode(array("values"=>$data));
	 echo $dataArray;

}
else if($role =="amount")
{	
	$code = $_POST['id'];
	$getdata = mysql_query("SELECT  `AP_HDR_CODE` ,  `AP_HDR_AMOUNT` ,  `AP_HDR_PARTICULAR` ,  `AP_HDR_REF_NO` , `AP_HDR_REF_TYPE` ,  `AP_HDR_CREATED_BY_ID` ,  `SUPPLIER_ID` , AP_HDR_CREATED_BY_ID from ap_header where ap_hdr_id='" . $code . "'");
	$data[] = "";
	while($arrProduct = mysql_fetch_array($getdata))
	{
		$data["code"] = $arrProduct["AP_HDR_CODE"];
		$data["amount"] = $arrProduct["AP_HDR_AMOUNT"];
		$data["particular"] = $arrProduct["AP_HDR_PARTICULAR"];
		$data["refNo"] = $arrProduct["AP_HDR_REF_NO"];
		$data["emp"] = $arrProduct["AP_HDR_CREATED_BY_ID"];
		$data["suppId"] = $arrProduct["SUPPLIER_ID"];
	}
	$dataArray= json_encode(array("cash"=>$data));
	 echo $dataArray;
}
else if($role =="edit")
{	
	$particular = $_POST['particular'];
	$emp = $_POST['emp'];
	$code = $_POST['id'];
	$getdata = mysql_query("UPDATE `ap_header` SET `AP_HDR_PARTICULAR`='". $particular ."',`AP_HDR_CREATED_BY_ID`='". $emp ."' WHERE ap_hdr_id='" . $code . "'");
	

}













?>