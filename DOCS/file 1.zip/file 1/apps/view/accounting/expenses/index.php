﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Expenses</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Expenses");
		datagridMenu("expense","new;edit");
		datagrid("customerTransact;checkPayment",false);
		$("#tabbed-grid").tabs({fx: { height: 'toggle', duration: 'fast' },
		});
		
		$("#pdf").click(function(){
		//window.open("../../view/reports/crm/crmMasterList.php","_new");
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/accounting/expenses/index.php");
 include("../../../controller/accounting/expensesController.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="expenses" class="datagrid-container">
	
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#details">Details</a></li>
	</ul> 
	
	<div id="details" class="scrollable" style="heigh:150px;"> 
		<!-- general description preview -->
	</div>
</div>

	<div class="import" id="import">
	<form method="POST" action="" >	
			
		<div id="formSegment" style="width:100%;">
		<div id="formDataCont" style="overflow:auto; height:200px; border:solid #ccc 1px;width:96%;">				
			<table id="expense">
				<th>PO CODE</th>
				<th>DATE NEEDED</th>
				<th>PAYMENT TYPE</th>
				<th>NET AMOUNT</th>
				<th>SUPPLIER</th>
				<tbody id="items">
					
				</tbody>
				
			</table>
		</div>
		<div id="formSegment" style="width:100%;">
				
		<h5>PO Details</h5>
					
			<div id="formDataCont" style="overflow:auto; height:200px; border:solid #ccc 1px;width:94%;">				
				<table id="poDetails">
					<th>ITEM CODE</th>
					<th>QUANTITY</th>
					<th>DESCRIPTION</th>
					<tbody id="details">
						
					</tbody>
					
				</table>
			</div>
		</div>
		</div>
		<div>
		
			<button class="importButtonCancel" id="importCancel">Cancel</button>
			<button class="importButtonSelect" id="importSave">Select</button>
		</div>
	</form>
	</div>



</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

