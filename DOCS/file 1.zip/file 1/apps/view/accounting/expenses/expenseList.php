<?php
include("../../../../config/config.php");

$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

include "../currency.php";

if($searchQuery!="")
	{
	$condition = " and adj_hdr_code LIKE '%".$searchQuery."%' or adj_hdr_date LIKE '%".$searchQuery."%' or adj_hdr_remarks LIKE '%".$searchQuery."%' ";
	}

elseif ($searchQuery == "")
	$condition = " ";


$cur_page = $page;
$page -= 1;
$per_page = 9;
$start = $page * $per_page;
	$outputData = "<table >
			<th></th>
			<th>Expense Code</th>
			<th>Date</th>
			<th>Particular</th>
			<th>Amount (".$symbol.")</th>
			<th>Ref No</th>
			<th>Ref Type</th>
			<th>Employee</th>";
			
			
			
$query = "SELECT AP_HDR_ID, AP_HDR_CODE ,  AP_HDR_AMOUNT ,  AP_HDR_DATE ,   AP_HDR_PARTICULAR ,  AP_HDR_REF_NO ,  AP_HDR_REF_TYPE ,CONCAT( emp_first_name,  ' ', emp_middle_name,  ' ', emp_last_name ) AS  'Employee' FROM  ap_header  inner join employee_profile on  AP_HDR_CREATED_BY_ID =emp_id where  AP_HDR_REF_TYPE ='Expense'".$condition."order by 1 desc";
				
			$count = mysql_num_rows(mysql_query($query));
			$no_of_paginations = ceil($count / $per_page);
	
			$arrRows = mysql_query($query." limit $start,$per_page");

$icon = "";

if(mysql_num_rows($arrRows) >0)
{
	while($arrProduct = mysql_fetch_array($arrRows))
	{
			$icon = "<td class='icon'><img src='../../../../images/icons/hand-icon.png' height=20 width=20 /> </td>";
	
		$outputData .= "<tr a='".$arrProduct['AP_HDR_ID']."'>";
		$outputData .= $icon;
		$outputData .= "<td>".$arrProduct['AP_HDR_CODE']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrProduct['AP_HDR_DATE']))."</td>";
		$outputData .= "<td>".$arrProduct['AP_HDR_PARTICULAR']."</td>";
		$outputData .= "<td align=right>".$arrProduct['AP_HDR_AMOUNT']."</td>";
		$outputData .= "<td>".$arrProduct['AP_HDR_REF_NO']."</td>";
		$outputData .= "<td>".$arrProduct['AP_HDR_REF_TYPE']."</td>";
		$outputData .= "<td>".$arrProduct['Employee']."</td>";
		$outputData .= "</tr>";
	}
		$outputData .= "</table>";
}

else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
	

	
?>
	
	
	