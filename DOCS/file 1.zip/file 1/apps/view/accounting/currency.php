<?php 

$currency = mysql_query("SELECT cur_symbol FROM currency where is_flag = 1");
$currency = mysql_fetch_array($currency);

$symbol = $currency['cur_symbol'];

?>