﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Account Receivables</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(function(){
		headTitle("Accounts Receivable");		
		datagrid("accounts-receivable;paymentHistory",true);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	$("#pdf").click(function(){
		window.open("../../../view/reports/accounting/accountsReceivable.php","_new");
		});
});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<?php include("../../modalForms/accounting/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="accounts-receivable" class="datagrid-container">

	<script>
		$('#accounts-receivable').load('../../../controller/accounting/receivablesController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#paymentHistory">Payment History</a></li>
	</ul> 
		
		<div id="paymentHistory"> 
		
		<div class="tabButtonPanel" style="position:absolute;left:140px;margin-top:-48px">
			<button id="custPayment" class="callModalForm" ref="new_custPayment" onclick="callModal('#custPayment')" style="width:50px;font-size:11px;color:#333;text-shadow:0 0 1px #fff;-webkit-box-shadow:0 0 0 transparent;" title="Post Payment"></button>
			<script>
			$( "button#custPayment" ).button({
            icons: {
                primary: "ui-icon-circle-plus"
            },
			text:false
			});
			</script>
		</div>
		
		<div id="paymentHistoryGrid">
			Please select customer/s above
		</div>
		</div>
	 
</div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

