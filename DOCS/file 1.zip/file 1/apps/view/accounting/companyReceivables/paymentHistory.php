<?php 
include("../../../../config/config.php");
$osNo = @$_POST['osNo'];

include "../../accounting/currency.php";

$outputData = "";
$x = "";
$image = "";
			
$payment = mysql_query("SELECT p.is_from_collection, p.payment_no, date_format(p.payment_date,'%b-%d-%Y') as 'payment_date', p.payment_type, p.payment_amount, p.payment_created_by_id, emp.emp_first_name, emp.emp_last_name
						FROM payment p, os_header os, employee_profile emp
						WHERE os.os_hdr_id=p.os_hdr_id and emp.emp_id=p.payment_created_by_id and os.os_hdr_no = '".$osNo."' and p.payment_type='cash'");
						
$cheque = mysql_query("select p.payment_no, date_format(p.payment_date,'%b-%d-%Y') as 'payment_date', p.payment_type, cp.is_posted, cp.check_amount, p.is_from_collection,  concat(ep.emp_first_name,' ', ep.emp_last_name) from payment p inner join check_profile cp on cp.check_ref_hdr_no = p.payment_no inner join 
						employee_profile ep on ep.emp_id = cp.created_by_id where p.payment_ref_no = '".$osNo."' and p.payment_type = 'cheque'");
									
if(mysql_num_rows($payment) > 0 || mysql_num_rows($cheque) > 0)
{
	$outputData .= "<table>
		<th></th>
		<th>Payment Number</th>
		<th>Payment Date</th>
		<th>Mode of Payment</th>
		<th>Amount Paid (".$symbol.")</th>
		<th>From Collection</th>
		<th>Received By</th>
		";
	
	while($paymentHistory = mysql_fetch_array($payment))
	{
		$outputData .= "<tr>";
		$outputData .= "<td><img src='/EBMS/images/icons/checkIcon.png' width=20 height=20></td>";
		$outputData .= "<td>".$paymentHistory['payment_no']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($paymentHistory['payment_date']))."</td>";
		$outputData .= "<td>Cash</td>";
		$outputData .= "<td align='right'>".number_format($paymentHistory['payment_amount'],2)."</td>";
		if($paymentHistory['is_from_collection'] == 1)
		{
			$x = 'Yes';
		}
		else
		{
			$x = 'No';
		}
		$outputData .= "<td>".$x."</td>";
		$outputData .= "<td>".$paymentHistory['emp_first_name']." ".$paymentHistory['emp_last_name']."</td>";
	    $outputData .= "</tr>";
	}
	
	while($arrCheque = mysql_fetch_array($cheque))
	{
		$outputData .= "<tr>";
		if($arrCheque['is_posted'] == 1)
		{
			$image = "/EBMS/images/icons/posted-checks.png";
		}
		else
		{
			$image = "/EBMS/images/icons/approved_icon.png";
		}
		$outputData .= "<td><img src='".$image."' width=20 height=20></td>";
		$outputData .= "<td>".$arrCheque['payment_no']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrCheque['payment_date']))."</td>";
		$outputData .= "<td>Cheque</td>";
		$outputData .= "<td align='right'>".number_format($arrCheque['check_amount'],2)."</td>";
		if($arrCheque['is_from_collection'] == 1)
		{
			$x = 'Yes';
		}
		else
		{
			$x = 'No';
		}
		$outputData .= "<td>".$x."</td>";
		$outputData .= "<td>".$arrCheque[6]."</td>";
	    $outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No Payment found.";
}

echo $outputData;
?>