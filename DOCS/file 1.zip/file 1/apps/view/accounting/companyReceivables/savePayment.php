<?php 
session_start();
include("../../../../config/config.php");

$refType = $_POST['refType'];
$particular = $_POST['particular'];
$paymentType = $_POST['paymentType'];
$amount = $_POST['amount'];
$fromCol = $_POST['fromCol'];
$refNo = $_POST['refNo'];
$osNo = $_POST['osNo'];
$osId = $_POST['osId'];
$checkNo = $_POST['checkNo'];
$checkDueDate = $_POST['checkDueDate'];
$checkDateIssue = $_POST['checkDateIssue'];
$checkType = $_POST['checkType'];
$accountNo = $_POST['accountNo'];
$accountName = $_POST['accountName'];
$bankId = $_POST['bankId'];
$customerId = $_POST['customerId'];

//generate code
$paymentNo = "";
$max = 0;
$zeros = "000000";
$payment = mysql_query("Select max(payment_id) From payment");
    
if(mysql_num_rows($payment) > 0)
{	
	while($id= mysql_fetch_array($payment))
	{
		$max = $id[0];
	}
			
    $max += 1;
	$my_t= date('Y');
    $paymentNo = "PN-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
}
	
//insert into payment table
mysql_query("insert into payment(payment_no, payment_date, payment_ref_type, payment_particular, payment_type, payment_amount, 
		is_from_collection, payment_created_by_id, payment_ref_no, os_hdr_id) values('".$paymentNo."',CURDATE(),'".$refType."','".
	$particular."','".$paymentType."',".$amount.",".$fromCol.",".$_SESSION['emp_id'].",'".$refNo."',".$osId.")");
	
//minus accounts receivables [GENERAL LEDGER]
mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', -".$amount.", 1, 3, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());
				
//add on cash [GENERAL LEDGER]
mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', ".$amount.", 1, 2, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());
				
//add on collection from AR [GENERAL LEDGER]
mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', ".$amount.", 1, 10, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());
	
if($paymentType == "cash")
{
	//add on cash on hand [GENERAL LEDGER]
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', ".$amount.", 1, 7, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());
				
	//insert into cash on hand
	$cashQuery = mysql_query("select cash_on_hand_amount from cash_on_hand");
	$cash = mysql_fetch_row($cashQuery);
	$cash[0] += $amount;
	mysql_query("update cash_on_hand set cash_on_hand_amount = ".$cash[0]);
	
	echo "Payment successfully added.";
}
elseif($paymentType == "cheque")
{
	//add on cash on bank [GENERAL LEDGER]
	mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type,
				gl_source_doc, account_type_id, gl_deleted) values(CURDATE(), '".$refNo."', ".$amount.", 1, 8, 'AR',
				'".$paymentNo."', 1, 0)") or die(mysql_error());
				
	//INSERT INTO CHECK_PROFILE TABLE
	mysql_query("insert into check_profile(check_no, check_due_date, check_date_issued, check_amount, check_type,
	check_account_no, check_account_name, check_ref_hdr_type, check_ref_no, bank_id, customer_id, flag, created_by_id, 
	check_ref_hdr_no) values('".$checkNo."','".date('Y-m-d', strtotime($checkDueDate))."',
	'".date('Y-m-d', strtotime($checkDateIssue))."',".$amount.",'".$checkType."','".$accountNo."','".$accountName."'
	,'".$refType."','".$refNo."',".$bankId.",".$customerId.", 'C', ".$_SESSION['emp_id'].",'".$paymentNo."')") 
	or die(mysql_error());
	
	echo "Check successfully added.";
}

?>