<?php 

include("../../../../config/config.php");

$outputData = "";

$query = mysql_query("
	SELECT ar.ar_hdr_no,ar.ar_hdr_amount,ar.ar_hdr_due_date
	FROM ar_header ar
	WHERE ar.ar_hdr_due_date = (SELECT DATE_ADD( CURDATE( ) , INTERVAL 2 DAY))
	");

$outputData = "<table style='text-align:left'>
				<th width=100>AR No.</th>
				<th width=200>Amount</th>
				<th width=250>Due Date</th>
				
				";
	
	if(mysql_num_rows($query) > 0)
	{
		while($rows = mysql_fetch_array($query))
		{
			$outputData .= "<tr><td>".$rows['ar_hdr_no']."</td><td>".$rows['ar_hdr_amount']."</td><td>".date("D M d, Y",strtotime($rows['ar_hdr_due_date']))."</td></tr>";
		}
	$outputData .= "</table>";
	echo $outputData;	
	}
	else 
	{
	echo "";
	}