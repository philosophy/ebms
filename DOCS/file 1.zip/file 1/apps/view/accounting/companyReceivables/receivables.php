<?php 
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";
$amount = 0;
$cheque = 0;
$balance = 0;

include "../currency.php";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " and (os.os_hdr_no LIKE '%".$searchQuery."%' or os.os_hdr_net_amount LIKE '%".$searchQuery."%' or customer_name LIKE '%".$searchQuery."%' or customer_code LIKE '%".$searchQuery."%' or area_name LIKE '%".$searchQuery."%' or date_format(os_hdr_date,'%b-%d-%Y') LIKE '%".$searchQuery."%')";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 10;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;
 $outputData .="<table>
		<th></th>
		<th>O.S. No.</th>
		<th>Customer Code</th>
		<th>Customer Name</th>
		<th>Area</th>
		<th>Date</th>
		<th>Amount Due (".$symbol.")</th>
		<th>Balance (".$symbol.")</th>
		<th>Amount Paid (".$symbol.")</th>
		";
	$query = "
			SELECT os.os_hdr_id, os.os_hdr_no,os.os_hdr_net_amount,cust.customer_name,cust.customer_code,a.area_name,date_format(os_hdr_date,'%b-%d-%Y') as 'os_hdr_date', cust.customer_id
			FROM os_header os,customer_profile cust,area a
			WHERE cust.customer_id = os.customer_id and a.area_id = os.area_id ".$condition."
			ORDER BY os.os_balance desc";
	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arrResult = mysql_query($query." limit $start,$per_page");
	
	if(mysql_num_rows($arrResult) > 0)
	{
	while($arrCustomer = mysql_fetch_array($arrResult))
	{
		//cash payment
		$amountPaid = mysql_query("select payment_amount, payment_type, payment_no from payment 
									where payment_ref_no ='".$arrCustomer['os_hdr_no']."'");
		if(mysql_num_rows($amountPaid) > 0)
		{
			while($arrAmount = mysql_fetch_array($amountPaid))
			{
				$amount += $arrAmount['payment_amount'];
				if($arrAmount['payment_type'] == "cheque")
				{
					$type = mysql_query("select is_posted from check_profile where check_ref_hdr_no = '".$arrAmount['payment_no']."'");
					while($arrType = mysql_fetch_array($type))
					{
						if($arrType['is_posted'] == 0)
						{
							$cheque = 1;
						}
					}
				}
			}
		}
		
		$balance = $arrCustomer['os_hdr_net_amount'] - $amount;
		
		mysql_query("update os_header set os_balance = ".$balance." where os_hdr_id = ".$arrCustomer['os_hdr_id']);
		
		if($balance != 0 || $cheque == 1)
		{
				$outputData .= "<tr osId=".$arrCustomer['os_hdr_id']." balance=".$balance." custId=".$arrCustomer['customer_id']." custNo=".$arrCustomer['customer_code']." osNo=".$arrCustomer['os_hdr_no'].">";
				
				if($amount > 0)
				{
					if($cheque == 1)
					{
						$outputData .= "<td><img title='With Pending Cheques' src='/EBMS/images/icons/ARWithCheque.png'></td>";
					}
					elseif($cheque == 0)
					{
						$outputData .= "<td><img title='No Pending Cheques' src='/EBMS/images/icons/ARWithoutCheque.png'></td>";
					}
				}
				else
				{
					$outputData .= "<td><img title='Unpaid' src='/EBMS/images/icons/warning.png'></td>";
				}
			
				$outputData .= "<td>".$arrCustomer['os_hdr_no']."</td>";
				$outputData .= "<td>".$arrCustomer['customer_code']."</td>";
				$outputData .= "<td>".$arrCustomer['customer_name']."</td>";
				$outputData .= "<td>".$arrCustomer['area_name']."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime($arrCustomer['os_hdr_date']))."</td>";
				$outputData .= "<td align='right'>".number_format($arrCustomer['os_hdr_net_amount'],2)."</td>";
				$outputData .= "<td align='right'>".number_format($balance, 2)."</td>";
				$outputData .= "<td align=right>".number_format($amount, 2)."</td>";
				$outputData .= "</tr>";

		}
		$amount = 0;
		$balance = 0;
		$cheque = 0;
	}
	
	$outputData .= "</table>";
	}
	
	else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrResult);

