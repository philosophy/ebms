<?php 
include("../../../../config/config.php");

$custCode = $_POST['custCode'];
$osNo = $_POST['osNo'];
$data[] = "";

//customer, Loc
$query = mysql_query("select cp.customer_name, concat(l.location_name, ', ', l.location_address) from customer_profile cp inner join location l
						on cp.customer_id = l.customer_id and cp.customer_code ='".$custCode."'");
						
if(mysql_num_rows($query) > 0)
{
	while($arrPayment = mysql_fetch_array($query))
	{
		$data['customer_name'] = $arrPayment['customer_name'];
		$data['location'] = $arrPayment[1];
	}
}

$dataArray = json_encode(array("values"=>$data));
echo $dataArray;
?>