﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Company Expenses</title>
<?php include("../../standard-js-css.php"); 
?>
<script>
	$(function(){
		headTitle("Company Expenses");		
		datagrid("company-expenses",true);
     });
	 
	$("#pdf").click(function(){
	window.open("../../../view/reports/accounting/companyExpenses.php","_new");
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<div id="body-pane" style="height:250px">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="company-expenses" class="datagrid-container">
	
</div>
</div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

