<?php
include("../../../../config/config.php");

$query = mysql_query("SELECT cash_on_hand_amount as 'amount' FROM cash_on_hand");

$row = mysql_fetch_array($query);

echo $row['amount'];

mysql_free_result($query);