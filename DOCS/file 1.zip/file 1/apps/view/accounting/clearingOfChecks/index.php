﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Clearing of Cheques</title>
<?php include("../../standard-js-css.php");?> 
<script>
	$(function(){
		headTitle("Clearing of Cheques");		
		datagrid("cleared-cheques",true);
		
	
	$("#pdf").click(function(){
		window.open("../../../view/reports/accounting/accountsReceivable.php","_new");
		});
});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<?php include("../../modalForms/accounting/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="cleared-cheques" class="datagrid-container">
	<script>
		$("#cleared-cheques").load("../../../controller/accounting/clearingChequesController.php");
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<label style="font-family:Tahoma;font-size:12px;font-weight:bold;margin-left:15px;margin-right:7px;">Check Amount</label><input type="text" style="height:20px;margin-top:5px" id="clearAmount" disabled>
	<div class="tabButtonPanel" style="position:absolute;left:270px;margin-top:-32px;">
	<button id="clearCheque" title="Clear Cheque" style="width:50px;font-size:11px;color:#333;text-shadow:0 0 1px #fff;-webkit-box-shadow:0 0 0 transparent;height:27px"></button>
	</div>
	<script>
			$( "button#clearCheque" ).button({
            icons: {
                primary: "ui-icon-circle-check"
            },
			text:false
			});
			</script>
</div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

