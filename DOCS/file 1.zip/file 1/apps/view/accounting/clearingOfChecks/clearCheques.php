<?php
session_start();
include("../../../../config/config.php");

$outputData = "";
$chequeNo = $_POST['chequeNo'];
$chequeAmount = $_POST['chequeAmount'];
$bankId = $_POST['bankId'];
$accountId = $_POST['accountId'];
$chequeId = $_POST['chequeId'];


//generate code
$withNo = "";
$max = 0;
$zeros = "000000";
$with = mysql_query("Select max(bank_with_id) From bank_withdrawal");
    
if(mysql_num_rows($with) > 0)
{	
	while($id= mysql_fetch_array($with))
	{
		$max = $id[0];
	}
			
    $max += 1;
	$my_t= date('Y');
    $withNo = "BANK-WITH-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
}

mysql_query("update check_profile set is_cleared = 1 where check_id = ".$chequeId) or die(mysql_error());

mysql_query("insert into bank_withdrawal(bank_with_no, bank_with_amount, bank_with_date, bank_id, bank_account_id, 
				bank_with_withdrawn_by_id, bank_with_ref_type, bank_with_ref_no) 
				values('".$withNo."',".$chequeAmount.", CURDATE(), ".$bankId.",".$accountId.",
				".$_SESSION['emp_id'].", 'Cheque', '".$chequeNo."')") or die(mysql_error());
				
//insert on -cash [GENERAL LEDGER]
// mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type, 
				// account_type_id, gl_deleted) values(CURDATE(), '".$withNo."', -".$chequeAmount.", 1, 2, 'CHEQUE',
				// 1, 0)") or die(mysql_error());
				
//insert on -cash in bank [GENERAL LEDGER]
mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type, 
				account_type_id, gl_deleted) values(CURDATE(), '".$withNo."', -".$chequeAmount.", 1, 8, 'CHEQUE',
				1, 0)") or die(mysql_error());
				

?>