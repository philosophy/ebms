﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Posting of Cheques</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(function(){
		headTitle("Posting of Cheques");		
		datagrid("posted-cheques",true);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	$("#pdf").click(function(){
		window.open("../../../view/reports/accounting/accountsReceivable.php","_new");
		});
});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<?php include("../../modalForms/accounting/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="posted-cheques" class="datagrid-container">
	<script>
	$("#posted-cheques").load("../../../controller/accounting/postingChequesController.php");
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#chequeDetails">Deposit to Bank</a></li>
	</ul> 
		<div id="chequeDetails"> 
			
		<div class="tabButtonPanel" style="position:absolute;left:140px;margin-top:-48px">
			<button id="postCheque" style="width:50px;font-size:11px;color:#333;text-shadow:0 0 1px #fff;-webkit-box-shadow:0 0 0 transparent;">Post</button>
			<script>
			$( "button#postCheque" ).button({
            icons: {
                primary: "ui-icon-pin-s"
            },
			text:false
			});
			</script>
			</div>
			
			<label style="width:150px; font-weight:bold">Bank Name:<label>
			<select id="chequeBankName" style="width:210px">
			</select>
			
			<label>Account Type:<label>
			<select id="chequeAccountType">
				<option id="Savings">Savings</option>
				<option id="Current">Current</option>
			</select>
			
			<label>Account No:<label>
			<select id="chequeAccountNo" style="width:150px">
			</select>
			
			<label>Amount:<label>
			<input type="text" id="chequeAmount" disabled=true style="width:120px">
		</div>
	 
</div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

