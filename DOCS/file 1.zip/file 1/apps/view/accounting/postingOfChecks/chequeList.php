<?php
include("../../../../config/config.php");

$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

include "../currency.php";

if($searchQuery!="")
	{
	$condition = " and adj_hdr_code LIKE '%".$searchQuery."%' or adj_hdr_date LIKE '%".$searchQuery."%' or adj_hdr_remarks LIKE '%".$searchQuery."%' ";
	}

elseif ($searchQuery == "")
	$condition = " ";


$cur_page = $page;
$page -= 1;
$per_page = 9;
$start = $page * $per_page;
	$outputData .= "<table>
					<th></th>
					<th>Cheque Number</th>
					<th>Account Number</th>
					<th>Account Name</th>
					<th>Check Amount (".$symbol.")</th>
					<th>Bank Name</th>
					<th>Bank Address</th>
					<th>Cheque Type</th>
					<th>Date Issued</th>
					<th>Cheque Due Date</th>";

include "../currency.php";
$query = "select c.check_no, c.check_account_no, c.check_account_name, c.check_amount, b.bank_name,
						b.bank_address, c.check_type, c.check_date_issued, c.check_due_date from check_profile c inner join
						bank b on b.bank_id = c.bank_id where c.check_ref_hdr_no IS NOT NULL and c.is_posted = 0 
						and c.check_ref_hdr_type = 'OS'";
		
			$count = mysql_num_rows(mysql_query($query));
			$no_of_paginations = ceil($count / $per_page);
	
			$arrResult = mysql_query($query." limit $start,$per_page");

if(mysql_num_rows($arrResult) > 0)
{
					
	while($arrCheque = mysql_fetch_array($arrResult))
	{
		$outputData .= "<tr amount=".$arrCheque['check_amount']." no='".$arrCheque['check_no']."'>";
		$outputData .= "<td><a href='#'><img class='includedItem' src='/EBMS/images/icons/add.png' width=25 height=25>
							<img class='addItem' src='/EBMS/images/icons/include.png' width=25 height=25 style='display:none;'></a></td>";
		$outputData .= "<td>".$arrCheque['check_no']."</td>";
		$outputData .= "<td>".$arrCheque['check_account_no']."</td>";
		$outputData .= "<td>".$arrCheque['check_account_name']."</td>";
		$outputData .= "<td align=right>".number_format($arrCheque['check_amount'], 2)."</td>";
		$outputData .= "<td>".$arrCheque['bank_name']."</td>";
		$outputData .= "<td>".$arrCheque['bank_address']."</td>";
		$outputData .= "<td>".$arrCheque['check_type']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrCheque['check_date_issued']))."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrCheque['check_due_date']))."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
}

else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
	

	
?>

