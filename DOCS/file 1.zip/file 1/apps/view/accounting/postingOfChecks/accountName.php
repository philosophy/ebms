<?php
include("../../../../config/config.php");

$outputData = "";
$bankId = $_POST['bankId'];
$type = $_POST['type'];

$query = mysql_query("select bank_account_id, bank_account_no, bank_account_name from bank_account where bank_id = ".$bankId.
						" and bank_account_type = '".$type."'");

if(mysql_num_rows($query) > 0)
{
	while($arrAccount = mysql_fetch_array($query))
	{
		$outputData .= "<option id=".$arrAccount['bank_account_id']." no='".$arrAccount['bank_account_no']."'>".$arrAccount['bank_account_name']."</option>";
	}
}

echo $outputData;
?>