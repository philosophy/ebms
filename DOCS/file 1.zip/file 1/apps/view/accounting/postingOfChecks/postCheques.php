<?php
include("../../../../config/config.php");

$chequeNo = $_POST['chequeNo'];
$depositId = $_POST['depositId'];
$chequeAmount = $_POST['chequeAmount'];

//is_posted = 1
mysql_query("update check_profile set is_posted = 1, check_date_posted = CURDATE() where check_no = '".$chequeNo."'") or die(mysql_error());

//insert bank deposit details
mysql_query("insert into bank_deposit_detail(bank_deposit_dtl_ref_no, bank_deposit_dtl_ref_type, bank_deposit_dtl_amount, bank_deposit_hdr_id)
				values('".$chequeNo."', 'Cheque', ".$chequeAmount.",".$depositId.")") or die(mysql_error());
				


?>