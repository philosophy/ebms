<?php
session_start();
include("../../../../config/config.php");

$bankId = $_POST['bankId'];
$accountNo = $_POST['accountNo'];
$amount = $_POST['amount'];

$depositNo = "";
$max = 0;
$zeros = "000000";
$deposit = mysql_query("Select max(bank_deposit_id) From bank_deposit_header");
    
if(mysql_num_rows($deposit) > 0)
{	
	while($id= mysql_fetch_array($deposit))
	{
		$max = $id[0];
	}
			
    $max += 1;
	$my_t= date('Y');
    $depositNo = "DEP-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
}

//insert into bank_deposit_header
mysql_query("insert into bank_deposit_header(bank_deposit_no, bank_deposit_amount, ref_hdr_type, bank_account_id, bank_deposit_by_id, bank_id, bank_deposit_date) values('".$depositNo."',".$amount.", 'Cheque', ".$accountNo.",".$_SESSION['emp_id'].",".$bankId.", CURDATE())") or die(mysql_error());

$id = mysql_insert_id();

//insert on cash [GENERAL LEDGER]
// mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type, 
				// account_type_id, gl_deleted) values(CURDATE(), '".$depositNo."', ".$amount.", 1, 2, 'CHEQUE',
				// 1, 0)") or die(mysql_error());
				
//insert on cash in bank [GENERAL LEDGER]
mysql_query("insert into general_ledger(gl_date, gl_ref_no, gl_amount, account_category_id, account_sub_category_id, type, 
				account_type_id, gl_deleted) values(CURDATE(), '".$depositNo."', ".$amount.", 1, 8, 'CHEQUE',
				1, 0)") or die(mysql_error());
 		
echo $id;


?>