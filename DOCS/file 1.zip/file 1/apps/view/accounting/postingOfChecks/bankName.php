<?php
include("../../../../config/config.php");

$outputData = "";

$query = mysql_query("select bank_id, bank_name from bank where is_deleted = 0");

if(mysql_num_rows($query) > 0)
{
	while($arrBank = mysql_fetch_array($query))
	{
		$outputData .= "<option id=".$arrBank['bank_id'].">".$arrBank['bank_name']."</option>";
	}
}

echo $outputData;
?>