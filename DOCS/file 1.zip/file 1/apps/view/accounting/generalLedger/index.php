﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | General Ledger</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("General Ledger");
		
		$("#pdf").click(function(){
		window.open("../../view/reports/crm/crmMasterList.php","_new");
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<div id="body-pane"  style="height:200px">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="generalLedger" class="datagrid-container">
	<script>
		$('#generalLedger').load('../../../controller/accounting/generalLedgerController.php');
	</script>
</div>
</div>
</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

