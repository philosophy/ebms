<?php 
include("../../../../config/config.php");
$outputData = "";

$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " WHERE (GL_DATE LIKE '%".$searchQuery."%' or GL_REF_NO LIKE '%".$searchQuery."%' or GL_AMOUNT LIKE '%".$searchQuery."%' or ACCOUNT_CATEGORY_NAME LIKE '%".$searchQuery."%' or ACCOUNT_SUB_CATEGORY_NAME LIKE '%".$searchQuery."%' or TYPE LIKE '%".$searchQuery."%' or GL_SOURCE_DOC LIKE '%".$searchQuery."%' or ACCOUNT_TYPE_NAME LIKE '%".$searchQuery."%') ";
	}

elseif ($searchQuery == "")
	$condition = "";

include "../currency.php";
$cur_page = $page;
$page -= 1;
$per_page = 10;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;
$outputData .= "<table>
		<th class=icon></th>
		<th>GL Ref No</th>
		<th>Source Doc</th>
		<th>GL Date</th>
		<th>GL Amount (".$symbol.")</th>
		<th>Category</th>
		<th>Sub Category</th>
		<th>GL Type</th>
		<th>Account Type</th>";
		
$totalAmount = 0;

$query = "
	SELECT  GL_DATE ,  GL_ID ,  GL_REF_NO ,  GL_AMOUNT ,
				 ACCOUNT_CATEGORY_NAME ,  ACCOUNT_SUB_CATEGORY_NAME ,
				 TYPE ,  GL_SOURCE_DOC ,  ACCOUNT_TYPE_NAME ,  GL_DELETED  
	FROM  general_ledger  gl 
			inner join  account_category  ac on ac.account_category_id = gl.account_category_id
			inner join  account_sub_category  asub on asub.account_sub_category_id = gl.account_sub_category_id
			inner join  account_type  at on at.account_type_id = gl.account_type_id
	".$condition;
						
		$count = mysql_num_rows(mysql_query($query));
		$no_of_paginations = ceil($count / $per_page);
	
		$arrResult = mysql_query($query." limit $start,$per_page");

include "../currency.php";

						
if(mysql_num_rows($arrResult) >0)
{
	
		while($arrGL = mysql_fetch_array($arrResult))
		{

			$icon = "<img src='/ebms/images/icons/generalLedger.png'>";
			$outputData .= "<tr a=".$arrGL['GL_ID'].">";
			$outputData .= "<td class=icon>".$icon."</td>";
			$outputData .= "<td>".$arrGL['GL_REF_NO']."</td>";
			$outputData .= "<td>".$arrGL['GL_SOURCE_DOC']."</td>";
			$outputData .= "<td>".date("D M d, Y",strtotime($arrGL['GL_DATE']))."</td>";
			$outputData .= "<td style='text-align:right'>".number_format($arrGL['GL_AMOUNT'],2)."</td>";
			$outputData .= "<td>".$arrGL['ACCOUNT_CATEGORY_NAME']."</td>";
			$outputData .= "<td>".$arrGL['ACCOUNT_SUB_CATEGORY_NAME']."</td>";
			$outputData .= "<td>".$arrGL['TYPE']."</td>";
			$outputData .= "<td>".$arrGL['ACCOUNT_TYPE_NAME']."</td>";
			
		}
		
	$outputData .= "</table>";
}
else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrResult);
