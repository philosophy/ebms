<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	
	$query = mysql_query("Select * From ap_header Where AP_HDR_ID = '" . $id . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr['AP_HDR_CODE'];
	}
	
	echo $outputData;
?>