<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	
	$query = mysql_query("Select AP_DTL_ID, ACCOUNT_SUB_CATEGORY_NAME, AP_DTL_DESCRIPTION, AP_DTL_AMOUNT, AD.ACCOUNT_TYPE_ID  
							From ap_detail AD, account_sub_category ACSC 
							Where AD.ACCOUNT_TYPE_ID = ACSC.ACCOUNT_SUB_CATEGORY_ID and 
									AP_HDR_ID = '" . $id . "'");
	
	while ($arr = mysql_fetch_array($query))
	{
		$outputData .= "<tr a='" . $arr[0] . "' b='haha' c='" . $arr[2] . "' d='" . $arr[0] . "'>";
		$outputData .= 		"<td f='" . $arr[4] . "'>" . $arr[1] . "</td>";
		$outputData .= 		"<td g=''>" . $arr[2] . "</td>";
		$outputData .= 		"<td e='amount'>" . number_format($arr[3],2) . "</td>";
		$outputData .= "</tr>";
	}
	
	echo $outputData;
?>