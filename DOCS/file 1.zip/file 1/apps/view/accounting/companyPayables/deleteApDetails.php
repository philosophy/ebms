<?php
	include("../../../../config/config.php");
	
	$id = @$_POST['id'];
	
	$query = mysql_query("Delete From ap_detail Where AP_HDR_ID = '" . $id . "'");
?>