<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	include "../currency.php";

	$code = @$_POST['code'];
	$id = 0;
	
	$query = mysql_query("Select AP_HDR_ID From ap_header Where AP_HDR_CODE = '" . $code . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$id = $arr[0];
	}
	
	$query = mysql_query("Select AP_DTL_ID, AP_DTL_AMOUNT, AP_DTL_DESCRIPTION, ACCOUNT_TYPE_NAME, ACCOUNT_SUB_CATEGORY_NAME 
							From ap_detail AD, ap_header AH, account_type AT, account_sub_category ACSC 
							Where AD.AP_HDR_ID = AH.AP_HDR_ID and 
									AD.ACCOUNT_ID = AT.ACCOUNT_TYPE_ID and 
									AD.ACCOUNT_TYPE_ID = ACSC.ACCOUNT_SUB_CATEGORY_ID and 
									AD.AP_HDR_ID = '" . $id . "'");
									
	$outputData .= "<table>
						<th>Amount (".$symbol.")</th>
						<th>Description</th>
						<th>Account Type</th>
						<th>Entry Name</th>";
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<tr a='" . $arr['AP_DTL_ID'] . "'>";
			$outputData .= 		"<td align=right>" . number_format($arr['AP_DTL_AMOUNT'], 2) . "</td>";
			$outputData .= 		"<td>" . $arr['AP_DTL_DESCRIPTION'] . "</td>";
			$outputData .=		"<td>" . $arr['ACCOUNT_TYPE_NAME'] . "</td>";
			$outputData .= 		"<td>" . $arr['ACCOUNT_SUB_CATEGORY_NAME'] . "</td>";
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
	}
	else
	{
		include("../../noResults.php");
		$cur_page = 0;
	}
	
	echo $outputData;//.
	// $strSeparator.
		// "Page $cur_page of $no_of_paginations".
	// $strSeparator.
		// @$cur_page.
	// $strSeparator.
		// @$no_of_paginations; 
?>