<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$accountTypeId = @$_POST['accountType'];
	$desc = @$_POST['desc'];
	$amount = @$_POST['amount'];
	
	$latestApHdr = @$_POST['hdrId'];
	$accountId = 2;
	
	$query = mysql_query("Select max(AP_HDR_ID) From ap_header");
	while ($arr = mysql_fetch_array($query))
	{
		$latestApHdr = $arr[0];
	}
	
	$query = mysql_query("Insert Into ap_detail(AP_DTL_AMOUNT, AP_DTL_DESCRIPTION, AP_HDR_ID, ACCOUNT_ID, ACCOUNT_TYPE_ID) Values('" . 
							$amount . "', '" . 
							$desc . "', '" . 
							$latestApHdr . "', '" . 
							$accountId . "', '" . 
							$accountTypeId . "')") or die(mysql_error());
							
	$outputData = $amount . $desc . $latestApHdr . $accountId . $accountTypeId;
	
	// $query = mysql_query("Select AP_HDR_CODE From ap_header Where AP_HDR_ID = '" . $latestApHdr . "'");
	// while ($arr = mysql_fetch_array($query))
	// {
		// $latestApHdrCode = $arr[0];
	// }
	
	// $query = mysql_query("Select curdate()");
	// while ($arr = mysql_fetch_array($query))
	// {
		// $curDate = $arr[0];
	// }
	
	// $query = mysql_query("Insert Into general_ledger(GL_DATE, GL_ID, GL_REF_NO, GL_AMOUNT, ACCOUNT_CATEGORY_ID, ACCOUNT_SUB_CATEGORY_ID, TYPE, GL_SOURCE_DOC, ACCOUNT_TYPE_ID, GL_DELETED) Values('" . 
								// $curDate . "', null, '" . 
								// $latestApHdrCode . "', '" . 
								// $amount . "', '" . 
								// "2" . "', '" . //cash disbursement
								// $accountTypeId . "', '" . 
								// "AP" . "', '" . 
								// $latestApHdrCode . "', '" . 
								// "2" . "', '" . //liability
								// "0" . "')") or die(mysql_error());
	
	// echo $accountTypeId;
?>