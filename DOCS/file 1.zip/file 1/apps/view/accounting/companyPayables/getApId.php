<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$code = @$_POST['code'];
	
	$query = mysql_query("Select * From ap_header Where AP_HDR_CODE = '" . $code . "'") or die(mysql_error());
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr['AP_HDR_ID'];
	}
	
	echo $outputData;
?>