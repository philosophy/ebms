<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$amount = @$_POST['amount'];
	$dueDate = @$_POST['dueDate'];
	$toEdit = @$_POST['toEdit'];
	
	$query = mysql_query("Update ap_header Set AP_HDR_AMOUNT = '" . $amount . "', AP_HDR_DUE_DATE = '" . $dueDate . "' Where AP_HDR_ID = '" . $toEdit . "'");
	
	$query = mysql_query("Select AP_HDR_CODE From ap_header Where AP_HDR_ID = '" . $toEdit . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$toEditCode = $arr[0];
	}
	
	$query = mysql_query("Update general_ledger Set GL_AMOUNT = '" . $amount . "' Where GL_REF_NO = '" . $toEditCode . "'");
	
	echo $toEditCode;
?>