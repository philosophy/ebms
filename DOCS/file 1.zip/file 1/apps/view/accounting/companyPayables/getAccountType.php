<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$query = mysql_query("Select ACCOUNT_SUB_CATEGORY_ID, ACCOUNT_SUB_CATEGORY_NAME From account_sub_category Where ACCOUNT_TYPE_ID = '2'");
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<option value='" . $arr[0] . "'>" . $arr[1] . "</option>";
		}
	}
	else
	{
		$outputData = "<option value=''>No record found</option>";
	}
	
	echo $outputData;
?>