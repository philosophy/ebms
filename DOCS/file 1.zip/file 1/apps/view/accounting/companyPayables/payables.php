<?php 
include("../../../../config/config.php");
$outputData = "";

$strSeparator = "&";

include "../../accounting/currency.php";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " and (ah.ap_hdr_code LIKE '%".$searchQuery."%' or ah.ap_hdr_ref_type LIKE '%".$searchQuery."%' or ah.ap_hdr_ref_no LIKE '%".$searchQuery."%' or ah.ap_hdr_particular LIKE '%".$searchQuery."%' or ah.ap_hdr_date LIKE '%".$searchQuery."%' or ah.ap_hdr_due_date LIKE '%".$searchQuery."%' or ah.ap_hdr_amount LIKE '%".$searchQuery."%')";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 10;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;
$outputData .= "<table>
		<th>Trans. No.</th>
		<th>Doc. Ref. No.</th>
		<th>Particular</th>
		<th>Date</th>
		<th>Due Date</th>
		<th>Amount Due (".$symbol.")</th>
		<th>Balance (".$symbol.")</th>
		<th>Amount Paid (".$symbol.")</th>";
		
$totalAmount = 0;

$query = "SELECT ah.ap_hdr_code, ah.ap_hdr_ref_type, ah.ap_hdr_ref_no, ah.ap_hdr_particular,
						ah.ap_hdr_date, ah.ap_hdr_due_date, ah.ap_hdr_amount, is_deleted  
						FROM ap_header ah 
						WHERE AP_HDR_REF_TYPE != 'Expense' 
						".$condition." Order By ah.ap_hdr_code desc
						";
						
		$count = mysql_num_rows(mysql_query($query));
		$no_of_paginations = ceil($count / $per_page);
	
		$arrResult = mysql_query($query." limit $start,$per_page");
	
						
if(mysql_num_rows($arrResult) >0)
{
	
		while($arrPayables = mysql_fetch_array($arrResult))
		{
			$x = (($arrPayables['is_deleted']==1)?"deleted=true":"deleted=false");
			
			$paid = mysql_query("SELECT payment_amount FROM payment WHERE payment_ref_type = 'AP'
									AND payment_ref_no = '".$arrPayables['ap_hdr_code']."'");
			if(mysql_num_rows($paid) > 0)
			{
				$totalAmount = 0;
				
				$outputData .= "<tr ".$x." a=".$arrPayables['ap_hdr_code']." b='paid' c=" . $arrPayables['is_deleted'] . ">";
				$outputData .= "<td>".$arrPayables['ap_hdr_code']."</td>";
				$outputData .= "<td>".$arrPayables['ap_hdr_ref_no']."</td>";
				$outputData .= "<td>".$arrPayables['ap_hdr_particular']."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime($arrPayables['ap_hdr_date']))."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime($arrPayables['ap_hdr_due_date']))."</td>";
				$outputData .= "<td align=right>".number_format($arrPayables['ap_hdr_amount'], 2)."</td>";
				
				//PAYMENT BALANCE
				$paid = mysql_query("SELECT payment_amount FROM payment WHERE payment_ref_type = 'AP'
										AND payment_ref_no = '".$arrPayables['ap_hdr_code']."'");
				if(mysql_num_rows($paid) > 0)
				{
					while($amountPaid = mysql_fetch_array($paid))
					{
						$totalAmount += $amountPaid['payment_amount'];
					}
					$outputData .= "<td align=right>". number_format($arrPayables['ap_hdr_amount'] - $totalAmount, 2)."</td>";
				}
				else
				{
					$outputData .= "<td align=right>" . number_format($arrPayables['ap_hdr_amount'], 2) . "</td>";
				}
				
				//PAYMENT AMOUNT PAID
				//$balance = $arrPayables['ap_hdr_amount'] - $totalAmount;
				$outputData .= "<td align=right>" . number_format($totalAmount, 2) . "</td>";
				$outputData .= "</tr>";
			}
			else
			{
				$totalAmount = 0;
				
				$outputData .= "<tr a=".$arrPayables['ap_hdr_code']." b='' c='" . $arrPayables['is_deleted'] . "'>";
				$outputData .= "<td>".$arrPayables['ap_hdr_code']."</td>";
				$outputData .= "<td>".$arrPayables['ap_hdr_ref_no']."</td>";
				$outputData .= "<td>".$arrPayables['ap_hdr_particular']."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime($arrPayables['ap_hdr_date']))."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime($arrPayables['ap_hdr_due_date']))."</td>";
				$outputData .= "<td align=right>".number_format($arrPayables['ap_hdr_amount'], 2)."</td>";
				
				//PAYMENT BALANCE
				$paid = mysql_query("SELECT payment_amount FROM payment WHERE payment_ref_type = 'AP'
										AND payment_ref_no = '".$arrPayables['ap_hdr_code']."'");
				if(mysql_num_rows($paid) > 0)
				{
					while($amountPaid = mysql_fetch_array($paid))
					{
						$totalAmount += $amountPaid['payment_amount'];
					}
					$outputData .= "<td align=right>".number_format($totalAmount, 2)."</td>";
				}
				else
				{
					$outputData .= "<td align=right>" . number_format($arrPayables['ap_hdr_amount'], 2) . "</td>";
				}
				
				//PAYMENT AMOUNT PAID
				//$balance = $arrPayables['ap_hdr_amount'] - $totalAmount;
				$outputData .= "<td align=right>" . number_format($totalAmount, 2) . "</td>";
				$outputData .= "</tr>";
			}
		}
		
	$outputData .= "</table>";
}
else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrResult);
