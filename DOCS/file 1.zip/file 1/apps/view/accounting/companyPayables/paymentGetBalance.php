<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	$code = @$_POST['code'];
	
	$query = mysql_query("Select * From ap_header Where AP_HDR_ID = '" . $id . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$amount = $arr['AP_HDR_AMOUNT'];
	}
	
	$query = mysql_query("Select sum(PAYMENT_AMOUNT) From payment Where PAYMENT_REF_NO = '" . $code . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$amountPaid = $arr[0];
	}
	
	$outputData = $amount - $amountPaid;
	
	echo $outputData;
?>