﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Company Payables</title>
<?php include("../../standard-js-css.php"); ?>
<script>
	$(function(){
		headTitle("Company Payables");		
		datagrid("company-payables;companyPayment",true);
		datagridMenu("payables","new;edit;delete;restore");
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
		$("#pdf").click(function(){
		window.open("../../../view/reports/accounting/companyPayables.php","_new");
		});
	
});
</script>
</head>
<body>
	<div id="header-pane">
		
		<?php 
		#Include top navigation pane
			include("../../orb/orb-top-nav.php");
		?>
		
	</div>

	<?php
		include("../../modalForms/accounting/accountPayables/index.php");
		include("../../modalForms/accounting/index.php");
	?>

	<div id="body-pane">
	<div id="body-content-container">
	<?php include("../../datagrid-options.php"); ?>
	<div id="company-payables" class="datagrid-container">
		<!-- PAYABLES LIST -->
		<script>
			$('#company-payables').load('../../../controller/accounting/payablesController.php');
		</script>
	</div>
	</div>

	<div id="tabbed-grid"> 
		<ul> 
			<li><a href="#apDetail">Details</a></li>
			<li><a href="#companyPayment">Payment History</a></li>
			<li>
				<button id="custPayment" class="callModalForm" ref="new_custPayment" onclick="callModal('#custPayment')" style="width:50px; height:30px; font-size:11px;color:#333;text-shadow:0 0 1px #fff;-webkit-box-shadow:0 0 0 transparent;" title="Post Payment"></button>
				<script>
				$( "button#custPayment" ).button({
				icons: {
					primary: "ui-icon-circle-plus"
				},
				text:false
				});
				</script>
			</li>
		</ul> 
		
		<div id="apDetail"> 
			Please select payable/s above
		</div> 
		
		<div id="companyPayment"> 
			<div id="paymentHistoryGrid">
				Please select customer/s above
			</div>
		</div>
		
		<!--<div class="tabButtonPanel" style="position:absolute;left:215px;margin-top:-74px">
			
		</div>-->
		 
	</div> 

	</div>
	<?php include("../../footer-view.php"); ?>

</body>
</html>

