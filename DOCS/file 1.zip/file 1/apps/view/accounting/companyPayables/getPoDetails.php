<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	
	$query = mysql_query("Select PO_DTL_QTY as 'qty', 
								 ITEM_CODE as 'itemCode', 
								 PO_DTL_ITEM_DESCRIPTION as 'desc',
								 PRODUCT_IMAGE as 'img'
						  From product p, po_header ph, po_detail pd 
						  Where ph.PO_HDR_ID = pd.PO_HDR_ID and 
								P.PRODUCT_CODE = pd.ITEM_CODE and 
								pd.PO_HDR_ID = '" . $id . "'");
								
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<li id='gridViewList'> 
							<a href='#' id='gridViewLink' qty='" . $arr[0] . "' itemCode='" . $arr[1] . "' desc='" . $arr[2] . "'>
								<img src='/ebms/images/stock/".(($arr['img']=='')?'default.png':$arr['img'])."'>
							</a>
							</li>";
		}
	}
	else
	{
		$outputData = "No items found";
	}
	
	echo $outputData;
?>