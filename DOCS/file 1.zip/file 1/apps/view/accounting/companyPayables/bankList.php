<?php 
include("../../../../config/config.php");

$outputData = "";

$query = mysql_query("select bank_id, bank_name, bank_address from bank where is_deleted = 0");

if(mysql_num_rows($query) > 0)
{
	while($arrBank = mysql_fetch_array($query))
	{
		$outputData .= "<option bankId=".$arrBank['bank_id']." bankAddress='".$arrBank['bank_address']."'>".$arrBank['bank_name']."</option>";
	}
}

echo $outputData;