<?php
	session_start();
	include("../../../../config/config.php");
	
	$empId = $_SESSION['emp_id'];
	
	$outputData = "";
	
	$amount = @$_POST['amount'];
	$dueDate = @$_POST['dueDate'];
	$poId = @$_POST['poId'];
	
	$maxId = 0;
	$zeros = "000000";
	$year = "";
	$curDate = "";
	$particular = "Unpaid";
	
	$query = mysql_query("Select max(AP_HDR_ID) From ap_header");
	while ($arr = mysql_fetch_array($query))
	{
		$maxId = $arr[0];
	}
	
	$maxId += 1;
	
	$query = mysql_query("Select year(curdate())");
	while ($arr = mysql_fetch_array($query))
	{
		$year = $arr[0];
	}
	
	$apHdrNo = "AP-" . $year . "-" . substr($zeros, 0, strlen($zeros) - strlen($maxId)) . $maxId;
	
	$query = mysql_query("Select curdate()");
	while ($arr = mysql_fetch_array($query))
	{
		$curDate = $arr[0];
	}
	
	$query = mysql_query("Select * From po_header Where PO_HDR_ID = '" . $poId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$poCode = $arr['PO_HDR_NO'];
	}
	
	$query = mysql_query("Insert Into ap_header(AP_HDR_CODE, AP_HDR_AMOUNT, AP_HDR_DATE, AP_HDR_DUE_DATE, AP_HDR_PARTICULAR, AP_HDR_CREATED_BY_ID, AP_HDR_REF_NO, AP_HDR_REF_TYPE) Values('" .
								$apHdrNo . "', '" . 
								$amount . "', '" . 
								$curDate . "', '" . 
								$dueDate . "', '" . 
								$particular . "', '" . 
								$empId . "', '" . 
								$poCode . "', '" . 
								"AP" . "')") or die(mysql_error());
								
	$query = mysql_query("Select max(AP_HDR_ID) From ap_header");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	$query = mysql_query("Insert Into general_ledger(GL_DATE, GL_ID, GL_REF_NO, GL_AMOUNT, ACCOUNT_CATEGORY_ID, ACCOUNT_SUB_CATEGORY_ID, TYPE, GL_SOURCE_DOC, ACCOUNT_TYPE_ID, GL_DELETED) Values('" . 
								$curDate . "', null, '" . 
								$apHdrNo . "', '" . 
								$amount . "', '" . 
								"2" . "', '" . //cash disbursement
								"4" . "', '" . 
								"AP" . "', '" . 
								$apHdrNo . "', '" . 
								"2" . "', '" . //liability
								"0" . "')") or die(mysql_error());
	
	$query = mysql_query("Insert Into general_ledger(GL_DATE, GL_ID, GL_REF_NO, GL_AMOUNT, ACCOUNT_CATEGORY_ID, ACCOUNT_SUB_CATEGORY_ID, TYPE, GL_SOURCE_DOC, ACCOUNT_TYPE_ID, GL_DELETED) Values('" . 
								$curDate . "', null, '" . 
								$apHdrNo . "', '" . 
								$amount . "', '" . 
								"2" . "', '" . //cash disbursement
								"12" . "', '" . 
								"AP" . "', '" . 
								$apHdrNo . "', '" . 
								"1" . "', '" . //liability
								"0" . "')") or die(mysql_error());
								
	// echo $apHdrNo;
?>