<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	
	$apId = 0;
	
	$query = mysql_query("Select * From account_sub_category Where ACCOUNT_SUB_CATEGORY_NAME = 'Accounts Payable'");
	while ($arr = mysql_fetch_array($query))
	{
		$apId = $arr['ACCOUNT_SUB_CATEGORY_ID'];
	}
	
	$query = mysql_query("Select format(PO_HDR_NET_AMOUNT,2) From po_header Where PO_HDR_ID = '" . $id . "'");
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<tr a='" . $id . "' b=''>";
			$outputData .= "<td id='accountType' a='" . $apId . "'>Accounts Payable</td>";
			$outputData .= "<td id='desc'>PO</td>";
			$outputData .= "<td id='amount'>" . $arr[0] . "</td>";
		}
	}
	else
	{
		$outputData = "No record(s) found";
	}
	
	echo $outputData;
?>