<?php 
include("../../../../config/config.php");

$outputData = "";
$bankId = $_POST['bankId'];
$accountType = $_POST['accountType'];

$query = mysql_query("select bank_account_id, bank_account_no, bank_account_name from bank_account where bank_id =".$bankId." and 
						bank_account_type='".$accountType."'");

if(mysql_num_rows($query) > 0)
{
	while($arrAccounts = mysql_fetch_array($query))
	{
		$outputData .= "<option accountNo='".$arrAccounts['bank_account_no']."' accountId=".$arrAccounts['bank_account_id']." 
						accountName='".$arrAccounts['bank_account_name']."'>".$arrAccounts['bank_account_no']."</option>";
	}
}

echo $outputData;

?>