<?php
	include("../../../../config/config.php");
	
	$id = @$_POST['id'];
	
	$query = mysql_query("Update ap_header Set IS_DELETED = '0' Where AP_HDR_ID = '" . $id . "'");
	
	$query = mysql_query("Select AP_HDR_CODE From ap_header Where AP_HDR_ID = '" . $id . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$toEditCode = $arr[0];
	}
	
	$query = mysql_query("Update general_ledger Set GL_DELETED = '0' Where GL_REF_NO = '" . $toEditCode . "'");
?>