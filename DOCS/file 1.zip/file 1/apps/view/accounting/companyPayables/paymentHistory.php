<?php 
include("../../../../config/config.php");

$apCode = @$_POST['apCode'];

include "../../accounting/currency.php";

$outputData = "";
			
$payment = mysql_query("SELECT p.payment_ref_no, p.payment_type, p.payment_amount, p.payment_date, 
						e.emp_first_name, e.emp_middle_name, e.emp_last_name
						FROM payment p INNER JOIN employee_profile e ON p.payment_created_by_id = e.emp_id
						WHERE payment_ref_type = 'AP' AND payment_ref_no = '".$apCode."'");
									
if(mysql_num_rows($payment) > 0)
{
	$outputData .= "<table>
			<th>Transaction No.</th>
			<th>Payment</th>
			<th>Amount Paid (".$symbol.")</th>
			<th>Date</th>
			<th>Created By</th>";
	
	while($paymentHistory = mysql_fetch_array($payment))
	{
		$outputData .= "<tr>";
		$outputData .= "<td>".$paymentHistory['payment_ref_no']."</td>";
		$outputData .= "<td>".ucfirst($paymentHistory['payment_type'])."</td>";
		$outputData .= "<td align=right>".number_format($paymentHistory['payment_amount'], 2)."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($paymentHistory['payment_date']))."</td>";
		$outputData .= "<td>".$paymentHistory['emp_first_name']." ".$paymentHistory['emp_middle_name']." ".$paymentHistory['emp_last_name']."</td>";
	}
	
	$outputData .= "</table>";
}
else
{
	$outputData = "No results found.";
}

echo $outputData;
?>