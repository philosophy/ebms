<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$rowId = @$_POST['rowId'];
	$accountTypeId = @$_POST['accountTypeId'];
	$amount = @$_POST['amount'];
	$desc = @$_POST['desc'];
	
	$accountType = "";
	
	$query = mysql_query("Select ACCOUNT_SUB_CATEGORY_NAME From account_sub_category Where ACCOUNT_SUB_CATEGORY_ID = '" . $accountTypeId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$accountType = $arr[0];
	}
	
	$outputData .= "<tr a='' b='" . $rowId . "' c='' d='" . $rowId . "'>";
	$outputData .= "<td f='" . $accountTypeId . "'>" . $accountType . "</td>";
	$outputData .= "<td g=''>" . $desc . "</td>";
	$outputData .= "<td e='amount'>" . $amount . "</td>";
	
	echo $outputData;
?>