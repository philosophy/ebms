<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$accountTypeId = @$_POST['accountType'];
	$desc = @$_POST['desc'];
	$amount = @$_POST['amount'];
	
	$toEdit = @$_POST['toEdit'];
	$accountId = 2;
	
	$query = mysql_query("Insert Into ap_detail(AP_DTL_AMOUNT, AP_DTL_DESCRIPTION, AP_HDR_ID, ACCOUNT_ID, ACCOUNT_TYPE_ID) Values('" . 
							$amount . "', '" . 
							$desc . "', '" . 
							$toEdit . "', '" . 
							$accountId . "', '" . 
							$accountTypeId . "')") or die(mysql_error());
							
	$outputData = $amount . $desc . $toEdit . $accountId . $accountTypeId;
	
	echo $outputData;
?>