<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$query = mysql_query("Select PO_HDR_ID, PO_HDR_NO, PO_HDR_DATE_NEEDED, PO_HDR_PAYMENT_TYPE, format(PO_HDR_NET_AMOUNT,2) From po_header");
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<tr a='" . $arr[0] . "'>";
			$outputData .= "<td>" . $arr[1] . "</td>";
			$outputData .= "<td>" . $arr[2] . "</td>";
			$outputData .= "<td>" . $arr[3] . "</td>";
			$outputData .= "<td>" . $arr[4] . "</td>";			
		}
	}
	else
	{
		$outputData = "No record(s) found";
	}
	
	echo $outputData;
?>