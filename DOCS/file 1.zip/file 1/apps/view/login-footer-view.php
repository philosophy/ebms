<div id="login-footer">
	<span>Powered By: <img src="../../../images/ebms-logo-mini.png">SME Soft, INC. | EBMS Beta v1 | © <?php echo date("Y"); ?> Copyright. All Rights Reserved</span>
	
	<div id="external-links">
	<b>Connect with us</b>
	<ul class="icon-pages-list">
	
	<li>
	<a href="http://plus.google.com" target="_new" title="+1'd us on Google Plus">
	<img alt="Google Plus" src="../../../images/icons/google-plus.png">
	</a>
	</li>
	
	<li>
	<a href="http://www.facebook.com/pages/SMESoft-Inc/163321967068616" target="_new" title="Like us on Facebook">
	<img alt="Facebook" src="../../../images/icons/fb-icon.png">
	</a>
	</li>
	
	<li>
	<a href="http://twitter.com/smesoft" target="_new" title="Follow us on Twiiter">
	<img alt="Twitter" src="../../../images/icons/twitter-icon.png">
	</a>
	</li>
	
	</ul>
	</div>
	
</div>
