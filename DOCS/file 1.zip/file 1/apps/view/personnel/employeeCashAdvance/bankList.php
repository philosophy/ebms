<?php
include("../../../../config/config.php");

$acctID = $_POST['acctID'];

$query = "SELECT b.BANK_ID AS 'id', BANK_NAME AS 'name' FROM bank b INNER JOIN bank_account ba ON ba.BANK_ID=b.BANK_ID WHERE ba.BANK_ACCOUNT_ID='".$acctID."'";
$result = mysql_query($query);
$bankList = '';
while($record = mysql_fetch_array($result))
{
    $bankList .= "<option value='".$record['id']."'>".$record['name']."</option>";
}
echo $bankList;
?>