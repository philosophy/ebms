<?php
include("../../../../config/config.php");

$caID = $_POST['id'];
$payAmt = $_POST['payAmt'];
$payType = $_POST['payType'];
$remarks = $_POST['remarks'];

	mysql_query("UPDATE employee_cash_advance SET EMP_CASH_AMOUNT='$payAmt', EMP_CASH_REMARKS='$remarks' WHERE EMP_CASH_ID='".$caID."'");

if ($payType == "CHECK")
{
	$checkQuery = mysql_query("SELECT CHECK_ID as 'check' FROM employee_cash_advance WHERE EMP_CASH_ID='".$caID."'");
	$checkID = mysql_fetch_array($checkQuery);
	
	 mysql_query("UPDATE check_profile SET CHECK_AMOUNT='$payAmt' WHERE CHECK_ID = '".$checkID['check']."'");
}
echo $caID.$payAmt.$payType;


?>