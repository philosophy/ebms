<?php
include("../../../../config/config.php");

$query = "SELECT BANK_ACCOUNT_ID AS 'id', BANK_ACCOUNT_NAME AS 'name' FROM bank_account";
$result = mysql_query($query);
$accountList = '';
while($record = mysql_fetch_array($result))
{
    $accountList .= "<option value='".$record['id']."'>".$record['name']."</option>";
}
echo $accountList;
?>