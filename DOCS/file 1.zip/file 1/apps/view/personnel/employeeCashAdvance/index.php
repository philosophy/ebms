﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Employee Cash Advance</title>
<?php include("../../standard-js-css.php"); 
?>
<script>
	$(function(){
		headTitle("Cash Advance");
		datagrid("cash-advance",true);
		datagrid("itemDetails",false);
		datagridMenu("cashAdvance","new;edit;delete;restore");
		$("#tabbed-grid").tabs();
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>

<?php 
include("../../modalForms/personnel/index.php"); 
?>
<div id="body-pane" style="height:70px;">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="cash-advance" class="datagrid-container">
	<script>
		$('#cash-advance').load('../../../controller/employeeCashAdvance/employeeCashAdvanceController.php');
	</script>
</div>
</div>
<!--<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#itemDetails">Item Details</a></li> 
	</ul> 
	<div id="itemDetails"> 

		
	</div> 
</div> -->

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

