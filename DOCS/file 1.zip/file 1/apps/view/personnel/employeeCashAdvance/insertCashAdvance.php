<?php
session_start();
include("../../../../config/config.php");

$user = $_SESSION['login'];
$empID = $_POST['empID'];
$remarks = $_POST['remarks'];
$payType = $_POST['payType'];
$payAmt = $_POST['payAmt'];
$bankID = $_POST['bankID'];
$acctNo = $_POST['acctNo'];
$checkType = $_POST['checkType'];
$checkInOut = $_POST['checkInOut'];
$checkDateIssue = $_POST['checkDateIssue'];
$checkDueDate = $_POST['checkDueDate'];
$checkNo = $_POST['checkNo'];
$acctName = $_POST['acctName'];

$zeros = "000000";

$countQuery = "SELECT COUNT(EMP_CASH_ID) FROM employee_cash_advance";
$countResult = mysql_query($countQuery);

$acctQuery = mysql_query("SELECT BANK_ACCOUNT_NAME AS 'acctName' FROM bank_account WHERE BANK_ACCOUNT_ID='".$acctName."'");
$actName = mysql_fetch_array($acctQuery);

if (mysql_num_rows($countResult) == 0)
{
	$caCode = "VCH-".date("Y")."-000001";
}
else
{
	$maxQuery = "SELECT MAX(EMP_CASH_ID) as 'max' FROM employee_cash_advance";
	$maxResult = mysql_query($maxQuery);
	$max = mysql_fetch_array($maxResult);
	$max['max'] += 1;
	$caCode = "VCH-".date("Y")."-".substr($zeros, 0, 6 - strlen($max['max'])).$max['max'];
}

if ($payType == "CASH")
{
	$query = mysql_query("INSERT INTO employee_cash_advance(EMP_CASH_CODE, EMP_CASH_DATE, EMP_CASH_AMOUNT, EMP_CASH_PAYMENT_TYPE, EMP_CASH_REMARKS, EMP_ID) VALUES ('$caCode',curdate(),'$payAmt','$payType','$remarks','$empID')");
}
else if ($payType == "CHECK")
{
	$query = mysql_query("INSERT INTO check_profile(CHECK_NO, CHECK_DUE_DATE, CHECK_DATE_ISSUED, CHECK_AMOUNT, CHECK_TYPE, CHECK_ACCOUNT_NO, CHECK_ACCOUNT_NAME, CHECK_REF_HDR_TYPE, CHECK_REF_NO, BANK_ID, CUSTOMER_ID, FLAG, CREATED_BY_ID) VALUES ('$checkNo','$checkDueDate','$checkDateIssue','$payAmt','$checkType','$acctNo','".$actName['acctName']."','CA','$caCode','$bankID','$empID','E','$user')");
	
	$maxCheck = mysql_query("SELECT MAX(CHECK_ID) as 'max' FROM check_profile");
	$checkID = mysql_fetch_array($maxCheck);

	$query = mysql_query("INSERT INTO employee_cash_advance(EMP_CASH_CODE, EMP_CASH_DATE, EMP_CASH_AMOUNT, EMP_CASH_PAYMENT_TYPE, EMP_CASH_REMARKS, EMP_ID, CHECK_ID) VALUES ('$caCode',curdate(),'$payAmt','$payType','$remarks','$empID','".$checkID['max']."')");
}

?>