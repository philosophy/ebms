<?php
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE concat(e.emp_first_name,' ',left(e.emp_middle_name,1),'. ',e.emp_last_name) LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 10;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;
$outputData = "<table >
			<th class=icon></th>
			<th >Code</th>
			<th >Employee Name</th>
			<th >Date Requested</th>
			<th>Payment Type</th>
			<th>Amount</th>
			<th >Status</th>
			<th >Remarks</th>";
				
				$query = "SELECT EMP_CASH_ID, EMP_CASH_CODE, CONCAT( e.emp_first_name,  ' ', e.emp_middle_name,  ' ', e.emp_last_name ) AS  'Name', date_format(EMP_CASH_DATE,'%b-%d-%Y') as 'requested',  EMP_CASH_PAYMENT_TYPE, EMP_CASH_AMOUNT, EMP_CASH_STATUS, EMP_CASH_REMARKS,  EMP_CASH_APPROVED_BY_ID, eca.IS_DELETED FROM employee_cash_advance eca
				INNER JOIN employee_profile e ON eca.EMP_ID = e.EMP_ID ".$condition." ORDER BY EMP_CASH_APPROVED_BY_ID";

	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$result = mysql_query($query." limit $start,$per_page");

	
	if(mysql_num_rows($result) > 0)
	{		
	while($arrPR = mysql_fetch_array($result))
	{
	$x = (($arrPR['IS_DELETED']==1)?"deleted=true":"deleted=false");
	
		$outputData .= "<tr ".$x." a=".$arrPR['EMP_CASH_ID'].">";
		if($arrPR['EMP_CASH_APPROVED_BY_ID'] == null)
		{
			$outputData .= "<td class=icon><img title='Click here to approve cash advance' class='pr_approve' a=".$arrPR['EMP_CASH_ID']." src='/EBMS/images/icons/approved_icon.png'></td>";
		}
		else
		{
			$outputData .= "<td class=icon><img title='Approved cash advance' class='approved' src='/EBMS/images/icons/checkIcon.png'></td>";
		}

		$outputData .= "<td >".$arrPR['EMP_CASH_CODE']."</td>";
		$outputData .= "<td >".$arrPR['Name']."</td>";
		$outputData .= "<td >".date("D M d, Y",strtotime($arrPR['requested']))."</td>";
		$outputData .= "<td >".$arrPR['EMP_CASH_PAYMENT_TYPE']."</td>";
		$outputData .= "<td >".$arrPR['EMP_CASH_AMOUNT']."</td>";
		$outputData .= "<td >".$arrPR['EMP_CASH_STATUS']."</td>";
		$outputData .= "<td >".$arrPR['EMP_CASH_REMARKS']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	
	else
	{
	include("../../../view/noResults.php");
	$cur_page = 0;
	}

	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($result);