<?php
session_start();
include("../../../../config/config.php");

$caID = $_POST['caID'];
$cashAdvance[] = "";
$check[] = "";

$query = mysql_query("SELECT EMP_CASH_CODE, EMP_CASH_DATE, EMP_CASH_AMOUNT, EMP_CASH_PAYMENT_TYPE, EMP_CASH_REMARKS, CONCAT( e.emp_first_name,  ' ', e.emp_middle_name,  ' ', e.emp_last_name ) AS 'Name', CHECK_ID FROM employee_cash_advance eca INNER JOIN employee_profile e ON eca.EMP_ID = e.EMP_ID WHERE EMP_CASH_ID='".$caID."'");


$arrCA = mysql_fetch_array($query);

	$cashAdvance['code'] = $arrCA['EMP_CASH_CODE'];
	$cashAdvance['date'] = $arrCA['EMP_CASH_DATE'];
	$cashAdvance['remarks'] = $arrCA['EMP_CASH_REMARKS'];
	$cashAdvance['payType'] = $arrCA['EMP_CASH_PAYMENT_TYPE'];
	$cashAdvance['payAmount'] = $arrCA['EMP_CASH_AMOUNT'];
	$cashAdvance['checkID'] = $arrCA['CHECK_ID'];
	$cashAdvance['empName'] = $arrCA['Name'];
	
$query2 = mysql_query("SELECT CHECK_NO, CHECK_DUE_DATE, CHECK_DATE_ISSUED, CHECK_TYPE, CHECK_ACCOUNT_NO, CHECK_ACCOUNT_NAME, b.BANK_NAME as 'bankName' FROM check_profile cp INNER JOIN bank b ON cp.BANK_ID = b.BANK_ID WHERE CHECK_ID ='".$cashAdvance['checkID']."'");

$arrCheck = mysql_fetch_array($query2);

	$check['code'] = $arrCheck['CHECK_NO'];
	$check['dueDate'] = $arrCheck['CHECK_DUE_DATE'];
	$check['issueDate'] = $arrCheck['CHECK_DATE_ISSUED'];
	$check['checkType'] = $arrCheck['CHECK_TYPE'];
	$check['acctNo'] = $arrCheck['CHECK_ACCOUNT_NO'];
	$check['acctName'] = $arrCheck['CHECK_ACCOUNT_NAME'];
	$check['bankName'] = $arrCheck['bankName'];


$dataCA = json_encode(array("ca"=>$cashAdvance, "check"=>$check));
echo $dataCA;
?>