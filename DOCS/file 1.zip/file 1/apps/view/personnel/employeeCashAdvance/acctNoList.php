<?php
include("../../../../config/config.php");

$acctID = $_POST['acctID'];

$query = "SELECT BANK_ACCOUNT_ID AS 'id', BANK_ACCOUNT_NO AS 'name' FROM bank_account WHERE BANK_ACCOUNT_ID='".$acctID."'";
$result = mysql_query($query);
$bankList = '';
while($record = mysql_fetch_array($result))
{
    $bankList .= "<option value='".$record['name']."'>".$record['name']."</option>";
}
echo $bankList;
?>