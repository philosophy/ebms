﻿<?php

include("../../../../config/config.php");


$PayEmpID = @$_POST['PayEmpID'];
$PayrollID = @$_POST['PayrollID'];

$role = @$_POST['role'];
$pDateFrom = @$_POST['pDateFrom'];
$pDateTo = @$_POST['pDateTo'];
$pBasicSal = @$_POST['pBasicSal'];
$pDailyRate = @$_POST['pDailyRate'];
$pHourlyRate = @$_POST['pHourlyRate'];
$pMinutesRate = @$_POST['pMinutesRate'];
$pOverRate = @$_POST['pOverRate'];
$pOverMin = @$_POST['pOverMin'];
$pRegHol = @$_POST['pRegHol'];
$pAllow = @$_POST['pAllow'];
$pDaysWork = @$_POST['pDaysWork'];
$pHoursWork = @$_POST['pHoursWork'];
$pMinsWork = @$_POST['pMinsWork'];
$pTotalEarns = @$_POST['pTotalEarns'];
$pWithTax = @$_POST['pWithTax'];
$pWithTaxPer = @$_POST['pWithTaxPer'];
$pTotalLeave = @$_POST['pTotalLeave'];
$pCompLoan = @$_POST['pCompLoan'];
$pTotalDed = @$_POST['pTotalDed'];
$pCashAd = @$_POST['pCashAd'];
$pNetPay = @$_POST['pNetPay'];
$pDeptID = @$_POST['pDeptID'];
$pEmpID = @$_POST['pEmpID'];
$_SESSION['pEmpID'] = $pEmpID;

$LeaveID = "";
$pLeaveID =  array();

$oearn = @$_POST['oearn'];
$oearnArray =  array();
$oded = @$_POST['oded'];
$odedArray =  array();

$outputData = "";

function selectPayrollID()
{
	$selPID = mysql_query("Select payroll_id from payroll where emp_id=".$_SESSION['pEmpID']." and payroll_date=curdate() order by payroll_id desc");
	$row = mysql_fetch_array($selPID);
	return $row[0];
}

if($role == "new")
{
	$query = mysql_query("INSERT INTO payroll(PAYROLL_DATE,PAYROLL_DATE_FROM,PAYROLL_DATE_TO,  
											  PAYROLL_BASIC_SALARY,PAYROLL_DAILY_RATE,PAYROLL_HOURLY_RATE,
		                                      PAYROLL_MINUTES_RATE,PAYROLL_OVERTIME_RATE,
											  PAYROLL_OVERTIME_MINUTES,PAYROLL_REGULAR_HOLIDAY,
											  PAYROLL_ALLOWANCE,PAYROLL_DAYS_WORK,
											  PAYROLL_HOURS_WORK,PAYROLL_MINUTES_WORK,PAYROLL_TOTAL_EARNINGS,
											  PAYROLL_WITHOLDING_TAX,PAYROLL_WITHOLDING_PERCENT,
											  PAYROLL_TOTAL_LEAVE,PAYROLL_COMPANY_LOAN,PAYROLL_TOTAL_DEDUCTIONS,
											  PAYROLL_CASH_ADVANCE_DEDUCTIONS,PAYROLL_NET_PAY,DEPT_ID,EMP_ID) 
											  VALUES(curdate(),'$pDateFrom','$pDateTo','$pBasicSal',
											  '$pDailyRate','$pHourlyRate','$pMinutesRate','$pOverRate',
											  '$pOverMin','$pRegHol','$pAllow','$pDaysWork','$pHoursWork',
											  '$pMinsWork','$pTotalEarns','$pWithTax','$pWithTaxPer','$pTotalLeave','$pCompLoan',
											  '$pTotalDed','$pCashAd','$pNetPay','$pDeptID','$pEmpID')");
	
	$pid = selectPayrollID();
	session_start();
	$_SESSION['payrollIdReport'] = $pid;
	if(@$_POST['pLeaveID']!="" || @$_POST['pLeaveID']!=null)
	{
		$LeaveID = substr(@$_POST['pLeaveID'],0,-1);			
		$pLeaveID = explode("|",$LeaveID);
		
		for($p=0;$p<count($pLeaveID);$p++)
		{
			$query = mysql_query("UPDATE leaves SET is_flag=1,payroll_id=".$pid." Where leave_id=".$pLeaveID[$p]);
		}
	}
		$oearn = substr($oearn,0,-1);
		$oearnArray = explode("|",$oearn);
		for($eArry=0;$eArry<count($oearnArray);$eArry++)
		{
			$query = mysql_query("INSERT INTO payroll_earning(PAYROLL_EARNING_DESC,PAYROLL_EARNING_AMOUNT,
			PAYROLL_ID) VALUES('".$oearnArray[$eArry]."',".$oearnArray[$eArry+1].",".$pid.")");	
			$eArry++;
		}

		$oded = substr($oded,0,-1);
		$odedArray = explode("|",$oded);
		for($oArry=0;$oArry<count($odedArray);$oArry++)
		{
			$query = mysql_query("INSERT INTO payroll_deduction(PAYROLL_DEDUCTION_DESC,
			PAYROLL_DEDUCTION_AMOUNT,PAYROLL_ID) VALUES('".$odedArray[$oArry]."',".$odedArray[$oArry+1].
			",".$pid.")");	
			$oArry++;
		}
	
	$query = mysql_query("UPDATE overtime SET is_flag=1 Where (overtime_date between '$pDateFrom' and '$pDateTo') and emp_id='$pEmpID'");
	$query = mysql_query("UPDATE employee_cash_advance SET is_flag=1 Where (emp_cash_date between '$pDateFrom' and '$pDateTo') and emp_id='$pEmpID'");
	
	echo 'new';
}

else if($role == "edit")
{
	$query = mysql_query("UPDATE payroll SET PAYROLL_REGULAR_HOLIDAY='$pRegHol',
							PAYROLL_ALLOWANCE='$pAllow',PAYROLL_TOTAL_EARNINGS='$pTotalEarns',
							PAYROLL_WITHOLDING_TAX='$pWithTax',PAYROLL_WITHOLDING_PERCENT='$pWithTaxPer',
							PAYROLL_TOTAL_LEAVE='$pTotalLeave',
							PAYROLL_COMPANY_LOAN='$pCompLoan',PAYROLL_TOTAL_DEDUCTIONS='$pTotalDed',
							PAYROLL_NET_PAY='$pNetPay',PAYROLL_CASH_ADVANCE_DEDUCTIONS='$pCashAd' Where payroll_id='$PayrollID'");
	
	    mysql_query("UPDATE leaves SET is_flag=0 Where payroll_id=".$PayrollID);
		if(@$_POST['pLeaveID']!="" || @$_POST['pLeaveID']!=null)
		{
			$LeaveID = substr(@$_POST['pLeaveID'],0,-1);			
			$pLeaveID = explode("|",$LeaveID);
			
			for($p=0;$p<count($pLeaveID);$p++)
			{
				$query = mysql_query("UPDATE leaves SET is_flag=1,payroll_id=".$PayrollID." Where leave_id=".$pLeaveID[$p]);
			}
		}
		
		mysql_query("DELETE FROM payroll_earning where payroll_id=".$PayrollID);
		$oearn = substr($oearn,0,-1);
		$oearnArray = explode("|",$oearn);
		for($eArry=0;$eArry<count($oearnArray);$eArry++)
		{
			$query = mysql_query("INSERT INTO payroll_earning(PAYROLL_EARNING_DESC,PAYROLL_EARNING_AMOUNT,
			PAYROLL_ID) VALUES('".$oearnArray[$eArry]."',".$oearnArray[$eArry+1].",".$PayrollID.")");	
			$eArry++;
		}
		
		mysql_query("DELETE FROM payroll_deduction where payroll_id=".$PayrollID);
		$oded = substr($oded,0,-1);
		$odedArray = explode("|",$oded);
		for($oArry=0;$oArry<count($odedArray);$oArry++)
		{
			$query = mysql_query("INSERT INTO payroll_deduction(PAYROLL_DEDUCTION_DESC,
			PAYROLL_DEDUCTION_AMOUNT,PAYROLL_ID) VALUES('".$odedArray[$oArry]."',".$odedArray[$oArry+1].
			",".$PayrollID.")");	
			$oArry++;
		}
		
	echo 'update';
}
else if($role == "restore")
{
	$query = mysql_query("UPDATE payroll SET is_deleted=0 Where payroll_id = '$PayrollID'");
	echo 'restore';
}
else if($role == "delete")
{
	$query = mysql_query("UPDATE payroll SET is_deleted=1 Where payroll_id = '$PayrollID'");
	echo 'delete';
}

else if($role == "VIEW")
{	
$viewType = @$_POST['viewType'];
$payFrom = @$_POST['payFrom'];
$payTo = @$_POST['payTo'];
$payIdEdit =  @$_POST['payIdEdit'];

$query = mysql_query("select pay.payroll_id,pay.payroll_daily_rate,pay.payroll_hourly_rate,pay.payroll_minutes_rate	,pay.payroll_overtime_rate,pay.payroll_overtime_minutes,pay.payroll_regular_holiday,pay.payroll_allowance,pay.payroll_days_work,pay.payroll_hours_work,pay.payroll_minutes_work,pay.is_deleted,ep.emp_id,ep.emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, date_format(pay.payroll_date,'%b-%d-%Y') as 'payroll_date', date_format(pay.payroll_date_from,'%b-%d-%Y') as 'payroll_date_from', date_format(pay.payroll_date_to,'%b-%d-%Y') as 'payroll_date_to',pay.payroll_basic_salary,pay.payroll_witholding_tax,pay.payroll_witholding_percent,pay.
payroll_total_leave,pay.payroll_total_earnings,pay.payroll_total_deductions,pay.payroll_cash_advance_deductions,pay.payroll_company_loan,pay.payroll_net_pay from employee_profile ep, payroll pay, position pos, department dept where ep.position_id=pos.position_id and ep.dept_id=dept.dept_id and pay.emp_id=ep.emp_id");
	
		if($viewType == null)
		{
			 $outputData .="<table>
							<th></th>
							<th>Employee No.</th>
							<th>Name</th>
							<th>Position</th>
							<th>Department</th>
							<th>Date Issued</th>
							<th>From - To</th>
							<th>Regular Pay</th>
							<th>Total Earnings</th>
							<th>Total Deductions</th>
							<th>Net Pay</th>";
				
				if(mysql_num_rows($query) > 0)
					{
						while($arr = mysql_fetch_array($query))
						{
							if($arr['is_deleted'] == 1)
							$statusWidget = "<img title='Deleted Payroll' src='../../../../images/icons/payrolldelete-icon.png' width=25 height=25 />";
							else if($arr['is_deleted'] == 0)
							$statusWidget = "<img title='Used Payroll' src='../../../../images/icons/acct-pay-icon.png' width=25 height=25 />";
						    
							$x = (($arr['is_deleted']==1)?"deleted=true":"deleted=false");
							$outputData .= "<tr ".$x." class='selPayroll' empIDP='".$arr['emp_id']."' name='".$arr['payroll_id']."' empCodeP='".$arr['emp_code']."' userP='".$arr['user']."' deptP='".$arr['dept_name']."' posP='".$arr['position_name']."' dateFromP='".$arr['payroll_date_from']."' dateToP='".$arr['payroll_date_to']."' salP='".$arr['payroll_basic_salary']."' totLeaveP='".$arr['payroll_total_leave']."' totEarnP='".$arr['payroll_total_earnings']."' totDedP='".$arr['payroll_total_deductions']."' netPayP='".$arr['payroll_net_pay']."' dRateP='".$arr['payroll_daily_rate']."' hRateP='".$arr['payroll_hourly_rate']."' mRateP='".$arr['payroll_minutes_rate']."' oRateP='".$arr['payroll_overtime_rate']."' oMinP='".$arr['payroll_overtime_minutes']."' cLoanP='".$arr['payroll_company_loan']."' cAdP='".$arr['payroll_cash_advance_deductions']."' wTaxP='".$arr['payroll_witholding_tax']."' wTaxPerP='".$arr['payroll_witholding_percent']."' regHolP='".$arr['payroll_regular_holiday']."' allowP='".$arr['payroll_allowance']."' dWorkP='".$arr['payroll_days_work']."' hWorkP='".$arr['payroll_hours_work']."' mWork='".$arr['payroll_minutes_work']."'>";
							$outputData .= "<td>".$statusWidget."</td>";
							$outputData .= "<td>".$arr['emp_code']."</td>";
							$outputData .= "<td>".$arr['user']."</td>";
							$outputData .= "<td>".$arr['dept_name']."</td>";
							$outputData .= "<td>".$arr['position_name']."</td>";
							$outputData .= "<td>".date("D M d, Y",strtotime($arr['payroll_date']))."</td>";
							$outputData .= "<td>".$arr['payroll_date_from']." ~ ".$arr['payroll_date_to']."</td>";
							$outputData .= "<td align='right'>".number_format($arr['payroll_basic_salary'],2)."</td>";
							$outputData .= "<td align='right'>".number_format($arr['payroll_total_earnings'],2)."</td>";
							$outputData .= "<td align='right'>".number_format($arr['payroll_total_deductions'],2)."</td>";
							$outputData .= "<td align='right'>".number_format($arr['payroll_net_pay'],2)."</td>";
						    $outputData .= "</tr>";
						}
					}	
				else
				{
				$outputData .= "<tr><td colspan='10' align='center' style='color:gray;'>No Payroll found...</td></tr>";
				}		
		$outputData .= "</table>";
		}
		
		else if($viewType == "comboBox")
		{
		$diffArray = array();
		$totSchedArray = array();
		$sch = "";
		$schID = "";
		$totSched = "";
		$querySched = mysql_query("SELECT es.emp_id,(SUM( TIMEDIFF( es.emp_end_time, es.emp_start_time ))) * .0001 AS  'diff', count(emp_sch_id) as 'totSched' FROM employee_schedule es GROUP BY es.emp_id");
		while($rowS = mysql_fetch_array($querySched))
		{
		$sch .= $rowS['diff']."|";
		$totSched .= $rowS['totSched']."|";
		$schID .= $rowS['emp_id'].",";
		}
		$sch = substr($sch,0,-1);	
        $totSched = substr($totSched,0,-1);		
		$diffArray = explode("|",$sch);
		$totSchedArray = explode("|",$totSched);
		$schID = substr($schID,0,-1);			
			
		$queryUser = mysql_query("SELECT ep.emp_id,d.dept_id,ep.emp_code, pos.position_name, d.dept_name, CONCAT( ep.emp_first_name,  ' ', LEFT( ep.emp_middle_name, 1 ) ,  '. ', ep.emp_last_name ) AS  'user', ep.emp_salary, sum(et.EMP_TOTAL_HRS_WORKED) as 'sumHr',
sum(et.EMP_TOTAL_MINS_WORKED) as 'sumMin', count(et.emp_id) as 'sumDay' FROM employee_profile ep, position pos, department d, employee_time_sheet_record et WHERE ep.position_id = pos.position_id
AND ep.dept_id = d.dept_id AND ep.emp_id = et.emp_id AND ep.is_deleted =0 and (et.emp_date_in between '$payFrom' and '$payTo') and ep.emp_id in (".$schID.") group by ep.emp_id");
		$x=0;
		$y=1;
		        $outputData .= "<option value='none' style='text-align:center;font-weight:Italic;color:gray;'> -Select Employee- </option>";
				while($row = mysql_fetch_array($queryUser))
				{
				    $empSalary = $row['emp_salary']/2;
					$dailyRate = $empSalary/($totSchedArray[$x]*2);
					$hourRate = $empSalary/$diffArray[count($diffArray)-$y];
					$minutesRate = $hourRate/60;
					$daySum = $row['sumDay'];
					$hourSum = $row['sumHr'];
					$minuteSum = $row['sumMin'];
					$outputData .= "<option value='".$row['emp_id']."|".$row['emp_code']."|".$row['position_name']."|".$row['dept_name']."|".$empSalary."|".$hourRate."|".$dailyRate."|".$minutesRate."|".$daySum."|".$hourSum."|".$minuteSum."|".$row['dept_id']."'>".$row['user']."</option>";
					$x++;
					$y++;
				}
		}
		else if($viewType == "otherEarning")
		{
		$queryEarn = mysql_query("select earning_no,earning_name from earning where is_deleted=0 and is_flag=1");
		
			while($row = mysql_fetch_array($queryEarn))
			{
				$outputData .= "<label>".$row['earning_name']."</label><input type='text' class='otherEarn' id='".$row['earning_no']."' earnName='".$row['earning_name']."' value='0.00' style='text-align:right;'/>";
			}
		}
		else if($viewType == "otherDeduction")
		{
		$queryDed = mysql_query("select deduction_no,deduction_name from deduction where is_deleted=0 and is_flag=1");
		
			while($row = mysql_fetch_array($queryDed))
			{
				$outputData .= "<label>".$row['deduction_name']."</label><input type='text' class='otherDed' dedName='".$row['deduction_name']."' id='".$row['deduction_no']."' value='0.00' style='text-align:right;'/>";
			}
		}
		else if($viewType == "selectOvertime")
		{
		$queryOvertime = mysql_query("SELECT SUM( overtime_mins ) as 'sumOver' FROM overtime where is_deleted=0 and is_flag=0 and emp_id='$PayEmpID' and (overtime_date between '$payFrom' and '$payTo')");
		
			while($row = mysql_fetch_array($queryOvertime))
			{
				$outputData .= $row["sumOver"];
			}
		}
		else if($viewType == "selectCashAdvance")
		{
		$queryCashAdvance = mysql_query("SELECT SUM( emp_cash_amount ) as 'sumCashAdvance' FROM employee_cash_advance where is_deleted=0 and is_flag=0 and emp_id='$PayEmpID' and (emp_cash_date between '$payFrom' and '$payTo')");
		
			while($row = mysql_fetch_array($queryCashAdvance))
			{
				$outputData .= $row["sumCashAdvance"];
			}
		}
		else if($viewType == "payrollEarning")
		{
		$payEarn = mysql_query("select payroll_earning_no,payroll_earning_desc,payroll_earning_amount from payroll_earning where payroll_id='$payIdEdit'");
		
			while($row = mysql_fetch_array($payEarn))
			{
				$outputData .= "<label>".$row['payroll_earning_desc']."</label><input type='text' class='payEarnE' id='".$row['payroll_earning_no']."' earnNameEdit='".$row['payroll_earning_desc']."' value='".$row['payroll_earning_amount']."' style='text-align:right;'/>";
			}
		}
		else if($viewType == "payrollDeduction")
		{
		$payDed = mysql_query("select payroll_deduction_no,payroll_deduction_desc,payroll_deduction_amount from payroll_deduction where payroll_id='$payIdEdit'");
		
			while($row = mysql_fetch_array($payDed))
			{
				$outputData .= "<label>".$row['payroll_deduction_desc']."</label><input type='text' class='payDedE' id='".$row['payroll_deduction_no']."' dedNameEdit='".$row['payroll_deduction_desc']."' value='".$row['payroll_deduction_amount']."' style='text-align:right;'/>";
			}
		}
		else if($viewType == "editLeave")
		{
		$queryLeaveP = mysql_query("select leave_id,leave_type_name,is_flag,datediff(leave_to_date,leave_from_date) as 'leaveCount',date_format(leave_from_date,'%b-%d-%Y') as 'leave_from_date',date_format(leave_to_date,'%b-%d-%Y') as 'leave_to_date' from leaves lv,leave_type lt where lv.leave_type_id=lt.leave_type_id and lv.is_deleted=0 and emp_id='$PayEmpID'");
			
			$outputData .="<table>
						   <th></th>
						   <th>Leave Name</th>
						   <th>From</th>
						   <th>To</th>";
			if(mysql_num_rows($queryLeaveP) > 0)
			{			   
			while($row = mysql_fetch_array($queryLeaveP))
			{
				if($row['is_flag']=="1")
				{
				$outputData .= "<tr><td style='margin:0;padding:3px;min-width:10px;'><input type='checkbox' checked title='Use Leave' class='payLeaveP' id='".$row['leave_type_name']."' lidP='".$row['leave_id']."' leaveCountP='".$row['leaveCount']."'/></td><td>".$row['leave_type_name']."</td><td>".$row['leave_from_date']."</td><td>".$row['leave_to_date']."</td></tr>";
				}
				else
				{
				$outputData .= "<tr><td style='margin:0;padding:3px;min-width:10px;'><input type='checkbox' title='Use Leave' class='payLeaveP' id='".$row['leave_type_name']."' lidP='".$row['leave_id']."' leaveCountP='".$row['leaveCount']."'/></td><td>".$row['leave_type_name']."</td><td>".$row['leave_from_date']."</td><td>".$row['leave_to_date']."</td></tr>";
				}
			}
			}
			else
			{
				$outputData .= "<tr><td colspan='4' align='center'>No file leave...</td></tr>";
			}
			$outputData .="</table>";
		}
		else if($viewType == "selectLeave")
		{
		$queryLeave = mysql_query("select leave_id,leave_type_name,datediff(leave_to_date,leave_from_date) as 'leaveCount',date_format(leave_from_date,'%b-%d-%Y') as 'leave_from_date',date_format(leave_to_date,'%b-%d-%Y') as 'leave_to_date' from leaves lv,leave_type lt where lv.leave_type_id=lt.leave_type_id and lv.is_deleted=0 and lv.is_flag=0 and emp_id='$PayEmpID'");
			
			$outputData .="<table>
						   <th></th>
						   <th>Leave Name</th>
						   <th>From</th>
						   <th>To</th>";
			if(mysql_num_rows($queryLeave) > 0)
			{			   
			while($row = mysql_fetch_array($queryLeave))
			{
				$outputData .= "<tr><td style='margin:0;padding:3px;min-width:10px;'><input type='checkbox' title='Use Leave' class='payLeave' id='".$row['leave_type_name']."' lid='".$row['leave_id']."' leaveCount='".$row['leaveCount']."'/></td><td>".$row['leave_type_name']."</td><td>".$row['leave_from_date']."</td><td>".$row['leave_to_date']."</td></tr>";
			}
			}
			else
			{
				$outputData .= "<tr><td colspan='4' align='center'>No file leave...</td></tr>";
			}
			$outputData .="</table>";
		}
		
	echo $outputData;
	mysql_free_result($query);
}