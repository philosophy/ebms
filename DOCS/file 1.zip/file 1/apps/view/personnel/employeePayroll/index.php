﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Personnel</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(function(){
		headTitle("Employee Payroll");
		datagrid("employeePayroll",true);
		datagridMenu("payroll","new;edit;delete;restore");
		
		$("#pdf").click(function(){
		window.open("../../../view/reports/employee/paySlip.php","_new");
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/personnel/index.php"); ?>
<?php include("../../../controller/personnel/payrollController.php"); ?>
<div id="body-pane" style="height:90px;">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="employeePayroll" class="datagrid-container">
</div>
</div>

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

