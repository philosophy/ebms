<?php 
include("../../../../config/config.php");
$empCode = @$_POST['empCode'];
$outputData = "";
	
$Result = mysql_query("SELECT with_hdr_no, date_format(with_hdr_date_issued,'%b-%d-%Y') as 'with_hdr_date_issued', with_hdr_type, with_hdr_purpose, with_hdr_remarks
						FROM withdrawal_header wh WHERE with_hdr_issued_to = (SELECT emp_code FROM employee_profile WHERE emp_id = '".$empCode."') AND is_deleted = 0");

	if(mysql_num_rows($Result)>0)
	{
		$outputData .="<table>
				<th>Withdrawal No.</th>
				<th>Date Issued</th>
				<th>Type</th>
				<th>Purpose</th>
				<th>Remarks</th>";
			
			
while($arrResult = mysql_fetch_array($Result))
			{
			$outputData .= "<tr>";
				$outputData .= "<td>".@$arrResult['with_hdr_no']."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime(@$arrResult['with_hdr_date_issued']))."</td>";
				$outputData .= "<td>".@$arrResult['with_hdr_type']."</td>";
				$outputData .= "<td>".@$arrResult['with_hdr_purpose']."</td>";
				$outputData .= "<td>".@$arrResult['with_hdr_remarks']."</td>";
			$outputData .= "</tr>";
			}
	}
	else // no results found 
	{
	$outputData = "No results found";
	}
	
echo $outputData;
?>