﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Personnel</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(function(){
		headTitle("Employee Profile");
		datagrid("employeeProfile",true);
		datagridMenu("personnel","new;edit;delete;restore");
		datagrid("fileLeave;fileOvertime",false);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
		$("#pdf").click(function(){
		window.open("../../../view/reports/employee/employeeMasterList.php","_new");
		});
		
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/personnel/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="employeeProfile" class="datagrid-container">
	<script>
		$('#employeeProfile').load('../../../controller/personnel/personnelController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#issuedItems">Issued Items</a></li>
		<li><a href="#fileLeave">File Leave</a></li> 
		<li><a href="#fileOvertime">File Overtime</a></li> 
		<!--<li><a href="#cashAdvances">Cash Advance</a></li>-->
		<li><a href="#workExp">Work Experience</a></li>
		<li><a href="#educBackground">Educational Background</a></li>
	</ul> 
	<div id="fileLeave"> 
		<div class="tabButtonPanel">
			<button id="newFileLeave" class="callModalForm" ref="new_fileLeave" onclick="callModal('#newFileLeave')" title='File New Leave' disabled>✚</button>
			<button id="editFileLeave" class="callModalForm" ref="edit_fileLeave" onclick="callModal('#editFileLeave')" title='Edit Filed Leave' disabled>✎</button>
			<button id="deleteFileLeave" class="callModalForm" ref="delete_fileLeave" onclick="callModal('#deleteFileLeave')" title='Delete Filed Leave' disabled>✖</button>
			<button id="restoreFileLeave" class="callModalForm" ref="restore_fileLeave" onclick="callModal('#restoreFileLeave')" title='Restore Filed Leave' disabled>➲</button>
		</div>
		
		<div id="fileLeaveGrid" class="scrollable">
			Please select a record above
		</div>
	</div> 
	
	<div id="fileOvertime"> 
		
		<div class="tabButtonPanel">
			<button id="newFileOvertime" class="callModalForm" ref="new_fileOvertime" onclick="callModal('#newFileOvertime')" title='New Overtime Record' disabled>✚</button>
			<button id="editFileOvertime" class="callModalForm" ref="edit_fileOvertime" onclick="callModal('#editFileOvertime')" title='Edit Overtime Record' disabled>✎</button>
			<button id="deleteFileOvertime" class="callModalForm" ref="delete_fileOvertime" onclick="callModal('#deleteFileOvertime')" title='Delete Overtime Record' disabled>✖</button>
			<button id="restoreFileOvertime" class="callModalForm" ref="restore_fileOvertime" onclick="callModal('#restoreFileOvertime')" title='Restore Overtime Record' disabled>➲</button>
		</div>
		
		<div id="fileOvertimeGrid" class="scrollable">
			Please select a record above
		</div>
	</div> 
		<!--
		<div id="cashAdvances">
		<div class="tabButtonPanel">
			<button id="cashAdvance" class="callModalForm" ref="new_cashAdvance" onclick="callModal('#cashAdvance')">New Cash Advance</button>
		</div>
			<div id="cashAdvancesGrid"></div>
		</div>
		-->
	<div id="workExp">
		<div class="tabButtonPanel">
			<button id="newWorkExpForm" class="callModalForm" ref="new_workExp" onclick="callModal('#newWorkExpForm')" title='New Work Experience' disabled>✚</button>
			<button id="editWorkExpForm" class="callModalForm" ref="edit_workExp" onclick="callModal('#editWorkExpForm')" title='Edit Work Experience' disabled>✎</button>
			<button id="deleteWorkExpForm" class="callModalForm" ref="delete_workExp" onclick="callModal('#deleteWorkExpForm')" title='Delete Work Experience' disabled>✖</button>
			<button id="restoreWorkExpForm" class="callModalForm" ref="restore_workExp" onclick="callModal('#restoreWorkExpForm')" title='Restore Work Experience' disabled>➲</button>
		</div>
		
		<div id="workExpGrid" class="scrollable">
			Please select a record above
		</div>
	</div>
	
	<div id="educBackground">
		<div class="tabButtonPanel">
			<button id="newEducBackgroundForm" class="callModalForm" ref="new_educBackground" onclick="callModal('#newEducBackgroundForm')" title='New Educational Background' disabled>✚</button>
			<button id="editEducBackgroundForm" class="callModalForm" ref="edit_educBackground" onclick="callModal('#editEducBackgroundForm')" title='Edit Educational Background' disabled>✎</button>
			<button id="deleteEducBackgroundForm" class="callModalForm" ref="delete_educBackground" onclick="callModal('#deleteEducBackgroundForm')" title='Delete Educational Background' disabled>✖</button>
			<button id="restoreEducBackgroundForm" class="callModalForm" ref="restore_educBackground" onclick="callModal('#restoreEducBackgroundForm')" title='Restore Educational Background' disabled>➲</button>
		</div>
	
		<div id="educBackgroundGrid" class="scrollable">
			Please select a record above
		</div>
		
		
	</div>
	
	<div id="issuedItems" class="scrollable">
			Please select a record above
	</div>
		
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

