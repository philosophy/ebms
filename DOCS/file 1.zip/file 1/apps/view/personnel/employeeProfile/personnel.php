<?php 
session_start();
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE ep.emp_code LIKE '%".$searchQuery."%' or concat(ep.emp_first_name,' ',left(ep.emp_middle_name,1),'. ',ep.emp_last_name) LIKE '%".$searchQuery."%' ";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 8;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;

		$outputData .="
				<table>
				<th class='icon'></th>
				<th>Employee No.</th>
				<th>Name</th>
				<th>Department</th>
				<th>Position</th>
				<th>Status</th>";
				
	$query = "select ep.emp_id, ep.emp_code, ep.emp_gender,ep.emp_first_name, ep.emp_middle_name, ep.emp_last_name, d.dept_name, p.position_name, es.emp_status_name,ep.is_deleted
					from employee_profile ep inner join department d on ep.dept_id = d.dept_id 
					inner join position p on ep.position_id = p.position_id inner join emp_status es on ep.emp_status_id = es.emp_status_id ".$condition." 
					ORDER By ep.is_deleted,ep.emp_id desc";
		
							
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arrResult = mysql_query($query." limit $start,$per_page");

	
	if(mysql_num_rows($arrResult) > 0)
	{
			while($arrPersonnel = mysql_fetch_array($arrResult))
				{
				$x = (($arrPersonnel['is_deleted']==1)?"deleted=true":"deleted=false");
					
					if($arrPersonnel['is_deleted'] == 0)
					{
						if($arrPersonnel['emp_gender'] == 'male')
							{
								$icon = "<img src='/ebms/images/icons/empBoyIcon.png' title='Male'>";
							}
						else
							{
								$icon = "<img src='/ebms/images/icons/empGirlIcon.png' title='Female'>";
							}
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
					
					
				$outputData .="<tr ".$x." a='".@$arrPersonnel['emp_id']."' empName='".$arrPersonnel['emp_first_name']." ".$arrPersonnel['emp_middle_name']." ".$arrPersonnel['emp_last_name']."'>";
					$outputData .="<td class='icon'>".$icon."</td>";
					$outputData .="<td>".@$arrPersonnel['emp_code']."</td>";
					$outputData .="<td>".$arrPersonnel['emp_first_name']." ".$arrPersonnel['emp_middle_name']." ".$arrPersonnel['emp_last_name']."</td>";
					$outputData .="<td>".@$arrPersonnel['dept_name']."</td>";
					$outputData .="<td>".@$arrPersonnel['position_name']."</td>";
					$outputData .="<td>".@$arrPersonnel['emp_status_name']."</td>";
				$outputData .="</tr>";
				}
		
		$outputData .="</table>";
	}
	
	
else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrResult);