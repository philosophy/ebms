<?php 
session_start();
include("../../../../config/config.php");
$empCode = @$_POST['empCode'];

$role = @$_POST['role'];
$outputData = "";

if($role == null)
{
	$arrResult = mysql_query("SELECT educ_id as 'id',educ_school_name as 'schName',educ_year_graduated as 'yrGrad',educ_remarks as 'remarks',is_deleted from educational_background WHERE emp_id ='".$empCode."'");
		
		if(mysql_num_rows($arrResult) > 0)
		{
		$outputData .="<table>
				<th class=icon></th>
				<th>School Name</th>
				<th>Year Graduated</th>
				<th>Remarks</th>";
			
			while($arrPersonnel = mysql_fetch_array($arrResult))
				{
				
				$x = (($arrPersonnel['is_deleted']==1)?"deleted=true":"deleted=false");
					
					if($arrPersonnel['is_deleted'] == 0)
					{
						$icon = "<img src='/ebms/images/icons/educBackground.png'>";
							
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
				
				$outputData .="<tr educBackgroundID='".@$arrPersonnel['id']."' ".$x." schoolName='".@$arrPersonnel['schName']."' yearGraduated='".@$arrPersonnel['yrGrad']."' remarks='".@$arrPersonnel['remarks']."'>";
					$outputData .="<td class=icon>".$icon."</td>";
					$outputData .="<td>".@$arrPersonnel['schName']."</td>";
					$outputData .="<td>".@$arrPersonnel['yrGrad']."</td>";
					$outputData .="<td>".@$arrPersonnel['remarks']."</td>";
				$outputData .="</tr>";
				}
		
		$outputData .="</table>";
		}
		
		else //no records found
		$outputData = "No records found";

echo $outputData;
}


elseif($role == "edit")
{
	$schoolName = addslashes(@$_POST['schoolName']);
	$yearGraduated = @$_POST['yearGraduated'];
	$remarks = addslashes(@$_POST['remarks']);

	$empID = @$_POST['empID'];
	$educID = @$_POST['educID'];
	
	mysql_query("UPDATE educational_background SET educ_school_name = '$schoolName', educ_year_graduated = '$yearGraduated', educ_remarks = '$remarks'
		WHERE emp_id = '$empID' and educ_id = '$educID'");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Educational background updated.', '".$_SESSION['emp_id']."')");
	echo $schoolName . " - " . $yearGraduated . " - " . $remarks . " - " . $empID . " - " .$educID. " - ";
}

elseif($role == "new")
{
$empID = @$_POST['empID'];
$educDetails = json_decode($_POST['educDetails']);
	for($i=0;$i<sizeof($educDetails);$i++)
	{
		$schoolName = addslashes($educDetails[$i][0]);
		$yearGraduated = $educDetails[$i][1];
		$remarks = addslashes($educDetails[$i][3]);
		
		mysql_query("INSERT INTO educational_background(EDUC_SCHOOL_NAME,EDUC_YEAR_GRADUATED,EDUC_REMARKS,IS_DELETED,EMP_ID) VALUES('$schoolName','$yearGraduated','$remarks','0','$empID')");
		
		$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Educational background created.', '".$_SESSION['emp_id']."')");
	}
	
}

	
elseif($role == "delete")
{
	$educID = @$_POST['educID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE educational_background SET is_deleted = '1' WHERE educ_id = '$educID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Educational background deleted.', '".$_SESSION['emp_id']."')");
}

elseif($role == "restore")
{
	$educID = @$_POST['educID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE educational_background SET is_deleted = '0' WHERE educ_id = '$educID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Educational background restored.', '".$_SESSION['emp_id']."')");
}



?>
				