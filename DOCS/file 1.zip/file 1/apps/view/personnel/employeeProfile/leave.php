<?php 
session_start();
include("../../../../config/config.php");
$empCode = @$_POST['empCode'];
$role = @$_POST['role'];
$outputData = "";

if($role == null)
{
	$arrResult = mysql_query("SELECT leave_id,l.leave_type_id,leave_from_date as 'from',leave_to_date as 'to',leave_type_name,date_format(leave_from_date,'%b-%d-%Y') as 'leave_from_date', date_format(leave_to_date,'%b-%d-%Y') as 'leave_to_date',leave_no_of_days as 'maxDays',l.is_deleted FROM leaves l 
						INNER JOIN leave_type lt ON l.leave_type_id = lt.leave_type_id 
						WHERE l.emp_id ='".$empCode."'");
		
		if(mysql_num_rows($arrResult) > 0)
		{
		$outputData .="
				<table>
				<th class=icon></th>
				<th>Leave Type</th>
				<th>From</th>
				<th>To</th>";
				
			while($arrPersonnel = mysql_fetch_array($arrResult))
				{
				$x = (($arrPersonnel['is_deleted']==1)?"deleted=true":"deleted=false");
					
					if($arrPersonnel['is_deleted'] == 0)
					{
						$icon = "<img src='/ebms/images/icons/fileLeave.png'>";
							
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
				
				$outputData .="<tr leaveID = '".$arrPersonnel['leave_id']."' ".$x." leaveTypeID='".$arrPersonnel['leave_type_id']."' dateFrom = '".$arrPersonnel['from']."' dateTo = '".$arrPersonnel['to']."'   maxDays = '".$arrPersonnel['maxDays']."'>";
					$outputData .="<td class=icon>".$icon."</td>";
					$outputData .="<td>".@$arrPersonnel['leave_type_name']."</td>";
					$outputData .="<td>".date("D M d, Y",strtotime($arrPersonnel['leave_from_date']))."</td>";
					$outputData .="<td>".date("D M d, Y",strtotime(@$arrPersonnel['leave_to_date']))."</td>";
				$outputData .="</tr>";
				}
		
		$outputData .="</table>";
		}
		
		else //no records found
		$outputData = "No records found";

echo $outputData;
}

elseif($role == "new")
{
	$leaveTypeID = @$_POST['leaveType'];
	$leaveFrom = @$_POST['dateFrom'];
	$leaveTo = @$_POST['dateTo'];
	$empID = @$_POST['empID'];
	
	mysql_query("INSERT leaves(leave_type_id,leave_from_date,leave_to_date,is_deleted,emp_id) VALUES ('$leaveTypeID','$leaveFrom','$leaveTo','0','$empID')");
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File leave created.', '".$_SESSION['emp_id']."')");
}

elseif($role == "edit")
{
	$leaveTypeID = @$_POST['leaveType'];
	$leaveID = @$_POST['leaveID'];
	$leaveFrom = @$_POST['dateFrom'];
	$leaveTo = @$_POST['dateTo'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE leaves SET leave_type_id = '$leaveTypeID',leave_from_date = '$leaveFrom',leave_to_date = '$leaveTo', emp_id = '$empID' WHERE leave_id = '$leaveID'");
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File leave updated.', '".$_SESSION['emp_id']."')");
}
	
elseif($role == "delete")
{
	$leaveID = @$_POST['leaveID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE leaves SET is_deleted = '1' WHERE leave_id = '$leaveID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File leave deleted.', '".$_SESSION['emp_id']."')");
}

elseif($role == "restore")
{
	$leaveID = @$_POST['leaveID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE leaves SET is_deleted = '0' WHERE leave_id = '$leaveID' and emp_id = '$empID' ");
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File leave restored.', '".$_SESSION['emp_id']."')");
}
	
?>
				