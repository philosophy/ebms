<?php 
session_start();
include("../../../../config/config.php");

$empID = @$_POST['empID'];
$output[]="";
$outputData = "";

if($_POST['role'] == "editEducDetails")
{

$educID = @$_POST['educID'];
$schName = addslashes(@$_POST['schName']);
$yrGrad = @$_POST['yrGrad'];
$remarks = addslashes(@$_POST['remarks']);
	
	mysql_query("UPDATE educational_background SET EDUC_SCHOOL_NAME = '$schName', EDUC_YEAR_GRADUATED = '$yrGrad', EDUC_REMARKS = '$remarks' WHERE emp_id = '$empID' and educ_id = '$educID'");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Educational background updated.', '".$_SESSION['emp_id']."')");
	
}

elseif($_POST['role'] == "editWorkDetails")
{

$workExpID = @$_POST['workExpID'];
$compName = addslashes(@$_POST['compName']);
$workExpFrom = @$_POST['workExpFrom'];
$workExpTo = @$_POST['workExpTo'];
$workDesc = addslashes(@$_POST['workDesc']);
	
	mysql_query("UPDATE work_experience SET WORK_COMPANY_NAME = '$compName', WORK_EXP_DESCRIPTION = '$workDesc', WORK_EXP_FROM_DATE = '$workExpFrom', WORK_EXP_TO_DATE = '$workExpTo' WHERE emp_id = '$empID' and work_exp_id = '$workExpID'");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail updated.', '".$_SESSION['emp_id']."')");
	
}

elseif($_POST['role'] == "editWorkDetails")
{
	
$schName = addslashes(@$_POST['schName']);
$yrGrad = addslashes(@$_POST['yrGrad']);
$remarks = addslashes(@$_POST['remarks']);
	
	mysql_query("UPDATE work_experience SET WORK_COMPANY_NAME = '$schName' ,WORK_EXP_FROM_DATE,WORK_EXP_TO_DATE,WORK_EXP_DESCRIPTION");
	
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail updated.', '".$_SESSION['emp_id']."')");
	
}

elseif($_POST['role'] == "editEmp")
{
//general info data
$fname = addslashes(@$_POST['fname']);
$mname = (($_POST['mname'] == 'Middle name')?"":addslashes(@$_POST['mname']));
$lname = addslashes(@$_POST['lname']);
$address = addslashes(@$_POST['address']);
$bday = @$_POST['bday'];
$gender = @$_POST['gender'];
$maritalStatus = @$_POST['mStat'];
$homeNo = @$_POST['homePhoneNo'];
$workNo = @$_POST['workPhoneNo'];
//employment info
$dateHired = @$_POST['dateHired'];
$deptID = @$_POST['deptID'];


$posID = @$_POST['posID'];
$empStatus = @$_POST['empStat'];

//payroll
$regSal = @$_POST['regSal'];

//others
$sssNo = @$_POST['sssNo'];
$philHealthNo = @$_POST['philHealthNo'];
$tinNo = @$_POST['tinNo'];
$pagibigNo = @$_POST['pagibigNo'];
	
	mysql_query("UPDATE employee_profile SET EMP_FIRST_NAME = '$fname' ,EMP_MIDDLE_NAME = '$mname' ,EMP_LAST_NAME = '$lname' ,EMP_ADDRESS = '$address' ,EMP_BIRTH_DATE = '$bday' ,EMP_GENDER = '$gender' ,EMP_MARITAL_STATUS = '$maritalStatus' ,EMP_HOME_PHONE_NO = '$homeNo' ,EMP_WORK_PHONE_NO = '$workNo' ,EMP_DATE_HIRED = '$dateHired' ,EMP_SSS_NO = '$sssNo' ,EMP_TIN_NO = '$tinNo' ,EMP_PHIL_HEALTH = '$philHealthNo' ,EMP_PAG_IBIG = '$pagibigNo' ,EMP_SALARY = '$regSal' ,EMP_STATUS_ID = '$empStatus' ,DEPT_ID = '$deptID' ,POSITION_ID = '$posID' WHERE emp_id = '$empID'");
	
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Employee profile updated.', '".$_SESSION['emp_id']."')");
	
	
}

elseif($_POST['role'] == "VIEW")
{
	if($_POST['viewType'] == "comboBox")
	{
		$query = mysql_query("
		SELECT CONCAT(emp.emp_first_name,' ',emp.emp_middle_name,' ',emp.emp_last_name) as 'name',emp.emp_id
		FROM employee_profile emp
		");
		
		if(mysql_num_rows($query) > 0)
		{
			$outputData = "<option value=''>...</option>";
					while($row = mysql_fetch_array($query))
					{
					$outputData .= "<option value='".$row['emp_id']."'>".$row['name']."</option>";
					}
		echo $outputData;
		mysql_free_result($query);
		}
	}
}

else if($_POST['role'] == "new")
{
//general info data
$fname = addslashes(@$_POST['fname']);
$mname = (($_POST['mname'] == 'Middle name')?"":addslashes(@$_POST['mname']));
$lname = addslashes(@$_POST['lname']);
$address = addslashes(@$_POST['address']);
$bday = @$_POST['bday'];
$gender = @$_POST['gender'];
$maritalStatus = @$_POST['maritalStatus'];
$homeNo = @$_POST['homeNo'];
$workNo = @$_POST['workNo'];

//educational background
$educDetails = json_decode($_POST['educDetails']);


//employment info
$dateHired = @$_POST['dateHired'];
$deptID = @$_POST['deptID'];

$query = mysql_query("SELECT dept_code FROM DEPARTMENT where dept_id = '$deptID'");
$deptCodeArr = mysql_fetch_array($query);
$deptCode = $deptCodeArr['dept_code'];

$posID = @$_POST['posID'];
$empStatus = @$_POST['empStatus'];
$workDetails = json_decode($_POST['workDetails']);

//payroll
$regSal = @$_POST['regSal'];

//others
$sssNo = @$_POST['sssNo'];
$philHealthNo = @$_POST['philHealthNo'];
$tinNo = @$_POST['tinNo'];
$pagibigNo = @$_POST['pagibigNo'];
$result = mysql_query("INSERT INTO employee_profile (EMP_FIRST_NAME,EMP_MIDDLE_NAME,EMP_LAST_NAME,EMP_ADDRESS,EMP_BIRTH_DATE,EMP_GENDER,EMP_MARITAL_STATUS,EMP_HOME_PHONE_NO,EMP_WORK_PHONE_NO,EMP_DATE_HIRED,EMP_SSS_NO,EMP_TIN_NO,EMP_PHIL_HEALTH,EMP_PAG_IBIG,EMP_SALARY,IS_DELETED,EMP_STATUS_ID,DEPT_ID,POSITION_ID) VALUES
('$fname','$mname','$lname','$address',$bday,'$gender','$maritalStatus','$homeNo','$workNo',$dateHired,'$sssNo','$tinNo','$philHealthNo','$pagibigNo','$regSal','0','$empStatus','$deptID','$posID')");



$id = mysql_insert_id();


$schName = "";
$yrGrad = "";
$schRemarks = "";

for($i=0;$i<sizeof($educDetails);$i++)
{
		$schName = addslashes($educDetails[$i][0]);
		$yrGrad = $educDetails[$i][1];
		$schRemarks = addslashes($educDetails[$i][2]);
		
		mysql_query("INSERT INTO educational_background(EDUC_SCHOOL_NAME,EDUC_YEAR_GRADUATED,EDUC_REMARKS,IS_DELETED,EMP_ID) VALUES('$schName','$yrGrad','$schRemarks','0','$id')");

	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Educational background created.', '".$_SESSION['emp_id']."')");
}

for($i=0;$i<sizeof($workDetails);$i++)
{
		$compName = addslashes($workDetails[$i][0]);
		$startDate = $workDetails[$i][1];
		$endDate = $workDetails[$i][2];
		$workDesc = addslashes($workDetails[$i][3]);
		
		mysql_query("INSERT INTO work_experience(WORK_COMPANY_NAME,WORK_EXP_FROM_DATE,WORK_EXP_TO_DATE,WORK_EXP_DESCRIPTION,IS_DELETED,EMP_ID) VALUES('$compName','$startDate','$endDate','$workDesc','0','$id')");
		
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail created.', '".$_SESSION['emp_id']."')");
}



	$empCode = "EMP-".date("Y").$deptCode."-".str_pad($id, 6, "0", STR_PAD_LEFT);	
	
	$query = mysql_query("UPDATE employee_profile SET emp_code = '$empCode' WHERE emp_id = '$id'");
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Employee record updated.', '".$_SESSION['emp_id']."')");
	echo "$fname - $mname - $lname - $address - $bday - $gender - $maritalStatus - $homeNo - $workNo - $dateHired - $sssNo - $tinNo - $philHealthNo - $pagibigNo - $regSal - 0 - $empStatus - $deptID - $posID";
	
	
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Employee record created.', '".$_SESSION['emp_id']."')");
}

elseif($_POST['role'] == "fetchEducDetails")
{

$query = mysql_query("
		SELECT educ_id, educ_school_name, educ_year_graduated, educ_remarks
		FROM educational_background
		WHERE is_deleted = 0 and emp_id = '$empID'
		");
		
	while($row = mysql_fetch_array($query))
	{
		$outputData .= "<tr educID='".$row['educ_id']."' educSchName='".$row['educ_school_name']."' educYrGrad='".$row['educ_year_graduated']."' educRemarks='".$row['educ_remarks']."'>";
		$outputData .= "<td>".$row['educ_school_name']."</td>";
		$outputData .= "<td>".$row['educ_year_graduated']."</td>";
		$outputData .= "<td>".$row['educ_remarks']."</td></tr>";
	}
	echo $outputData;
}

elseif($_POST['role'] == "fetchWorkDetails")
{

$query = mysql_query("
		SELECT work_exp_id, work_company_name, work_exp_description, work_exp_from_date, work_exp_to_date
		FROM work_experience
		WHERE is_deleted = 0 and emp_id = '$empID'
		");
		
	while($row = mysql_fetch_array($query))
	{
		$outputData .= "<tr workExpID='".$row['work_exp_id']."' workCompName = '".$row['work_company_name']."' workExpFrom='".$row['work_exp_from_date']."' workExpTo='".$row['work_exp_to_date']."' workDesc='".$row['work_exp_description']."'>";
		$outputData .= "<td>".$row['work_company_name']."</td>";
		$outputData .= "<td>".$row['work_exp_from_date']."</td>";
		$outputData .= "<td>".$row['work_exp_to_date']."</td>";
		$outputData .= "<td>".$row['work_exp_description']."</td></tr>";
	}
	echo $outputData;
}

elseif($_POST['role'] == "fetchData")
{
	
	$query = mysql_query("
		SELECT emp.emp_first_name as 'fname', emp.emp_middle_name as 'mname', emp.emp_last_name as 'lname',
			   emp.emp_address as 'address',emp.emp_birth_date as 'bday',emp.emp_gender as 'gender',
			   emp.emp_marital_status as 'mStat',emp.emp_home_phone_no as 'homeNo',emp.emp_work_phone_no as 'workNo',
			   emp.emp_date_hired as 'dateHired', emp.emp_sss_no as 'sss', emp.emp_tin_no as 'tin', emp.emp_phil_health as 'philhealth',
			   emp.emp_pag_ibig as 'pagibig', emp.emp_salary as 'sal', emp.dept_id as 'dept', emp.position_id as 'pos', emp.emp_status_id as 'empStat'
		FROM employee_profile emp
		WHERE emp.emp_id = '$empID'
		");
		
	while($row = mysql_fetch_array($query))
	{
		$output['fname'] = array($row['fname']);
		$output['mname'] = array($row['mname']);
		$output['lname'] = array($row['lname']);
		
		$output['bday'] = array($row['bday']);
		$output['address'] = array($row['address']);
		$output['gender'] = array($row['gender']);
		
		$output['mStat'] = array($row['mStat']);
		$output['homeNo'] = array($row['homeNo']);
		$output['workNo'] = array($row['workNo']);
		
		$output['dateHired'] = array($row['dateHired']);
		$output['sss'] = array($row['sss']);
		$output['tin'] = array($row['tin']);
		$output['philhealth'] = array($row['philhealth']);
		$output['pagibig'] = array($row['pagibig']);
		$output['sal'] = array($row['sal']);
		
		$output['pos'] = array($row['pos']);
		$output['dept'] = array($row['dept']);
		$output['empStat'] = array($row['empStat']);
		
	}
mysql_free_result($query);	
	
		
	$dataArr = json_encode(array("data"=>$output));
	
	echo $dataArr;
	
}


elseif($_POST['role'] == "delete")
{
mysql_query("UPDATE employee_profile SET is_deleted = 1 WHERE emp_id = '$empID'");

	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Employee record deleted.', '".$_SESSION['emp_id']."')");
}

elseif($_POST['role'] == "restore")
{
mysql_query("UPDATE employee_profile SET is_deleted = 0 WHERE emp_id = '$empID'");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Employee record restored.', '".$_SESSION['emp_id']."')");
}