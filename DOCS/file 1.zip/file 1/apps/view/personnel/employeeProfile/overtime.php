<?php 
session_start();
include("../../../../config/config.php");
$empCode = @$_POST['empCode'];
$role = @$_POST['role'];
$outputData = "";

if($role == null)
{
	$arrResult = mysql_query("SELECT overtime_id,date_format(overtime_date,'%b-%d-%Y') as 'overtime_date',overtime_date as 'o', overtime_mins,is_deleted
					FROM overtime WHERE emp_id ='".$empCode."'");
		
		if(mysql_num_rows($arrResult) > 0)
		{
		
		
		$outputData .="<table>
				<th class=icon></th>
				<th>Overtime Date</th>
				<th>Overtime Hours</th>";
			
			while($arrPersonnel = mysql_fetch_array($arrResult))
				{
				
				$x = (($arrPersonnel['is_deleted']==1)?"deleted=true":"deleted=false");
					
					if($arrPersonnel['is_deleted'] == 0)
					{
						$icon = "<img src='/ebms/images/icons/overtime.png'>";
							
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
				
				$hours = @$arrPersonnel['overtime_mins'] / 60;
				$mins = @$arrPersonnel['overtime_mins'] % 60;
				
				$outputData .="<tr ".$x." overtimeId = '".$arrPersonnel['overtime_id']."' overtimeHours = '".floor($hours)." hours' overtimeDate = '".$arrPersonnel['o']."' overtimeMins = '".floor($mins)." minutes' >";
					$outputData .="<td class=icon>".$icon."</td>";
					$outputData .="<td>".date("D M d, Y",strtotime(@$arrPersonnel['overtime_date']))."</td>";
					$outputData .="<td>".floor($hours)." <sup>hour(s)</sup> ".$mins." <sup>minute(s)</sup></td>";
				$outputData .="</tr>";
				}
		
		$outputData .="</table>";
		}
		
		else //no records found
		$outputData = "No records found";

echo $outputData;
}

elseif($role == "new")
{
	$overtimeMin = @$_POST['overtimeMin'];
	$overtimeDate = @$_POST['overtimeDate'];
	$empID = @$_POST['empID'];
	
	mysql_query("INSERT INTO `overtime`(`OVERTIME_MINS`, `OVERTIME_DATE`, `IS_DELETED`, `EMP_ID`) VALUES ('$overtimeMin','$overtimeDate','0','$empID')");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File overtime created.', '".$_SESSION['emp_id']."')");
	//echo $overtimeMin . " - " . $overtimeDate . " - " . $empID;
}


elseif($role == "edit")
{
	$overtimeMin = @$_POST['overtimeMin'];
	$overtimeDate = @$_POST['overtimeDate'];
	$empID = @$_POST['empID'];
	$overtimeID = @$_POST['overtimeID'];
	
	mysql_query("UPDATE `overtime` SET `OVERTIME_MINS`='$overtimeMin',`OVERTIME_DATE`= '$overtimeDate' WHERE overtime_id = '$overtimeID'");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File overtime updated.', '".$_SESSION['emp_id']."')");
	//echo $overtimeMin . " - " .$overtimeDate . " - " . $empID . " - " . $overtimeID;
}

	
elseif($role == "delete")
{
	$overtimeID = @$_POST['overtimeID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE overtime SET is_deleted = '1' WHERE overtime_id = '$overtimeID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File overtime deleted.', '".$_SESSION['emp_id']."')");
}

elseif($role == "restore")
{
	$overtimeID = @$_POST['overtimeID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE overtime SET is_deleted = '0' WHERE overtime_id = '$overtimeID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'File overtime restored.', '".$_SESSION['emp_id']."')");
}


?>
				