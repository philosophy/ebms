<?php 
session_start();
include("../../../../config/config.php");
$empCode = @$_POST['empCode'];

$role = @$_POST['role'];

if($role == null)
{
$outputData = "";

	$arrResult = mysql_query("SELECT work_exp_id as 'id',work_exp_description as 'desc',work_company_name as 'compName',work_exp_from_date as 'from',work_exp_to_date as 'to',is_deleted from work_experience WHERE emp_id ='".$empCode."' ");
		
		if(mysql_num_rows($arrResult) > 0)
		{
		$outputData .="<table>
				<th class=icon></th>
				<th>Company Name</th>
				<th>Date Start</th>
				<th>Date Ended</th>
				<th>Work Description</th>";
			
			while($arrPersonnel = mysql_fetch_array($arrResult))
				{
				
				$x = (($arrPersonnel['is_deleted']==1)?"deleted=true":"deleted=false");
					
					if($arrPersonnel['is_deleted'] == 0)
					{
						$icon = "<img src='/ebms/images/icons/workExp.png'>";
							
					}
					
					else
					{
						$icon = "<img src='/ebms/images/icons/deleted-icon.png' title='Deleted'>";
					}
				
				$outputData .="<tr workExpID='".@$arrPersonnel['id']."' ".$x." compName='".@$arrPersonnel['compName']."' workExpFrom='".@$arrPersonnel['from']."' workExpTo='".@$arrPersonnel['to']."' workDesc='".@$arrPersonnel['desc']."'>";
					$outputData .="<td class=icon>".$icon."</td>";
					$outputData .="<td>".@$arrPersonnel['compName']."</td>";
					$outputData .="<td>".date("D M d, Y",strtotime(@$arrPersonnel['from']))."</td>";
					$outputData .="<td>".date("D M d, Y",strtotime(@$arrPersonnel['to']))."</td>";
					$outputData .="<td>".@$arrPersonnel['desc']."</td>";
				$outputData .="</tr>";
				}
		
		$outputData .="</table>";
		}
		
		else //no records found
		$outputData = "No records found";

echo $outputData;
}

elseif($role == "edit")
{
	$compName = @$_POST['compName'];
	$workExpFrom = @$_POST['workExpFrom'];
	$workExpTo = @$_POST['workExpTo'];
	$workDesc = @$_POST['workDesc'];
	$empID = @$_POST['empID'];
	$workExpID = @$_POST['workExpID'];
	
	mysql_query("UPDATE work_experience SET work_company_name = '$compName', work_exp_from_date = '$workExpFrom', work_exp_to_date = '$workExpTo', work_exp_description = '$workDesc'
		WHERE emp_id = '$empID' and work_exp_id = '$workExpID'");
		$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail updated.', '".$_SESSION['emp_id']."')");
}

elseif($role == "new")
{
$empID = @$_POST['empID'];
$workDetails = json_decode($_POST['workDetails']);
	for($i=0;$i<sizeof($workDetails);$i++)
	{
		$compName = addslashes($workDetails[$i][0]);
		$startDate = $workDetails[$i][1];
		$endDate = $workDetails[$i][2];
		$workDesc = addslashes($workDetails[$i][3]);
		
		mysql_query("INSERT INTO work_experience(WORK_COMPANY_NAME,WORK_EXP_FROM_DATE,WORK_EXP_TO_DATE,WORK_EXP_DESCRIPTION,IS_DELETED,EMP_ID) VALUES('$compName','$startDate','$endDate','$workDesc','0','$empID')");
		$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail created.', '".$_SESSION['emp_id']."')");
	}
	
}

	
elseif($role == "delete")
{
	$workExpID = @$_POST['workExpID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE work_experience SET is_deleted = '1' WHERE work_exp_id = '$workExpID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail deleted.', '".$_SESSION['emp_id']."')");
}

elseif($role == "restore")
{
	$workExpID = @$_POST['workExpID'];
	$empID = @$_POST['empID'];
	
	mysql_query("UPDATE work_experience SET is_deleted = '0' WHERE work_exp_id = '$workExpID' and emp_id = '$empID' ");
	$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Work history detail restored.', '".$_SESSION['emp_id']."')");
}

?>
				