﻿<?php

include("../../../../config/config.php");

$schedEmpID = @$_POST['schedEmpID'];
$schedID = @$_POST['schedID'];
$stime = DATE("H:i",STRTOTIME(@$_POST['stime']));
$etime = DATE("H:i",STRTOTIME(@$_POST['etime']));
$sbreak = DATE("H:i",STRTOTIME(@$_POST['sbreak']));
$ebreak = DATE("H:i",STRTOTIME(@$_POST['ebreak']));

$mon = @$_POST['mon'];
$tue = @$_POST['tue'];
$wed = @$_POST['wed'];
$thu = @$_POST['thu'];
$fri = @$_POST['fri'];
$sat = @$_POST['sat'];
$sun = @$_POST['sun'];

$daysArray = array($mon,$tue,$wed,$thu,$fri,$sat,$sun);

$role = @$_POST['role'];
$_SESSION['schedEmpID'] = $schedEmpID;
$_SESSION['schedID'] = $schedID;

$days = array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");
$outputData = "";

function retrieveInfoAudit()
{
 
  $queryValidate = mysql_query("select emp_code from employee_profile where emp_id = ".$_SESSION['schedEmpID']);
  $row = mysql_fetch_row($queryValidate);
  return $row[0];
}

function checkSchedule($dy)
{
 
  $queryValidate = mysql_query("select emp_days from employee_schedule where emp_id=".$_SESSION['schedEmpID']." and emp_days='".$dy."'");
  $row = mysql_fetch_row($queryValidate);
  $num = mysql_num_rows($queryValidate);
  if( $num > 0)
		$daysCheck=1;
  if( $num == 0)
	    $daysCheck=0;
  return $daysCheck;
}

if($role == "news")
{
   for($x=0;$x<count($days);$x++)
    {
		if($daysArray[$x]=="check")
		{
		$query = mysql_query("INSERT INTO employee_schedule (emp_days,emp_start_time,emp_end_time, emp_start_break_time,emp_end_break_time,is_deleted,emp_id) VALUES ('".$days[$x]."','$stime','$etime','$sbreak','$ebreak',0,'$schedEmpID')");
		}
	}
	echo 'news';
}

else if($role == "new")
{
   for($x=0;$x<count($days);$x++)
   {
		$cday = checkSchedule($days[$x]);
		if($cday==0 && $daysArray[$x]=="check")
		{
			$query = mysql_query("INSERT INTO employee_schedule (emp_days,emp_start_time,emp_end_time, emp_start_break_time,emp_end_break_time,is_deleted,emp_id) VALUES ('".$days[$x]."','$stime','$etime','$sbreak','$ebreak',0,'$schedEmpID')");
		}
		else if($cday==1 && $daysArray[$x]=="check")
		{
			$query = mysql_query("UPDATE employee_schedule SET emp_start_time='$stime', emp_end_time='$etime', emp_start_break_time='$sbreak', emp_end_break_time='$ebreak' WHERE emp_id = '$schedEmpID' and emp_days='".$days[$x]."'");
		}
		
	}
	echo 'new';
}

else if($role == "edit")
{
	$query = mysql_query("UPDATE employee_schedule SET emp_start_time='$stime', emp_end_time='$etime', emp_start_break_time='$sbreak', emp_end_break_time='$ebreak' WHERE emp_sch_id = ".$_SESSION['schedID']);
	
	/*$at = retrieveInfoAudit();
	
	mysql_query("INSERT INTO audit_trail(AUDIT_DATE,AUDIT_TIME,AUDIT_ACTION_TAKEN,EMP_ID)
		VALUES (curdate(),curtime(),'Update Schedule of Employee '".$at."','$empID')");*/
	
	echo 'update';
}

else if($role == "delete")
{
	$query = mysql_query("Delete from employee_schedule WHERE emp_sch_id = ".$_SESSION['schedID']);
	echo 'delete';
}

else if($role == "VIEW")
{
$viewType = @$_POST['viewType'];

$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " and concat(EMP_FIRST_NAME,' ',left(EMP_MIDDLE_NAME,1),'. ',EMP_LAST_NAME) LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	{$condition = "";}


$cur_page = $page;
$page -= 1;
$per_page = 1;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;

	if($viewType == null)
	{
			$outputData .="<table>
							<th style='padding:5px;width:10px;'></th>
							<th>Days</th>
							<th>Start Time</th>
							<th>End Time</th>
							<th>Start Break Time</th>
							<th>End Break Time</th>";
							
$query = "select es.emp_id,ep.emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', emp_days, emp_start_time, emp_end_time, emp_start_break_time, emp_end_break_time from employee_profile ep, employee_schedule es where ep.emp_id=es.emp_id ".$condition." group by ep.emp_id";

	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arrResult = mysql_query($query." limit $start,$per_page");

	
		if(mysql_num_rows($arrResult) > 0)
		{
				while($arrCustomer = mysql_fetch_array($arrResult))
				{
					$outputData .= "<tr>";
					$outputData .= "<td colspan='6' style='background:lightblue;font-weight:bold;'><input type='radio' class='empR' name='emp' id='".$arrCustomer['emp_id']."' empName='".$arrCustomer['user']."'/><img src='../../../../images/icons/empsched-icon.png' width=20 height=20 />".$arrCustomer['user']." - ".$arrCustomer['emp_code']."</td>";
					$outputData .= "</tr>";		
					
					$querySched = mysql_query("select es.EMP_SCH_ID,emp_code, 
			concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', emp_days, emp_start_time, emp_end_time, emp_start_break_time, emp_end_break_time from employee_profile ep, employee_schedule es where ep.emp_id=es.emp_id");
				
					while($arrSched = mysql_fetch_array($querySched))
					{
					if($arrSched['emp_code']==$arrCustomer['emp_code'])
						{
						$outputData .= "<tr class='selSched' name='".$arrSched['EMP_SCH_ID']."' userSched='".$arrSched['user']."' days='".$arrSched['emp_days']."' startT='".date("g:i a", strtotime($arrSched['emp_start_time']))."' endT='".date("g:i a", strtotime($arrSched['emp_end_time']))."' startB='".date("g:i a", strtotime($arrSched['emp_start_break_time']))."' endB='".date("g:i a", strtotime($arrSched['emp_end_break_time']))."'>";
							$outputData .= "<td><img src='../../../../images/icons/schedule-icon.png' width=20 height=20 /></td>";
							$outputData .= "<td>".$arrSched['emp_days']."</td>";
							$outputData .= "<td>".date("g:i a", strtotime($arrSched['emp_start_time']))."</td>";
							$outputData .= "<td>".date("g:i a", strtotime($arrSched['emp_end_time']))."</td>";
							$outputData .= "<td>".date("g:i a", strtotime($arrSched['emp_start_break_time']))."</td>";
							$outputData .= "<td>".date("g:i a", strtotime($arrSched['emp_end_break_time']))."</td>";
						$outputData .= "</tr>";
						}
					}
				}
				
		$outputData .= "</table>";
		}
		else
		{	
		include("../../noResults.php");
		$cur_page = 0;
		}
	
	
	}
	else if($viewType == "comboBox")
	{
				$queryUser = mysql_query("select ep.emp_id,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user' from employee_profile ep where ep.is_deleted=0 and NOT EXISTS (SELECT * FROM employee_schedule es
                WHERE ep.emp_id=es.emp_id);");
		
		        $outputData .= "<option value='none' style='text-align:center;font-weight:Italic;color:gray;'> - Select Employee - </option>";
				while($row = mysql_fetch_array($queryUser))
				{
				$outputData .= "<option empid='".$arr['emp_id']."' value='".$row['emp_id']."'>".$row['user']."</option>";
				}
	}	 	
			
			echo $outputData.
			$strSeparator.
				"Page $cur_page of $no_of_paginations".
			$strSeparator.
				@$cur_page.
			$strSeparator.
				@$no_of_paginations; 
				
		mysql_free_result($arrResult);	
}
