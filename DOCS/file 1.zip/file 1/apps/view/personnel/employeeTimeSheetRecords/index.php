﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Employee Time Sheet Records</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Employee Time Sheet Records");
		
		$("#pdf").click(function(){
		window.open("../../../view/reports/timeSheet/timeSheetRecord.php","_new");
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<div id="body-pane" style="height:70px;">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="time-sheet" class="datagrid-container">
	<script>
		$('#time-sheet').load('../../../controller/dailyTimeRecord/timeSheetController.php');
    </script>
</div>
</div>

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

