﻿<?php 
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " and concat(EMP_FIRST_NAME,' ',left(EMP_MIDDLE_NAME,1),'. ',EMP_LAST_NAME) LIKE '%".$searchQuery."%'";
	}

else if ($searchQuery == "")
	$condition = "";



$cur_page = $page;
$page -= 1;
$per_page = 7;

$start = $page * $per_page;
 $outputData .="<table>
        <th style='padding:5px;width:10px;'></th>
		<th>Employee Name</th>
		<th>Department</th>
		<th>Position</th>
		<th>Date</th>
		<th>Time In</th>
		<th>Time Out</th>";
	$query = "select emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, date_format(emp_date_in,'%b-%d-%Y') as 'emp_date_in', emp_time_in, emp_time_out from employee_profile ep, position pos, emp_status es, department dept, employee_time_sheet_record etsr where ep.emp_status_id=es.emp_status_id and ep.position_id=pos.position_id and ep.dept_id=dept.dept_id and etsr.emp_id=ep.emp_id ".$condition." order by etsr.emp_date_in desc,etsr.emp_time_in desc";
	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arrResult = mysql_query($query." limit $start,$per_page");
	
	if(mysql_num_rows($arrResult) > 0)
	{
	while($arrCustomer = mysql_fetch_array($arrResult))
	{
         
		$outputData .= "<tr>";
			$outputData .= "<td><img src='../../../../images/icons/timesheetrecord-icon.png' width=25 height=25 /></td>";
			$outputData .= "<td>".$arrCustomer['user']."</td>";
			$outputData .= "<td>".$arrCustomer['dept_name']."</td>";
			$outputData .= "<td>".$arrCustomer['position_name']."</td>";
			$outputData .= "<td>".date("D M d, Y",strtotime($arrCustomer['emp_date_in']))."</td>";
			$outputData .= "<td>".date("g:i a", strtotime($arrCustomer['emp_time_in']))."</td>";
			if($arrCustomer['emp_time_out']=="" || $arrCustomer['emp_time_out']==null)
			$outputData .= "<td align='center'>----</td>";
			else
			$outputData .= "<td>".date("g:i a", strtotime($arrCustomer['emp_time_out']))."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	
	else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrResult);
