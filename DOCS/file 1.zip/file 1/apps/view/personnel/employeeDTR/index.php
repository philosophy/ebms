﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Employee Daily Time Records</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Employee Daily Time Records");
		datagridMenu("DTR","log");
		datagrid("dtr-view",false);
		
		$("#pdf").click(function(){
		window.open("../../../view/reports/timeSheet/timeSheetRecord.php","_new");
		});
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/personnel/index.php"); ?>
<?php include("../../../controller/dailyTimeRecord/dtrController.php"); ?>
<div id="body-pane" style="height:90px;">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="dtr-view" class="datagrid-container">
</div>
</div>
</div>

<?php include("../../footer-view.php"); ?>

</body>
</html>

