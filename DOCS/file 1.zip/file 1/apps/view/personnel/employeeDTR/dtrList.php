﻿<?php

include("../../../../config/config.php");
$empID = @$_POST['empID'];
$pword = @$_POST['pword'];
$role = @$_POST['role'];
$_SESSION['empID'] = $empID;
$_SESSION['pword'] = $pword;
$outputData = "";

function validateUser()
{
  $queryValidate = mysql_query("select ua.emp_id,ua.user_password from user_account ua where ua.emp_id=".$_SESSION['empID']." and user_password=sha('".$_SESSION['pword']."')");
  $num = mysql_num_rows($queryValidate);
  if( $num > 0)
		$isValid=1;
  if( $num == 0)
	    $isValid=0;
  return $isValid;
}

function alreadyLogIn()
{
  $queryValidate = mysql_query("select * from employee_time_sheet_record where emp_id=".$_SESSION['empID']." and emp_date_in=curdate()");
  $ex = mysql_num_rows($queryValidate);
  if( $ex == 0)
		$exist=1;
  if( $ex > 0)
	    $exist=0;
  return $exist;
}

function alreadyLogOut()
{
  $queryValidate = mysql_query("select emp_time_out from employee_time_sheet_record where emp_id=".$_SESSION['empID']." and emp_date_in=curdate()");
  $row = mysql_fetch_row($queryValidate);
  if( $row[0] == "" || $row[0] == null)
		$exist=1;
  if( $row[0] != "" || $row[0] != null)
	    $exist=0;
  return $exist;
}

function noLogInYet()
{
  $queryValidate = mysql_query("select * from employee_time_sheet_record where emp_id=".$_SESSION['empID']." and emp_date_in=curdate()");
  $ex = mysql_num_rows($queryValidate);
  if( $ex == 0)
		$exist=0;
  if( $ex > 0)
	    $exist=1;
  return $exist;
}

if($role == "timein")
{
    $isValid=validateUser();
	$existIn=alreadyLogIn();
	if($isValid==1&&$existIn==1)
	{
		$query = mysql_query("INSERT INTO employee_time_sheet_record (emp_date_in,emp_time_in,emp_id) 
		VALUES (curdate(),curtime(),'$empID')");
		
	    mysql_query("INSERT INTO audit_trail(AUDIT_DATE,AUDIT_TIME,AUDIT_ACTION_TAKEN,EMP_ID)
		VALUES (curdate(),curtime(),'Employee time in','$empID')");
		echo 'TimeIn';
	}
	else if($isValid==0)
	{
        echo 'Invalid';
	}
	else if($existIn==0)
	{
	    echo 'ExistIn';
	}
}
else if($role == "timeout")
{
    $isValid=validateUser();
	$existOut=alreadyLogOut();
	$noLogIn=noLogInYet();
	if($isValid==1&&$existOut==1&&$noLogIn==1)
	{
		$query = mysql_query("UPDATE employee_time_sheet_record SET emp_time_out = curtime() WHERE 
		emp_id = '$empID' and emp_date_in=curdate()");
		
		mysql_query("INSERT INTO audit_trail(AUDIT_DATE,AUDIT_TIME,AUDIT_ACTION_TAKEN,EMP_ID)
		VALUES (curdate(),curtime(),'Employee time out','$empID')");
		
		$queryHrMin = mysql_query("select
		round((time_to_sec(TIMEDIFF(emp_time_out,emp_time_in))/60),0) as 'min',     
		round((time_to_sec(TIMEDIFF(emp_time_out,emp_time_in))/3600),0) as 'hr'
		from employee_time_sheet_record WHERE 
		emp_id = '$empID' and emp_date_in=curdate()");
		
		$row = mysql_fetch_row($queryHrMin);
		$query = mysql_query("UPDATE employee_time_sheet_record 
		SET EMP_TOTAL_HRS_WORKED = ".$row[1].",EMP_TOTAL_MINS_WORKED = ".$row[0]." WHERE 
		emp_id = '$empID' and emp_date_in=curdate()");
		echo 'TimeOut';
	}
	else if($isValid==0)
	{
		echo 'Invalid';
	}
	else if($existOut==0)
	{
	    echo 'ExistOut';
	}
	else if($noLogIn==0)
	{
	    echo 'ExistLogIn';
	}
}

else if($role == "VIEW")
{
$viewType = @$_POST['viewType'];

$query = mysql_query("select ep.emp_id,ep.emp_code,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user', dept_name, position_name, date_format(emp_date_in,'%b-%d-%Y') as 'emp_date_in', emp_time_in, emp_time_out from employee_profile ep, position pos, emp_status es, department dept, employee_time_sheet_record etsr where ep.emp_status_id=es.emp_status_id and ep.position_id=pos.position_id and ep.dept_id=dept.dept_id and etsr.emp_id=ep.emp_id and etsr.emp_date_in=curdate() order by etsr.emp_time_in desc,etsr.emp_time_out desc");
	
		if($viewType == null)
		{
			$outputData .="<table>
							<th style='padding:5px;width:10px;min-width:10px;'></th>
							<th>Name</th>
							<th>Time In</th>
							<th>Time Out</th>";
				
				if(mysql_num_rows($query) > 0)
					{
						while($arr = mysql_fetch_array($query))
						{
							$outputData .= "<tr title='".$arr['emp_code']."'>";
							$outputData .= "<td style='padding:5px;width:10px;min-width:10px;'><img src='../../../../images/icons/dailytime-icon.png' width=25 height=25 /></td>";
							$outputData .= "<td>".$arr['user']."</td>";
							$outputData .= "<td>".date("g:i a", strtotime($arr['emp_time_in']))."</td>";
							if($arr['emp_time_out']=="" || $arr['emp_time_out']==null)
							{$outputData .= "<td align='center'>-----</td>";}
							else
							{$outputData .= "<td>".date("g:i a", strtotime($arr['emp_time_out']))."</td>";}
						    $outputData .= "</tr>";
						}
					}	
				else
				{
				$outputData .= "<tr><td colspan='4' align='center' style='color:gray;'>No DTR found...</td></tr>";
				}		
		$outputData .= "</table>";
		}
		
		else if($viewType == "comboBox")
		{
		$queryUser = mysql_query("select ep.emp_id,concat(emp_first_name,' ',left(emp_middle_name,1),'. ',emp_last_name) as 'user' from employee_profile ep, user_account ua where ep.emp_id = ua.emp_id and ep.is_deleted=0");
		
		        $outputData .= "<option value='none' style='text-align:center;font-weight:Italic;color:gray;'> -Select Employee-</option>";
				while($row = mysql_fetch_array($queryUser))
				{
				$outputData .= "<option empid='".$arr['emp_id']."' value='".$row['emp_id']."'>".$row['user']."</option>";
				}
		}
	
	echo $outputData;
	
	mysql_free_result($query);
}