﻿<?php 

$week = 35;

echo "Week No. today: ".$week;

$date = date("Y-m-j",strtotime("2011-01-01 + ".$week." weeks"));
echo "<br/>Prev Date: ".$date."<br/>";
$newdate = strtotime ( '-5 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-j' , $newdate );

for($i=1;$i<=7;$i++)
	{
	echo "<br/>Date: ".$newdate;
	$newdate = date("Y-m-j",strtotime($newdate."+1 Days"));
	}