﻿<?php
include("../doctype-standard.php"); ?>
<head>
<title>EBMS Home View</title>
<?php include("../standard-js-css.php"); ?>
		<link rel="stylesheet" type="text/css" href="/EBMS/css/clock.css" />
        <script type="text/javascript" src="/EBMS/js/jquery.rotate.1-1.js"></script> 
        <script type="text/javascript" src="/EBMS/js/clock.js"></script> 
</head>
<body>
<div id="header-pane">
	<?php #Include top navigation pane
		include("../orb/orb-top-nav.php");
	?>	
</div>
<?php 
include("../../controller/logout/logoutOnBrowserCloseController.php");
?>
<div id="body-pane">

	<div id="bodyPaneView">

	</div>

	<div class="body-left-pane">

		<div id="clock-cont">
			<!--This is the clock--> 
            <div id="analog-clock" > 
                <img id='bg' src='/EBMS/images/clock/clockBg.png' width='170px' height='170px' alt='clock face' /> 
                <img id='hourHand' src='/EBMS/images/clock/hourHand.png' alt='hour hand' /> 
                <img id='minuteHand' src='/EBMS/images/clock/minuteHand.png' alt='minute hand' /> 
                <img id='secondHand' src='/EBMS/images/clock/secondHand.png' alt='second hand' /> 
            </div> 
		</div>

		<div id="summary"> <!--container element for summary viewer-->
			
				<script>
				$.post("summary-view.php",
					function(response)
						{
						$("#summary").html(response);
						$("#summary").prepend("<h4>SUMMARY</h4><?php date("m")?>");
						});
				</script>
		</div>


		<div id="attendance"> <!--container element for attendance viewer-->
				<script>
				$.post("attendance-view.php",
					function(response)
						{
						$("#attendance").html(response);
						$("#attendance").prepend("<h4>ATTENDANCE</h4>");
						});
				</script>
</div>

	</div>
<!--end body left pane container-->
	<div class="body-right-pane">
		<div id="body-content-container">
			<div id="instantViewCont">
			<?php include "instant-view.php"; ?>
			</div>
			
			<div id="moduleViewCont">	
				<div id="modules">
					<ul class="moduleNav">
						<!--CRM-->
						<li id="moduleList">
							<a href="#" id="moduleLink">
							<img src="../../../images/icons/crmIcon.png" id="icon">
							<h3>Customer Management Records</h3>
							</a>
							<ul class="subModuleNav">
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Customer Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View customers with issued items
										</a>
									</li>
							</ul>
						</li>
						<!--Sales Management-->
						<li id="moduleList">
							<a href="#" id="moduleLink">
							<img src="../../../images/icons/salesIcon.png" id="icon">
							<h3>Sales Management</h3>
							</a>
							<ul class="subModuleNav">
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Create Order Slip
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Create Delivery Receipt
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View Daily Sales Report
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View Sales Forecast
										</a>
									</li>
								</ul>
						</li>
						<!--Accounts Management-->
						<li id="moduleList">
							<a href="#" id="moduleLink">
							<img src="../../../images/icons/accountIcon.png" id="icon">
							<h3>Accounts Management</h3>
							</a>
							<ul class="subModuleNav">
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View Customer With Balance
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View company payables
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Check Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Voucher Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Bank Records and Transactions
										</a>
									</li>
								</ul>
						</li>
						<!--Purchasing Management-->
						<li id="moduleList">
							<a href="#" id="moduleLink">
							<img src="../../../images/icons/purchasingIcon.png" id="icon">
							<h3>Purchasing Management</h3>
							</a>
							<ul class="subModuleNav">
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Create Purchase Request
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Create Purchase Order
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Supplier Records
										</a>
									</li>
								</ul>
						</li>
						<!--Personnel Management-->
						<li id="moduleList">
							<a href="#" id="moduleLink">
							<img src="../../../images/icons/personnelIcon.png" id="icon">
							<h3>Personnel Management</h3>
							</a>
							<ul class="subModuleNav">
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Employee Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Employee Schedule
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View Time Sheet Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Cash Advance
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Employee Payroll
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View Employee With Issued Items
										</a>
									</li>
								</ul>
						</li>
						<!--Inventory Management-->
						<li id="moduleList">
							<a href="#" id="moduleLink">
							<img src="../../../images/icons/inventoryIcon.png" id="icon">
							<h3>Inventory Management</h3>
							</a>	
								<ul class="subModuleNav">
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Product Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Manage Asset and Supplies Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											View, Create or Print Receiving Records
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Create Withdrawal Slip
										</a>
									</li>
									<li id="subModuleList">
										<a href="#" id="subModuleLink">
											Record Product Adjustments
										</a>
									</li>
								</ul>
						</li>
						
					</ul>
				</div>
				
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function(){
		
		$(".body-right-pane").height($("#instantViewCont").height()-1);
		
		$("#bodyPaneViewList").find("a#bodyPaneViewLink").click(function(){
		
		var ref = $(this).attr("ref");
		var height = $(".body-right-pane").height();
		var elemNo = Number($(this).attr("no"))-1;
		var scrollHeight = height*elemNo;
		
		$("a#bodyPaneViewLink").removeClass("bodyPaneViewLinkActive");
		$(this).addClass("bodyPaneViewLinkActive");
		$(".body-right-pane").stop().animate({scrollTop:Number(scrollHeight)-2},"slow",
			function()
			{
			var adjustHeight = $("#"+ref).height() - $(".body-right-pane").height();
			var adjustString = "";
				if(adjustHeight <= 0)
				{
				$(".body-right-pane").animate({height:$("#"+ref).height()},"slow");
				}
				else
				{
				adjustHeight += 20;
				$(".body-right-pane").animate({height:"+="+adjustHeight},"slow");
				}
				
			});
		
		return false;
		});
		
	});
</script>

<?php include("../footer-view.php"); ?>
</body>
</html>

