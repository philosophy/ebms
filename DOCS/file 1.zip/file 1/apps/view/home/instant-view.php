
<div id="instant-view-container">

<div class="dash-view">
<iframe src="../dashboard/dashboard-view-sales.php" width="670" height="430" scrolling="no" style="padding:0" frameborder="0" id="iframe-dashboard"></iframe>	
</div>
<div id="dashboard-nav-cont">
<div id="dashboard-nav">
	<ul>
		
		<li>
		<img class="divOnDisplay" id="thumbs" alt="Sales" src="/EBMS/images/icons/sales-icon.png">
		<img class="point" id="sales" src="/EBMS/images/point-arrow.png">
		<div class="tooltip">
		Sales Monitoring
		</div>
		</li>
		
		<li>
		<img alt="CRM" id="thumbs" src="/EBMS/images/icons/crm-icon.png">
		<img class="point" id="crm" src="/EBMS/images/point-arrow.png">
		<div class="tooltip">
		Customer Records Management
		</div>
		</li>
		<li>
		<img alt="Forecast" id="thumbs" src="/EBMS/images/icons/project-icon.png">
		<img class="point" id="forecast" src="/EBMS/images/point-arrow.png">
		<div class="tooltip">
		Sales Forecasting
		</div>
		</li>
		
	</ul>
</div>
</div>
</div>

