<?php 
include("../../../config/config.php");
$customerCode = @$_POST['customerCode'];

$arrResult = mysql_query("SELECT cur_symbol FROM currency where is_flag=1");
$cur = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT coalesce(SUM(GL_AMOUNT),0.00) as 'sumCashOnHand' FROM general_ledger where gl_date=curdate() and ACCOUNT_SUB_CATEGORY_ID = 7");
$cashOnHand = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT COUNT(is_active) as 'numActive' FROM customer_profile WHERE is_active = 1");
$numActive = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT COUNT(is_active) as 'numInactive' FROM customer_profile WHERE is_active = 0");
$numInactive = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT coalesce(SUM(os_hdr_net_amount),0.00) as 'sales' FROM os_header where os_hdr_date=curdate()");
$sales = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT count(customer_id) as 'numCustomer' from customer_profile where date_created = curdate()");
$newCustomer = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT coalesce(SUM(GL_AMOUNT),0.00) as 'sumAP' FROM general_ledger where gl_date=curdate() and ACCOUNT_SUB_CATEGORY_ID = 4");
$ap = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT coalesce(SUM(GL_AMOUNT),0.00) as 'sumEXP' FROM general_ledger where gl_date=curdate() and ACCOUNT_SUB_CATEGORY_ID = 6");
$exp = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT coalesce(SUM(GL_AMOUNT),0.00) as 'sumAR' FROM general_ledger where gl_date=curdate() and ACCOUNT_SUB_CATEGORY_ID = 3");
$ar = mysql_fetch_array($arrResult);

$arrResult = mysql_query("SELECT coalesce(SUM(OS_DTL_QTY),0) as 'sumOrder' FROM os_header oh, os_detail od where oh.os_hdr_no=od.os_hdr_id and os_hdr_date=curdate()");
$order = mysql_fetch_array($arrResult);

$outputData = "";
	$outputData .="<div style='font-family:Tahoma;padding-bottom:2px;border-bottom:1px solid #069;color:#635B5D;text-align:center;font-size:12px;margin-top:-15px;'>As of ".date("m/d/Y")."</div>
	<table>
		<th>Name</th><th>Value</th>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/smiley-icon.png'>New Customer</td><td>".$newCustomer['numCustomer']."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/smiley-icon.png'>Total Active</td><td>".$numActive['numActive']."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/inactive.png'>Total Inactive</td><td>".$numInactive['numInactive']."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/order-icon.png'>Total Order</td><td>".$order['sumOrder']."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/money-icon.png'>Total Collected</td><td>".$cur['cur_symbol'].number_format($ar['sumAR'], 2)."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/hand-icon.png'>Cash On Hand</td><td>".$cur['cur_symbol'].number_format($cashOnHand['sumCashOnHand'], 2)."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/sales-icon.png'>Total Sales</td><td>".$cur['cur_symbol'].number_format($sales['sales'], 2)."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/voucher-icon.png'>Exp. Voucher</td><td>".$cur['cur_symbol'].number_format($exp['sumEXP'], 2)."</td>
			</tr>
			<tr class='list-brkdwn'>
			<td><img src='../../../images/icons/acct-pay-icon.png'>Exp. A/P</td><td>".$cur['cur_symbol'].number_format($ap['sumAP'], 2)."</td>
			</tr>";
			
$outputData .= "</table>";

echo $outputData;

mysql_free_result($arrResult);