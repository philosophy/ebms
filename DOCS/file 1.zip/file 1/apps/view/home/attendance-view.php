<?php 
include("../../../config/config.php");

$outputData = "";
	$outputData .="
	    <table>
		<th>Name<span style='color:#069;float:right'>  ".date("D M d, Y")."</span></th>";
			
	$arrResult = mysql_query("select EMP_FIRST_NAME,EMP_MIDDLE_NAME,EMP_LAST_NAME,EMP_TIME_IN,EMP_TIME_OUT from employee_time_sheet_record etsr, employee_profile ep where etsr.emp_id=ep.emp_id and emp_date_in=curdate()");
	$number_of_audit = mysql_num_rows($arrResult);
	if($number_of_audit>0)
	{
	
	while($arrCustomer = mysql_fetch_array($arrResult))
	{
		if($arrCustomer['EMP_TIME_OUT']==null)
		{
			$outputData .= "<tr class='list-brkdwn' title='Time In: ".date("g:i a", strtotime($arrCustomer['EMP_TIME_IN']))."'>";
		}	 
		else
		{
			$outputData .= "<tr class='list-brkdwn' title='Time In: ".date("g:i a", strtotime($arrCustomer['EMP_TIME_IN'])).' Time Out: '.date("g:i a", strtotime($arrCustomer['EMP_TIME_OUT']))."'>";
		}
		$outputData .= "<td><img src='../../../images/icons/employee-icon.png'>".((strlen($arrCustomer['EMP_FIRST_NAME'].' '.$arrCustomer['EMP_LAST_NAME']) > 27)?(substr($arrCustomer['EMP_FIRST_NAME'].' '.$arrCustomer['EMP_LAST_NAME'],0,27)."..."):$arrCustomer['EMP_FIRST_NAME'].' '.$arrCustomer['EMP_LAST_NAME'])."</td>";
		$outputData .= "</tr>";	
	}
	}
	else
	{
	$outputData .= "";
	}
	
$outputData .= "</table>";

echo $outputData;

mysql_free_result($arrResult);