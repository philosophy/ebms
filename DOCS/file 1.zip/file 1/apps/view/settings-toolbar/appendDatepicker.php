<?php 
	$settingsBtn = "<div id='settings-btn' >Settings <img src='../../../images/icons/settings-icon.png'></div>";
	
	$months = "";
	for($i=0;$i<12;$i++)
		{
		$months .="<option value='".$i."'>".date("F",mktime(0, 0, 0, $i+1))."</option>";
		}
		$year = "";
	
	$defaultYear = date("Y");
	
	$defaultYear -=5;
	for($i=1;$i<5;$i++)
	{
	$defaultYear ++;
	$year .= "<option value={$defaultYear}>".$defaultYear."</option>";
	}
	
	$defaultYear = date("Y");
	
	for($i=1;$i<=5;$i++)
	{
	$year .= "<option value={$defaultYear}>".$defaultYear."</option>";
	$defaultYear ++;
	}
	
	echo "<script>$('select#year option').val('2011');</script>";
	
	
	$selectPeriod = "<ul class='period-option'>
						<li><a href='#' id='daily'>Daily</a></li>
						<li><a href='#' id='weekly'>Weekly</a></li>
						<li><a href='#' id='monthly'>Monthly</a></li>
					</ul>";
	$goBtn = "<div id='goBtn'><button id='go'>Go</button></div>";
 	$datepickerOption_daily = "<div id='daily_datepicker' style='display:show'><label for='from'>From</label><input type='text' id='dayFrom' name='dayFrom'/><label for='to'>to</label><input type='text' id='dayTo' name='to'/>".$goBtn."</div>";

 	$datepickerOption_weekly = "<div id='weekly_datepicker' style='display:none'><label for='from'>Week</label><input type='text' id='weekFrom' name='from'/><label for='to'>to</label><input type='text' id='weekTo' name='to'/>".$goBtn."</div>";

 	$datepickerOption_monthly = "<div id='monthly_datepicker' style='display:none'><label for='from'>From</label><input type='text' id='monthFrom' name='from'><label for='to'>To</label><input type='text' id='monthTo' name='to'>".$goBtn."</div>";

	
	$optionsPane = "<div id='graph-options-pane'>".$datepickerOption_daily.$datepickerOption_weekly.$datepickerOption_monthly.$selectPeriod."</div>";
		
	$toolbarDiv = "<div id='settings'>".$settingsBtn.$optionsPane."</div>";
	
	echo $toolbarDiv;
?>

	
	
	