﻿<?php 

$searchQuery = stripslashes($searchQuery);
	$outputData = "
		<div id='noResult'>
		<img src='/ebms/images/icons/searchNotFound.png'>
		<span>No results found ".(($searchQuery=='')?"":" for '".$searchQuery."'")."</span>
		</div>";

?>