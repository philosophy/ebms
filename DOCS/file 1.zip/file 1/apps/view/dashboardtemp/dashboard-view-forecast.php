<?php include("../doctype-standard.php"); ?>
<head> 
	<?php include("../standard-js-css.php"); ?>
  	<link rel="stylesheet" type="text/css" href="/EBMS/css/dashboard-graph-stylesheet.css" />
	<!--
	<php include("../graph-js-css.php"); ?>
	<script type="text/javascript" language="javascript"> 
  
  $(document).ready(function(){
	graphTitle = "Sales Forecasting";
    plot6 = $.jqplot('sales-forecast', [[1,7,3,2,9,11,8]],{
	
	 // Give the plot a title.
      title: graphTitle,
      // You can specify options for all axes on the plot at once with
      // the axesDefaults object.  Here, we're using a canvas renderer
      // to draw the axis label which allows rotated text.
      axesDefaults: {
        labelRenderer: $.jqplot.CanvasAxisLabelRenderer
      },// An axes object holds options for all axes.
      // Allowable axes are xaxis, x2axis, yaxis, y2axis, y3axis, ...
      // Up to 9 y axes are supported.
      axes: {
        // options for each axis are specified in seperate option objects.
        xaxis: {
          label: "Day",
          // Turn off "padding".  This will allow data point to lie on the
          // edges of the grid.  Default padding is 1.2 and will keep all
          // points inside the bounds of the grid.
          pad: 1
        },
        yaxis: {
          label: "Unit Sales"
        }
      }
    });
 
  });
  </script> 
  </head> 
  <body>

  <div id="graph-tab-header-title">Dashboard for Sales Forecasting</div>  
  <php include("../settings-toolbar/appendDatepicker.php"); ?>
  <div id="graph-container">
  <div id="sales-forecast">
  </div>
  </div>-->
  
	<?php
	include("../graph-js-css.php");
	include("../../controller/dashboard/dashboardControllerForecast.php");
	?>
  </head> 
  <body>
  <div id="graph-tab-header-title">Dashboard for Sales Forecasting</div>  
  
  
  <?php include("../settings-toolbar/settings-toolbar-datepicker.php"); ?> 
  
	<div id="graph-parent">
		<?php include("../settings-toolbar/appendDatepicker.php"); ?>
		<div id="dailyForecast" ref="graphPlot"></div>
		<div id="monthlyForecast" ref="graphPlot"></div>
		<div id="weeklyForecast" ref="graphPlot"></div>
	</div>

  </body> 
</html>