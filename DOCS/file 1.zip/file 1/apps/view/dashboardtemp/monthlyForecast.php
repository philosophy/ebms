<?php 
session_start();
include("../../../config/config.php");
$i=0;
$output[]="";
		
		
		$dateFrom = date("Y-m-d");
		
		$query = mysql_query("
		SELECT SUM(os_hdr_net_amount) as 'sum',monthname(os_hdr_date) as 'month'
		FROM OS_HEADER
		GROUP BY month desc
		");
	
		
		while($arrResult = mysql_fetch_array($query))
		{
		$dateVal = $arrResult['month'];
		$salesVal = (float)$arrResult['sum'];
		
		$output[$i] = array($dateVal,$salesVal);
		$i++;
		}

	$dataArray = json_encode(array("data"=>$output));
	
	echo $dataArray."&&"."monthly";

