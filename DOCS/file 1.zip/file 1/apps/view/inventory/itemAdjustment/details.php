<?php
include("../../../../config/config.php");
$role = $_POST['role'];
$adjID = @$_POST['adjid'];

if($role=="view")
{
	$outputData = "<table>
		<th>Item Code</th>
		<th>Description</th>
		<th>Add</th>
		<th>Less</th>
		<th>Remarks</th>";

	$rec=mysql_query("SELECT `ADJ_DTL_ITEM_DESCRIPTION`, `ADJ_DTL_REMARKS`, `ADJ_DTL_ADD`, `ADJ_DTL_LESS`, `ITEM_CODE` FROM `adjustment_detail` WHERE adj_hdr_id='".$adjID."'");
							

	$recList = mysql_num_rows($rec);

	if($recList > 0)
	{
		while($row = mysql_fetch_array($rec))
		{
			$outputData .= "<tr>";
			$outputData .= "<td>".$row["ITEM_CODE"]."</td>";
			$outputData .= "<td>".$row["ADJ_DTL_ITEM_DESCRIPTION"]."</td>";
			$outputData .= "<td>".$row["ADJ_DTL_ADD"]."</td>";
			$outputData .= "<td>".$row["ADJ_DTL_LESS"]."</td>";
			$outputData .= "<td>".$row["ADJ_DTL_REMARKS"]."</td>";
			
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
		echo $outputData;
	}
	else
	{
		echo 'No results found';
	}
}
else if($role=="render")
{
	$outputData = "";

	$rec=mysql_query("SELECT adj_dtl_id, `ADJ_DTL_ITEM_DESCRIPTION`, `ADJ_DTL_REMARKS`, `ADJ_DTL_ADD`, `ADJ_DTL_LESS`, `ITEM_CODE` FROM `adjustment_detail` WHERE adj_hdr_id='".$adjID."'");
							

	$recList = mysql_num_rows($rec);
	while($row = mysql_fetch_array($rec))
	{
		$outputData .= "<tr id='". $row["adj_dtl_id"] ."'>";
		$outputData .= "<td>".$row["ITEM_CODE"]."</td>";
		$outputData .= "<td>".$row["ADJ_DTL_ITEM_DESCRIPTION"]."</td>";
		$outputData .= "<td>".$row["ADJ_DTL_ADD"]."</td>";
		$outputData .= "<td>".$row["ADJ_DTL_LESS"]."</td>";
		$outputData .= "<td><input type='text' id='remarks' style='width:100%' value='".$row["ADJ_DTL_REMARKS"]."'/></td>";
		
		$outputData .= "</tr>";
	}
		
	$outputData .= "</table>";
	echo $outputData;
}

?>