<?php
session_start();
include("../../../../config/config.php");
$emp = $_SESSION['emp_id'];
$role = $_POST['role'];

if($role=="add")
{
	$remarks = $_POST['remarks'];
	$id = 0;
	$year=0;
	$prodCode="";
	$query = "SELECT MAX(adj_hdr_ID) as 'id',YEAR(CURDATE()) as 'year' FROM adjustment_header";
	$result = mysql_query($query);
	while ($row = mysql_fetch_array($result))
	{
		if($row['id']=="")
		{
			$id=0;
		}
		else
		{
			$id = $row['id'];
		}
		$year = $row['year'];
	}
	
		$prodCode = "ADJ-" . $year ."-" . substr("000000",0,strlen("000000") - strlen($id + 1)) . ($id + 1);
		
	$query = "INSERT INTO `adjustment_header`(`ADJ_HDR_CODE`, `ADJ_HDR_DATE`, `ADJ_HDR_REMARKS`, `IS_DELETED`, `ADJ_CREATED_BY_ID`) VALUES ('". $prodCode ."', curdate(),'". $remarks ."',0,'". $emp ."')";	
	mysql_query($query);
	echo $prodCode;
}
else if($role=="addDetails")
{
	$code = $_POST['itemCode'];
	$quantity = $_POST['qty'];
	$action= $_POST['method'];
	$stock = $_POST['inventory'];
	$desc = $_POST['description'];
	$remarks = $_POST['remark'];
	$adjCode = $_POST['adjcode'];
	$adjID="";
	$result = mysql_query("SELECT adj_hdr_ID FROM adjustment_header where adj_hdr_code='" . $adjCode . "'");
	while ($row = mysql_fetch_array($result))
	{
		$adjID=$row[0];
	}
	
	if($action=="Add")
	{
		$query = "INSERT INTO `adjustment_detail`(`ADJ_DTL_ITEM_DESCRIPTION`, `ADJ_DTL_REMARKS`, `ADJ_DTL_ADD`, `ADJ_DTL_LESS`, `ADJ_HDR_ID`, `ITEM_CODE`) VALUES ('". $desc ."','". $remarks ."','". $quantity ."','0','". $adjID ."','". $code ."')";
		$inventory = "update product set product_qty='". ($stock + $quantity) ."' where product_code = '" . $code . "'";
	}
	else if($action == "Less")
	{
		$query = "INSERT INTO `adjustment_detail`(`ADJ_DTL_ITEM_DESCRIPTION`, `ADJ_DTL_REMARKS`, `ADJ_DTL_ADD`, `ADJ_DTL_LESS`, `ADJ_HDR_ID`, `ITEM_CODE`) VALUES ('". $desc ."','". $remarks ."','0','". $quantity ."','". $adjID ."','". $code ."')";
		$inventory = "update product set product_qty='". ($stock - $quantity) ."' where product_code = '" . $code . "'";
	}
	mysql_query($query);
	mysql_query($inventory);
	echo $inventory;
}
else if($role=="updateHeaderRemarks")
{
	$adjCode = $_POST['adjCode'];
	$remarks = $_POST['remarks'];
	$query = "update adjustment_header set adj_hdr_remarks='" . $remarks . "' where adj_hdr_code='" . $adjCode . "'";
	mysql_query($query);
}
else if($role=="updateDetailsRemarks")
{
	$id = $_POST['id'];
	$remarks = $_POST['remarks'];
	$query = "update adjustment_detail set adj_dtl_remarks='" . $remarks . "' where adj_dtl_id='" . $id . "'";
	mysql_query($query);
}
?>
