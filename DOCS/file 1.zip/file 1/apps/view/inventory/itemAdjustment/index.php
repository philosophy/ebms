﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Item Adjustment</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Item Adjustment");
		datagridMenu("adjustment","new;edit");
		datagrid("customerTransact;checkPayment",false);
		$("#tabbed-grid").tabs({fx: { height: 'toggle', duration: 'fast' },
		});
		
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php 
include("../../../controller/itemAdjustment/itemAdjustmentController.php");
include("../../modalForms/inventory/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="adjustmentList" class="datagrid-container">
	
</div>
</div>
 
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#details">Details</a></li>
	</ul> 
	
	<div id="details" class="scrollable" style="height:150px;"> 
		<!-- general description preview -->
	</div>
</div>
</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

