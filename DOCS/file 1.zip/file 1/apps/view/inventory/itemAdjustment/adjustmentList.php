<?php
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = " where adj_hdr_code LIKE '%".$searchQuery."%' or adj_hdr_date LIKE '%".$searchQuery."%' or adj_hdr_remarks LIKE '%".$searchQuery."%' ";
	}

elseif ($searchQuery == "")
	$condition = " ";


$cur_page = $page;
$page -= 1;
$per_page = 9;
$start = $page * $per_page;
	$outputData = "<table >
			<th></th>
			<th>Adjustment Code</th>
			<th>Date</th>
			<th>Employee</th>
			<th>Remarks</th>";
			
$query = "SELECT  `ADJ_HDR_CODE` AS  'Adjustment Code', `ADJ_HDR_ID` AS  'ID', DATE_FORMAT( ADJ_HDR_DATE,  '%M %d, %Y' ) AS  'Date', CONCAT( emp_first_name,  ' ', emp_middle_name,  ' ', emp_last_name ) AS  'Employee',  `ADJ_HDR_REMARKS` AS 'Remarks', adjustment_header.IS_DELETED as 'deleted',  `ADJ_CREATED_BY_ID` 
FROM  `adjustment_header` 
INNER JOIN employee_profile ON emp_id = adj_created_by_id".$condition."order by 1 desc";
				
			$count = mysql_num_rows(mysql_query($query));
			$no_of_paginations = ceil($count / $per_page);
	
			$arrRows = mysql_query($query." limit $start,$per_page");

$icon = "";

if(mysql_num_rows($arrRows) >0)
{
	while($arrProduct = mysql_fetch_array($arrRows))
	{	
		if($arrProduct['deleted'] == 1)
		{
			$icon = "<td class='icon'><img src='../../../../images/icons/maintenance.png' height=20 width=20 /> </td>";
		}
		else if($arrProduct['deleted'] == 0)
		{
			$icon = "<td class='icon'><img src='../../../../images/icons/maintenance.png' height=20 width=20 /> </td>";
		}
	
		$outputData .= "<tr remarks='".$arrProduct['Remarks']."' adjID='". $arrProduct['ID'] ."' a=".$arrProduct['Adjustment Code']." deleted=" . $arrProduct['deleted'].">";
		$outputData .= $icon;
		$outputData .= "<td>".$arrProduct['Adjustment Code']."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrProduct['Date']))."</td>";
		$outputData .= "<td>".$arrProduct['Employee']."</td>";
		$outputData .= "<td>".$arrProduct['Remarks']."</td>";
		$outputData .= "</tr>";
	}
		$outputData .= "</table>";
}

else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrRows);