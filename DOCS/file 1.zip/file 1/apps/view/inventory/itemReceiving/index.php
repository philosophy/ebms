﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Item Receiving</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Item Receiving Records");
		datagridMenu("itemReceiving","new;edit");
		datagrid("receivingList",false);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php 
include("../../modalForms/inventory/index.php"); 
?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="receivingList" class="datagrid-container">
	<script>
		$('#receivingList').load('../../../controller/itemReceiving/itemReceivingController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#receivingDetails">Item Receiving Details</a></li>
	</ul>
	<div id="receivingDetails"> 
	Please select a Item Receiving record above	
	</div> 
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

