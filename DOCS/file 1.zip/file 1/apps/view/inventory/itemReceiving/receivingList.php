
<?php

include("../../../../config/config.php");
$outputData = "";

$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
		$condition = "WHERE REC_HDR_RECEIVED_REF_TYPE LIKE '%".$searchQuery."%' or REC_HDR_NO LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	$condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 7;

$start = $page * $per_page;

$index = 1;
	$outputData .= "<table>
		<th>Receiving #</th>
		<th>Date Received</th>
		<th>Reference #</th>
		<th>Returner Type</th>
		<th>Returned By</th>
		<th>Received Via</th>";
		
$query = "Select REC_HDR_ID, REC_HDR_NO,
REC_HDR_DATE,
REC_HDR_RECEIVED_REF_NO,
REC_HDR_RECEIVED_REF_TYPE,
ifnull(CUSTOMER_NAME, ifnull(concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME), SUPPLIER_NAME)) as 'Name',
REC_HDR_RECEIVED_REF 
From receiving_header RH
left outer join customer_profile C on RH.REC_HDR_RECEIVED_FROM = C.CUSTOMER_CODE
left outer join employee_profile E on RH.REC_HDR_RECEIVED_FROM = E.EMP_CODE
left outer join supplier_profile S on RH.REC_HDR_RECEIVED_FROM = S.SUPPLIER_CODE " . $condition . " Order By REC_HDR_NO desc";
				
	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arr = mysql_query($query." limit $start,$per_page");
	
	if(mysql_num_rows($arr) > 0)
	{
	while($arrResult = mysql_fetch_array($arr))
	{	
		$outputData .= "<tr a='".$arrResult['REC_HDR_ID']."'>";
		$outputData .=	"<td>".$arrResult['REC_HDR_NO']."</td>";
		$outputData .=	"<td>".date("D M d, Y",strtotime($arrResult['REC_HDR_DATE']))."</td>";
		$outputData .=	"<td>".$arrResult['REC_HDR_RECEIVED_REF_NO']."</td>";
		$outputData .=	"<td>".$arrResult['REC_HDR_RECEIVED_REF_TYPE']."</td>";
		$outputData .=	"<td>".$arrResult['Name']."</td>";
		$outputData .=	"<td>".$arrResult['REC_HDR_RECEIVED_REF']."</td>";
		$outputData .= "</tr>";
	}
	
	
	mysql_free_result($arr);
	$outputData .= "</table>";
	}
	
	else
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
 
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 

	