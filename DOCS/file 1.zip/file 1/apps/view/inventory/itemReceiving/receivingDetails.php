
<?php

include("../../../../config/config.php");
$outputData = "";

$receiveCode = $_POST['receiveCode'];
	$outputData .= "<table>
		<th>Quantity</th>
		<th>Unit</th>
		<th>Item Code</th>
		<th>Brand</th>
		<th>Category</th>
		<th>SubCategory</th>
		<th>Item Description</th>";
		
$query = mysql_query("Select REC_DTL_ID, REC_DTL_QTY,
UNIT_NAME,
PRODUCT_CODE,
BRAND_NAME,
CATEGORY_NAME,
SUB_CATEGORY_NAME,
REC_DTL_ITEM_DESCRIPTION
From receiving_detail RD
INNER JOIN receiving_header RH ON RD.REC_HDR_ID = RH.REC_HDR_ID
LEFT OUTER JOIN product P ON RD.ITEM_CODE = P.PRODUCT_CODE
LEFT OUTER JOIN brand B ON P.BRAND_ID = B.BRAND_ID
LEFT OUTER JOIN category C ON P.CATEGORY_ID= c.CATEGORY_ID
LEFT OUTER JOIN category_sub_category SUB ON P.SUB_CATEGORY_ID = SUB.SUB_CATEGORY_ID
LEFT OUTER JOIN unit U ON P.UNIT_ID = U.UNIT_ID
WHERE RD.REC_HDR_ID = '$receiveCode'");
				
	
	if(mysql_num_rows($query) > 0)
	{
	while($arrResult = mysql_fetch_array($query))
	{	
		$outputData .= "<tr a='".$arrResult['REC_DTL_ID']."'>";
		$outputData .=	"<td>".$arrResult['REC_DTL_QTY']."</td>";
		$outputData .=	"<td>".$arrResult['UNIT_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['PRODUCT_CODE']."</td>";
		$outputData .=	"<td>".$arrResult['BRAND_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['CATEGORY_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['SUB_CATEGORY_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['REC_DTL_ITEM_DESCRIPTION']."</td>";
		$outputData .= "</tr>";
	}
	
	
	$outputData .= "</table>";
	}
	else
	{
	$outputData = "No records found.";
	}

	
echo $outputData;
	
mysql_free_result($query);