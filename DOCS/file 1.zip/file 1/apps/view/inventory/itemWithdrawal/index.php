﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Item Withdrawal</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Item Withdrawal Records");
		datagridMenu("withdrawal","new;edit");
		datagrid("withdrawalList",false);
		$("#tabbed-grid").tabs({ collapsible: "true",
			fx: { height: 'toggle', duration: 'fast' },
		});
		
	
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php 
include("../../../controller/itemWithdrawal/itemListController.php");
include("../../modalForms/inventory/index.php"); 
?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="withdrawalList" class="datagrid-container">
	<script>
		$('#withdrawalList').load('../../../controller/itemWithdrawal/itemWithdrawalController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#withdrawalDetails">Item Withdrawal Details</a></li>
	</ul>
	<div id="withdrawalDetails"> 
	Please select a Item Withdrawal record above	
	</div> 
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

