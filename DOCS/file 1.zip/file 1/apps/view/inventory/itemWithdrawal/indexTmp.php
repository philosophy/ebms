﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Item Withdrawal</title>
<?php include("../../standard-js-css.php"); ?> 
<script>
	$(document).ready(function(){
		headTitle("Item Withdrawal");
		datagridMenu("withdrawal","new;edit;delete;restore");
		
	});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/inventory/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="crm-profile" class="datagrid-container">
	
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#customerTransact">Transactions</a></li> 
		<li><a href="#customerLocation">Location</a></li> 
		<li><a href="#customerIssuedItem">Issued Item</a></li>
		<li><a href="#checkPayment">Check Payments</a></li> 
	</ul> 
	<div id="customerTransact"> 
	Please select customer record above	
	</div> 
	<div id="customerLocation"> 
	<script>
		//compute height for tabs-2
		$('#tabbed-grid').bind('tabsshow', function(event, ui) {
		if (ui.index == 1) {
		$("#tabs-2").height($(".subgrid-pair").height()+50);
		}
		});
	</script>
		
		<div id="subgrid-head-first" class="subgrid-head-pair">Customer</div>		
		<div id="subgrid-head-second" class="subgrid-head-pair">Contacts</div>
		
		<div id="subgrid-first" class="subgrid-pair">
			<!-- customer location will be displayed here-->
		</div>
		
		<div id="subgrid-second" class="subgrid-pair">
			<!-- contact records will be displayed here-->
		</div>
	</div> 
	<div id="customerIssuedItem"> 
		Please select customer record above
		<!-- issued item will be displayed here-->
	</div> 
	<div id="checkPayment" class="subdatagrid"> 
        Please select customer record above
	</div> 
</div> 

</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

