
<?php

include("../../../../config/config.php");
$outputData = "";

$withdrawCode = @$_POST['withdrawCode'];
	$outputData .= "<table>
		<th>Quantity</th>
		<th>Unit</th>
		<th>Item Code</th>
		<th>Brand</th>
		<th>Category</th>
		<th>SubCategory</th>
		<th>Item Description</th>";
		
$query = mysql_query("Select WITH_DTL_ID,
WITH_DTL_ORIGINAL_QTY,
UNIT_NAME,
ITEM_CODE,
BRAND_NAME,
CATEGORY_NAME,
SUB_CATEGORY_NAME,
WITH_DTL_ITEM_DESCRIPTION
From withdrawal_detail WD
INNER JOIN withdrawal_header WH ON WD.WITH_HDR_ID = WH.WITH_HDR_ID
LEFT OUTER JOIN product P ON WD.ITEM_CODE = P.PRODUCT_CODE
LEFT OUTER JOIN brand B ON P.BRAND_ID = B.BRAND_ID
LEFT OUTER JOIN category C ON P.CATEGORY_ID = c.CATEGORY_ID
LEFT OUTER JOIN category_sub_category SUB ON P.SUB_CATEGORY_ID = SUB.SUB_CATEGORY_ID
LEFT OUTER JOIN unit U ON P.UNIT_ID = U.UNIT_ID
WHERE WD.WITH_HDR_ID = '$withdrawCode'");
				
	
	if(mysql_num_rows($query) > 0)
	{
	while($arrResult = mysql_fetch_array($query))
	{	
		$outputData .= "<tr a='".$arrResult['WITH_DTL_ID']."'>";
		$outputData .=	"<td>".$arrResult['WITH_DTL_ORIGINAL_QTY']."</td>";
		$outputData .=	"<td>".$arrResult['UNIT_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['ITEM_CODE']."</td>";
		$outputData .=	"<td>".$arrResult['BRAND_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['CATEGORY_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['SUB_CATEGORY_NAME']."</td>";
		$outputData .=	"<td>".$arrResult['WITH_DTL_ITEM_DESCRIPTION']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	else
	{
	$outputData = "No records found.";
	}

	
echo $outputData;
	
mysql_free_result($query);