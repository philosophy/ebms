
<?php

include("../../../../config/config.php");
$outputData = "";

$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE WITH_HDR_TYPE LIKE '%".$searchQuery."%' or WITH_HDR_PURPOSE LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	$condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 9;

$start = $page * $per_page;

$index = 1;

	$outputData .= "<table>
		<th>Withdrwal #</th>
		<th>Date Issued</th>
		<th>PURPOSE</th>
		<th>Withdrawed By</th>
		<th>Withdrawer Type</th>";
		
$query = "Select WITH_HDR_ID, WITH_HDR_NO,
concat(monthname(WITH_HDR_DATE_ISSUED), ' ', day(WITH_HDR_DATE_ISSUED), ', ', year(WITH_HDR_DATE_ISSUED)),
WITH_HDR_PURPOSE,
ifnull(CUSTOMER_NAME, ifnull(concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME), SUPPLIER_NAME)) as 'Name',
WITH_HDR_TYPE
From withdrawal_header WH
left outer join employee_profile E on WH.WITH_HDR_ISSUED_TO = E.EMP_CODE
left outer join customer_profile C on WH.WITH_HDR_ISSUED_TO = C.CUSTOMER_CODE
left outer join supplier_profile S on WH.WITH_HDR_ISSUED_TO = S.SUPPLIER_CODE " . $condition . " Order By WITH_HDR_NO desc";
				
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arr = mysql_query($query." limit $start,$per_page");
	
	if(mysql_num_rows($arr) > 0)
	{
		while($arrResult = mysql_fetch_array($arr))
		{	
			$outputData .= "<tr a='".$arrResult['WITH_HDR_ID']."'>";
			$outputData .=	"<td>".$arrResult['WITH_HDR_NO']."</td>";
			$outputData .=	"<td>".date("D M d, Y",strtotime($arrResult[2]))."</td>";
			$outputData .=	"<td>".$arrResult['WITH_HDR_PURPOSE']."</td>";
			$outputData .=	"<td>".$arrResult['Name']."</td>";
			$outputData .=	"<td>".$arrResult['WITH_HDR_TYPE']."</td>";
			$outputData .= "</tr>";
		}
	
		mysql_free_result($arr);
		
		$outputData .= "</table>";
	}
	else
	{
		include("../../noResults.php");
		$cur_page = 0;
	}
 
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
?>
	