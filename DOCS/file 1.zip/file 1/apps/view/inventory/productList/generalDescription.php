<?php
include("../../../../config/config.php");

$productCode = @$_POST['productCode'];
$outputData = "";
	$imagepath = "";
					
	$pic = mysql_query("SELECT p.product_image from product p where p.product_code='" . $productCode . "'");
	if(mysql_num_rows($pic)>0)
	{
		
		while($row = mysql_fetch_array($pic))
		{
			if($row[0] != "")
			$imagepath="../../../../images/stock/" . $row[0];
			else
			$imagepath="../../../../images/stock/default.png";
		}
	}

	$arrResult = mysql_query("SELECT p.product_FIELD_NAME as 'Field',
					i.product_DESCRIPTION as 'Value'
					FROM product_field p, product_information i
					where p.product_FIELD_ID = i.product_FIELD_ID
					and i.product_ID = '".$productCode. "'");
	if(mysql_num_rows($arrResult)>0)
	{
	$outputData .= "<div id='image' style='background:#ddd;width:15%;height:120px;float:left'><img src='" 
						. $imagepath . "' style='width:100%;height:100%;'/></div>
						<div id='tableDesc' style='float:Left;width:85%'>
						<table>
						<th>Field</th>
						<th>Value</th>";
						
			
	
		while($arrChecks = mysql_fetch_array($arrResult))
			{
			$outputData .= "<tr>";
				$outputData .= "<td>".@$arrChecks['Field']."</td>";
				$outputData .= "<td>".@$arrChecks['Value']."</td>";
			$outputData .= "</tr>";
			}
			$outputData .= "</table></div>";
	}
	else  
	{
	$outputData = "<div id='image' style='background:#ddd;width:15%;height:120px;float:left'><img src='" . $imagepath . "' style='width:98%;height:98%; margin:2px 2px 2px 2px;'/></div>
					<div id='tableDesc' style='float:Left;width:85%'>
					<br>No results found.</div>";
	}
	
echo $outputData;

?>