<?php
include("../../../../config/config.php");


$get_cust_type = mysql_query("Select brand_id, brand_name,is_deleted from brand where is_deleted=0");
$outputData ="";
if(mysql_num_rows($get_cust_type) > 0)
	{
			while($row = mysql_fetch_array($get_cust_type))
			{
				if($row['is_deleted'] == 0)
				$outputData .= "<option value='".$row['brand_id']."'>".$row['brand_name']."</option>";
			}
	}
	
	echo $outputData;
?>