<?php 
include("../../../../config/config.php");

$role = $_POST['role'];
$code = $_POST['item'];
$categoryId = "";
$subCategoryId = "";
$brandId="";
if($role=="update")
{
$getdata = mysql_query("Select P.Brand_id, P.Category_id, P.Sub_category_id, P.unit_id, P.Product_code, B.Brand_name, C.Category_name, SC.Sub_category_name, format(P.Product_Unit_Price,2) as 'Price', P.product_image, u.unit_name, p.minimum_stock, p.normal_stock,p.product_remarks from Product P left join Brand B on P.BRAND_ID = B.brand_id left join category C on P.CATEGORY_ID = C.CATEGORY_ID left join Category_Sub_Category SC on P.Sub_category_Id = SC.SUB_CATEGORY_ID inner join Unit u on P.unit_id=u.unit_id where  P.product_code='".$code."'");
$data[] = "";
if(mysql_num_rows($getdata) > 0)
		{	
			while($arrProduct = mysql_fetch_array($getdata))
			{
			$data["categoryID"] = $arrProduct["Category_id"];
			$data["brandID"] = $arrProduct["Brand_id"];
			$data["subCategoryID"] = $arrProduct["Sub_category_id"];
			$data["unitID"] = $arrProduct["unit_id"];
			$data["productCode"] = $arrProduct["Product_code"];
			$data["brand"] = $arrProduct["Brand_name"];
			$data["category"] = $arrProduct["Category_name"];
			$data["subCategory"] = $arrProduct["Sub_category_name"];
			$data["price"] = $arrProduct["Price"];
			$data["unit"] = $arrProduct["unit_name"];
			$data["image"] = $arrProduct["product_image"];
			$data["min"] = $arrProduct["minimum_stock"];
			$data["norm"] = $arrProduct["normal_stock"];
			$data["remarks"] = $arrProduct["product_remarks"];
			}
		}
	 $dataArray= json_encode(array("values"=>$data));
	 echo $dataArray;
}
else if($role=="delete")
{
	$query = "update product set is_deleted=1 where product_code='" . $code . "'";
	$result = mysql_query($query);
	echo "Item Deleted.";
}
else if($role=="restore")
{
	$query = "update product set is_deleted=0 where product_code='" . $code . "'";
	$result = mysql_query($query);
	echo "Item Restored.";
}

?>