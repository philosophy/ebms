<?php
include("../../../../config/config.php");
$subCategory = @$_POST['subcat'];
$category = @$_POST['cat'];
$outputData = "";

$query = "Select category_id from category where category_name='" . $category . "'";
$result = mysql_query($query);
while($row = mysql_fetch_array($result))
{
	$categoryid = $row[0];
}

$query2 = "Select sub_category_id from category_sub_category where sub_category_name='" . $subCategory . "' and category_id='" . $categoryid . "'";
$result2 = mysql_query($query2);
while($row2 = mysql_fetch_array($result2))
{
	$subCategoryid = $row2[0];
}
$query3 = "Select product_field_id, product_field_name from product_field where is_deleted=0 and sub_category_id='" . $subCategoryid . "'";
$get_fields = mysql_query($query3);
	while($row = mysql_fetch_array($get_fields))
	{
		$outputData .= "<option value = '" . $row[0] . "'>" . $row[1] . "</option>";
	}
	echo $outputData;
?>