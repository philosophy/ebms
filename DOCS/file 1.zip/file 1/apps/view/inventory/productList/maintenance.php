<?php
include("../../../../config/config.php");
$role = $_POST['role'];
$code = @$_POST['code'];

if($role=="view")
{
	$outputData = "<table>
		<th></th>
		<th>Subject</th>
		<th>Note</th>
		<th>Date</th>
		<th>Time</th>
		<th>Remind</th>
		<th>Status</th>";

	$rec=mysql_query("SELECT REMIND_EVERY, ITEM_MAINTENANCE_ID, case STATUS when '0' then 'Alert OFF' when '1' then 'Alert ON' end as 'Status', IS_DELETED, DATE_FORMAT(ALERT_DATE,  '%M %d, %Y' ) AS  'Date', ALERT_TIME, SUBJECT, NOTE FROM item_maintenance_reminder where item_code='".$code."'");
							

	$recList = mysql_num_rows($rec);

	if($recList > 0)
	{
		$icon="";
		while($row = mysql_fetch_array($rec))
		{
			
			if($row['IS_DELETED'] == 1)
			{
				$icon = "<td class='icon'><img src='../../../../images/icons/deleted-icon.png' height=20 width=20 /> </td>";
			
				$outputData .= "<tr deleted='true' maintenanceID='". $row["ITEM_MAINTENANCE_ID"] ."'>";
				$outputData .= $icon;
			}
			else if($row['IS_DELETED'] == 0)
			{
				$icon = "<td class='icon'><img src='../../../../images/icons/dtrIcon.png' height=20 width=20 /> </td>";
			
				$outputData .= "<tr deleted='false' maintenanceID='". $row["ITEM_MAINTENANCE_ID"] ."'>";
				$outputData .= $icon;
			}
			
			
			$outputData .= "<td>".$row["SUBJECT"]."</td>";
			$outputData .= "<td>".$row["NOTE"]."</td>";
			$outputData .= "<td>".date("D M d, Y",strtotime($row["Date"]))."</td>";
			$outputData .= "<td>".date("g:i a", strtotime($row["ALERT_TIME"]))."</td>";
			$outputData .= "<td>".$row["REMIND_EVERY"]."</td>";
			$outputData .= "<td>".$row["Status"]."</td>";
			
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
		echo $outputData;
	}
	else
	{
		echo 'No results found';
	}
}
else if($role=="add")
{
	$code = $_POST['code'];
	$date = $_POST['date'];
	$remind = $_POST['remind'];
	$time = DATE("H:i",STRTOTIME(@$_POST['time']));
	$subject = $_POST['subject'];
	$note = $_POST['note'];
	$status= $_POST['status'];
	
	$query = "INSERT INTO `item_maintenance_reminder`(REMIND_EVERY,`ITEM_CODE`, `STATUS`, `IS_DELETED`, `ALERT_DATE`, `ALERT_TIME`, `SUBJECT`, `NOTE`) VALUES ('". $remind ."','". $code ."','". $status ."',0,'". $date ."','". $time ."','". $subject ."','". $note ."')";
	
	$result = mysql_query($query);
	//echo $query;
	//echo $code . " " . $date . " " . $remind . " " . $time . " " . $subject . " " . $note . " " . $status;
}

else if($role=="render")
{
	$id = $_POST['id'];
	
	$query = "SELECT remind_every,subject,note,alert_date,alert_time,status FROM  item_maintenance_reminder WHERE  	ITEM_MAINTENANCE_ID ='". $id . "'";
	$getdata = mysql_query($query);
	$data[] = "";
	if(mysql_num_rows($getdata) > 0)
		{	
			while($arrProduct = mysql_fetch_array($getdata))
			{
				$data["remindEvery"] = $arrProduct["remind_every"];
				$data["subjectMaintenance"] = $arrProduct["subject"];
				$data["noteMaintenance"] = $arrProduct["note"];
				$data["alertDate"] = $arrProduct["alert_date"];
				$data["alertTime"] = date("g:i a", strtotime($arrProduct["alert_time"]));
				$data["statusMaintenance"] = $arrProduct["status"];
			}
		}
	$dataArray= json_encode(array("details"=>$data));
	echo $dataArray;
}
else if($role=="update")
{
	$id = $_POST['id'];
	$date = $_POST['date'];
	$remind = $_POST['remind'];
	$time = DATE("H:i",STRTOTIME(@$_POST['time']));
	$subject = $_POST['subject'];
	$note = $_POST['note'];
	$status= $_POST['status'];
	
	
	$query = "UPDATE `item_maintenance_reminder` SET `STATUS`='". $status ."', `ALERT_DATE`='". $date ."', `ALERT_TIME`='". $time ."', `SUBJECT`='". $subject ."', `NOTE`='". $note ."', `REMIND_EVERY`='". $remind ."' WHERE ITEM_MAINTENANCE_ID='". $id ."'";
	
	$result = mysql_query($query);
	echo $query;
}
else if($role=="delete")
{
	$id = $_POST['id'];
	
	$query = "UPDATE item_maintenance_reminder set is_deleted=1 WHERE ITEM_MAINTENANCE_ID='". $id ."'";
	
	$result = mysql_query($query);
	echo $query;
}
else if($role=="restore")
{
	$id = $_POST['id'];
	
	$query = "UPDATE item_maintenance_reminder set is_deleted=0 WHERE ITEM_MAINTENANCE_ID='". $id ."'";
	
	$result = mysql_query($query);
	echo $query;
}
?>