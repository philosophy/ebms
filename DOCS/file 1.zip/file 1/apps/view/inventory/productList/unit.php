<?php
include("../../../../config/config.php");
$get_cust_type = mysql_query("Select unit_name from unit where is_deleted=0");
$custType[] = "";
if(mysql_num_rows($get_cust_type) > 0)
	{
		$i = 0;
		while($arrCustType = mysql_fetch_array($get_cust_type))
		{
			$custType[$i] = array($arrCustType["unit_name"]);
			$i++;
		}
	}
	$unit = json_encode(array("u" => $custType));
	echo $unit;
?>