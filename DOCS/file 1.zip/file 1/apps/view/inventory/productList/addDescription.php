<?php
include("../../../../config/config.php");

$productCode = @$_POST['productCode'];
$role = @$_POST['role'];
$desc = @$_POST['desc'];
$id = @$_POST['fieldid'];
if($role == "add")
{
	$outputData = "";	
	$outputData = "<tr field='". $id ."'>
		<td fieldid='" . $id . "'>". $desc ."</td>
		<td><input type='text' id='txtValue'/>  </td>
		</tr>";
	echo $outputData;
}
else if($role =="rows")
{
	$query = "SELECT product_field_name, product_description FROM product_field INNER JOIN product_information ON product_field.product_field_id = product_information.product_field_id WHERE product_id ='" . $productCode . "'";
	
	$result = mysql_query($query);
	echo mysql_num_rows($result);
}
else if($role =="view")
{
	$query = "SELECT product_field.product_field_id, product_field_name, product_description FROM product_field INNER JOIN product_information ON product_field.product_field_id = product_information.product_field_id WHERE product_id ='" . $productCode . "'";
	
	$result = mysql_query($query);
	$outputData = "";
	while($row = mysql_fetch_array($result))
	{
		$outputData .= "<tr>
		<td fieldid='" . $row['product_field_id'] . "'>". $row['product_field_name']."</td>
		<td><input type='text' id='txtValue' value='". $row['product_description'] ."'/>  </td>
		</tr>";
	}
	echo $outputData;
}

?>