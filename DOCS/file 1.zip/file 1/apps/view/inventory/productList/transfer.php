<?php 
include("../../../../config/config.php");

$role = $_POST['role'];

if($role == "transfer")
{
	$flag = $_POST['flag'];
	$code = $_POST['code'];
	
	$query = "update product set item_flag='" . $flag . "' where product_code='" . $code . "'";
	$result5 = mysql_query($query);
	
}
	
	
?>