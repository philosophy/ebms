<?php
include("../../../../config/config.php");
$role= $_POST['role'];

if($role=="add")
{
	$fieldid = $_POST['field'];
	$values = $_POST['value'];
	$code = $_POST['productCode'];

	$query = "insert into product_information(product_field_id,product_id,product_description) values('" . $fieldid . "','". $code . "','" . $values . "')";
	$result = mysql_query($query);

	echo $fieldid . ' ' . $values . ' ' . $code;
}
else if($role=="delete")
{
	$code = $_POST['productCode'];

	$query = "delete from product_information where product_id='". $code ."'";
	$result = mysql_query($query);
	//echo $query;
	//echo $fieldid . ' ' . $values . ' ' . $code;
}



?>