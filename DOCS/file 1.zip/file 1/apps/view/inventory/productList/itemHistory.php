<?php
include("../../../../config/config.php");

$productCode = @$_POST['productCode'];

	$outputData = "<table>
		<th>Header No.</th>
		<th>Date Issued</th>
		<th>Type</th>
		<th>Purpose</th>
		<th>Quantity</th>
		<th>Person Name</th>";

//withdrawal [EMPLOYEE, CUSTOMER] 
$result=mysql_query("SELECT wh.with_hdr_no, wh.with_hdr_date_issued, wh.with_hdr_type, 
						wh.with_hdr_purpose, wd.with_dtl_qty, WITH_HDR_ISSUED_TO 
						FROM withdrawal_header wh 
						INNER JOIN withdrawal_detail wd ON wh.with_hdr_id = wd.with_hdr_id
						WHERE wd.item_code = '".$productCode."'");

//receiving [EMPLOYEE, CUSTOMER, SUPPLIER]
$rec=mysql_query("SELECT rh.rec_hdr_no, rh.rec_hdr_date, rh.REC_HDR_RECEIVED_REF_TYPE, 
						rh.REC_HDR_RECEIVED_REF, rd.REC_DTL_QTY, REC_HDR_RECEIVED_FROM
						FROM receiving_header rh 
						INNER JOIN receiving_detail rd ON rh.rec_hdr_id = rd.rec_hdr_id
						WHERE rd.item_code= '".$productCode."'");
						
$number_of_audit = mysql_num_rows($result);
$recList = mysql_num_rows($rec);

//RECEIVING
if($recList > 0)
{
	while($row = mysql_fetch_array($rec))
	{
		
		$outputData .= "<tr>";
		$outputData .= "<td>".$row["rec_hdr_no"]."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($row["rec_hdr_date"]))."</td>";
		$outputData .= "<td>".$row["REC_HDR_RECEIVED_REF_TYPE"]."</td>";
		$outputData .= "<td>".$row["REC_HDR_RECEIVED_REF"]."</td>";
		$outputData .= "<td>".$row["REC_DTL_QTY"]."</td>";
		if(mysql_num_rows($emp = mysql_query("SELECT emp_first_name, emp_middle_name, emp_last_name
										FROM employee_profile WHERE emp_code = '".$row['REC_HDR_RECEIVED_FROM']."'")))
		{
			$empRow = mysql_fetch_row($emp);
			$outputData .= "<td>".$empRow[0]." ".$empRow[1]." ".$empRow[2]."</td>";
		}
		elseif(mysql_num_rows($cust = mysql_query("SELECT customer_name
										FROM customer_profile WHERE customer_code = '".$row['REC_HDR_RECEIVED_FROM']."'")))
		{
			$custRow = mysql_fetch_row($cust);
			$outputData .= "<td>".$custRow[0]."</td>";
		}
		elseif(mysql_num_rows($sup = mysql_query("SELECT supplier_name
										FROM supplier_profile WHERE supplier_code = '".$row['REC_HDR_RECEIVED_FROM']."'")))
		{
			$supRow = mysql_fetch_row($sup);
			$outputData .= "<td>".$supRow[0]."</td>";
		}
		$outputData .= "</tr>";
	}
}

//WITHDRAWAL
if($number_of_audit>0)
{	
	while($row = mysql_fetch_array($result))
	{
		$outputData .= "<tr>";
		$outputData .= "<td>".$row["with_hdr_no"]."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($row["with_hdr_date_issued"]))."</td>";
		$outputData .= "<td>".$row["with_hdr_type"]."</td>";
		$outputData .= "<td>".$row["with_hdr_purpose"]."</td>";
		$outputData .= "<td>".$row["with_dtl_qty"]."</td>";
		if(mysql_num_rows($emp = mysql_query("SELECT emp_first_name, emp_middle_name, emp_last_name
										FROM employee_profile WHERE emp_code = '".$row['WITH_HDR_ISSUED_TO']."'")))
		{
			$empRow = mysql_fetch_row($emp);
			$outputData .= "<td>".$empRow[0]." ".$empRow[1]." ".$empRow[2]."</td>";
		}
		elseif(mysql_num_rows($cust = mysql_query("SELECT customer_name
										FROM customer_profile WHERE customer_code = '".$row['WITH_HDR_ISSUED_TO']."'")))
		{
			$custRow = mysql_fetch_row($cust);
			$outputData .= "<td>".$custRow[0]."</td>";
		}
		$outputData .= "</tr>";
	}
}

if($number_of_audit == 0 && $recList == 0)
{
	echo 'No results found';
}
else
{
	$outputData .= "</table>";
	echo $outputData;
}
?>