<?php 
include("../../../../config/config.php");

$name = $_FILES['itemImage']['name'];
$tmp = $_FILES['itemImage']['tmp_name'];

move_uploaded_file($tmp,"../../../../images/stock/".$name);

exit;

?>