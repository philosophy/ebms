<?php
include("../../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);
$listType = $_POST['listType'];

if($searchQuery!="")
	{
	if($listType == "product")
	$condition = "and (product_code LIKE '%".$searchQuery."%' or p.product_unit_price LIKE '%".$searchQuery."%' or b.brand_name LIKE '%".$searchQuery."%' or sc.sub_category_name LIKE '%".$searchQuery."%' or c.category_name LIKE '%".$searchQuery."%' or U.unit_name LIKE '%".$searchQuery."%')";
	
	elseif($listType == "asset")
	$condition = "and (product_code LIKE '%".$searchQuery."%' or p.product_unit_price LIKE '%".$searchQuery."%' or b.brand_name LIKE '%".$searchQuery."%' or sc.sub_category_name LIKE '%".$searchQuery."%' or c.category_name LIKE '%".$searchQuery."%' or U.unit_name LIKE '%".$searchQuery."%')";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 8;
$start = $page * $per_page;
	$outputData = "<table >
			<th></th>
			<th>Item Code</th>
			<th>Category</th>
			<th>Sub-Category</th>
			<th>Brand</th>
			<th>Unit Price</th>
			<th>Unit</th>
			<th>Quantity</th>";
			
$asset = "select product_code,p.product_unit_price, p.product_qty, b.brand_name, c.category_name, sc.sub_category_name, U.unit_name,
						p.is_deleted from product p INNER JOIN brand b ON b.brand_id = p.brand_id
						INNER JOIN category c ON c.category_id = p.category_id
						INNER JOIN category_sub_category sc ON sc.sub_category_id = p.sub_category_id inner join unit u on 
						p.unit_id = u.unit_id
						where p.item_flag='A' ".$condition."
						group by p.product_code order by p.is_deleted, c.category_name, sc.sub_category_name, b.brand_name";
						
					
						
$product = "select product_code,p.product_unit_price, p.product_qty, b.brand_name, c.category_name, sc.sub_category_name, U.unit_name, p.is_deleted
						from product p INNER JOIN brand b ON b.brand_id = p.brand_id
						INNER JOIN category c ON c.category_id = p.category_id
						INNER JOIN category_sub_category sc ON sc.sub_category_id = p.sub_category_id inner join unit u on 
						p.unit_id = u.unit_id
						where p.item_flag='P' ".$condition."
						group by p.product_code order by p.is_deleted, c.category_name, sc.sub_category_name, b.brand_name";
			
			if($listType == "product")
			$query = $product;
			
			elseif($listType == "asset")
			$query = $asset;
			
			$count = mysql_num_rows(mysql_query($query));
			$no_of_paginations = ceil($count / $per_page);
	
			$arrRows = mysql_query($query." limit $start,$per_page");

$icon = "";

if(mysql_num_rows($arrRows) >0)
{
	// if($listType == "product")
	// {
	while($arrProduct = mysql_fetch_array($arrRows))
	{	
		if($arrProduct['is_deleted'] == 1)
		{
			$icon = "<td class='icon'><img src='../../../../images/icons/deleted-icon.png' height=20 width=20 /> </td>";
			
			$outputData .= "<tr deleted='true' a=".$arrProduct['product_code'].">";
			$outputData .= $icon;
		}
		else if($arrProduct['is_deleted'] == 0)
		{
			$icon = "<td class='icon'><img src='../../../../images/icons/inventory.png' height=20 width=20 /> </td>";
			
			$outputData .= "<tr deleted='false' a=".$arrProduct['product_code'].">";
			$outputData .= $icon;
		}
	
		
		$outputData .= "<td>".$arrProduct['product_code']."</td>";
		$outputData .= "<td>".$arrProduct['category_name']."</td>";
		$outputData .= "<td>".$arrProduct['sub_category_name']."</td>";
		$outputData .= "<td>".$arrProduct['brand_name']."</td>";
		$outputData .= "<td align='right'>".number_format($arrProduct['product_unit_price'], 2)."</td>";
		$outputData .= "<td>".$arrProduct['unit_name']."</td>";
		$outputData .= "<td align='right'>".$arrProduct['product_qty']."</td>";
		//$outputData .= "<td>".$arrProduct[1]."</td>";
		$outputData .= "</tr>";
	}
	// }
	
	// elseif($listType == "asset")
	// {
	// while($arrAsset = mysql_fetch_array($arrRows))
	// {
		// $outputData .= "<tr a=".$arrAsset['asset_code'].">";
		// $outputData .= "<td>".$arrAsset['asset_code']."</td>";
		// $outputData .= "<td>".$arrAsset['brand_name']."</td>";
		// $outputData .= "<td>".$arrAsset['category_name']."</td>";
		// $outputData .= "<td>".$arrAsset['sub_category_name']."</td>";
		// $outputData .= "<td>".$arrAsset[1]."</td>";
		// $outputData .= "<td align='right'>".number_format($arrAsset['asset_unit_price'], 2)."</td>";
		// $outputData .= "<td>".$arrAsset['asset_qty']."</td>";
		// $outputData .= "</tr>";
	// }
	// }
		$outputData .= "</table>";
}

else 
	{
	include("../../noResults.php");
	$cur_page = 0;
	}
	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($arrRows);