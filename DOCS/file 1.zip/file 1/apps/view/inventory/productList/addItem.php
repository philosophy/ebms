<?php 
include("../../../../config/config.php");

$role = $_POST['role'];
$category = $_POST['cat'];
$subcategory = $_POST['subCat'];
$prodPrice = $_POST['price'];
$brand = $_POST['brand'];
$unit= $_POST['unit'];
$remarks = $_POST['remarks'];
$img = $_POST['image'];
$min = $_POST['min'];
$norm = $_POST['norm'];		
			
$result1 = mysql_query("SELECT category_id from category where category_name='" . $category . "'");
while ($row = mysql_fetch_array($result1))
{
    $categoryid = $row[0];
}
	
$result2 = mysql_query("SELECT sub_category_id from category_sub_category where category_id='" . $categoryid . "' and sub_category_name='" . $subcategory . "'");
while ($row = mysql_fetch_array($result2))
{
	$subcategoryid = $row[0];
}
	
	if($role == "addproduct")
	{
		$word1 = explode(" ",$category);
		$word2 = explode(" ",$subcategory);
		$str1="";
		$str2="";
				
		for($x = 0; $x < sizeof($word1); $x++)
		{
			$str1 .= Substr($word1[$x],0,1);
		}
		for ($y = 0;$y < sizeof($word2); $y++)
		{
		$str2 .= Substr($word2[$y],0,1);
		}
		$id = 0;
		$result = mysql_query("SELECT MAX(PRODUCT_ID) FROM product");

		while ($row = mysql_fetch_array($result))
		{
				$id=1;
				$id = $row[0];
			
		}
		$prodCode = strtoupper($str1) ."-" . strtoupper($str2) ."-" . substr("000000",0,strlen("000000") - strlen($id + 1)) . ($id + 1);
		
	
		$query = "Insert into product(product_code,product_qty, product_unit_price,product_remarks, is_deleted, brand_id, category_id, sub_category_id,unit_id, product_image,minimum_stock,normal_stock,item_flag) values('". $prodCode ."',0,'". $prodPrice ."','" . $remarks . "',0,'". $brand."','". $categoryid ."', '". $subcategoryid ."','". $unit . "','" . $img ."','". $min . "','" . $norm ."','P')";
	}
	elseif($role == "addasset")
	{
		$id = 0;
		$result = mysql_query("SELECT MAX(PRODUCT_ID),YEAR( CURDATE( ) ) FROM product");

		while ($row = mysql_fetch_array($result))
		{
			$id = $row[0];
			$year = $row[1]; 
		}
		$prodCode = "AS-" . $year ."-" . substr("000000",0,strlen("000000") - strlen($id + 1)) . ($id + 1);
	
		$query = "Insert into product(product_code,product_qty, product_unit_price,product_remarks, is_deleted, brand_id, category_id, sub_category_id,unit_id, product_image,minimum_stock,normal_stock,item_flag) values('". $prodCode ."',0,'". $prodPrice ."','" . $remarks . "',0,'". $brand."','". $categoryid ."', '". $subcategoryid ."','". $unit . "','" . $img ."','". $min . "','" . $norm ."','A')";
	}
	elseif($role == "edit")
	{
	
	$codetoedit = $_POST['code'];
	$result3 = mysql_query("SELECT unit_id from unit where unit_name='" . $unit . "'");
	while ($row = mysql_fetch_array($result3))
	{
		$unitid = $row[0];
	}
		
		$query = "update product set product_unit_price='". $prodPrice ."',product_remarks='" . $remarks . "',brand_id='". $brand."',category_id='". $categoryid ."', sub_category_id='". $subcategoryid ."',unit_id='". $unitid . "',product_image='" . $img ."',minimum_stock='". $min . "',normal_stock='" . $norm ."' where product_code='" . $codetoedit . "'";
	$result5 = mysql_query($query);
	}
	
	
	
	if($role!="edit")
	{
		echo $prodCode;
		$result5 = mysql_query($query);
	}
	else
	{
		echo $codetoedit;
	}

?>