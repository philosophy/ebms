<?php
include("../../../../config/config.php");
$role = $_POST['role'];


if($role=="view")
{
	$code = @$_POST['code'];
	$outputData = "<table>
		<th></th>
		<th>Date</th>
		<th>Person Name</th>
		<th>Contact No</th>
		<th>Findings</th>
		<th>Action Taken</th>";

	$rec=mysql_query("SELECT DATE_FORMAT( `ITEM_DATE`,  '%M %d, %Y' ) AS  'Date', ITEM_HISTORY_ID, `ITEM_PERSON_NAME`, `ITEM_FINDINGS`, `ITEM_STEP_TAKEN`, `ITEM_PERSON_CONTACT_NO`, is_deleted FROM `item_maintenance_history` WHERE item_code='".$code."'");
							

	$recList = mysql_num_rows($rec);

	if($recList > 0)
	{
		$icon= "";
		while($row = mysql_fetch_array($rec))
		{	
			if($row['is_deleted'] == 1)
			{
				$icon = "<td class='icon'><img src='../../../../images/icons/deleted-icon.png' height=20 width=20 /> </td>";
			
				$outputData .= "<tr deleted='true' historyID='". $row["ITEM_HISTORY_ID"] ."'>";
				$outputData .= $icon;
			}
			else if($row['is_deleted'] == 0)
			{
				$icon = "<td class='icon'><img src='../../../../images/icons/maintenance.png' height=20 width=20 /> </td>";
			
				$outputData .= "<tr deleted='false' historyID='". $row["ITEM_HISTORY_ID"] ."'>";
				$outputData .= $icon;
			}
			
			$outputData .= "<td>".date("D M d, Y",strtotime($row["Date"]))."</td>";
			$outputData .= "<td>".$row["ITEM_PERSON_NAME"]."</td>";
			$outputData .= "<td>".$row["ITEM_PERSON_CONTACT_NO"]."</td>";
			$outputData .= "<td>".$row["ITEM_FINDINGS"]."</td>";
			$outputData .= "<td>".$row["ITEM_STEP_TAKEN"]."</td>";
			
			$outputData .= "</tr>";
		}
		
		$outputData .= "</table>";
		echo $outputData;
	}
	else
	{
		echo 'No results found';
	}
}
else if($role=="add")
{
	$code = $_POST['code'];
	$date = $_POST['date'];
	$person = $_POST['person'];
	$contact = $_POST['contact'];
	$findings = $_POST['findings'];
	$steps = $_POST['steps'];
	
	$query = "INSERT INTO `item_maintenance_history`(`ITEM_CODE`, `ITEM_PERSON_NAME`, `ITEM_FINDINGS`, `ITEM_STEP_TAKEN`, `ITEM_PERSON_CONTACT_NO`, `ITEM_DATE`, `IS_DELETED`) VALUES ('". $code ."','". $person ."','". $findings ."','". $steps ."','". $contact ."','". $date ."',0)";
	
	$result = mysql_query($query);
	//echo $query;
	//echo $date . " " . $person . " " . $contact . " " . $findings . " " . $steps . " " . $code;
}

else if($role=="render")
{
	$id = $_POST['id'];
	
	$query = "SELECT `ITEM_PERSON_NAME` ,  `ITEM_FINDINGS` ,  `ITEM_STEP_TAKEN` , `ITEM_PERSON_CONTACT_NO` ,  `ITEM_DATE` FROM  `item_maintenance_history` WHERE  `ITEM_HISTORY_ID` ='". $id . "'";
	$getdata = mysql_query($query);
	$data[] = "";
	if(mysql_num_rows($getdata) > 0)
		{	
			while($arrProduct = mysql_fetch_array($getdata))
			{
				$data["person"] = $arrProduct["ITEM_PERSON_NAME"];
				$data["findings"] = $arrProduct["ITEM_FINDINGS"];
				$data["steps"] = $arrProduct["ITEM_STEP_TAKEN"];
				$data["contact"] = $arrProduct["ITEM_PERSON_CONTACT_NO"];
				$data["date"] = $arrProduct["ITEM_DATE"];
				
			}
		}
	$dataArray= json_encode(array("datum"=>$data));
	echo $dataArray;
}

else if($role=="update")
{
	$id = $_POST['id'];
	$date = $_POST['date'];
	$person = $_POST['person'];
	$contact = $_POST['contact'];
	$findings = $_POST['findings'];
	$steps = $_POST['steps'];
	
	$query = "UPDATE `item_maintenance_history` SET `ITEM_PERSON_NAME`='". $person ."',`ITEM_FINDINGS`='". $findings ."',`ITEM_STEP_TAKEN`='". $steps ."',`ITEM_PERSON_CONTACT_NO`='". $contact ."',`ITEM_DATE`='" . $date . "' WHERE `ITEM_HISTORY_ID`='". $id ."'";
	
	$result = mysql_query($query);
	echo $query;
}
else if($role=="delete")
{
	$id = $_POST['id'];
	
	$query = "UPDATE item_maintenance_history set is_deleted=1 WHERE ITEM_HISTORY_ID='". $id ."'";
	
	$result = mysql_query($query);
	echo $query;
}
else if($role=="restore")
{
	$id = $_POST['id'];
	
	$query = "UPDATE item_maintenance_history set is_deleted=0 WHERE ITEM_HISTORY_ID='". $id ."'";
	
	$result = mysql_query($query);
	echo $query;
}

?>