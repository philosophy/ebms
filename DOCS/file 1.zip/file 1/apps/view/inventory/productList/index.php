﻿<?php include("../../doctype-standard.php"); ?>
<head>
<title>EBMS | Product/Asset List</title>
<?php include("../../standard-js-css.php"); ?>
<script>
	$(function(){
		headTitle("Product/Asset List");	
		datagrid("itemHistory",true);
		datagridMenu("prodAsset","new;edit;delete;restore;transfer");
		listType();
		$("#tabbed-grid").tabs({fx: { height: 'toggle', duration: 'fast' },
		});
});
</script>
</head>
<body>

<div id="header-pane">
	
	<?php 
	#Include top navigation pane
		include("../../orb/orb-top-nav.php");
	?>
	
</div>
<?php include("../../modalForms/inventory/index.php"); ?>
<div id="body-pane">
<div id="body-content-container">
<?php include("../../datagrid-options.php"); ?>
<div id="product-list" class="datagrid-container">
	<!--product and asset list -->
	<script>
		$('#product-list').load('../../../controller/productList/productListController.php');
	</script>
</div>
</div>
<div id="tabbed-grid"> 
	<ul> 
		<li><a href="#generalTab">General</a></li>
		<li><a href="#maintenance">Maintenance</a></li>
		<li><a href="#maintenanceHistory">Maintenance History</a></li>
		<li><a href="#itemHistory">Item History</a></li>
	</ul> 
	
	<div id="generalTab" class="scrollable"> 
		<!-- general description preview -->
	</div>
	
	
	<div id="maintenance" class="scrollable"> 
		<div class="tabButtonPanel">
			<button id="new_maintenance" class="callModalForm" ref="new_maintenance" onclick="callModal('#new_maintenance')" title='New Maintenance Record'>✚</button>
			<button id="edit_maintenance" class="callModalForm" ref="edit_maintenance" onclick="callModal('#edit_maintenance')" title='Edit Maintenance Record'>✎</button>
			<button id="delete_maintenance" class="callModalForm" ref="delete_maintenance" onclick="callModal('#delete_maintenance')" title='Delete Maintenance Record'>✖</button>
			<button id="restore_maintenance" class="callModalForm" ref="restore_maintenance" onclick="callModal('#restore_maintenance')" title='Restore Maintenance Record'>➲</button>
		</div>
		<div id="maintenanceGrid">
		
		</div>
		<!-- maintenance preview -->
		
	</div>
	
	<div id="maintenanceHistory" class="scrollable"> 
		<div class="tabButtonPanel">
			<button id="new_maintenanceHistory" class="callModalForm" ref="new_maintenanceHistory" onclick="callModal('#new_maintenanceHistory')" title='New Maintenance History Record'>✚</button>
			<button id="edit_maintenanceHistory" class="callModalForm" ref="edit_maintenanceHistory" onclick="callModal('#edit_maintenanceHistory')" title='Edit Maintenance History Record'>✎</button>
			<button id="delete_maintenanceHistory" class="callModalForm" ref="delete_maintenanceHistory" onclick="callModal('#delete_maintenanceHistory')" title='Delete Maintenance History Record'>✖</button>
			<button id="restore_maintenanceHistory" class="callModalForm" ref="restore_maintenanceHistory" onclick="callModal('#restore_maintenanceHistory')" title='Restore Maintenance History Record'>➲</button>
		</div>
		<div id="maintenanceHistoryGrid">
		<!-- maintenance history preview -->
		</div>
	</div>
	
	<div id="itemHistory" class="scrollable"> 
		<!-- item history preview -->
		<div class="tabButtonPanel">
			<a id="pdf" href="#">
			<img src="/EBMS/images/icons/pdf-icon.png" alt="View in PDF"  title="View in PDF" style="height:30px;width:30px;">
			</a>
		</div>
		<div id="itemHistoryGrid">
		<!-- maintenance history preview -->
		</div>
	</div>
</div>
</div>
<?php include("../../footer-view.php"); ?>

</body>
</html>

