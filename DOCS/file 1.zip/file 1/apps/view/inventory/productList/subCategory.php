<?php
include("../../../../config/config.php");
$catID= $_POST['cat'];

$get_cust_type = mysql_query("Select sub_category_name from category_sub_category where is_deleted=0 and category_id='" .$catID. "'");
$custType[] = "";
if(mysql_num_rows($get_cust_type) > 0)
	{
		$i = 0;
		while($arrCustType = mysql_fetch_array($get_cust_type))
		{
			$custType[$i] = array($arrCustType["sub_category_name"]);
			$i++;
		}
	}
	$subCategory = json_encode(array("sc" => $custType));
	echo $catID;
?>