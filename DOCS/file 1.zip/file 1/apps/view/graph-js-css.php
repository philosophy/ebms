<link rel="stylesheet" type="text/css" href="/EBMS/plugin/dist/jquery.jqplot.css" />
<script language="javascript" type="text/javascript" src="/EBMS/plugin/dist/jquery.jqplot.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.canvasTextRenderer.min.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.canvasAxisLabelRenderer.min.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.canvasAxisTickRenderer.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.highlighter.min.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.cursor.min.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.dateAxisRenderer.min.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.pieRenderer.js"></script> 
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.meterGaugeRenderer.js"></script>
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.barRenderer.min.js"></script>	
<script type="text/javascript" src="/EBMS/plugin/dist/plugins/jqplot.categoryAxisRenderer.min.js"></script>