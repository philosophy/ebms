<?php 
include("../../../config/config.php");
$get_loc_type = mysql_query("Select location_type_name from location_type where is_deleted = 0");
$locType[] = "";
if(mysql_num_rows($get_loc_type) > 0)
	{
		$i = 0;
		while($arrLocType = mysql_fetch_array($get_loc_type))
		{
		 $locType[$i] = array($arrLocType["location_type_name"]);
		 $i++;
		}
	}	
	$locationType = json_encode(array("lt" => $locType));
	echo $locationType;
?>