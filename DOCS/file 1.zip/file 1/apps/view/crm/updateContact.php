<?php 
session_start();
include("../../../config/config.php");
$contactId = @$_POST['contactId'];
$locationId = @$_POST['locationId'];

$contactName = addslashes(@$_POST['contactName']);
$newContactName = addslashes(@$_POST['newContactName']);
$locId = @$_POST['locationId'];
$contactDepartment = @$_POST['contactDepartment'];
$contactJobTitle = @$_POST['contactJobTitle'];
$contactEmailAddress = @$_POST['contactEmailAddress'];
$contactMobileNo = @$_POST['contactMobileNo'];
$contactPhoneNo = @$_POST['contactPhoneNo'];
$contactFaxNo = @$_POST['contactFaxNo'];
$deptId = @$_POST['deptId'];	
$jobId = @$_POST['jobId'];	
$contId = "";


$query = mysql_query("select contact_name , contact_email_address, contact_phone_no, contact_mobile_no, contact_fax_no, contact_department, contact_job_title from contact where contact_name='".$contactId."' and location_id ='".$locationId."'");
$data[] = "";
if(mysql_num_rows($query) > 0)
		{	
			while($arrContact= mysql_fetch_array($query))
			{
			$data["name"] = $arrContact["contact_name"];
			$data["email"] = $arrContact["contact_email_address"];
			$data["phoneNo"] = $arrContact["contact_phone_no"];
			$data["mobileNo"] = $arrContact["contact_mobile_no"];
			$data["faxNo"] = $arrContact["contact_fax_no"];
			$data["department"] = $arrContact["contact_department"];
			$data["jobTitle"] = $arrContact["contact_job_title"];
			}
		}
	 $dataArray = json_encode(array("values"=>$data));
	echo $dataArray;
	 
$query = mysql_query("select contact_id from contact where contact_name='".$contactName."' and location_id ='".$locationId."'");
if(mysql_num_rows($query) > 0)
		{	
			while($arrContact= mysql_fetch_array($query))
			{
			$contId = $arrContact["contact_id"];
			}
		}

if($contId != ""){
$query = mysql_query("Update contact set contact_name = '$newContactName', contact_email_address = '$contactEmailAddress', contact_phone_no = '$contactPhoneNo', contact_mobile_no = '$contactMobileNo', contact_fax_no ='$contactFaxNo', contact_department = '$contactDepartment', contact_job_title = '$contactJobTitle', department_id = '$deptId', position_id = '$jobId' where contact_id = '$contId' and location_id ='$locationId'");


$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Contact record updated.', '".$_SESSION['emp_id']."')")or die(mysql_error());
}

?>

