<?php 
session_start();
include("../../../config/config.php");
$locationId = @$_POST['locId'];
$locationName = addslashes(@$_POST['locName']);
$locationType = @$_POST['locType'];
$city = @$_POST['locCity'];
$barangay = @$_POST['locBarangay'];
$area = @$_POST['locArea'];
$address = @$_POST['locAddress'];
$phoneNo = @$_POST['locPhoneNo'];
$faxNo = @$_POST['locFaxNo'];


$getdata = mysql_query("Select location_name, lt.location_type_name, c.city_name, b.barangay_name, a.area_name, location_address, location_fax_no, location_phone_no from location l, location_type lt, city c, barangay b, area a where l.location_type_id = lt.location_type_id and l.city_id = c.city_id and l.barangay_id = b.barangay_id and l.area_id = a.area_id and location_id ='".$locationId."'");

$data[] = "";
if(mysql_num_rows($getdata) > 0)
		{	
			while($arrCustomer = mysql_fetch_array($getdata))
			{
			$data["locationName"] = $arrCustomer["location_name"];
			$data["locationType"] = $arrCustomer["location_type_name"];
			$data["city"] = $arrCustomer["city_name"];
			$data["barangay"] = $arrCustomer["barangay_name"];
			$data["area"] = $arrCustomer["area_name"];
			$data["address"] = $arrCustomer["location_address"];
			$data["fax"] = $arrCustomer["location_fax_no"];
			$data["phone"] = $arrCustomer["location_phone_no"];
			}
		}
	 $dataArray = json_encode(array("values"=>$data));
	 echo $dataArray;

	
if($locationType == "")
		$locTypeId = 0;
else{
$query = mysql_query("Select location_type_id from location_type where location_type_name ='".$locationType."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$locTypeId = $id["location_type_id"];
		}
	}
}	


if($city == "")
		$cityId = 0;
else{
$query = mysql_query("Select city_id from city where city_name ='".$city."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$cityId = $id["city_id"];
		}
	}
}
	
	
if($barangay == "")
		$barangayId = 0;
else{	
$query = mysql_query("Select barangay_id from barangay where barangay_name ='".$barangay."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$barangayId = $id["barangay_id"];
		}
	}
}

if($area == "")
		$areaId = 0;
else{	
$query = mysql_query("Select area_id from area where area_name ='".$area."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$areaId = $id["area_id"];
		}
	}
}
	
if($areaId != "")
{
$query = mysql_query("update location set location_name = '$locationName', location_type_id = '$locTypeId', city_id ='$cityId', barangay_id = '$barangayId', area_id = '$areaId', location_address = '$address', location_phone_no ='$phoneNo', location_fax_no = '$faxNo' where location_id ='$locationId'");	


$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Location record updated.', '".$_SESSION['emp_id']."')")or die(mysql_error());
}
	
	 
?>