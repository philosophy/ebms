<?php 
include("../../../config/config.php");
$locationId = $_POST['locId'];

$query = mysql_query("select location_type_name, location_name from location l , location_type lt where l.location_type_id = lt.location_type_id and location_id ='".$locationId."'");
$array[] = "";

if(mysql_num_rows($query) > 0)
	{
		while($result = mysql_fetch_array($query))
		{
			$array["location_type_name"] = $result["location_type_name"];
			$array["location_name"] = $result["location_name"];
		}
	}
$dataArray = json_encode(array("values"=>$array));
echo $dataArray;	
	


?>