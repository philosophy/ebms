<?php 
session_start();
include("../../../config/config.php");

$contactName = addslashes($_POST['contactName']);
$contactDepartment = $_POST['contactDepartment'];
$contactJobTitle = $_POST['contactJobTitle'];
$contactEmailAddress = $_POST['contactEmailAddress'];
$contactMobileNo = $_POST['contactMobileNo'];
$contactPhoneNo = $_POST['contactPhoneNo'];
$contactFaxNo = $_POST['contactFaxNo'];
$locId = $_POST['locId'];
$deptId = $_POST['deptId'];	
$jobId = $_POST['jobId'];	

echo $contactJobTitle;

$query = mysql_query("insert into contact(contact_name, department_id, position_id, location_id, contact_department, contact_job_title, contact_email_address, contact_mobile_no, contact_phone_no, contact_fax_no) values('$contactName', '$deptId', '$jobId', '$locId', '$contactDepartment', '$contactJobTitle' , '$contactEmailAddress', '$contactMobileNo' , '$contactPhoneNo', '$contactFaxNo')");


$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Contact record updated.', '".$_SESSION['emp_id']."')")or die(mysql_error());

?>