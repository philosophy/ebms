<?php 
include("../../../config/config.php");
$job = "";
$get = mysql_query("Select position_id, position_name from position where is_deleted = 0");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $job .= "<option value='".$array["position_id"]."'>".$array["position_name"]."</option>";
		}
	}
	
	echo $job;

?>