<?php 
session_start();
include("../../../config/config.php");
$contactId = @$_POST['contId'];
$locationId = @$_POST['locId'];
$restore = mysql_query("Update contact set is_deleted = 1 where contact_name='".$contactId."' and location_id ='".$locationId."'");
$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Contact record deleted.', '".$_SESSION['emp_id']."')")or die(mysql_error());
?>