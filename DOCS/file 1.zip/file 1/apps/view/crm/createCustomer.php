<?php 
session_start();
include("../../../config/config.php");
	
$customerName = addslashes($_POST['customerName']);
$customerType = $_POST['customerType'];
$industryType = $_POST['industryType'];
$emailAddress = $_POST['emailAddress'];
$mobileNo = addslashes($_POST['mobileNo']);
$phoneNo = $_POST['phoneNo'];
$faxNo = $_POST['faxNo'];
$remarks = addslashes($_POST['remarks']);

$ctId = "";
$itId = "";

$getCustTypeId = mysql_query("Select customer_type_id from customer_type where customer_type_name = '".$customerType."'");	
if(mysql_num_rows($getCustTypeId) > 0)
	{
		while($custTypeId = mysql_fetch_array($getCustTypeId))
		{
			$ctId = $custTypeId["customer_type_id"];
		}
	}

	
if($industryType == "...")
		$itId = 0;
else
{	
	$getIndTypeId = mysql_query("Select industry_type_id from industry_type where industry_type_name = '".$industryType."'");	
	if(mysql_num_rows($getIndTypeId) > 0)
		{
			while($indTypeId = mysql_fetch_array($getIndTypeId))
			{
				$itId = $indTypeId["industry_type_id"];
			}
		}
}

	$max = 0;
    $zeros = "000000";
	$query = mysql_query("Select max(CUSTOMER_ID) From customer_profile");
    if(mysql_num_rows($query) > 0)
		{	
			while($id= mysql_fetch_array($query))
			{
				$max = $id[0];
			}
			
            $max += 1;
			$my_t= date('Y');
            $cc = "CUS-" .$my_t. "-" . substr($zeros, 0, strlen($zeros) - strlen($max)) . $max;
		}
		


$update = mysql_query("Insert into customer_profile(customer_code, customer_name, customer_type_id, industry_type_id, customer_email_address, customer_mobile_no, customer_phone_no, customer_fax_no, customer_remarks,date_created) values('$cc','$customerName',$ctId,$itId,'$emailAddress','$mobileNo','$phoneNo','$faxNo','$remarks', curdate())");		


$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Customer record updated.', '".$_SESSION['emp_id']."')")or die(mysql_error());

echo $cc;


?>