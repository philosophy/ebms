<?php
include("../../../config/config.php");

$customerCode = @$_POST['customerCode'];
$outputData = "";
	
	$arrResult = mysql_query("
		SELECT os_hdr_no, date_format(os_hdr_date,'%b-%d-%Y') as 'os_hdr_date', os_hdr_gross_amount, os_hdr_net_amount, os_hdr_discount_amount, os_hdr_remarks, CONCAT( ep.emp_first_name,  ' ', LEFT( ep.emp_middle_name, 1 ) , '. ', ep.emp_last_name ) AS  'Employee', CONCAT( eps.emp_first_name,  ' ', LEFT( eps.emp_middle_name, 1 ) ,  '. ', eps.emp_last_name ) AS  'Employee1'
		FROM os_header oh
		INNER JOIN employee_profile ep ON ep.emp_id = oh.sales_person_id
		INNER JOIN employee_profile eps ON eps.emp_id = oh.created_by_id
		INNER JOIN customer_profile cp ON cp.customer_id = oh.customer_id
		INNER JOIN area ar ON ar.area_id = oh.area_id
		INNER JOIN location loc ON loc.location_id = oh.os_hdr_bill_to_id
		WHERE cp.customer_code =  '$customerCode'
		GROUP BY cp.customer_id, os_hdr_gross_amount");
	
	$arrResultSum = mysql_query("
	    select sum(os_hdr_gross_amount) as 'sum' from os_header os, customer_profile cp where os.customer_id=cp.customer_id and cp.customer_code='$customerCode'");
	$sum = 0;
	if(mysql_num_rows($arrResult)>0)
	{
	$outputData .= "<table>
					<th>Doc. No.</th>
					<th>Date</th>
					<th>Gross Amount</th>
					<th>Net Amount</th>
					<th>Discount Amount</th>
					<th>Sales Person</th>
					<th>Created By</th>";
	
		while($arrChecks = mysql_fetch_array($arrResult))
			{
			$outputData .= "<tr a='".$arrChecks['os_hdr_no']."'>";
				$outputData .= "<td>".@$arrChecks['os_hdr_no']."</td>";
				$outputData .= "<td>".@$arrChecks['os_hdr_date']."</td>";
				$outputData .= "<td align='right'>".number_format(@$arrChecks['os_hdr_gross_amount'],2)."</td>";
				$outputData .= "<td align='right'>".number_format(@$arrChecks['os_hdr_net_amount'],2)."</td>";
				$outputData .= "<td align='right'>".number_format(@$arrChecks['os_hdr_discount_amount'],2)."</td>";
				$outputData .= "<td>".@$arrChecks['Employee']."</td>";
				$outputData .= "<td>".@$arrChecks['Employee1']."</td>";
			$outputData .= "</tr>";
			}
		while($arrSum = mysql_fetch_array($arrResultSum))
			{
		  $sum = "<div id='total-sales'><p>Total Sales: Php ". number_format(@$arrSum['sum'],2)."</p></div>";
		    }
	}
	else  
	{
	$outputData = "No results found";
	$sum = "";
	}
	
echo $outputData.";".$sum;

?>