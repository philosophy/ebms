﻿<?php 
include("../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE customer_name LIKE '%".$searchQuery."%' or customer_code LIKE '%".$searchQuery."%' or customer_type_name LIKE '%".$searchQuery."%' or customer_phone_no LIKE '%".$searchQuery."%' or customer_mobile_no LIKE '%".$searchQuery."%' or industry_type_name LIKE '%".$searchQuery."%'  or customer_email_address LIKE '%".$searchQuery."%'";
	}

elseif ($searchQuery == "")
	$condition = "";

$cur_page = $page;
$page -= 1;
$per_page = 9;

$start = $page * $per_page;

$index = 1;
 $outputData .="<table>
		<th></th>
		<th>Customer Code</th>
		<th>Customer Name</th>
		<th>Customer Type</th>
		<th>Phone/Mobile No.</th>
		<th>Industry Type</th>
		<th>Email</th>";

	$query = "select customer_code, customer_name, customer_type_name,
	customer_phone_no, customer_mobile_no, industry_type_name,
	customer_email_address, is_active, cp.is_deleted from customer_profile as cp 
		left outer join industry_type as it on cp.industry_type_id = it.industry_type_id
		inner join customer_type as ct on ct.customer_type_id = cp.customer_type_id
	$condition  order by cp.is_deleted asc, is_active desc, customer_code desc	";
	
	
	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$arrResult = mysql_query($query." limit $start,$per_page");
	
	if(mysql_num_rows($arrResult) > 0)
	{
	while($arrCustomer = mysql_fetch_array($arrResult))
	{
	if($arrCustomer['customer_phone_no'] == "")
		$separator = "";
	else // if customer phone is not null
		$separator = "/";

	
	if($arrCustomer['is_active'] == 1)
		$custStatusWidget = "<img title='Active customer' src='../../../images/icons/smiley-icon.png' width=20 height=20 />";
	else if($arrCustomer['is_active'] == 0)
		$custStatusWidget = "<img title='Inactive customer' src='../../../images/icons/inactive.png' width=20 height=20 />";
	if($arrCustomer['is_deleted'] == 1)
		$custStatusWidget = "<img title= 'Deleted'   src='../../../images/icons/deleted-icon.png' width=20 height=20/>";
			$x = (($arrCustomer['is_deleted']==1)?"deleted=true":"deleted=false");
		
			$outputData .= "<tr ".$x." a=".$arrCustomer['customer_code']." customerName='".$arrCustomer['customer_name']."'>";
			$outputData .= "<td>".$custStatusWidget."</td>";
			$outputData .= "<td>".$arrCustomer['customer_code']."</td>";
			$outputData .= "<td>".rawurldecode($arrCustomer['customer_name'])."</td>";
			$outputData .= "<td>".$arrCustomer['customer_type_name']."</td>";
			$outputData .= "<td>".$arrCustomer['customer_phone_no']. $separator . $arrCustomer['customer_mobile_no']."</td>";
			$outputData .= "<td>".$arrCustomer['industry_type_name']."</td>";
			$outputData .= "<td>".rawurldecode($arrCustomer['customer_email_address'])."</td>";
			$outputData .= "</tr>";
		
	}
	mysql_free_result($arrResult); 
	
	$outputData .= "</table>";
    }
	
	else
	{
	include("../noResults.php");
	$cur_page = 0;
	}
 
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
	

?>