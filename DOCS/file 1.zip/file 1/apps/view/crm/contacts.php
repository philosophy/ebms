<?php 
include("../../../config/config.php");
$customerCode = @$_POST['customerCode'];
$locationID = @$_POST['locationID'];
$outputData = "";

	$arrResult = mysql_query("
			SELECT cont.contact_name,cont.contact_job_title,cont.contact_department,cont.contact_email_address,cont.contact_phone_no,cont.contact_mobile_no,cont.contact_fax_no,  cont.is_deleted
			FROM contact cont 
				INNER JOIN location loc on loc.LOCATION_ID = cont.LOCATION_ID
				INNER JOIN customer_profile cust on cust.CUSTOMER_ID = loc.CUSTOMER_ID				
			WHERE cust.CUSTOMER_CODE = '$customerCode' AND loc.LOCATION_ID = '$locationID'
				");
		
		if(mysql_num_rows($arrResult))
		{
		$outputData .="
				<table>
				<th></th>
				<th>Contact Name</th>
				<th>Job Title</th>
				<th>Department</th>
				<th>Work Email</th>
				<th>Phone No.</th>
				<th>Mobile No.</th>
				<th>Fax No.</th>";
				
			while($arrContact = mysql_fetch_array($arrResult))
				{
				
				if($arrContact['is_deleted'] == 0)
				$custStatusWidget = "<img  src='../../../images/icons/Phone-icon.png' width=20 height=20 />";
				if($arrContact['is_deleted'] == 1)
				$custStatusWidget = "<img title= 'Deleted'   src='../../../images/icons/deleted-icon.png' width=20 height=20/>";
					$x = (($arrContact['is_deleted']==1)?"deleted=true":"deleted=false");
				$outputData .="<tr ".$x." contact = '".$arrContact['contact_name']."'>";
					$outputData .="<td>".$custStatusWidget."</td>";
					$outputData .="<td>".@$arrContact['contact_name']."</td>";
					$outputData .="<td>".@$arrContact['contact_job_title']."</td>";
					$outputData .="<td>".@$arrContact['contact_department']."</td>";
					$outputData .="<td>".@$arrContact['contact_email_address']."</td>";
					$outputData .="<td>".@$arrContact['contact_phone_no']."</td>";
					$outputData .="<td>".@$arrContact['contact_mobile_no']."</td>";
					$outputData .="<td>".@$arrContact['contact_fax_no']."</td>";
				$outputData .="</tr>";
				}
		
		$outputData .="</table>";
		}
		
		else //no records found
		$outputData = "No records found";

echo $outputData;
				