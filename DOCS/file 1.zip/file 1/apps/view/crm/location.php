<?php
include("../../../config/config.php");
$customerCode = @$_POST['customerCode'];
$outputData = "";
	
	$arrResult = mysql_query("
		SELECT cust.customer_code,loc.location_id,cust.customer_name, loc.location_name, locType.location_type_name,loc.location_address,a.area_name, loc.is_deleted
		FROM customer_profile cust 
			INNER JOIN location loc on loc.CUSTOMER_ID = cust.CUSTOMER_ID
			LEFT JOIN location_type locType on locType.LOCATION_TYPE_ID = loc.LOCATION_TYPE_ID
			INNER JOIN area a on a.AREA_ID = loc.AREA_ID
		WHERE cust.CUSTOMER_CODE = '".$customerCode."'
			");
	
	if(mysql_num_rows($arrResult)>0)
	{
	$outputData .= "<table>
				<th></th>
				<th>Location Name</th>
				<th>Location Type</th>
				<th>Address</th>
				<th>Area</th>";
				
		while($arrLocation = mysql_fetch_array($arrResult))
			{
			
			if($arrLocation['is_deleted'] == 1)
			$image = "<img title= 'Deleted' src='../../../images/icons/deleted-icon.png' width=20 height=20/>";
			else if($arrLocation['is_deleted'] == 0)
			$image = "<img src='../../../images/icons/location.png' width=20 height=20 />";
				$x = (($arrLocation['is_deleted']==1)?"deleted=true":"deleted=false");
			
			$outputData .= "<tr ".$x." a=".$arrLocation['customer_code']." b=".$arrLocation['location_id'].">";
				$outputData .= "<td>".@$image."</td>";
				$outputData .= "<td>".@$arrLocation['location_name']."</td>";
				$outputData .= "<td>".@$arrLocation['location_type_name']."</td>";
				$outputData .= "<td>".rawurldecode(@$arrLocation['location_address'])."</td>";
				$outputData .= "<td>".@$arrLocation['area_name']."</td>";
			$outputData .= "</tr>";
			}
	}
	else // no results found 
	{
	$outputData = "No results found";
	}
	
echo $outputData;

?>