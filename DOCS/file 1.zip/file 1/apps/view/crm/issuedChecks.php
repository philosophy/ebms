<?php
include("../../../config/config.php");

$customerCode = @$_POST['customerCode'];
$outputData = "";
	
	$arrResult = mysql_query("
		SELECT check_no, check_account_no, check_account_name, check_amount, bank_name, bank_address,date_format(check_date_issued,'%b-%d-%Y') as 'check_date_issued',
		date_format(check_due_date,'%b-%d-%Y') as 'check_due_date',date_format(check_date_posted,'%b-%d-%Y') as 'check_date_posted',is_posted
		From check_profile cp, bank b, customer_profile cust
		Where cp.bank_id = b.bank_id and cp.customer_id=cust.customer_id and cust.customer_code='$customerCode'");
	
	if(mysql_num_rows($arrResult)>0)
	{
	$outputData .= "<table>
					<th></th>
					<th>Check No.</th>
					<th>Account No.</th>
					<th>Acct. Name</th>
					<th>Amount</th>
					<th>Bank</th>
					<th>Address</th>
					<th>Date Issued</th>
					<th>Due Date</th>
					<th>Date Posted</th>";
	
		while($arrChecks = mysql_fetch_array($arrResult))
			{
			if($arrChecks['is_posted'] == 1)
		       $checkStatusWidget = "<img title='Posted Checks' src='../../../images/icons/posted-checks.png' width=20 height=20 />";
	        else
		       $checkStatusWidget = "<img title='Cleared Checks' src='../../../images/icons/cleared-checks.png' width=20 height=20 />";
			$outputData .= "<tr>";
			    $outputData .= "<td>".$checkStatusWidget."</td>";
				$outputData .= "<td>".@$arrChecks['check_no']."</td>";
				$outputData .= "<td>".@$arrChecks['check_account_no']."</td>";
				$outputData .= "<td>".@$arrChecks['check_account_name']."</td>";
				$outputData .= "<td align='right'>".number_format(@$arrChecks['check_amount'],2)."</td>";
				$outputData .= "<td>".@$arrChecks['bank_name']."</td>";
				$outputData .= "<td>".@$arrChecks['bank_address']."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime(@$arrChecks['check_date_issued']))."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime(@$arrChecks['check_due_date']))."</td>";
				$outputData .= "<td>".date("D M d, Y",strtotime(@$arrChecks['check_date_posted']))."</td>";
			$outputData .= "</tr>";
			}
	}
	else // no results found 
	{
	$outputData = "No results found";
	}
	
echo $outputData;

?>