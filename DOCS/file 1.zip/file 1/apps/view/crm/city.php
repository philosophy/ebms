<?php
include("../../../config/config.php");
$get_city = mysql_query("Select city_name from city where is_deleted = 0");
$cityName[] = "";
if(mysql_num_rows($get_city) > 0)
	{
		$i = 0;
		while($arrCity = mysql_fetch_array($get_city))
		{
		 $cityName[$i] = array($arrCity["city_name"]);
		 $i++;
		}
	}
		
	$city = json_encode(array("city" => $cityName));
	echo $city;
?>
