<?php 
include("../../../config/config.php");
$department = "";
$get = mysql_query("Select dept_id, dept_name from department where is_deleted = 0");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $department .= "<option value='".$array["dept_id"]."'>".$array["dept_name"]."</option>";
		}
	}
	
	echo $department;

?>