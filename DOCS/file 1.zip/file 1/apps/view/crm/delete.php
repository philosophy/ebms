<?php 
session_start();
include("../../../config/config.php");
$customerCode = @$_POST['customerCode'];
$restore = mysql_query("Update customer_profile set is_deleted = 1 where customer_code='".$customerCode."'");
$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Customer record deleted.', '".$_SESSION['emp_id']."')")or die(mysql_error());
?>