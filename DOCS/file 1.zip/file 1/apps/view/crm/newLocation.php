<?php
session_start();
include("../../../config/config.php");

$customerCode = @$_POST['code'];
$locationName = addslashes(@$_POST['locName']);
$locationType = @$_POST['locType'];
$city = @$_POST['locCity'];
$barangay = @$_POST['locBarangay'];
$area = @$_POST['locArea'];
$address = @$_POST['locAddress'];
$phoneNo = @$_POST['locPhoneNo'];
$faxNo = @$_POST['locFaxNo'];

$query = mysql_query("Select location_type_id from location_type where location_type_name ='".$locationType."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$locTypeId = $id["location_type_id"];
		}
	}
	
$query = mysql_query("Select city_id from city where city_name ='".$city."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$cityId = $id["city_id"];
		}
	}
	
$query = mysql_query("Select barangay_id from barangay where barangay_name ='".$barangay."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$barangayId = $id["barangay_id"];
		}
	}
	
$query = mysql_query("Select area_id from area where area_name ='".$area."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$areaId = $id["area_id"];
		}
	}
	
$query = mysql_query("Select customer_id from customer_profile where customer_code ='".$customerCode."'");

if(mysql_num_rows($query) > 0)
	{
		while($id = mysql_fetch_array($query))
		{
			$custId = $id["customer_id"];
		}
	}		
	
$query = mysql_query("Insert into location(location_name, location_address, location_phone_no, location_fax_no, area_id, city_id, barangay_id, customer_id, location_type_id) values('$locationName', '$address', '$phoneNo', '$faxNo', '$areaId', '$cityId', '$barangayId', '$custId', '$locTypeId')");

$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Location record created.', '".$_SESSION['emp_id']."')")or die(mysql_error());

?>