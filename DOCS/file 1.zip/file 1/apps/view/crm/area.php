<?php
include("../../../config/config.php");
$get_area = mysql_query("Select area_name from area where is_deleted = 0");
$areaName[] = "";
if(mysql_num_rows($get_area) > 0)
	{
		$i = 0;
		while($arrArea = mysql_fetch_array($get_area))
		{
		 $areaName[$i] = array($arrArea["area_name"]);
		 $i++;
		}
	}
		
	$area = json_encode(array("area" => $areaName));
	echo $area;
?>
