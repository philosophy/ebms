<?php
include("../../../config/config.php");
$city = @$_POST['city'];

$get = mysql_query("Select city_id from city where city_name = '".$city."'");
if(mysql_num_rows($get) > 0)
	{
		while($array = mysql_fetch_array($get))
		{
		 $cityId = $array["city_id"];
		}
	}
else
		 $cityId = 0;

$get = mysql_query("Select barangay_name from barangay where is_deleted = 0 and city_id = '".$cityId."'");
$barangayName[] = "";
if(mysql_num_rows($get) > 0)
	{
		$i = 0;
		while($arr = mysql_fetch_array($get))
		{
		 $barangayName[$i] = array($arr["barangay_name"]);
		 $i++;
		}
		
		
	}
		$barangay = json_encode(array("brgy" => $barangayName));
		echo $barangay;	
		
	
		
	
?>
