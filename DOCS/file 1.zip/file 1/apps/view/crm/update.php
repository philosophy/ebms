<?php 
session_start();
include("../../../config/config.php");

$customerCode = @$_POST['customer'];
$code = @$_POST['code'];
$customerName = addslashes(@$_POST['customerName']);
$customerType = @$_POST['customerType'];
$industryType = @$_POST['industryType'];
$emailAddress = @$_POST['emailAddress'];
$mobileNo = @$_POST['mobileNo'];
$phoneNo = @$_POST['phoneNo'];
$faxNo = @$_POST['faxNo'];
$remarks = addslashes(@$_POST['remarks']);
$ctId = "";
$itId = "";
$getdata = mysql_query("select customer_name, customer_type_name,
	customer_phone_no, customer_mobile_no, industry_type_name, customer_remarks,
	customer_email_address, customer_fax_no from customer_profile as cp 
		left outer join industry_type as it on cp.industry_type_id = it.industry_type_id
		inner join customer_type as ct on ct.customer_type_id = cp.customer_type_id where customer_code ='".$customerCode."'");
$data[] = "";
if(mysql_num_rows($getdata) > 0)
		{	
			while($arrCustomer = mysql_fetch_array($getdata))
			{
			$data["name"] = $arrCustomer["customer_name"];
			$data["customer_type"] = $arrCustomer["customer_type_name"];
			$data["industry_type"] = $arrCustomer["industry_type_name"];
			$data["email"] = $arrCustomer["customer_email_address"];
			$data["mobile"] = $arrCustomer["customer_mobile_no"];
			$data["phone"] = $arrCustomer["customer_phone_no"];
			$data["fax"] = $arrCustomer["customer_fax_no"];
			$data["remarks"] = $arrCustomer["customer_remarks"];
			}
		}
	 $dataArray = json_encode(array("values"=>$data));
	 echo $dataArray;
		
$getCustTypeId = mysql_query("Select customer_type_id from customer_type where customer_type_name = '".$customerType."'");	
if(mysql_num_rows($getCustTypeId) > 0)
	{
		while($custTypeId = mysql_fetch_array($getCustTypeId))
		{
			$ctId = $custTypeId["customer_type_id"];
		}
	}
	
if($industryType == "...")
		$itId = 0;
else
{	
	$getIndTypeId = mysql_query("Select industry_type_id from industry_type where industry_type_name = '".$industryType."'");	
	if(mysql_num_rows($getIndTypeId) > 0)
		{
			while($indTypeId = mysql_fetch_array($getIndTypeId))
			{
				$itId = $indTypeId["industry_type_id"];
			}
		}
}
if($itId != "")
{
$update = mysql_query("Update customer_profile set customer_name = '".$customerName."', customer_type_id = '".$ctId."', industry_type_id = '".$itId."', customer_email_address = '".$emailAddress."',customer_mobile_no ='".$mobileNo."', customer_phone_no ='".$phoneNo."', customer_fax_no = '".$faxNo."', customer_remarks = '".$remarks."' where customer_code = '".$code."'");	

$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Customer record updated.', '".$_SESSION['emp_id']."')")or die(mysql_error());
}

?>