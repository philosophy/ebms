<?php
session_start();
include("../../../config/config.php");
$locationId = @$_POST['locId'];
$query = mysql_query("update location set is_deleted = 0 where location_id = ".$locationId);
$query = mysql_query("Insert into audit_trail values(curdate(), curtime(), 'Location record restored.', '".$_SESSION['emp_id']."')")or die(mysql_error());

?>