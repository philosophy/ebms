﻿<div id="footer">
<div id="sys-mask-name">
<img src="/EBMS/images/sme-soft.png">
</div>

<span>Powered By: SMESoft, INC. | EBMS | © <?php echo date("Y"); ?> All Rights Reserved</span>
	
	<div id="external-links">
	<b>Connect with us</b>
	<ul class="icon-pages-list">
	
	<li>
	<a href="http://plus.google.com" target="_new" title="+1'd us on Google Plus">
	<img alt="Google Plus" src="/EBMS/images/icons/google-plus.png">
	</a>
	</li>
	
	<li>
	<a href="http://www.facebook.com/pages/SMESoft-Inc/163321967068616" target="_new" title="Like us on Facebook">
	<img alt="Facebook" src="/EBMS/images/icons/fb-icon.png">
	</a>
	</li>
	
	<li>
	<a href="http://twitter.com/smesoft" target="_new" title="Follow us on Twiiter">
	<img alt="Twitter" src="/EBMS/images/icons/twitter-icon.png">
	</a>
	</li>
	
	</ul>
	</div>
</div>