<?php 

session_start();
include("../../../config/config.php");
$role = @$_POST['role'];

if($role == "view")
{
$query = mysql_query("
	SELECT COUNT(notif_ref_id) as 'cnt', notif_reference
	FROM notifications
	WHERE is_marked = 0
	GROUP BY notif_reference
	");
$notifCnt=0;
$taskCnt = 0;
$payCnt = 0;
$cslCnt = 0;
$rcvCnt = 0;
$output[] = "";

if(mysql_num_rows($query) > 0)
{
	while($result = mysql_fetch_array($query))
	{
		/*
			$getTableName = mysql_query("
								SELECT *
								FROM ".$result['notif_ref_table']."
								AS Task
								");
			$setTableName = mysql_field_table($getTableName, 0);
		*/
		
	$notifCnt += $result['cnt'];
	
		if($result['notif_reference'] == "taskReminder")
		{
			$taskCnt += $result['cnt'];
		}
	
		elseif($result['notif_reference'] == "payables")
		{
			$payCnt += $result['cnt'];
		}

		elseif($result['notif_reference'] == "receivables")
		{
			$rcvCnt += $result['cnt'];
		}	
		
		elseif($result['notif_reference'] == "criticalStockLevel")
		{
			$cslCnt += $result['cnt'];
		}	
	
	}
	
	$notifCnt = number_format($notifCnt);
	$taskCnt = number_format($taskCnt);
	
		
}

else
{
	$notifCnt = 0;
	

}

$output["notifTotal"] = array($notifCnt);
		$output["taskTotal"] = array($taskCnt);
		$output["payables"] = array($payCnt);
		$output["receivables"] = array($rcvCnt);
		$output["criticalStockLevel"] = array($cslCnt);

	$dataArray = json_encode(array("data"=>$output));
	
	echo $dataArray;

mysql_free_result($query);
}

else if($role == "update")
{
$ref = @$_POST['ref'];
mysql_query("UPDATE notifications SET is_marked = 1 WHERE notif_reference = '$ref'");
}

?>
