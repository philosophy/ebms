
<!--form for Create/Edit OS-->
<div id="new_pr" class="modalForm" w=800>
		<div id="modalTitle">Purchase Request Slip</div>
	<form action="" method="POST" class="pr">
		<div id="formSegment">
			<h5>PR Information</h5>
			
			<label>Pr No.</label>
			<input type="text" id="prNo" value="<Auto>" disabled />
			
			<label>Request Name</label>
			<select id="requestName">
				
			</select>
			
			<label>Date</label>
			<input type="text" datepicker=true id="prDate" value="<?php echo date('Y-m-d'); ?>" disabled />
			
			<label>Date Needed</label>
			<input type="text" datepicker=true id="prDateNeeded">
			
			<label>Remarks</label>
			<textarea id="prRemarks"></textarea>
		
		</div>
	
		<div id="formSegment" style="width:55%;margin-top:-20px">
		<h5>Item List</h5>
			<div id="formDataCont" ref="orderItemsList" style="overflow:hidden;height:230px;">
			<div id="formDataContMenu">
				<input type="text" id="formDataContSearch" value="Search">
				
				<select id="itemType" style="color:#333">
					<option value="product">Product</option>
					<option value="asset">Asset</option>
				</select>
				
				<div id="pagingCont">
					<button id="first" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;"></button>
					
				</div>
			</div>
				<ul class="gridViewNav">
				</ul>
		
			</div>
		
		<h5>Requested Items</h5>
			<div id="formDataCont" style="height:100px;">
				<table>
					<th>Quantity</th>
					<th>Unit</th>
					<th>Code</th>
					<th>Unit Price</th>
					<th>Category</th>
					<th>Item Description</th>
					
					<tbody id="requestedItems">
						
					</tbody>
					
				</table>
			</div>
		
		</div>
				
		<div class="itemDetails" style='width:300px;bottom:90px'>
		<label class="itemCode">Item Code</label>
		<span class="itemDesc">Sample sample</span>
		</div>	
		
		
		
			
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>



<!--form for Create/Edit OS-->
<div id="edit_pr" class="modalForm" w=800>
		<div id="modalTitle">Purchase Request Slip</div>
		<form action="" method="POST" class="pr">
		<div id="formSegment" style="width:800px">
		<div id="formSegment" style="margin-top:-20px">
			<h5>PR Information</h5>
			
			<label>Pr No.</label>
			<input type="text" id="prNo" disabled />
			
			<label>Request Name</label>
			<input type="text" id="requestName" disabled />
			
			<label>Date</label>
			<input type="text" id="prDate" disabled />
			
			<label>Date Needed</label>
			<input type="text" datepicker=true id="prEditDateNeeded">
			
			<label>Remarks</label>
			<textarea id="prRemarks"></textarea>
			
	</div>
		
		
		<div id="formSegment" style="width:55%;margin-top:-20px">
		<h5>Requested Items</h5>
			<div id="formDataCont" style="height:100px;">
				<table>
					<th>Quantity</th>
					<th>Unit</th>
					<th>Code</th>
					<th>Unit Price</th>
					<th>Category</th>
					<th>Item Description</th>
					
					<tbody id="requestedItems">
						
					</tbody>
					
				</table>
			</div>
		</div>
		</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>

<div id="delete_pr" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="delete">Delete</button>
	</div>
	</div>
	
<div id="restore_pr" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="restore">Restore</button>
	</div>
</div>
	
	
<div id="new_po" class="modalForm" w=800>
<div id="modalTitle">Purchase Order</div>
	<form action="" method="POST" class="po">
		<div id="formSegment" style="width:800px;margin-top:-20px">
		<h5>PO Information</h5>
			
			<div id="formSegment" style="margin-top:-20px">
			<label>PO No.</label>
			<input type="text" id="poNo" value="<Auto>" disabled />
			<label>Sold To</label>
			<select id="poSoldTo">
			
			</select>
			<label>Supplier</label>
			<select id="poSupplier">
			
			</select>
			
			<label>Date</label>
			<input type="text" id="poDate" datepicker=true value="<?php echo date('Y-m-d'); ?>" disabled />
			
			<label>Date Needed</label>
			<input type="text" id="poDateNeeded" datepicker=true>
			
			<label>Payment Type</label>
			<select id="poPaymentType">
			<option value="Cash">Cash</option>
			<option value="Check">Check</option>
			</select>
			
			<label>Terms</label>
			<input type="text" value="0" id="poTerms">
			
			</div>
			
			
			<div id="formSegment">
			<label>Gross Amount</label>
			<input type="text" value="0" id="poGrossAmount" style="text-align: right;" disabled />
			
			<label>Discount</label>
			<input type="text" value="0"id="poDiscount" style="text-align: right; width: 100px;">%
			
			
			<label>Net Amount</label>
			<input type="text" value="0" id="poNetAmount" style="text-align: right;" disabled />
			
			
			<label>Remarks</label>
			<textarea id="poRemarks"></textarea>
		
			</div>
		
		</div>
		
		<div id="formSegment" style="width:44%;margin-top:-30px">
		<h5>Item List</h5>
			<div id="formDataCont" ref="orderItemsList" style="height:200px;">
			<div id="formDataContMenu">
				<select id="cboRefNo" style="color:#333">
					
				</select>
				
			</div>
			
				<ul class="gridViewNav">
				
				</ul>
					
			</div>
			
			<div class="itemDetails" style="width:340px">
			<label class="itemCode">Item Code</label>
			<span class="itemDesc">Sample sample</span>
			</div>
			
		</div>
		
		<div id="formSegment" style="margin-top:-20px">
		<h5>Ordered Item</h5>
		<div id="formSegment">
		<div id="formDataCont" style="width:393px;margin-top:-20px;height:200px">
				<table>
					<th>Quantity</th>
					<th>Unit</th>
					<th>Reference No</th>
					<th>Code</th>
					<th>Unit Price</th>
					<th>Category</th>
					<th>Item Description</th>
					
					<tbody id="orderedItems">
						
					</tbody>
					
				</table>
		</div>
		</div>
		</div>
		
		
		
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
		
	</form>
</div>
	
<div id="edit_po" class="modalForm" w=670>
<div id="modalTitle">Purchase Order</div>
	<form action="" method="POST" class="po">
		<div id="formSegment" style="width:670px;margin-top:-20px">
		<h5>PO Information</h5>
			
			<div id="formSegment" style="margin-top:-20px">
			<label>PO No.</label>
			<input type="text" id="poNo" disabled />
			<label>Sold To</label>
			<input type="text" id="poSoldTo" disabled />
			<label>Supplier</label>
			<input type="text" id="poSupplier" disabled />
			
			<label>Date</label>
			<input type="text" id="poDate" datepicker=true disabled />
			
			<label>Date Needed</label>
			<input type="text" id="poEditDateNeeded" datepicker=true>
			
			<label>Payment Type</label>
			<select id="poPaymentType">
			<option value="Cash">Cash</option>
			<option value="Check">Check</option>
			</select>
			
			<label>Terms</label>
			<input type="text" id="poTerms">
			
			</div>
			
			
			<div id="formSegment">
			<label>Gross Amount</label>
			<input type="text" id="poGrossAmount" style="text-align: right;" disabled />
			
			<label>Discount</label>
			<input type="text" id="poDiscount" style="text-align: right; width: 100px;" />%
			
			<label>Net Amount</label>
			<input type="text" id="poNetAmount" style="text-align: right;" disabled />
			
			
			<label>Remarks</label>
			<textarea id="poRemarks"></textarea>
		
			</div>
		
		</div>
		
		<div id="formSegment" style="margin-top:-20px">
		<h5>Ordered Item</h5>
		<div id="formSegment">
		<div id="formDataCont" style="width:600px;margin-top:-20px;height:200px">
			<table>
				<th>Quantity</th>
				<th>Unit</th>
				<th>Reference No</th>
				<th>Code</th>
				<th>Unit Price</th>
				<th>Category</th>
				<th>Item Description</th>
					
				<tbody id="orderedItems">
						
				</tbody>
					
			</table>
		
		</div>
		</div>
		</div>
		
		
		
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
		
	</form>
</div>
<div id="delete_po" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="delete">Delete</button>
	</div>
	</div>
	
<div id="restore_po" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="restore">Restore</button>
	</div>
</div>

	<div id="new_supplier" class="modalForm" w=700>
	
	<div id="modalTabControl">
		<ul class="modalTabNav">
			<li id="modalTabList">
				<a href="#general" id="modalTabLink" class="modalTabActive">
				General
				</a>
			</li>
			<li id="modalTabList">
				<a href="#supplierLocation" id="modalTabLink">
				Location
				</a>
			</li>
			<li id="modalTabList">
				<a href="#supplierContact" id="modalTabLink">
				Contact
				</a>
			</li>
			
	</div>
	
	<form method="POST" action="">
		<div id="general" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Supplier Code</label>
			<input type="text" id="supplierCode" value="<Auto>" disabled />
		
		<label>Supplier Name</label>
			<input type="text" id="supplierName">
			
			
		<label>Industry Type</label>
			<select id="industryType">
			
			</select>
		
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		
		<label>Remarks</label>
			<textarea id="remarks"></textarea>
		
		</div>
		</div>
		
		<div id="supplierLocation" class="modalFormTabCont"> 
		
		<div id="formSegment" style="width: 700px;" >
			<div id="formSegment" >
				<label>Supplier Code</label>
				<input type="text" id="supplierCode" value="<Auto>" disabled />
		
				<label>Location Type</label>
				<select id="locationType">
				</select>
		
				<label>Location Name</label>
				<input type="text" id="locationName">
			
				<label>City</label>
				<select id="city">
				</select>
		
				<label>Barangay</label>
				<select id="barangay">
				</select>
		
				<label>Area</label>
				<select id="area">
				</select>
		
				<label>Address</label><textarea id="address"></textarea>
		</div>
				<div id="formSegment">
				<label>Phone Number</label>
				<input type="text" id="phoneNo">

				<label>Fax Number</label>
				<input type="text" id="faxNo">
		
			</div>
		</div>
	
		</div>
		
		<div id="supplierContact" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Supplier Code</label>
			<input type="text" id="supplierCode" value="<Auto>" disabled />
		
		<label>Contact Name</label>
			<input type="text" id="contactName">
		
		<label>Job Title</label>
			<select id="jobTitle">
			</select>
		
		<label>Department</label>
			<select id="department" disabled />
			</select>
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		</div>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	</div>
	
	
	<div id="edit_supplier" class="modalForm" w=700>
	
	<div id="modalTabControl">
		<ul class="modalTabNav">
			<li id="modalTabList">
				<a href="#general" id="modalTabLink" class="modalTabActive">
				General
				</a>
			</li>
			<li id="modalTabList">
				<a href="#supplierLocation" id="modalTabLink">
				Location
				</a>
			</li>
			<li id="modalTabList">
				<a href="#supplierContact" id="modalTabLink">
				Contact
				</a>
			</li>
			
	</div>
	
	<form method="POST" action="">
		<div id="general" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Supplier Code</label>
			<input type="text" id="supplierCode" disabled />
		
		<label>Supplier Name</label>
			<input type="text" id="supplierName">
			
			
		<label>Industry Type</label>
			<select id="industryType">
			</select>
		
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		
		<label>Remarks</label>
			<textarea id="remarks"></textarea>
		
		</div>
		</div>
		
		<div id="supplierLocation" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Supplier Code</label>
			<input type="text" id="supplierCode" disabled />
			
		<label>Location Type</label>
			<select id="locationType">
			</select>
		
		<label>Location Name</label>
			<input type="text" id="locationName">
			
		<label>City</label>
			<select id="city">
			</select>
		
		<label>Barangay</label>
			<select id="barangay">
			</select>
		
		<label>Area</label>
			<select id="Area">
			</select>
		
		<label>Address</label><textarea id="address"></textarea>
			
		</div>
		<div id="formSegment">
				<label>Phone Number</label>
				<input type="text" id="phoneNo">

				<label>Fax Number</label>
				<input type="text" id="faxNo">
		
			</div>
		
		</div>
		
		<div id="supplierContact" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Supplier Code</label>
			<input type="text" id="supplierCode" disabled />
		
		<label>Contact Name</label>
			<input type="text" id="contactName">
		
		<label>Job Title</label>
			<select id="jobTitle">
			</select>
		
		<label>Department</label>
			<select id="department" disabled />
			</select>
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		</div>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	</div>
	
	<div id="delete_supplier" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="delete">Delete</button>
	</div>
	</div>
	
<div id="restore_supplier" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="restore">Restore</button>
	</div>
</div>
	
	
	