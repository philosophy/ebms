	<div id="new_crm" class="modalForm" w=700>
	<div id="modalTitle">Customer Profile</div>
	<div id="modalTabControl">
		<ul class="modalTabNav">
			<li id="modalTabList">
				<a href="#customerInfo" id="modalTabLink" class="modalTabActive">
				Customer Info
				</a>
			</li>
			<li id="modalTabList">
				<a href="#customerLocation" id="modalTabLink">
				Location
				</a>
			</li>
			<li id="modalTabList">
				<a href="#customerContact" id="modalTabLink">
				Contact
				</a>
			</li>
			
	</div>
	
	<form method="POST" action="">
		<div id="customerInfo" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Customer Code</label>
			<input type="text" id="customerCode">
		
		<label>Customer Name<span>* </span></label>
			<input type="text" id="customerName">
			
		<label>Customer Type<span>* </span></label>
			<select id="customerType">
			<option value="">...</option>
			</select>
			
		<label>Industry Type</label>
			<select id="industryType">
			<option value="">...</option>
			</select>
		
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		
		<label>Remarks</label>
			<textarea id="remarks"></textarea>
		
		</div>
		</div>
		
		<div id="customerLocation" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Customer Code</label>
			<input type="text" id="customerCode">
		
		<label>Location Name<span>* </span></label>
			<input type="text" id="locationName">
			
		<label>Location Type<span>* </span></label>
			<select id="locationType">
			<option value="">...</option>
			</select>
			
		<label>City</label>
			<select id="city">
			<option value="">...</option>
			</select>
		
		<label>Barangay</label>
			<select id="barangay">
			<option value="">...</option>
			</select>
		
		<label>Area</label>
			<select id="Area">
			<option value="">...</option>
			</select>
		
		<label>Address</label><textarea id="address"></textarea>
			
		</div>
		
		<div id="formSegment">
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		
		</div>
		
		
		
		
		
		</div>
		
		<div id="customerContact" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Customer Code</label>
			<input type="text" id="customerCode">
			
		<label>Location Type</label>
			<select id="locationType">
			<option value="">...</option>
			</select>
		
		<label>Location Name</label>
			<select id="locationName">
			<option value="">...</option>
			</select>
		
		<label>Contact Name<span>* </span></label>
			<input type="text" id="contactName">
		
		<label>Job Title</label>
			<select id="jobTitle">
			<option value="">...</option>
			</select>
		
		<label>Department</label>
			<select id="department">
			<option value="">...</option>
			</select>
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		</div>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	</div>
	
	
	<div id="delete_crm" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
		
	<div id="delete_location" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
	<div id="delete_contact" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
	<div id="restore_crm" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>
	
	<div id="restore_contact" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>
	
	
	<div id="restore_location" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>
	
	<div id="edit_crm" class="modalForm" w=700>
	<div id="modalTitle">Customer Profile</div>
	<div id="modalTabControl">
		<ul class="modalTabNav">
			<li id="modalTabList">
				<a href="#customerInfo" id="modalTabLink" class="modalTabActive">
				Customer Info
				</a>
			</li>
			<li id="modalTabList">
				<a href="#customerLocation" id="modalTabLink">
				Location
				</a>
			</li>
			<li id="modalTabList">
				<a href="#customerContact" id="modalTabLink">
				Contact
				</a>
			</li>
			
	</div>
	
	<form method="POST" action="">
		<div id="customerInfo" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Customer Code</label>
			<input type="text" id="customerCode">
		
		<label>Customer Name<span>* </span></label>
			<input type="text" id="customerName">
			
		<label>Customer Type<span>* </span></label>
			<select id="customerType">
			<option value="">...</option>
			</select>
			
		<label>Industry Type</label>
			<select id="industryType">
			<option value="">...</option>
			</select>
		
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		
		<label>Remarks</label>
			<textarea id="remarks"></textarea>
		
		</div>
		</div>
		
		<div id="customerLocation" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Customer Code</label>
			<input type="text" id="customerCode">
		
		<label>Location Name<span>* </span></label>
			<input type="text" id="customerName">
			
		<label>Location Type<span>* </span></label>
			<select id="locationType">
			<option value="">...</option>
			</select>
			
		<label>City</label>
			<select id="city">
			<option value="">...</option>
			</select>
		
		<label>Barangay</label>
			<select id="barangay">
			<option value="">...</option>
			</select>
		
		<label>Area</label>
			<select id="Area">
			<option value="">...</option>
			</select>
		
		<label>Address</label><textarea id="address"></textarea>
			
		</div>
		
		<div id="formSegment">
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		
		</div>
		
		
		
		
		
		</div>
		
		<div id="customerContact" class="modalFormTabCont"> 
		
		<div id="formSegment">
		<label>Customer Code</label>
			<input type="text" id="customerCode">
			
		<label>Location Type</label>
			<select id="locationType">
			<option value="">...</option>
			</select>
		
		<label>Location Name</label>
			<select id="locationName">
			<option value="">...</option>
			</select>
		
		<label>Contact Name<span>* </span></label>
			<input type="text" id="contactName">
		
		<label>Job Title</label>
			<select id="jobTitle">
			<option value="">...</option>
			</select>
		
		<label>Department</label>
			<select id="department">
			<option value="">...</option>
			</select>
			
		</div>
		
		<div id="formSegment">
		<label>Email Address</label>
			<input type="text" id="emailAddress">
		
		<label>Mobile Number</label>
			<input type="text" id="mobileNo">
		
		<label>Phone Number</label>
			<input type="text" id="phoneNo">

		<label>Fax Number</label>
			<input type="text" id="faxNo">
		</div>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	</div>
