<div id="log_DTR" class="modalForm" w=330>
	<div id="modalTitle">Daily Time Record</div>

	<form method="POST" action="">
		
		<div id="formSegment">
		<h5>Mode</h5>
		<fieldset style="padding:5px;padding-left:40px;border-radius:5px;background:#F0E6E8">
		<input type="radio" name="dtr" id="timeIn"><label for="radioCheckbox">Time In</label>
		<input type="radio" name="dtr" id="timeOut"><label for="radioCheckbox">Time Out</label>
		</fieldset>
		</div>
		
		<div id="formSegment">
		<label>Name</label>
			<select id="empName" style="color:black;">
			<script>
				$.post("/ebms/apps/view/personnel/employeeDTR/dtrList.php",{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#empName").html(response);
					});
			</script>
			</select>
		<label>Password</label>
			<input type="password" id="empPassword">
		</div>
		<div id="formSegment">
			<div id="formDataCont" ref="dtrList" >
			</div>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
        <input type="button"  value="Time In" id="time"/>
		</div>
		
	</form>
</div>

<div id="new_schedule" class="modalForm" w=470>
	
	<div id="formSegment" style="width:470px;">
		<label>Employee Name</label>
		<select id="empNameSNewN" style="color:black;text-align:center;">
			<script>
				$.post("/ebms/apps/view/personnel/employeeSchedule/schedule.php",{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#empNameSNewN").html(response);
					});
			</script>
		</select>
		<!--<input type="text" id="empNameSNewN" disabled="disable" style="width:270px;text-align:center;">-->
	</div>
	<div id="formSegment" style="width:450px"> 
	<fieldset id="radioCheckbox" style="width:80px;padding:8px;">
    <legend style="font-size:11px;background:lightblue;">Select Days</legend>
		<input type="checkbox" id="mondayNN"><label>Monday</label>
		<input type="checkbox" id="tuesdayNN"><label>Tuesday</label>
		<input type="checkbox" id="wednesdayNN"><label>Wednesday</label>
		<input type="checkbox" id="thursdayNN"><label>Thursday</label>
		<input type="checkbox" id="fridayNN"><label>Friday</label>
		<input type="checkbox" id="saturdayNN"><label>Saturday</label>
		<input type="checkbox" id="sundayNN"><label>Sunday</label>
	</fieldset>
	
	<div id="formSegment">
		<label>Time In</label>
		<input type="text" id="timeInSchedNN">
		
		<label>Time Out</label>
		<input type="text" id="timeOutSchedNN">
		
		<label>Start Break Time</label>
		<input type="text" id="startBreakTimeNN">
		
		<label>End Break Time</label>
		<input type="text" id="endBreakTimeNN">
	</div>
	
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	</div>
	
</div>


<div id="multipleEdit_schedule" class="modalForm" w=470>
	
	<div id="formSegment" style="width:470px;">
		<label>Employee Name</label>
		<input type="text" id="empNameSNew" disabled="disable" style="width:270px;text-align:center;">
	</div>
	<div id="formSegment" style="width:450px"> 
	<fieldset id="radioCheckbox" style="width:80px;padding:8px;">
    <legend style="font-size:11px;background:lightblue;">Select Days</legend>
		<input type="checkbox" id="mondayN"><label>Monday</label>
		<input type="checkbox" id="tuesdayN"><label>Tuesday</label>
		<input type="checkbox" id="wednesdayN"><label>Wednesday</label>
		<input type="checkbox" id="thursdayN"><label>Thursday</label>
		<input type="checkbox" id="fridayN"><label>Friday</label>
		<input type="checkbox" id="saturdayN"><label>Saturday</label>
		<input type="checkbox" id="sundayN"><label>Sunday</label>
	</fieldset>
	
	<div id="formSegment">
		<label>Time In</label>
		<input type="text" id="timeInSchedN">
		
		<label>Time Out</label>
		<input type="text" id="timeOutSchedN">
		
		<label>Start Break Time</label>
		<input type="text" id="startBreakTimeN">
		
		<label>End Break Time</label>
		<input type="text" id="endBreakTimeN">
	</div>
	
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	</div>
	
</div>


<div id="edit_schedule" class="modalForm" w=470>
	
	<div id="formSegment" style="width:470px;">
		<label>Employee Name</label>
		<input type="text" id="empNameS" disabled="disable" style="width:270px;text-align:center;">
	</div>
	
	<div id="formSegment" style="width:450px"> 
	<fieldset id="radioCheckbox" style="width:80px;padding:8px;">
    <legend style="font-size:11px;background:lightblue;">Select Days</legend>
		<input type="checkbox" id="mondayE"><label>Monday</label>
		<input type="checkbox" id="tuesdayE"><label>Tuesday</label>
		<input type="checkbox" id="wednesdayE"><label>Wednesday</label>
		<input type="checkbox" id="thursdayE"><label>Thursday</label>
		<input type="checkbox" id="fridayE"><label>Friday</label>
		<input type="checkbox" id="saturdayE"><label>Saturday</label>
		<input type="checkbox" id="sundayE"><label>Sunday</label>
	</fieldset>
	
	<div id="formSegment">
		<label>Time In</label>
		<input type="text" id="timeInSchedE">
		
		<label>Time Out</label>
		<input type="text" id="timeOutSchedE">
		
		<label>Start Break Time</label>
		<input type="text" id="startBreakTimeE">
		
		<label>End Break Time</label>
		<input type="text" id="endBreakTimeE">
	</div>
	
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	</div>
	
</div>

<div id="new_cashAdvance" class="modalForm" w=650>
	<div id="modalTitle">Cash Advance</div>
	<div id="formSegment">
	
	<label>Voucher No.</label>
	<input type="text" id="voucherNo" value="<Auto>" disabled />
	
	<label>Date</label>
	<input type="text" id="cashAdvDate" datepicker=true value="<?php echo date('Y-m-d'); ?>" disabled />
	</div>
	<div id="formSegment">
	<label>Employee Name</label>
	
	<select id="empName">
	</select>
	
	<label>Remarks</label>
	<textarea id="remarks"></textarea>
	
	</div>

	<div id="formSegment" style="width:700px">
	<h5>Payment</h5>
		
		<div id="formSegment">
			<label>Payment Type</label>
			<select id="paymentType">
			<option value="CASH">Cash</option>
			<option value="CHECK">Check</option>
			</select>
			
			<label>Amount</label>
			<input type="text" id="paymentAmount">
			
			<label>Bank Name</label>
			<select id="bankName" disabled />
			</select>
			
			<label>Account Name</label>
			<select id="acctName" disabled />
			</select>
			
			<label>Account Number</label>
			<select id="acctNo" disabled />
			</select>
		</div>
		
		<div id="formSegment">
		<label>Check No</label>
		<input type="text" id="checkNo" disabled />
		
		<label>Check Type</label>
		<select id="checkType" disabled />
		
		</select>
		
		<label>Check In/Out</label>
		<select id="checkInOut" disabled />
		</select>
		
		<label>Check Date Issue</label>
		<input type="text" id="checkDateIssue" datepicker=true disabled />
		
		<label>Check Due Date</label>
		<input type="text" id="checkDueDate" datepicker=true disabled />
		
		</div>
		
	</div>
	
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	
</div>

<div id="edit_cashAdvance" class="modalForm" w=650>
		<div id="modalTitle">Cash Advance</div>
	<div id="formSegment">
	
	<label>Voucher No.</label>
	<input type="text" id="voucherNo" disabled />
	
	<label>Date</label>
	<input type="text" id="editCashAdvDate" datepicker=true disabled />
	</div>
	<div id="formSegment">
	<label>Employee Name</label>
	<input type="text" id="empName" disabled />
	
	
	<label>Remarks</label>
	<textarea id="remarks"></textarea>
	
	</div>

	<div id="formSegment" style="width:700px">
	<h5>Payment</h5>
		
		<div id="formSegment">
			<label>Payment Type</label>
				<input type="text" id="paymentType" disabled />
			
			<label>Amount</label>
			<input type="text" id="paymentAmount">
			
			<label>Bank Name</label>
				<input type="text" id="bankName" disabled />
			
			<label>Account Name</label>
				<input type="text" id="acctName" disabled />
			
			<label>Account Number</label>
				<input type="text" id="acctNo" disabled />
		</div>
		
		<div id="formSegment">
		<label>Check No</label>
		<input type="text" id="checkNo" disabled />
		
		<label>Check Type</label>
		<input type="text" id="checkType" disabled />
		
		<label>Check In/Out</label>
		<input type="text" id="checkInOut" disabled />
		
		<label>Check Date Issue</label>
		<input type="text" id="editCheckDateIssue" datepicker=true disabled />
		
		<label>Check Due Date</label>
		<input type="text" id="editCheckDueDate" datepicker=true disabled />
		
		</div>
		
	</div>
	
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	
</div>

<div id="delete_cashAdvance" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="delete">Delete</button>
	</div>
	</div>
	
<div id="restore_cashAdvance" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="restore">Restore</button>
	</div>
</div>

<div id="new_payroll" class="modalForm" w=640>
<div id="modalTitle">Payroll</div>
	<style>
	#new_payroll fieldset{
	border:1px solid silver
	}
	#new_payroll fieldset:hover{
	background:azure;
	}
	#new_payroll img:hover{
	background:lightblue;
	border-radius:10px;
	cursor:pointer;
	}
	.totPay label{
	font-weight:bold;
	}
	
	</style>
	<fieldset style="margin:10px;border-radius:5px;padding-left:15px;">
	From<input type="text" id="payrollDateFromN" style="width:235px;margin-left:10px;margin-right:10px;text-align:center;" datepicker=true>
    To<input type="text" id="payrollDateToN" style="width:235px;margin-left:10px;margin-right:10px;text-align:center;"  datepicker=true>	
	</fieldset>	
	<div id="formSegment" style="width:640px;padding:0;border-radius:3px;margin:0;background:#F2F5FA;">

		<div id="formSegment">
			<label>Name</label>
			<select id="empNamePayN" style="color:black;">
			<script>
				$.post("/ebms/apps/view/personnel/employeePayroll/payrollList.php",{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#empNamePayN").html(response);
					});
			</script>
			</select>
			<label>Position</label>
			<input type="text" id="empPositionPayN" disabled="disable">
		</div>
		
		<div id="formSegment">
			<label>Employee No.</label>
			<input type="text" id="empNoPayN" disabled="disable">
			<label>Department</label>
			<input type="text" id="empDepartmentPayN" disabled="disable">
		</div>
	</div>
		
	<div id="formSegment">
	<fieldset style="border-radius:5px;padding-top:10px;height:250px;padding:10px;">
	<legend style="background:#0A3694;font-size:14px;color:white;padding:4px;border-radius:5px;font-weigt:bold;">Earnings 
	<a href="javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/earningManager/index.php',570,630)">
	<img src="../../../../images/icons/select-icon.png" title="add other earnings"/>
	</a>
	</legend>
	<div style="height:225px;overflow:auto;">
		
		<label>Regular Pay</label>
		<input type="text" id="regularPayN" style="text-align:right;" disabled="disable" value='0.00'>
		<label>Hour Rate</label>
		<input type="text" id="hourRateN" style="text-align:right;" disabled="disable" value='0.00'>
			
	    <label>Hours Worked</label>
		<input type="text" id="hoursWorkedN" style="text-align:right;" disabled="disable" value='0.00'>
		
		<label>Minute Rate</label>
		<input type="text" id="minRateN" style="text-align:right;" disabled="disable" value='0.00'>

		<label>Minutes Worked</label>
		<input type="text" id="minsWorkedN" style="text-align:right;" disabled="disable" value='0.00'>
		
		<label>Overtime</label>
		<input type="text" id="overtimeN" style="text-align:right;" disabled="disable" value='0.00'>
			
		<label>Daily Rate</label>
		<input type="text" id="dailyRateN" style="text-align:right;" disabled="disable" value='0.00'>
			
		<label>Days Worked</label>
		<input type="text" id="daysWorkedN" style="text-align:right;" disabled="disable" value='0.00'>
			
		<label>Regular Holiday</label>
		<input type="text" id="regHolidayN" style="text-align:right;" value='0.00'>
			
		<label>Allowance</label>
		<input type="text" id="allowanceN" style="text-align:right;" value='0.00'>
		<div id="otherEarn">
		<script>
				$.post("/ebms/apps/view/personnel/employeePayroll/payrollList.php",{role:"VIEW",viewType:"otherEarning"},
					function(response)
					{
					$("#otherEarn").html(response);
					});
		</script>
		</div>
	</div>
	</fieldset>
	
	<fieldset style="border-radius:5px;padding-top:10px;margin-top:5px;padding:10px;">
		<legend style="background:#0A3694;font-size:14px;color:white;padding:4px;border-radius:5px;font-weigt:bold;">Leave Details 
		</legend>
		<div id="formDataCont" style="margin-bottom:5px;width:265px;">
		<table>
			<th>Leave Name</th>
			<th>From</th>
			<th>To</th>
		</table>
		</div>
		<label>Leave Paid</label>
		<input type="text" id="leavePaidN" style="text-align:right;" disabled="disable">
	</fieldset>
	</div>
	<div id="formSegment">
	<fieldset style="border-radius:5px;padding-top:10px;height:250px;overflow:auto;padding:10px;">
		<legend style="background:#0A3694;font-size:14px;color:white;padding:4px;border-radius:5px;font-weigt:bold;">Deductions 
		<a href="javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/deductionManager/index.php',570,630)">
		<img src="../../../../images/icons/select-icon.png" title="add other deductions"/>
		</a>
		</legend>
		<label>Withholding Tax</label>
		<input type="text" id="withholdingTaxN" style="text-align:right;width:115px;" value='0' disabled>%
		<input type="checkbox" id="withholdingTaxNCheck">
		<label>Cash Advance</label>
		<input type="text" id="cashAdvanceN" style="text-align:right;" value='0.00' disabled>
		<label>Company Loans</label>
		<input type="text" id="companyLoansN" style="text-align:right;" value='0.00'>
		<div id="otherDed">
		<script>
				$.post("/ebms/apps/view/personnel/employeePayroll/payrollList.php",{role:"VIEW",viewType:"otherDeduction"},
					function(response)
					{
					$("#otherDed").html(response);
					});
		</script>
		</div>
	</fieldset>		
	</div>
	<div id="formSegment" class="totPay">
		<fieldset style="border-radius:5px;padding:10px;">
		<label>Total Earnings</label>
		<input type="text" style="text-align:right;" id="totalEarningsN" disabled="disable">
		
		<label>Total Deductions</label>
		<input type="text" style="text-align:right;" id="totalDeductionsN" disabled="disable">
		
		<label>Net Pay</label>
		<input type="text" style="text-align:right;" id="netPayN" disabled="disable">
		</fieldset>
		<div id="formSegment" class="buttonPanel" style="margin-top:30px;">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</div>

</div>


<div id="edit_payroll" class="modalForm" w=640>
<div id="modalTitle">Payroll</div>
	<style>
	#edit_payroll fieldset:hover{
	background:azure;
	}
	#edit_payroll img:hover{
	background:lightblue;
	border-radius:10px;
	cursor:pointer;
	}
	
	.totPay label{
	font-weight:bold;
	}
	
	</style>
	<fieldset style="margin:10px;border-radius:5px;padding-left:15px;">
	From<input type="text" id="payrollDateFromE" style="width:235px;margin-left:10px;margin-right:10px;text-align:center;" datepicker=true disabled>
    To<input type="text" id="payrollDateToE" style="width:235px;margin-left:10px;margin-right:10px;text-align:center;"  datepicker=true disabled>	
	</fieldset>	
	<div id="formSegment" style="width:640px;padding:0;border-radius:3px;margin:0;background:#F2F5FA;">

		<div id="formSegment">
			<label>Name</label>
			<input type="text" id="empNamePayE" disabled="disable">
			<label>Position</label>
			<input type="text" id="empPositionPayE" disabled="disable">
		</div>
		
		<div id="formSegment">
			<label>Employee No.</label>
			<input type="text" id="empNoPayE" disabled="disable">
			<label>Department</label>
			<input type="text" id="empDepartmentPayE" disabled="disable">
		</div>
	</div>
		
	<div id="formSegment">
	<fieldset style="border-radius:5px;padding-top:10px;padding:10px;">
	<legend style="background:#0A3694;font-size:14px;color:white;padding:4px;border-radius:5px;font-weigt:bold;">Earnings 
	<a href="javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/earningManager/index.php',570,630)">
	<img src="../../../../images/icons/select-icon.png" title="add other earnings"/>
	</a>
	</legend>
	<div style="height:225px;overflow:auto;">
	
		<label>Regular Pay</label>
		<input type="text" id="regularPayE" style="text-align:right;" disabled="disable" value='0.00'>
		<label>Hour Rate</label>
		<input type="text" id="hourRateE" style="text-align:right;" disabled="disable" value='0.00'>
			
	    <label>Hours Worked</label>
		<input type="text" id="hoursWorkedE" style="text-align:right;" disabled="disable" value='0.00'>
		
		<label>Minute Rate</label>
		<input type="text" id="minRateE" style="text-align:right;" disabled="disable" value='0.00'>

		<label>Minutes Worked</label>
		<input type="text" id="minsWorkedE" style="text-align:right;" disabled="disable" value='0.00'>
		
		<label>Overtime</label>
		<input type="text" id="overtimeE" style="text-align:right;" disabled="disable" value='0.00'>
			
		<label>Daily Rate</label>
		<input type="text" id="dailyRateE" style="text-align:right;" disabled="disable" value='0.00'>
			
		<label>Days Worked</label>
		<input type="text" id="daysWorkedE" style="text-align:right;" disabled="disable" value='0.00'>
			
		<label>Regular Holiday</label>
		<input type="text" id="regHolidayE" style="text-align:right;" value='0.00'>
			
		<label>Allowance</label>
		<input type="text" id="allowanceE" style="text-align:right;" value='0.00'>
		
		<div id="otherEarnEdit">
		</div>
	</div>
	</fieldset>
	<fieldset style="border-radius:5px;padding-top:10px;margin-top:5px;padding:10px;">
		<legend style="background:#0A3694;font-size:16px;color:white;padding:4px;border-radius:5px;font-weigt:bold;">Leave Details</legend>
		<div id="formDataCont" style="margin-bottom:5px;width:265px;" class='leaveEdit'>
		</div>
		<label>Leave Paid</label>
		<input type="text" id="leavePaidE" disabled="disable" style="text-align:right;" value='0.00'>
	</fieldset>
	</div>
	<div id="formSegment">
	<fieldset style="border-radius:5px;padding-top:10px;height:250px;padding:10px;">
		<legend style="background:#0A3694;font-size:14px;color:white;padding:4px;border-radius:5px;font-weigt:bold;">Deductions 
		<a href="javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/deductionManager/index.php',570,630)">
		<img src="../../../../images/icons/select-icon.png" title="add other deductions"/>
		</a>
		</legend>
		<label>Withholding Tax</label>
		<input type="text" id="withholdingTaxE" style="text-align:right;width:115px;" value='0' disabled>%
		<input type="checkbox" id="withholdingTaxECheck">
		<label>Cash Advance</label>
		<input type="text" id="cashAdvanceE" style="text-align:right;" value='0.00' disabled>
		<label>Company Loans</label>
		<input type="text" id="companyLoansE" style="text-align:right;" value='0.00'>
		<div id="otherDedEdit">
		</div>
	</fieldset>		
	</div>
	<div id="formSegment" class="totPay">
		<fieldset style="border-radius:5px;padding:10px;">
		<label>Total Earnings</label>
		<input type="text"  style="text-align:right;" id="totalEarningsE" disabled value='0.00'>
		
		<label>Total Deductions</label>
		<input type="text"  style="text-align:right;" id="totalDeductionsE" disabled value='0.00'>
		
		<label>Net Pay</label>
		<input type="text"  style="text-align:right;" id="netPayE" disabled value='0.00'>
		</fieldset>
		<div id="formSegment" class="buttonPanel" style="margin-top:30px;">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</div>
</div>

    <div id="restore_payroll" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>
	
	<div id="delete_schedule" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
	<div id="delete_payroll" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
	<div id="restore_personnel" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>

	<div id="delete_personnel" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
<div id="new_personnel" class="modalForm" w=700>
<div id="modalTitle">Employee Profile</div>
<div id="modalTabControl">
	<ul class="modalTabNav">
		<li id="modalTabList">
			<a href="#general" id="modalTabLink" class="modalTabActive">
			General
			</a>
		</li>
		<li id="modalTabList">
			<a href="#educationalBackground" id="modalTabLink">
			Educational Background
			</a>
		</li>
		<li id="modalTabList">
			<a href="#employmentInfo" id="modalTabLink">
			Employment Info
			</a>
		</li>
		<li id="modalTabList">
			<a href="#payrollInfo" id="modalTabLink">
			Payroll
			</a>
		</li>
		
</div>

<form method="POST" action="">
	<div id="general" class="modalFormTabCont"> 
		<div id="formSegment">
		
		<label>Employee Name <span>*</span></label>
		<input type="text" id="empFname" value="Firstname" title="Firstname">
		<label></label>
		<input type="text" id="empMname" value="Middle name" title="Middle name">
		<label><span>*</span></label>
		<input type="text" id="empLname" value="Lastname" title="Lastname">
		
		<label>Home Address <span>*</span></label>
		<textarea id="empAddress"></textarea>
		
		<label>Birthdate <span>*</span></label>
		<input type="text" id="empBday" datepicker="true">
		
		<label>Gender <span>*</span></label>
		<div id="radioCheckbox">
		<input type="radio" name="gender" id="male" class="empGender"><label for="radioCheckbox">Male</label>
		<input type="radio" name="gender" id="female" class="empGender"><label for="radioCheckbox">Female</label>
		</div>
		
		<label>Marital Status <span>*</span></label>
			<select id="empMaritalStatus">
			<option value="">...</option>
			<option value="single">Single</option>
			<option value="married">Married</option>
			<option value="widowed">Widowed</option>
			</select>
		</div>
		
		<div id="formSegment">
		<h5>Contact</h5>
			<label>Home Phone No. <span>*</span></label>
			<input type="text" id="homePhoneNumber">
			
			<label>Work Phone No. <span>*</span></label>
			<input type="text" id="workPhoneNumber">
			
		</div>
		
	</div>
	
	<div id="educationalBackground" class="modalFormTabCont"> 
	<div id="formSegment">
		<label>School Name  <span>*</span></label>
		<input type="text" id="schoolName">
		
		<label>Year Graduated  <span>*</span></label>
		<input type="number" id="yearGraduated">
		
	</div>
	
	<div id="formSegment">
		<label>Remarks</label>
		<textarea id="remarks" style="width:300px"></textarea>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" type="reset" id="clearDetailBtn">Clear</button>
		<button class="formButton" id="saveDetailBtn">Save</button>
		</div>
	</div>
	
	<div id="formSegment" style="width:650px">
		<div id="formDataCont" style="width:650px">
			<table>
				<th style='width:16px;padding:0;'></th>
				<th>School Name</th>
				<th>Year Graduated</th>
				<th>Remarks</th>
				
				
				<tbody id="educDetails">
					
				</tbody>
			</table>
		</div>
	</div>
	
	
	</div>
	
	<div id="employmentInfo" class="modalFormTabCont"> 
		<div id="formSegment">
		<label>Date Hired</label>
		<input type="text" id="dateHired" datepicker="true">
		
		<label>Department</label>
		<select id="department" disabled>
			<script>
			$.post("../../systemRecords/fileMaintenance/departmentManager/departmentManager.php",
				{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
						$("#department").html(response);
					}
				);
			</script>
		</select>
		
		<label>Position</label>
		<select id="position">
			<script>
			$.post("../../systemRecords/fileMaintenance/employeePositionManager/employeePositionManager.php",
				{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
						$("#position").html(response);
						
						$("#new_personnel select#position").change(function(){
							$.post("../../systemRecords/fileMaintenance/employeePositionManager/employeePositionManager.php",
							{role:"Search",posID:$(this).val()},
								function(response)
								{
									$("#department").val(response);
									
								});
						
						});
					}
				);
			</script>
		</select>
		
		<label>Employment Status</label>
		<select id="employmentStatus">
			<script>
			$.post("../../systemRecords/fileMaintenance/employeeStatusManager/employeeStatusManager.php",
				{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
						$("#employmentStatus").html(response);
					}
				);
			</script>
		</select>
		</div>
		
		<div id="formSegment" style="margin-top:-10px">
		<h5>Work Experience</h5>
		
		<label>Company Name</label>
		<input type="text" id="companyName">
		
		<label>Date Started</label>
		<input type="text" datepicker=true id="workExpFrom">
		
		<label>Date Ended</label>
		<input type="text" datepicker=true id="workExpTo">
		
		<label>Work Description</label>
		<textarea id="workDescription" style="min-height:30px"></textarea>
		
		
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" type="reset" id="clearDetailBtn">Clear</button>
		<button class="formButton" id="saveDetailBtn" >Save</button>
		</div>
		</div>
		
		<div id="formSegment" style="width:670px">
			
			<div id="formDataCont">
				<table>
				<th style='width:16px;padding:0;'></th>
				<th>Company Name</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Work Description</th>
				
				
				<tbody id="workDetails">
					
				</tbody>
			</table>
			</div>
		
		</div>
		
	</div>	
	
	<div id="payrollInfo" class="modalFormTabCont"> 
	
	<div id="formSegment">
	<label>Regular Salary <span>*</span></label>
	<input type="text" value="0.00" id="regSal">
	</div>
	
	
	<div id="formSegment">
	<h5>Others</h5>
	<label>SSS Number</label>
	<input type="text" id="sssNo">
	<label>PhilHealth Number</label>
	<input type="text" id="philHealthNo">
	<label>Tin Number</label>
	<input type="text" id="tinNo">
	<label>PagIbig Number</label>
	<input type="text" id="pagibigNo">
	</div>
	</div>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>
	
</form>
</div>


<div id="edit_personnel" class="modalForm" w=700>
<div id="modalTitle">Employee Profile</div>
<div id="modalTabControl">
<ul class="modalTabNav">
	<li id="modalTabList">
		<a href="#general" id="modalTabLink" class="modalTabActive">
		General
		</a>
	</li>
	
	<li id="modalTabList">
		<a href="#employmentInfo" id="modalTabLink">
		Employment Info
		</a>
	</li>
	<li id="modalTabList">
		<a href="#payrollInfo" id="modalTabLink">
		Payroll
		</a>
	</li>
	
</div>

<form method="POST" action="">
<div id="general" class="modalFormTabCont"> 
	<div id="formSegment">
	
	<label>Employee Name <span>*</span></label>
	<input type="text" id="empFname" value="Firstname" title="Firstname">
	<label></label>
	<input type="text" id="empMname" value="Middle name" title="Middle name">
	<label><span>*</span></label>
	<input type="text" id="empLname" value="Lastname" title="Lastname">
	
	<label>Employee Address</label>
	<textarea id="empAddress"></textarea>
	
	<label>Birthdate</label>
	<input type="text" id="editEmpBday" datepicker="true">
	
	<label>Gender</label>
	<div id="radioCheckbox">
	<input type="radio" name="gender" id="male" class="empGender"><label for="radioCheckbox">Male</label>
	<input type="radio" name="gender" id="female" class="empGender"><label for="radioCheckbox">Female</label>
	</div>
	
	<label>Marital Status</label>
		<select id="empMaritalStatus">
		<option value="">...</option>
		<option value="single">Single</option>
		<option value="married">Married</option>
		<option value="widowed">Widowed</option>
		</select>
	</div>
	
	<div id="formSegment">
	<h5>Contact</h5>
		<label>Home Phone Number</label>
		<input type="text" id="homePhoneNumber">
		
		<label>Work Phone Number</label>
		<input type="text" id="workPhoneNumber">
		
	</div>
	
</div>

<div id="employmentInfo" class="modalFormTabCont"> 
	<div id="formSegment">
	<label>Date Hired</label>
	<input type="text" id="editDateHired" datepicker="true">
	
	<label>Department</label>
	<select id="department" disabled>
		<script>
		$.post("../../systemRecords/fileMaintenance/departmentManager/departmentManager.php",
			{role:"VIEW",viewType:"comboBox"},
				function(response)
				{
					$("#edit_personnel #department").html(response);
				}
			);
		</script>
	</select>
	
	<label>Position</label>
	<select id="position">
		<script>
		$.post("../../systemRecords/fileMaintenance/employeePositionManager/employeePositionManager.php",
			{role:"VIEW",viewType:"comboBox"},
				function(response)
				{
					$("#edit_personnel #position").html(response);
					
					$("#edit_personnel select#position").change(function(){
						$.post("../../systemRecords/fileMaintenance/employeePositionManager/employeePositionManager.php",
						{role:"Search",posID:$(this).val()},
							function(response)
							{
								$("#department").val(response);
								
							});
					
					});
				}
			);
		</script>
	</select>
	
	<label>Employment Status</label>
	<select id="employmentStatus">
		<script>
		$.post("../../systemRecords/fileMaintenance/employeeStatusManager/employeeStatusManager.php",
			{role:"VIEW",viewType:"comboBox"},
				function(response)
				{
					$("#edit_personnel #employmentStatus").html(response);
				}
			);
		</script>
	</select>
	</div>
	
</div>	

<div id="payrollInfo" class="modalFormTabCont"> 

<div id="formSegment">
<label>Regular Salary <span>*</span></label>
<input type="text" value="0.00" id="regSal">
</div>


<div id="formSegment">
<h5>Others</h5>
<label>SSS Number</label>
<input type="text" id="sssNo">
<label>PhilHealth Number</label>
<input type="text" id="philHealthNo">
<label>Tin Number</label>
<input type="text" id="tinNo">
<label>PagIbig Number</label>
<input type="text" id="pagibigNo">
</div>
</div>

<div id="formSegment" class="buttonPanel">
<button class="formButton" id="cancel">Cancel</button>
<button class="formButton" id="save">Save</button>
</div>

</form>
</div>


<div id="new_workExp" class="modalForm" w=700>
<div id="modalTitle">Work Experience</div>
<div id="formSegment" style="width:670px">
<div id="formSegment">
	
	<label>Company Name</label>
	<input type="text" id="companyName">
	
	<label>Date Started</label>
	<input type="text" datepicker=true id="newWorkExpFrom">
	
	<label>Date Ended</label>
	<input type="text" datepicker=true id="newWorkExpTo">
	
	<label>Work Description</label>
	<textarea id="workDescription" style="min-height:30px"></textarea>
	
	
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton">Cancel</button>
	<button class="formButton" id="saveDetailBtn">Save</button>
	</div>
	</div>
	
	<div id="formSegment"  style="width:300px">
		
		<div id="formDataCont" style="width:350px">
			<table>
			<th></th>
			<th>Company Name</th>
			<th>Start Date</th>
			<th>End Date</th>
			<th>Work Description</th>
			
			
			<tbody id="workDetails">
				
			</tbody>
		</table>
		</div>
	
	</div>
</div>
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>

</div>

<div id="delete_workExp" class="modalForm" w=350>
<h5>Are you sure you want to delete this record?</h5>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Delete</button>
	</div>
</div>
<div id="restore_workExp" class="modalForm" w=350>
<h5>Are you sure you want to restore this record?</h5>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Restore</button>
	</div>
</div>


<div id="delete_educBackground" class="modalForm" w=350>
<h5>Are you sure you want to delete this record?</h5>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Delete</button>
	</div>
</div>
<div id="restore_educBackground" class="modalForm" w=350>
<h5>Are you sure you want to restore this record?</h5>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Restore</button>
	</div>
</div>


<div id="edit_workExp" class="modalForm" w=300>
<div id="modalTitle">Work Experience</div>
<div id="formSegment">
	
	<label>Company Name</label>
	<input type="text" id="companyName" disabled>
	
	<label>Date Started</label>
	<input type="text" datepicker=true id="updateWorkExpFrom" disabled>
	
	<label>Date Ended</label>
	<input type="text" datepicker=true id="updateWorkExpTo" disabled>
	
	<label>Work Description</label>
	<textarea id="workDescription" style="min-height:30px" disabled></textarea>
	
	
</div>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>

</div>

<div id="new_fileLeave" class="modalForm" w=300>
<div id="modalTitle">File Leave</div>
<div id="formSegment">
	<label>Name</label>
	<input type="text" id="empName" disabled>
	
	<label>Leave Type</label>
	<select id="leaveType">
		<script>
			
			$.post("/ebms/apps/view/systemRecords/fileMaintenance/employeeLeaveManager/employeeLeaveManager.php",
				{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#leaveType").html(response);
						$("#leaveType").change(function(){
							$("#maxDays").val($(this).find("option:selected").attr("maxDays"));
						});
					});
		</script>
	</select>
	
	<label>Maximum Days</label>
	<input type="text" id="maxDays" disabled>
	
	<label>Date From</label>
	<input type="text" datepicker=true id="dateFrom">
	
	<label>Date To</label>
	<input type="text" datepicker=true id="dateTo">
	

	
</div>

<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>
</div>

<div id="edit_fileLeave" class="modalForm" w=300>
<div id="modalTitle">File Leave</div>
<div id="formSegment">
	<label>Name</label>
	<input type="text" id="empName" disabled>
	
	<label>Leave</label>
	<select id="leaveType">
		<script>
			
			$.post("/ebms/apps/view/systemRecords/fileMaintenance/employeeLeaveManager/employeeLeaveManager.php",
				{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#edit_fileLeave #leaveType").html(response);
						$("#leaveType").change(function(){
							$("#maxDays").val($(this).find("option:selected").attr("maxDays"));
						});
					});
		</script>
	</select>
	
	<label>Maximum Days</label>
	<input type="text" id="maxDays" disabled>
	
	<label>Date From</label>
	<input type="text" datepicker=true id="editDateFrom">
	
	<label>Date To</label>
	<input type="text" datepicker=true id="editDateTo">
	

	
</div>

<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>
</div>

<div id="delete_fileLeave" class="modalForm" w=350>
	<h5>Are you sure you want to delete this record?</h5>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>

<div id="restore_fileLeave" class="modalForm" w=350>
	<h5>Are you sure you want to restore this record?</h5>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
		</div>
</div>

<div id="new_fileOvertime" class="modalForm" w=300>
<div id="modalTitle">File Overtime</div>
<div id="formSegment">
	<label>Name</label>
	<input type="text" id="empName" disabled>
	
	<label>Overtime Date</label>
	<input type="text" datepicker=true id="overtimeDate">
	
	<label>Overtime :</label>
	<div class="timepicker">
	<input type="text" id="overtimeHours" timepickerHour=true value="0 hours" disabled>
	<div class="sliderHour"></div>
	</div>
	
	<div class="colon">:</div>
	
	<div class="timepicker">
	<input type="text" id="overtimeMinutes" timepickerMinute=true value="0 minutes" disabled>
	<div class="sliderMinute">
	</div>
	</div>

	
</div>

<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>
</div>

<div id="edit_fileOvertime" class="modalForm" w=300>
<div id="modalTitle">File Overtime</div>
<div id="formSegment">
	<label>Name</label>
	<input type="text" id="empName" disabled>
	
	<label>Overtime Date</label>
	<input type="text" datepicker=true id="editOvertimeDate">
	
	<label>Overtime :</label>
	<div class="timepicker">
	<input type="text" id="editOvertimeHours" timepickerHour=true value="0 hours" disabled>
	<div class="sliderHour"></div>
	</div>
	
	<div class="colon">:</div>
	
	<div class="timepicker">
	<input type="text" id="editOvertimeMinutes" timepickerMinute=true value="0 minutes" disabled>
	<div class="sliderMinute">
	</div>
	</div>

	
</div>

<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>
</div>


<div id="delete_fileOvertime" class="modalForm" w=350>
<h5>Are you sure you want to delete this record?</h5>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Delete</button>
	</div>
</div>
<div id="restore_fileOvertime" class="modalForm" w=350>
<h5>Are you sure you want to restore this record?</h5>
	
	<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Restore</button>
	</div>
</div>


<div id="new_educBackground" class="modalForm" w=700>
<div id="modalTitle">Educational Background</div>
<div id="formSegment" style="width:100%">
<div id="formSegment">
	<label>School Name</label>
	<input type="text" id="schoolName">
	
	<label>Year Graduated</label>
	<input type="number" id="yearGraduated">
	
	<label>Remarks</label>
	<textarea id="remarks"></textarea>
	<div id="formSegment" class="buttonPanel">
	<button class="formButton">Cancel</button>
	<button class="formButton" id="saveDetailBtn">Save</button>
	</div>
</div>

<div id="formSegment" style="width:350px">
	<div id="formDataCont" style="width:350px">
		<table>
			<th></th>
			<th>School Name</th>
			<th>Year Graduated</th>
			<th>Remarks</th>
			
			
			<tbody id="educDetails">
				
			</tbody>
		</table>
	</div>
</div>
	
	<div id="formSegment" style="width:690px" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
	</div>
</div>
</div>

<div id="edit_educBackground" class="modalForm" w=300>
	<div id="modalTitle">Educational Background</div>
<div id="formSegment">
<h5>Educational Background</h5>
	<label>School Name</label>
	<input type="text" id="schoolName" disabled>
	
	<label>Year Graduated</label>
	<input type="number" id="yearGraduated" disabled>
	
</div>

<div id="formSegment">
	<label>Remarks</label>
	<textarea id="remarks" style="width:270px" disabled></textarea>
</div>

<div id="formSegment" class="buttonPanel">
	<button class="formButton" id="cancel">Cancel</button>
	<button class="formButton" id="save">Save</button>
</div>
</div>

