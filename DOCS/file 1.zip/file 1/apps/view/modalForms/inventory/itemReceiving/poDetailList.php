<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$hdrId = @$_POST['hdrId'];
	
	$query = mysql_query("Select PO_DTL_QTY as 'qty',
								ITEM_CODE as 'code',
								PO_DTL_ITEM_DESCRIPTION as 'desc',
								PRODUCT_IMAGE as 'img'
						  From product P, po_header PH, po_detail PD
						  Where PH.PO_HDR_ID = '" . $hdrId . "' and
								P.PRODUCT_CODE = PD.ITEM_CODE and 
								PH.PO_HDR_ID = PD.PO_HDR_ID");	
								
	if (mysql_num_rows($query) > 0)					
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<li id='gridViewList'> 
							<a href='#' id='gridViewLink' qty='" . $arr[0] . "' itemCode='" . $arr[1] . "' desc='" . $arr[2] . "'>
								<div id='itemMenu'>
									<button class='addItem' title='Add Item'>✚</button>
									<button class='removeItem' title='Remove Item'>✖</button>
									<button class='selectedItem' title='Selected Item'>✔</button>
								</div>
								<img src='/ebms/images/stock/".(($arr['img']=='')?'default.png':$arr['img'])."'>
							</a>
							</li>";
		}
	}
	else 
	{
		$outputData = "No items found";
	}
	
	echo $outputData;
?>