<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	$ref = @$_POST['ref'];
	$remarks = @$_POST['remarks'];
	$contactId = @$_POST['contactId'];
	
	$maxId = 0;
	$zeros = "000000";
	$year = "";
	
	$query = mysql_query("Select max(REC_HDR_ID) From receiving_header");
	while ($arr = mysql_fetch_array($query))
	{
		$maxId = $arr[0];
	}
	
	$maxId += 1;
	
	$query = mysql_query("Select year(curdate())");
	while ($arr = mysql_fetch_array($query))
	{
		$year = $arr[0];
	}
	
	$recHdrNo = "REC-" . $year . "-" . substr($zeros, 0, strlen($zeros) - strlen($maxId)) . $maxId;
	
	$refType = "";
	$refNo = "";
	$receivedFrom = 0;
	
	if ($ref == "PO")
	{
		$refType = "Supplier";
		
		$query = mysql_query("Select PO_HDR_NO From po_header Where PO_HDR_ID = '" . $id . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$refNo = $arr[0];
		}
		
		$query = mysql_query("Select SUPPLIER_CODE From supplier_profile SP, po_header PH Where SP.SUPPLIER_ID = PH.SUPPLIER_ID and PO_HDR_ID = '" . $id . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$receivedFrom = $arr[0];
		}
	}
	else if ($ref == "WD")
	{
		$query = mysql_query("Select WITH_HDR_NO, WITH_HDR_TYPE, WITH_HDR_ISSUED_TO From withdrawal_header WHere WITH_HDR_ID = '" . $id . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$refNo = $arr[0];
			$refType = $arr[1];
			$receivedFrom = $arr[2];
		}
	}
	
	$query = mysql_query("Insert Into receiving_header(REC_HDR_NO, REC_HDR_DATE, REC_HDR_RECEIVED_REF_TYPE, REC_HDR_RECEIVED_REF_NO, REC_HDR_RECEIVED_REF, REC_HDR_REMARKS, 
							REC_HDR_RECEIVED_FROM, IS_DELETED, CONTACT_ID) Values('" .
								$recHdrNo . "', " . 
								"curdate()" . ", '" . 
								$refType . "', '" .
								$refNo . "', '" .
								$ref . "', '" . 
								$remarks . "', '" .
								$receivedFrom . "', '" .
								"0" . "', '" . 
								$contactId . "')") or die(mysql_error());
	
	// echo $contactId;	
?>