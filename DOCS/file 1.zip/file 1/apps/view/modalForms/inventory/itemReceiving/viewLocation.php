<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	
	$type = "";
	$receivedFrom = "";
	$customerId = 0;
	
	$query = mysql_query("Select * From receiving_header Where REC_HDR_ID = '" . $id . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$type = $arr['REC_HDR_RECEIVED_REF_TYPE'];
		$receivedFrom = $arr['REC_HDR_RECEIVED_FROM'];
	}
	
	if ($type == "Customer")
	{	
		$query = mysql_query("Select * From customer_profile Where CUSTOMER_CODE = '" . $receivedFrom . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$customerId = $arr['CUSTOMER_ID'];
		}
	
		$query = mysql_query("Select LOCATION_NAME From location Where CUSTOMER_ID = '"  . $customerId . "' and FLAG = 'C'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr[0];
		}
	}
	else if ($type == "Employee")
	{
		$outputData = "N/A";
	}
	else if ($type == "Supplier")
	{
		$query = mysql_query("Select * From supplier_profile Where SUPPLIER_CODE = '" . $receivedFrom . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$customerId = $arr['SUPPLIER_ID'];
		}
	
		$query = mysql_query("Select LOCATION_NAME From location Where CUSTOMER_ID = '"  . $customerId . "' and FLAG = 'S'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr[0];
		}
	}
	
	echo $outputData;
?>