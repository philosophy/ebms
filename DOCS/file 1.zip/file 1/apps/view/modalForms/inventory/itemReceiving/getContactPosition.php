<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$contactId = $_POST['contactId'];
	
	$query = mysql_query("Select * From contact Where CONTACT_ID = '" . $contactId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr['CONTACT_JOB_TITLE'];
	}
	
	echo $outputData;
?>