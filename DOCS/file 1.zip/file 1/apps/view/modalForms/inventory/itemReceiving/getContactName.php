<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$locationId = $_POST['locationId'];
	
	$query = mysql_query("Select CONTACT_NAME, CONTACT_ID From contact Where LOCATION_ID = '" . $locationId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData .= "<option value='" . $arr[1] . "'>" . $arr[0] . "</option>";
	}
	
	echo $outputData;
?>