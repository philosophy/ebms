<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	
	$query = mysql_query("Select * From receiving_header Where REC_HDR_ID = '" . $id . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr['REC_HDR_REMARKS'];
	}
	
	echo $outputData;
?>	