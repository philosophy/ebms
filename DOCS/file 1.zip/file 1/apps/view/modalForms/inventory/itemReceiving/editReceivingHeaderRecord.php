<?php
	include("../../../../../config/config.php");
	
	$id = @$_POST['id'];
	$remarks = @$_POST['remarks'];
	
	$query = mysql_query("Update receiving_header Set REC_HDR_REMARKS = '" . $remarks . "' Where REC_HDR_ID = '" . $id . "'");
?>