<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$qty = @$_POST['qty'];
	$itemCode = @$_POST['itemCode'];
	
	$currentStock = 0;
	
	$query = mysql_query("Select * From product Where PRODUCT_CODE = '" . $itemCode. "'");
	while ($arr = mysql_fetch_array($query))
	{
		$currentStock = $arr['PRODUCT_QTY'];
	}
	
	$newStock = $currentStock + $qty;
	
	$query = mysql_query("Update product Set PRODUCT_QTY = '" . $newStock . "' Where PRODUCT_CODE = '" . $itemCode . "'") or die(mysql_error());
	
	echo $newStock;
?>