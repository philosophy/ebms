<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$qty = @$_POST['qty'];
	$itemCode = @$_POST['itemCode'];
	$from = @$_POST['from'];
	$id = @$_POST['id'];
	
	$currentStock = 0;
	
	if ($from == "PO")
	{
		$query = mysql_query("Select * From po_detail Where PO_HDR_ID = '" . $id . "' and ITEM_CODE = '" . $itemCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$currentStock = $arr['PO_DTL_QTY'];
		}
		
		$newStock = $currentStock - $qty;
		
		$query = mysql_query("Update po_detail Set PO_DTL_QTY = '" . $newStock . "' Where PO_HDR_ID = '" . $id . "' and ITEM_CODE = '" . $itemCode . "'");
		
		if ($newStock == 0)
		{
			$query = mysql_query("Update po_detail Set IS_RECEIVED = '2' Where PO_HDR_ID = '" . $id . "' and ITEM_CODE = '" . $itemCode . "'");
			// $query = mysql_query("Update po_header Set IS_RECEIVED = '2' Where PO_HDR_ID = '" . $id . "'");
		}
		else if ($newStock > 0)
		{
			$query = mysql_query("Update po_detail Set IS_RECEIVED = '1' Where PO_HDR_ID = '" . $id . "' and ITEM_CODE = '" . $itemCode . "'");	
			// $query = mysql_query("Update po_header Set IS_RECEIVED = '1' Where PO_HDR_ID = '" . $id . "'");
		}
		
		$query = mysql_query("Select count(*) From po_detail Where PO_HDR_ID = '" . $id . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$rowCount = $arr[0];
		}
		
		$toKnowFully = $rowCount * 2;
		
		$query = mysql_query("Select sum(IS_RECEIVED) From po_detail Where PO_HDR_ID = '" . $id . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$comparator = $arr[0];
		}
		
		if ($toKnowFully == $comparator)
		{
			$query = mysql_query("Update po_header Set IS_RECEIVED = '2' Where PO_HDR_ID = '" . $id . "'");
		}
		else if ($comparator > 0 && $comparator < $toKnowFully)
		{
			$query = mysql_query("Update po_header Set IS_RECEIVED = '1' Where PO_HDR_ID = '" . $id . "'");
		}
	}
	else if ($from == "WD")
	{
		$query = mysql_query("Select * From withdrawal_detail Where WITH_HDR_ID = '" . $id . "' and ITEM_CODE = '" . $itemCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$currentStock = $arr['WITH_DTL_QTY'];
		}
		
		$newStock = $currentStock - $qty;
		
		$query = mysql_query("Update withdrawal_detail Set WITH_DTL_QTY = '" . $newStock . "' Where WITH_HDR_ID = '" . $id . "' and ITEM_CODE = '" . $itemCode . "'");
	}
	
	// echo $newStock . " = " . $currentStock . " - " . $qty . " of " . $itemCode;
	echo $toKnowFully;
	echo $comparator;
?>