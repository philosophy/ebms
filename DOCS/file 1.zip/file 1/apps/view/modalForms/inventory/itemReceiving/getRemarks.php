<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$withHdrId = $_POST['withHdrId'];
	$from = $_POST['from'];
	
	if ($from == "WD")
	{
		$query = mysql_query("Select * From withdrawal_header Where WITH_HDR_ID = '" . $withHdrId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr['WITH_HDR_REMARKS'];
		}
	}
	else if ($from == "PO")
	{
		$query = mysql_query("Select * From po_header Where PO_HDR_ID = '" . $withHdrId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr['PO_HDR_REMARKS'];
		}
	}
	
	echo $outputData;
?>