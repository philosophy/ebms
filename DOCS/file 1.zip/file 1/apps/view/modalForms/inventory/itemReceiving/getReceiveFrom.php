<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$withHdrId = $_POST['withHdrId'];
	$from = $_POST['from'];
	
	$code = "";
	$type = "";
	
	if ($from == "WD")
	{
		$query = mysql_query("Select * From withdrawal_header Where WITH_HDR_ID = '" . $withHdrId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$type = $arr['WITH_HDR_TYPE'];
			$code = $arr['WITH_HDR_ISSUED_TO'];
		}
		
		if ($type == "Customer")
		{
			$query = mysql_query("Select CUSTOMER_NAME From customer_profile Where CUSTOMER_CODE = '" . $code . "'");
			while ($arr = mysql_fetch_array($query))
			{
				$outputData = $arr[0];
			}
		}
		else if ($type == "Employee")
		{
			$query = mysql_query("Select concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME) From employee_profile Where EMP_CODE = '" . $code . "'");
			while ($arr = mysql_fetch_array($query))
			{
				$outputData = $arr[0];
			}
		}
		else if ($type == "Supplier")
		{
			$query = mysql_query("Select SUPPLIER_NAME From supplier_profile Where SUPPLIER_CODE = '" . $code . "'");
			while ($arr = mysql_fetch_array($query))
			{
				$outputData = $arr[0];
			}
		}
	}
	else if ($from == "PO")
	{
		$query = mysql_query("Select * From po_header Where PO_HDR_ID = '" . $withHdrId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$code = $arr['SUPPLIER_ID'];
		}
		
		$query = mysql_query("Select SUPPLIER_NAME From supplier_profile Where SUPPLIER_ID = '" . $code . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr[0];
		}
	}
	
	echo $outputData;
?>