<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$id = @$_POST['id'];
	$type = @$_POST['type'];
	
	$contactId = 0;
	
	$query = mysql_query("Select * From receiving_header Where REC_HDR_ID = '" . $id . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$contactId = $arr['CONTACT_ID'];
	}
	
	if ($type == "Customer")
	{
		$query = mysql_query("Select * From contact Where CONTACT_ID = '" . $contactId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr['CONTACT_NAME'];
		}
	}
	else if ($type == "Employee" || $type == "Supplier")
	{
		$outputData = "N/A";
	}
	else
	{
		$outputData = "N";
	}
	
	echo $outputData;
?>