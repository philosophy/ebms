<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$qty = @$_POST['qty'];
	$itemCode = @$_POST['itemCode'];
	$desc = @$_POST['desc'];
	$from = @$_POST['from'];
	
	$latestRecHdrId = 0;
	$unitId = 0;
	
	if ($from == "WD")
	{
		$query = mysql_query("Select UNIT_ID From product Where PRODUCT_CODE = '" . $itemCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$unitId = $arr[0];
		}
	}
	else if ($from == "PO")
	{
		$query = mysql_query("Select UNIT_ID From product Where PRODUCT_CODE = '" . $itemCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$unitId = $arr[0];
		}
	}
	
	$query = mysql_query("Select max(REC_HDR_ID) From receiving_header");
	while ($arr = mysql_fetch_array($query))
	{
		$latestRecHdrId = $arr[0];
	}
	
	$query = mysql_query("Insert Into receiving_detail(REC_DTL_QTY, REC_DTL_ITEM_DESCRIPTION, REC_HDR_ID, UNIT_ID, ITEM_CODE) Values('" . 
								$qty . "', '" . 
								$desc . "', '" . 
								$latestRecHdrId . "', '" . 
								$unitId . "', '" . 
								$itemCode . "')") or die(mysql_error());
							
	// $outputData = $qty . " " . $desc . " " . $latestRecHdrId . " " . $unitId . " " . $itemCode;
	$outputData = $unitId;
?>