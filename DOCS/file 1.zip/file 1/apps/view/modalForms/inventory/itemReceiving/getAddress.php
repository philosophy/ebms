<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$withHdrId = $_POST['withHdrId'];
	$from = $_POST['from'];
	
	$type = "";
	$code = "";
	$locationId = "";
	
	if ($from == "WD")
	{
		$query = mysql_query("Select * From withdrawal_header Where WITH_HDR_ID = '" . $withHdrId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$type = $arr['WITH_HDR_TYPE'];
			$code = $arr['WITH_HDR_ISSUED_TO'];
			$locationId = $arr['LOCATION_ID'];
		}
		
		if ($type == "Customer")
		{
			$query = mysql_query("Select LOCATION_ADDRESS From location Where LOCATION_ID = '" . $locationId . "'");
			while ($arr = mysql_fetch_array($query))
			{
				$outputData = $arr[0];
			}
		}
		else if ($type == "Employee")
		{
			$query = mysql_query("Select EMP_ADDRESS From employee_profile Where EMP_CODE = '" . $code . "'");
			while ($arr = mysql_fetch_array($query))
			{
				$outputData = $arr[0];
			}
		}
		else if ($type == "Supplier")
		{
			$outputData = "Undecided";
		}
	}
	else if ($from == "PO")
	{
		$outputData = "Undecided";
	}
	
	echo $outputData;
?>