<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$type = $_POST['type'];
	
	if ($type == "PO")
	{
		$query = mysql_query("Select PO_HDR_ID, PO_HDR_NO,
								concat(monthname(PO_HDR_DATE_REQUESTED), ' ', day(PO_HDR_DATE_REQUESTED), ', ', year(PO_HDR_DATE_REQUESTED)),
								PO_HDR_PAYMENT_TYPE, PO_HDR_CONTACT_NAME, PO_HDR_NET_AMOUNT
							  From po_header");
		if (mysql_num_rows($query) > 0)
		{
			while ($arrResult = mysql_fetch_array($query))
			{
				$outputData .= "<tr a='".$arrResult[0]."'>";
				$outputData .=	"<td>".$arrResult[1]."</td>";
				$outputData .=	"<td>".$arrResult[2]."</td>";
				$outputData .=	"<td>".$arrResult[3]."</td>";
				$outputData .=	"<td>".$arrResult[4]."</td>";
				$outputData .=	"<td>".$arrResult[5]."</td>";
				$outputData .= "</tr>";
			}
		}							  
	}
	else if ($type == "WD")
	{	
		$query = mysql_query("Select WITH_HDR_ID, WITH_HDR_NO,
								concat(monthname(WITH_HDR_DATE_ISSUED), ' ', day(WITH_HDR_DATE_ISSUED), ', ', year(WITH_HDR_DATE_ISSUED)),
								WITH_HDR_PURPOSE,
								ifnull(CUSTOMER_NAME, ifnull(concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME), SUPPLIER_NAME)) as 'Name',
								WITH_HDR_TYPE
							  From withdrawal_header WH
									left outer join employee_profile E on WH.WITH_HDR_ISSUED_TO = E.EMP_CODE
									left outer join customer_profile C on WH.WITH_HDR_ISSUED_TO = C.CUSTOMER_CODE
									left outer join supplier_profile S on WH.WITH_HDR_ISSUED_TO = S.SUPPLIER_CODE");
		if (mysql_num_rows($query) > 0)
		{
			while ($arrResult = mysql_fetch_array($query))
			{
				$outputData .= "<tr a='".$arrResult['WITH_HDR_ID']."'>";
				$outputData .=	"<td>".$arrResult['WITH_HDR_NO']."</td>";
				$outputData .=	"<td>".$arrResult[2]."</td>";
				$outputData .=	"<td>".$arrResult['WITH_HDR_PURPOSE']."</td>";
				$outputData .=	"<td>".$arrResult['Name']."</td>";
				$outputData .=	"<td>".$arrResult['WITH_HDR_TYPE']."</td>";
				$outputData .= "</tr>";
			}
		}		
	}
	
	echo $outputData;
?>