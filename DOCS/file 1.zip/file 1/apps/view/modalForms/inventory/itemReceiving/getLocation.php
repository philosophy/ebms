<?php
	include("../../../../../config/config.php");
	
	$outputData = "";
	
	$withHdrId = $_POST['withHdrId'];
	$from = $_POST['from'];
	
	$type = "";
	$locationId = "";
	
	if ($from == "WD")
	{
		$query = mysql_query("Select WITH_HDR_TYPE, LOCATION_ID From withdrawal_header Where WITH_HDR_ID = '" . $withHdrId . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$type = $arr['WITH_HDR_TYPE'];
			$locationId = $arr['LOCATION_ID'];
		}
		
		if ($type == "Employee")
		{
			$outputData = $locationId . "&&N/A";
		}
		else if ($type == "Customer")
		{
			$query = mysql_query("Select LOCATION_NAME From location Where LOCATION_ID = '" . $locationId . "'");
			while ($arr = mysql_fetch_array($query))
			{
				$outputData = $locationId . "&&" . $arr[0];
			}
		}
		else if ($type == "Supplier")
		{
			$outputData = $locationId . "&&Undecided";
		}
	}
	else if ($from == "PO")
	{
		$outputData = $locationId . "&&N/A";
	}
	
	echo $outputData;
?>