<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withId = $_POST['id'];
	
	$locationId = 0;
	
	$query = mysql_query("Select LOCATION_ID From withdrawal_header Where WITH_HDR_ID = '" . $withId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$locationId = $arr[0];
	}
	
	$query = mysql_query("Select AREA_NAME 
							From area A, location L 
							Where L.AREA_ID = A.AREA_ID and 
								LOCATION_ID = '" . $locationId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	echo $outputData;
?>