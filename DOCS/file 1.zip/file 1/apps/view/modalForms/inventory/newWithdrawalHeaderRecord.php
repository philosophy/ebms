<?php
	session_start();
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$issuedBy = $_SESSION['login'];
	
	$type = $_POST['type'];
	$purpose = $_POST['purpose'];
	$remarks = $_POST['remarks'];
	$issuedTo = $_POST['issuedTo'];
	
	if ($type == "Customer")
	{
		$location = $_POST['location'];
	}
	
	$maxId = 0;
	$zeros = "000000";
	
	$query = mysql_query("Select max(WITH_HDR_ID) From withdrawal_header");
	while ($arr = mysql_fetch_array($query))
	{
		$maxId = $arr[0];
	}
	
	$maxId += 1;
	$year = "";
	
	$query = mysql_query("Select YEAR(CURDATE())");
	while ($arr = mysql_fetch_array($query))
	{
		$year = $arr[0];
	}
	
	$withHdrNo = "WITH-" . $year . "-" . substr($zeros, 0, strlen($zeros) - strlen($maxId)) . $maxId;
	
	if ($type == "Customer")
	{
		$query = mysql_query("Insert Into withdrawal_header(WITH_HDR_NO, WITH_HDR_DATE_ISSUED, WITH_HDR_TYPE, WITH_HDR_PURPOSE, WITH_HDR_REMARKS, IS_DELETED, 
								WITH_HDR_ISSUED_BY_ID, WITH_HDR_ISSUED_TO, LOCATION_ID) VALUES('" . 
									$withHdrNo . "', " .
									"curdate()" . ", '" .
									$type . "', '" . 
									$purpose . "', '" .
									$remarks . "', '" .
									"0" . "', '" .
									$issuedBy . "', '" .
									$issuedTo . "', '" .
									$location . "')") or die(mysql_error());	
	}								
	else if ($type == "Employee")
	{
		$query = mysql_query("Insert Into withdrawal_header(WITH_HDR_NO, WITH_HDR_DATE_ISSUED, WITH_HDR_TYPE, WITH_HDR_PURPOSE, WITH_HDR_REMARKS, IS_DELETED, 
								WITH_HDR_ISSUED_BY_ID, WITH_HDR_ISSUED_TO) VALUES('" . 
									$withHdrNo . "', " .
									"curdate()" . ", '" .
									$type . "', '" . 
									$purpose . "', '" .
									$remarks . "', '" .
									"0" . "', '" .
									$issuedBy . "', '" .
									$issuedTo . "')") or die(mysql_error());	
	}
	else if ($type == "Supplier")
	{
		$query = mysql_query("Insert Into withdrawal_header(WITH_HDR_NO, WITH_HDR_DATE_ISSUED, WITH_HDR_TYPE, WITH_HDR_PURPOSE, WITH_HDR_REMARKS, IS_DELETED, 
								WITH_HDR_ISSUED_BY_ID, WITH_HDR_ISSUED_TO) VALUES('" . 
									$withHdrNo . "', " .
									"curdate()" . ", '" .
									$type . "', '" . 
									$purpose . "', '" .
									$remarks . "', '" .
									"0" . "', '" .
									$issuedBy . "', '" .
									$issuedTo . "')") or die(mysql_error());	
	}
	
	//$query = mysql_query("Insert Into audit_trail Values(curdate(), curtime(), 'Withdrawal record created.', '" . $_SESSION['emp_id'] . "')") or die(mysql_error());
	
	$query = mysql_query("Select max(WITH_HDR_ID) From withdrawal_header");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	echo $outputData;
?>