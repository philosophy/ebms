<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$code = $_POST['code'];
	$type = $_POST['type'];
	
	$custId = 0;
	
	if ($type == "Customer")
	{
		$query = mysql_query("Select * From customer_profile Where CUSTOMER_CODE = '" . $code . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$custId = $arr['CUSTOMER_ID'];
		}
		
		$query = mysql_query("Select LOCATION_ID, LOCATION_NAME
								From location L, customer_profile CP 
								Where L.CUSTOMER_ID = CP.CUSTOMER_ID and
									CP.CUSTOMER_ID = '" . $custId . "' and 
									L.IS_DELETED = 0");
	}	
	
	if (mysql_num_rows($query) > 0)
	{
		while ($arr = mysql_fetch_array($query))
		{
			$outputData .= "<option value='" . $arr['LOCATION_ID'] . "'>" . $arr['LOCATION_NAME'] . "</option>";
		}
	}
	else
	{
		$outputData = "<option value=''>No record found</option>";
	}
	
	echo $outputData;
?>