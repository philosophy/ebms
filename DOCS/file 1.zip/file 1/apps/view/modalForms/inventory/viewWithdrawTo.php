<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withId = $_POST['id'];
	
	$withdrawToCode = "";
	$withdrawToType = "";
	
	$query = mysql_query("Select WITH_HDR_ISSUED_TO, WITH_HDR_TYPE From withdrawal_header Where WITH_HDR_ID = '" . $withId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$withdrawToCode = $arr[0];
		$withdrawToType = $arr[1];
	}
	
	if ($withdrawToType == "Customer")
	{
		$query = mysql_query("Select CUSTOMER_NAME From customer_profile Where CUSTOMER_CODE = '" . $withdrawToCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr[0];
		}
	}
	else if ($withdrawToType == "Employee")
	{
		$query = mysql_query("Select concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME) From employee_profile Where EMP_CODE = '" . $withdrawToCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr[0];
		}
	}
	else if ($withdrawToType == "Supplier")
	{
		$query = mysql_query("Select SUPPLIER_NAME From supplier_profile Where SUPPLIER_CODE = '" . $withdrawToCode . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$outputData = $arr[0];
		}
	}
	
	echo $outputData;
?>