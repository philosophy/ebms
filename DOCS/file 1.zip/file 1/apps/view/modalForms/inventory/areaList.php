<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$barangayId = $_POST['barangayId'];
	
	if ($barangayId != "")
	{
		$query = mysql_query("Select A.AREA_ID, AREA_NAME 
								From area A, location L 
								Where L.AREA_ID = A.AREA_ID and 
									L.BARANGAY_ID = '" . $barangayId . "' and 
									A.IS_DELETED = 0");
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<option value = '" . $arr['AREA_ID'] . "'>" . $arr['AREA_NAME'] . "</option>";
			}
		}
		else
		{
			$outputData = "<option value = ''> No record found </option>";
		}
		
		echo $outputData;
	}
?>