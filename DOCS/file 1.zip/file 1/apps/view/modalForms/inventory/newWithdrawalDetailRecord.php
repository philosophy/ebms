<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$qty = $_POST['qty'];
	$desc = $_POST['desc'];
	$itemCode = $_POST['itemCode'];
	
	$latestWithHdrId = @$_POST['hdrId'];
	$unitId = 0;
	
	$query = mysql_query("Select UNIT_ID From product Where PRODUCT_CODE = '" . $itemCode . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$unitId = $arr[0];
	}	
	
	mysql_query("Insert Into withdrawal_detail(WITH_DTL_QTY, WITH_DTL_ORIGINAL_QTY, WITH_DTL_ITEM_DESCRIPTION, WITH_HDR_ID, UNIT_ID, ITEM_CODE) Values('" . 
							$qty . "', '" .
							$qty . "', '" .
							$desc . "', '" . 
							$latestWithHdrId . "', '" . 
							$unitId . "', '" . 
							$itemCode . "')") or die(mysql_error());
	$outputData = "Record Created!";
	
	echo $latestWithHdrId;
?>