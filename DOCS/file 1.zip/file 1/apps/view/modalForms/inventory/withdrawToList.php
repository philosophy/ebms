<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withdrawToType = $_POST['wType'];
	
	if ($withdrawToType == "Customer")
	{
		$query = mysql_query("Select CUSTOMER_CODE, CUSTOMER_NAME 
								From customer_profile 
								Where IS_DELETED = 0");
								
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<option value='".$arr['CUSTOMER_CODE']."'>".$arr['CUSTOMER_NAME']."</option>";
			}
		}
		else
		{
			$outputData = "<option value=''>No customer found</option>";
		}
		
		echo $outputData;
	}
	else if ($withdrawToType == "Employee")
	{
		$query = mysql_query("Select EMP_CODE, concat(EMP_FIRST_NAME, ' ', EMP_LAST_NAME)
								From employee_profile
								Where IS_DELETED = 0");
								
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<option value='".$arr['EMP_CODE']."'>".$arr[1]."</option>";
			}
		}
		else
		{
			$outputData = "<option value=''>No employee found</option>";
		}
		
		echo $outputData;
	}
	else if ($withdrawToType == "Supplier")
	{
		$query = mysql_query("Select SUPPLIER_CODE, SUPPLIER_NAME
								From supplier_profile
								Where IS_DELETED = 0");
		
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<option value='".$arr['SUPPLIER_CODE']."'>".$arr['SUPPLIER_NAME']."</option>";
			}
		}
		else
		{
			$outputData = "<option value=''>No supplier found</option>";
		}
		
		echo $outputData;
	}
?>