
<div id="new_prodAsset" class="modalForm" w=650>
	<div id="modalTitle">Product</div>
	<div id="formSegment">
			
	
		<label>Item Code</label>
		<input type="text" id="itemCode">
		
		<label>Category</label>
		<input type="text" id="category" disabled value="<Auto>">
		
		<label>Sub Category</label>
		<input type="text" id="subCategory" disabled value="<Auto>">
		
		<label>Brand</label>
		<select id="brand">
			<script>
				$.post("../../systemRecords/fileMaintenance/brandManager/brandManager.php",{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#brand").html(response);
					
					});
			</script>
		</select>
		
		<label>Unit</label>
		<select id="unit">
			<script>
				$.post("../../systemRecords/fileMaintenance/unitManager/unitManager.php",{role:"VIEW",viewType:"comboBox"},
					function(response)
					{
					$("#unit").html(response);
					});
			</script>
		</select>
		
		<label>Price</label>
		<input type="text" value="0" id="price" maxlength="15">
		
		<label>Normal Stock</label>
		<input type="text" id="normalstock" maxlength="15" value="0" style="width:100px;">
		
		<label>Minimum Stock</label>
		<input type="text" id="minimumstock" maxlength="15" value="0" style="width:100px;">
		
		<label>Remarks</label>
		<input type="text" id="remarks">
	</div>
	
	<div id="formSegment">
	<label>Upload Item Image</label>

	<form method="POST" action="imageUp.php" id="image" enctype="multipart/form-data">
		<input type="file" accept="image/png, image/jpeg" id="itemImage" name="itemImage" />
	</form>
	
	
	<h5>Desription <br>
	<select id="description" style="float:left;">
	<option value="0">-Select Description-</option>
	</select>
	<a href="javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/itemFieldManager/index.php',480,600)" style="text-decoration:none">
	<input type="button" class="newBtn" style="width:25px;float:left;margin-left:5px;" value="✚" title="Open Item Field Manager"></a>
	
	<input type="button" id="refreshdesc" class="newBtn" style="width:25px;float:left;margin-left:5px;font-weight:bold;" value="↻" title="Refresh">
	<br>
	</h5>
	<div id="formDataCont" ref="divDescription">
	
	<table ref="divDescription">
	<th>Field</th>
	<th>Value</th>
	
	<tbody id="desc">
	
	</tbody>
	</table>
	</div>
	<button id="removeDescription" style="width:20%;">Remove</button>
	
	</div>
	
	
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</div>

<div id="edit_prodAsset" class="modalForm" w=650>

	<div id="modalTitle">Edit Product/Asset</div>
		<div id="formSegment">
			
	
	
		<label>Item Code</label>
		<input type="text" id="itemCode">
		
		<label>Category</label>
		<input type="text" id="category" disabled value="<Auto>">
		
		<label>Sub Category</label>
		<input type="text" id="subCategory" disabled value="<Auto>">	
		
		<label>Brand</label>
		<select id="brand">
			<script>
				$.post("../../inventory/productList/updateItem.php",{role:"viewbrand"},
					function(response)
					{
					$("div#edit_prodAsset #brand").html(response);
					
					});
			</script>
		</select>
		<label>Unit</label>
		<select id="unit">
		
		</select>
		<label>Price</label>
		<input type="text" id="price" maxlength="15">
		
		<label>Normal Stock</label>
		<input type="text" id="normalstock" style="width:100px;" maxlength="15">
		
		<label>Minimum Stock</label>
		<input type="text" id="minimumstock" style="width:100px;" maxlength="15">
		<label>Remarks</label>
		<input type="text" id="remarks">	
	</div>
	
	<div id="formSegment">
	<label>Upload Item Image</label>

	<form method="POST" action="imageUp.php" id="image" enctype="multipart/form-data">
		<input type="file" accept="image/png, image/jpeg" id="itemImage" name="itemImage">
	</form>
	
	
	<h5>Desription <br>
	<select id="description" style="float:left;">
	<option value="0">-Select Description-</option>
	</select>
	<a href="javascript:newPopup('/EBMS/apps/view/systemRecords/fileMaintenance/itemFieldManager/index.php',480,600)" style="text-decoration:none">
	<input type="button" class="newBtn" style="width:25px;float:left;margin-left:5px;" value="✚" title="Open Item Field Manager"></a>
	
	<input type="button" id="refreshdesc" class="newBtn" style="width:25px;float:left;margin-left:5px;font-weight:bold;" value="↻" title="Refresh">
	<br>
	</h5>
	<div id="formDataCont" ref="divDescription">
	
	<table ref="divDescription">
	<th>Field</th>
	<th>Value</th>
	
	<tbody id="desc">
	
	</tbody>
	</table>
	</div>
	<button id="removeDescription" style="width:20%;">Remove</button>
	</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
</div>


<div id="delete_prodAsset" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to delete?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>

<div id="restore_prodAsset" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to restore?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
		</div>
</div>

<div id="transfer_prodAsset" class="modalForm" w=500>
<div id="formSegment" style="width:100%;">
<h4><b id="assetOrProduct"> </b>?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Transfer</button>
		</div>
</div>

<div id="new_itemReceiving" class="modalForm" w=650>
	<div id="modalTitle">Item Receiving</div>
		
	<div id="formSegment" style="width:100%; margin-top:-20px">
	<div id="formSegment">
		<h5>Company Info</h5>
		<label>Receive From</label>
		<input id="receiveFrom" type="text" disabled="true">
		
		<label>Location</label>
		<input id="location" type="text" disabled="true">
		
		<label>Address</label>
		<textarea id="address" style="min-height:30px" disabled="true"></textarea>
	
	</div>
	
	<div id="formSegment">
		<h5>Contact Info</h5>
		
		<label>Contact Name</label>
		<!--<input id="contactName" type="text">-->
		<select id="contactName">
		
		</select>
		
		<label>Department</label>
		<input id="department" type="text" disabled="true">
		
		<label>Position</label>
		<input id="position" type="text" disabled="true">
		
		<label>Remarks</label>
		<textarea id="remarks" style="min-height:30px"></textarea>
		
	</div>
	
	<div id="formSegment" style="width:600px">
				<div id="formDataContMenu">
					<label>Import From</label>
					<select id="importFrom" style="font-size:12px">
						<option value="">...</option>
						<option value="PO">PO</option>
						<option value="WD">Withdrawal</option>					
					</select>
					
				</div>
			<div id="formDataCont" style="height:180px;">	
					
				<table ref='withHdr'>
					<tbody id="header">
						<th>Withdrawal Code</th>
						<th>Date Withdrawn</th>
						<th>Purpose</th>
						<th>Withdrawn To</th>
						<th>Type</th>
					</tbody>
					
					<tbody id="withdrawnItems">
						
					</tbody>
					
				</table>
			
			</div>
		</div>
	<div id="formSegment" style="width:93%; margin-top:-10px">
	
	<h5>Receiving Info</h5>
		
	<div style='overflow:auto; height:200px'>
		
			<div id="formSegment" style="width:40%">
				<div id="formDataCont" ref="itemList" style="overflow:auto;height:170px;">
				<div id="formDataContMenu">
					<label style="font-size:12px">Item List</label>
					
				</div>
					<ul class="gridViewNav">
					</ul>
						
				</div>
				<div class="itemDetails" style="left:295px;bottom:230px;width:310px;">
				<label class="itemCode">Item Code</label>
				<span class="itemDesc">Sample sample</span>
				</div>
			</div>
			
		<div id="formSegment" style="width:53%">
	
			<div id="formDataCont" style="height:170px;">
				<table ref='receive'>
					<th>Quantity</th>
					<th>Max Quantity to Receive</th>
					<th>Item Code</th>
					<th>Item Description</th>
					
					<tbody id="withdrawnItems">
						
					</tbody>
					
				</table>
			</div>
		</div>
	
	</div>
	</div>
	
	</div>
		<div id="formSegment" style="margin-top:-20px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	
</div>


<div id="edit_itemReceiving" class="modalForm" w=640>
	<div id="modalTitle">Item Receiving</div>
		
	<div id="formSegment" style="width:100%; margin-top:-20px">
	<div id="formSegment">
		<h5>Company Info</h5>
		<label>Receive From</label>
		<input id="receiveFrom" type="text" disabled = "true">
		
		<label>Location</label>
		<input id="location" type="text" disabled = "true">
		
		<label>Address</label>
		<textarea id="address" disabled = "true"></textarea>
	
	</div>
	
	<div id="formSegment">
		<h5>Contact Info</h5>
		
		<label>Contact Name</label>
		<input id="contactName" type="text" disabled = "true">
		
		<label>Department</label>
		<input id="department" type="text" disabled = "true">
		
		<label>Position</label>
		<input id="position" type="text" disabled = "true">
		
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
	</div>
	
	<!--<div id="formSegment" style="width:90%">
	<h5>Receiving Info</h5>
		<div id="formDataCont">
		</div>
	</div>-->
	
	</div>
	
	
		<div id="formSegment" style="margin-top:-10px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	
</div>


<div id="delete_itemReceiving" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to delete?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>


<div id="restore_itemReceiving" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to restore?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>


<div id="new_withdrawal" class="modalForm" w=780>
	<form action="" method="POST">
	<div id="modalTitle">Stock Withdrawal</div>
	<div id="formSegment">
		
		<!--<label>Withdrawal No</label>
		<input type="text" id="wNo" value="-Auto-" readOnly=true>-->
		
		<label>Type</label>
		<!--<input type="text" id="wType">-->
		<select id="wType">
			<option value="Customer">Customer</option>
			<option value="Employee">Employee</option>
			<option value="Supplier">Supplier</option>
		</select>
		
		<label>Withdraw To</label>
		<!--<input type="text" id="withdrawTo">-->
		<select id="withdrawTo">
		
		</select>
		
		<label>Location</label>
		<select id="location">
		
		</select>
		
		<label>City</label>
		<!--<input type="text" id="city">-->
		<select id="city">
		
		</select>
		
		<label>Barangay</label>
		<!--<input type="text" id="barangay">-->
		<select id="barangay">
		
		</select>
		
		<label>Area</label>
		<!--<input type="text" id="area">-->
		<select id="area">
		
		</select>
		
	</div>
	
	<div id="formSegment">
		
		<label>Purpose</label>
		<select id="purpose">
			<option value="Dispose">Dispose</option>
			<option value="Issue Item">Issue Item</option>
			<option value="Repair">Repair</option>
		</select>
		
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
		<label>Address</label>
		<textarea id="address"></textarea>
		
	</div>
	
	<div id="formSegment" style="width:52%;margin-top:-20px">
		<h5>Item List</h5>
			<div id="formDataCont" ref="itemList" style="overflow:auto;height:230px;">
			<div id="formDataContMenu">
				<input type="text" id="formDataContSearch" value="Search">
				
			</div>
				<ul class="gridViewNav">
				</ul>
					
			</div>
			
			<div class="itemDetails" style="bottom:0px;width:395px">
			<label class="itemCode">Item Code</label>
			<span class="itemDesc">Sample sample</span>
			</div>
			
		</div>
		
		<div id="formSegment" style="width:40%;margin-top:-20px">
		<h5>Withdrawn Items</h5>
			<div id="formDataCont" style="height:230px;">
				<table ref="withdraw">
					<th>Quantity</th>
					<th>Stock on Hand</th>
					<th>Unit Price</th>
					<th>Item Code</th>
					<th>Item Description</th>
					
					<tbody id="withdrawnItems">
						
					</tbody>
					
				</table>
			</div>
		</div>
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	</form>
</div>

<div id="edit_withdrawal" class="modalForm" w=650>
	<div id="modalTitle">Stock Withdrawal</div>
	<div id="formSegment" style="width:100%">
		<label>Date</label>
		<input type="text" id="stockWithdrawalDate" datepicker=true disabled="true">
	</div>
	
	<div id="formSegment">
		
		<label>Withdrawal No</label>
		<input type="text" id="wNo" disabled="true">
		
		<label>Type</label>
		<input type="text" id="wType" disabled="true">
		
		<label>Withdraw To</label>
		<input type="text" id="withdrawTo" disabled="true">
		
		<label>Location</label>
		<input type="text" id="location" disabled="true">
		
		<label>City</label>
		<input type="text" id="city" disabled="true">
		
		<label>Barangay</label>
		<input type="text" id="barangay" disabled="true">
		
		<label>Area</label>
		<input type="text" id="area" disabled="true">
		
	</div>
	
	<div id="formSegment">
		
		<label>Purpose</label>
		<select id="purpose">
			<option value="Dispose">Dispose</option>
			<option value="Issue Item">Issue Item</option>
			<option value="Repair">Repair</option>
		</select>
		
		<label>Remarks</label>
		<textarea id="remarks" disabled="true"></textarea>
		
		<label>Address</label>
		<textarea id="address" disabled="true"></textarea>
		
		
		<!--<button class="formButton" id="removeOrder">Remove</button>
		<button class="formButton" id="addOrder">Withdraw</button>-->
		
	</div>
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>

</div>

<div id="new_adjustment" class="modalForm" w=800>
	<div id="modalTitle">Adjustment</div>
	<form method="POST" action="" class="crudOS">
	
		
		<div id="formSegment" style="width:95%; margin-top:-15px;">
			<h5 style="margin-left:60%">Adjustment Number: <input type="text" value="<Auto>" id="adjustmentCode" disabled /></h5>
		</div>
		<div id="formSegment" style="width:56%; margin-top:-20px;">
			<div id="formDataCont" ref="adjustItems" style="overflow:auto;height:230px;">
			<div id="formDataContMenu">
				<input type="text" id="adjFormDataContSearch" value="Search">
					<select id="prodorasset" style="width:70px; margin-left:5px;">
					<option value="product">Product</option>
					<option value="asset">Asset</option>
				</select>
					<select id="addorless" style="width:50px; margin-left:5px;">
					<option value="add">Add</option>
					<option value="less">Less</option>
				</select>
				<div id="pagingCont">
					<button id="first" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;"></button>
					
				</div>
			</div>
				<ul class="gridViewNav">
				</ul>
					
			</div>
			
		
		<div class="itemDetails" style="width:450px;bottom:80px;">
		<label class="itemCode">Item Code</label>
		<span class="itemDesc">Sample sample</span>
		</div>
		
			<h5>Remarks</h5>
			<textarea id="remarks" style="width:100%" ></textarea>
		</div>
		
		<div id="formSegment" style="width:38%; margin-top:-20px;">
			<div id="formDataCont" style="height:230px;">
				<table ref="addAdjustment">
					<th>Item Code</th>
					<th>Quantity</th>
					<th>Action</th>
					<th>Stock on Hand</th>
					<th>Item Description</th>
					<th>Remarks</th>
					
					<tbody id="items">
						
					</tbody>
					
				</table>
			</div>
			
		</div>
		
		
		
		<div id="formSegment" class="buttonPanel" style="margin-top:-40px">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
</div>


<div id="edit_adjustment" class="modalForm" w=800>
	<div id="modalTitle">Adjustment</div>
	<form method="POST" action="" class="crudOS">
	
		
		<div id="formSegment" style="width:95%; margin-top:-15px;">
		<h5><font color="red">Remarks field are the only editable fields.</font></h5>
			<h5 style="margin-left:60%">Adjustment Number: <input type="text" id="adjustmentCode" disabled /></h5>
		</div>

		
		<div id="formSegment" style="width:95%; margin-top:-20px;">
			<div id="formDataCont" style="height:230px;">
				<table ref="editAdjustment">
					<th>Item Code</th>
					<th>Description</th>
					<th>Add</th>
					<th>Less</th>
					<th>Remarks</th>
					
					<tbody id="items">
						
					</tbody>
					
				</table>
			</div>
		</div>
		
		
		<div id="formSegment" style="width:95%">
			<h5>Remarks</h5>
			<textarea id="remarks" style="width:100%" ></textarea>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
</div>


<div id="delete_adjustment" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to delete?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>


<div id="restore_adjustment" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to restore?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>


<div id="new_maintenanceHistory" class="modalForm" w=300>
	<div id="modalTitle">Entry Window</div>
	<form method="POST" action="" class="crudOS">
		<div id="formSegment" style="width:95%">
		
		<label>Date:</label>
		<input type="text" id="addDate" datepicker=true maxlength=10><br>
		
		<label>Person Name:</label>
		<input type="text" id="personName"><br>
		
		<label>Contact No:</label>
		<input type="text" id="contactNo"><br>
		
		<label>Findings:</label>
		<input type="text" id="findings"><br>
		
		<label>Step(s) taken:</label>
		<textarea id="steps"></textarea><br>
		
		</div>
			
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
</div>

<div id="edit_maintenanceHistory" class="modalForm" w=300>
	<div id="modalTitle">Entry Window</div>
	<form method="POST" action="" class="crudOS">
		<div id="formSegment" style="width:95%">
		
		<label>Date:</label>
		<input type="text" id="editDate" datepicker=true maxlength=10><br>
		
		<label>Person Name:</label>
		<input type="text" id="personName"><br>
		
		<label>Contact No:</label>
		<input type="text" id="contactNo"><br>
		
		<label>Findings:</label>
		<input type="text" id="findings"><br>
		
		<label>Step(s) taken:</label>
		<textarea id="steps"></textarea><br>
		
		</div>
			
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
</div>

<div id="delete_maintenanceHistory" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to delete?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>

<div id="restore_maintenanceHistory" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to restore?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
		</div>
</div>

<div id="new_maintenance" class="modalForm" w=300>
	<div id="modalTitle">Maintenance</div>
	<form method="POST" action="" class="crudOS">
		<div id="formSegment" style="width:95%">
		
		<label>Alert Date:</label>
		<input type="text" id="addAlertDate" datepicker=true />
		
		<label>Remind me:</label>
		<select id="remindEvery">
			<option value="Daily">Daily</option>
			<option value="Weekly">Weekly</option>
			<option value="Monthly">Monthly</option>
			<option value="Yearly">Yearly</option>
		</select>
		
		<label>Alert Time:</label>
		<input type="text" id="alertTime">
		
		<label>Subject:</label>
		<input type="text" id="subject">
		
		<label>Note:</label>
		<textarea id="note"></textarea>
		
		<label>Status:</label>
		<select id="status">
			<option value="1">Alert ON</option>
			<option value="0">Alert OFF</option>
		</select>
		
		</div>
			
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
</div>

<div id="edit_maintenance" class="modalForm" w=300>
	<div id="modalTitle">Maintenance</div>
	<form method="POST" action="" class="crudOS">
		<div id="formSegment" style="width:95%">
		
		<label>Alert Date:</label>
		<input type="text" id="editAlertDate" datepicker=true />
		
		<label>Remind me:</label>
		<select id="remindEvery">
			<option value="Daily">Daily</option>
			<option value="Weekly">Weekly</option>
			<option value="Monthly">Monthly</option>
			<option value="Yearly">Yearly</option>
		</select>
		
		<label>Alert Time:</label>
		<input type="text" id="editAlertTime">
		
		<label>Subject:</label>
		<input type="text" id="subject">
		
		<label>Note:</label>
		<textarea id="note"></textarea>
		
		<label>Status:</label>
		<select id="status">
			<option value="1">Alert ON</option>
			<option value="0">Alert OFF</option>
		</select>
		
		</div>
			
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
</div>

<div id="delete_maintenance" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to delete?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
		</div>
</div>


<div id="restore_maintenance" class="modalForm" w=500>
<div id="formSegment">
<h4>Are you sure you want to restore?</h4>
</div>
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
		</div>
</div>