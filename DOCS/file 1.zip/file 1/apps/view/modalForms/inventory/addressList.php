<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$code = $_POST['code'];
	$type = $_POST['type'];
	
	$custId = 0;
	
	if ($type == "Customer")
	{
		$query = mysql_query("Select * From customer_profile Where CUSTOMER_CODE = '" . $code . "'");
		while ($arr = mysql_fetch_array($query))
		{
			$custId = $arr['CUSTOMER_ID'];
		}
	
		$query = mysql_query("Select LOCATION_ADDRESS 
								From location L, customer_profile CP 
								Where L.CUSTOMER_ID = CP.CUSTOMER_ID and 
									CP.CUSTOMER_ID = '" . $custId . "' and 
									CP.IS_DELETED = 0");
									
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= $arr['LOCATION_ADDRESS'];
			}
		}
		else
		{
			$outputData = "No record found";
		}
		
		echo $outputData;
	}
	else if ($type == "Employee")
	{
		$query = mysql_query("Select EMP_ADDRESS 
								From employee_profile 
								Where EMP_CODE = '" . $code . "'");
								
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= $arr['EMP_ADDRESS'];
			}
		}
		else
		{
			$outputData = "No record found";
		}
		
		echo $outputData;						
	}
?>