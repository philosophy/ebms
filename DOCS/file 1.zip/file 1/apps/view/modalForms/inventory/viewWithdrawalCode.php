<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withId = $_POST['id'];
	
	$query = mysql_query("Select WITH_HDR_NO From withdrawal_header Where WITH_HDR_ID = '" . $withId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	echo $outputData;
?>