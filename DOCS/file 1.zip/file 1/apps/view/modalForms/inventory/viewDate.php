<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withId = $_POST['id'];
	
	$query = mysql_query("Select concat(monthname(WITH_HDR_DATE_ISSUED), ' ', day(WITH_HDR_DATE_ISSUED), ', ', year(WITH_HDR_DATE_ISSUED)) 
							From withdrawal_header 
							Where WITH_HDR_ID = '" . $withId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	echo $outputData;
?>