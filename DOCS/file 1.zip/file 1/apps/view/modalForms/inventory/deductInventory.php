<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$qty = $_POST['qty'];
	$itemCode = $_POST['itemCode'];
	
	$latestWithHdrId = 0;
	$currentStock = 0;
	
	$query = mysql_query("Select max(WITH_HDR_ID) From withdrawal_header");
	while ($arr = mysql_fetch_array($query))
	{
		$latestWithHdrId = $arr[0];
	}
	
	$query = mysql_query("Select PRODUCT_QTY From product Where PRODUCT_CODE = '" . $itemCode . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$currentStock = $arr[0];
	}
	
	$newStock = $currentStock - $qty;
	
	$query = mysql_query("Update product Set PRODUCT_QTY = '" . $newStock . "' Where PRODUCT_CODE = '" . $itemCode . "'");
	
	// echo $outputData;
?>