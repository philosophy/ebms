<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withId = $_POST['id'];
	$purpose = $_POST['purpose'];
	
	$query = mysql_query("Update withdrawal_header Set WITH_HDR_PURPOSE = '" . $purpose . "' Where WITH_HDR_ID = '" . $withId . "'");
	$outputData = "Record Edited!";
	
	echo $outputData;
?>