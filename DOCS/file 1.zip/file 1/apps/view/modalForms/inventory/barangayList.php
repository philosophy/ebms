<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$cityId = $_POST['cityId'];
	
	if ($cityId != "")
	{
		$query = mysql_query("Select B.BARANGAY_ID, BARANGAY_NAME 
								From barangay B, location L 
								Where L.BARANGAY_ID = B.BARANGAY_ID and 
									B.CITY_ID = '" . $cityId . "' and 
									B.IS_DELETED = 0");
		if (mysql_num_rows($query) > 0)
		{
			while ($arr = mysql_fetch_array($query))
			{
				$outputData .= "<option value = '" . $arr['BARANGAY_ID'] . "'>" . $arr['BARANGAY_NAME'] . "</option>";
			}
		}
		else
		{
			$outputData = "<option value = ''>No record found</option>";
		}
		
		echo $outputData;
	}
?>