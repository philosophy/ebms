<?php

include("../../../../config/config.php");
$outputData = "";

$itemType = $_POST['itemType'];

if($itemType == "product")
{
$query = mysql_query("select product_code as 'code', GROUP_CONCAT(' ', pf.product_field_name, ': ', pi.product_description) as 'desc',product_image as 'img',
						p.product_unit_price as 'unit_price', p.product_qty, b.brand_name, c.category_name, sc.sub_category_name
						from product p inner join product_information pi on pi.product_id = p.product_code 
						inner join product_field pf on pf.product_field_id = pi.product_field_id 
						INNER JOIN brand b ON b.brand_id = p.brand_id
						INNER JOIN category c ON c.category_id = p.category_id
						INNER JOIN category_sub_category sc ON sc.sub_category_id = p.sub_category_id
						where pf.is_add_to_description = 1 AND p.is_deleted = 0
						group by p.product_code");
}

elseif($itemType == "asset")
{
$q = addslashes(@$_POST['q']);
	
		if($q == "")
		{
			$condition = "";
		}
		
		else
		{
			$condition = "and (p.product_code LIKE '%".$q."%')";		
		}
	
$query = mysql_query("select product_code as 'code', product_qty as 'stock on hand', GROUP_CONCAT(' ', pf.product_field_name, ': ', pi.product_description) as 'desc', product_image as 'img', 
						p.product_unit_price as 'unit_price', p.product_qty, b.brand_name, c.category_name, sc.sub_category_name
						from product p inner join product_information pi on pi.product_id = p.product_code 
						inner join product_field pf on pf.product_field_id = pi.product_field_id 
						INNER JOIN brand b ON b.brand_id = p.brand_id
						INNER JOIN category c ON c.category_id = p.category_id
						INNER JOIN category_sub_category sc ON sc.sub_category_id = p.sub_category_id
						where pf.is_add_to_description = 1 AND p.is_deleted = 0 and p.PRODUCT_QTY != 0 and p.ITEM_FLAG = 'A' ".$condition."
						group by p.product_code");
}						
						
	if(mysql_num_rows($query) > 0)
	{
		while($arr = mysql_fetch_array($query))
		{
			$outputData .= "<li id='gridViewList'>
							<a href='#' id='gridViewLink' stockOnHand='" . $arr['stock on hand'] ."' desc='".$arr['desc']."' code='".$arr['code']."' unitPrice='".number_format($arr['unit_price'],2)."'>
								<div id='itemMenu'>
									<button class='addItem' title='Add Item'>✚</button>
									<button class='removeItem' title='Remove Item'>✖</button>
									<button class='selectedItem' title='Selected Item'>✔</button>
								</div>
								<img src='/ebms/images/stock/".(($arr['img']=='')?'default.png':$arr['img'])."'>
							</a>
							</li>";
		}
	}
	
	else
	{
	$outputData = "No items found";
	}
	
	echo $outputData;