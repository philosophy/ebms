<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$query = mysql_query("Select max(WITH_HDR_ID) From withdrawal_header");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	echo $outputData;
?>