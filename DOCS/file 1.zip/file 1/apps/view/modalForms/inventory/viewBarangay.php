<?php
	include("../../../../config/config.php");
	
	$outputData = "";
	
	$withId = $_POST['id'];
	
	$locationId = 0;
	
	$query = mysql_query("Select LOCATION_ID From withdrawal_header Where WITH_HDR_ID = '" . $withId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$locationId = $arr[0];
	}
	
	$query = mysql_query("Select BARANGAY_NAME 
							From barangay B, location L 
							Where L.BARANGAY_ID = B.BARANGAY_ID and 
								L.LOCATION_ID = '" . $locationId . "'");
	while ($arr = mysql_fetch_array($query))
	{
		$outputData = $arr[0];
	}
	
	echo $outputData;
?>