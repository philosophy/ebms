
<div id="new_custPayment" class="modalForm" w=700>
<div id="modalTitle">Customer Payments</div>

		<div id="formSegment">
			
			<label>Transaction No.</label>
			<input type="text" id="transNo" disabled=true value="<Auto>">
			
			<label>Transaction Date</label>
			<input type="text" id="transDate" datepicker=true value="<?php echo date('Y-M-d'); ?>" disabled=true>
			
			<label>Customer Name</label>
			<input type="text" id="custName" disabled=true>
			
			<label>Location</label>
			<textarea id="custLocation" disabled=true></textarea>
		</div>
		
		<div id="formSegment">
			<label>Doc. Type</label>
			<input type="text" id="docType" disabled=true value="OS">
		
			<label>Ref. No.</label>
			<input type="text" id="refNo" disabled=true>
			
			<label>Payment Type <span>*</span></label>
			<select id="paymentType">
				<option value="cash">Cash</option>
				<option value="cheque">Cheque</option>
			</select>
		
			<label>Particulars</label>
			<input type="text" id="particular">
			
			<label>Amount <span>*</span></label>
			<input type="text" id="amount">
			
			<label>Bank Name <span>*</span></label>
			<select id="bankName" disabled=true>
			
			</select>
			
			<label>Address</label>
			<textarea id="address" disabled=true></textarea>
		</div>
		
		<div id="formSegment">
			<label>Account Type <span>*</span></label>
			<select id="accountType" disabled=true>
				<option value="savings">Savings</option>
				<option value="current">Current</option>
			</select>
			
			<label>Account No. <span>*</span></label>
			<select id="accountNo" disabled=true>
				
			</select>
			
			<label>Account Name</label>
			<input type="text" id="accountName" disabled=true>
			
			<label>Check Type <span>*</span></label>
			<select id="checkType" disabled=true>
				<option value="">...</option>
				<option value="On-Dated">On Dated Cheque</option>
				<option value="Post-Dated">Post Dated Cheque</option>
			</select>
		</div>
		
		<div id="formSegment">
			<label>Check No. <span>*</span></label>
			<input type="text" id="checkNo" disabled=true>
			
			<label>Check Date Issue <span>*</span></label>
			<input type="text" id="checkDateIssue" disabled=true datepicker=true>
			
			<label>Check Due Date <span>*</span></label>
			<input type="text" id="checkDueDate" disabled=true datepicker=true>
			
			<label>Balance</label>
			<input type="text" id="balance" disabled>
			
			<label>From Collection?</label>
			<input type="checkbox" id="fromCol" value="">
		</div>
	
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	
</div>
