
<!-- dfdf
!-->

<div id="new_bank" class="modalForm" w=650>
<div id="modalTitle">Bank Records</div>

<div id="modalTabControl">
		<ul class="modalTabNav">
			<li id="modalTabList">
				<a href="#generalInfo" id="modalTabLink" class="modalTabActive">
				General
				</a>
			</li>
			<li id="modalTabList">
				<a href="#contactInfo" id="modalTabLink">
				Contact
				</a>
			</li>
			<li id="modalTabList">
				<a href="#accountInfo" id="modalTabLink">
				Account No.
				</a>
			</li>
			
</div>

<div id="generalInfo" class="modalFormTabCont"> 
		
		<div id="formSegment">
		
		<label>Bank Name</label>
			<input type="text" id="bankName">		
		
		<label>Address</label>
			<textarea id="bankAddress"></textarea>
		
		</div>
		
		<div id="formSegment">
		<label>Website</label>
			<input type="text" id="website">		
			
		<label>Email</label>
			<input type="text" id="email">	
			
		<label>Phone No</label>
			<input type="text" id="phoneNo">	
		
		<label>Fax No</label>
			<input type="text" id="faxNo">		
		
		</div>
</div>


<div id="contactInfo" class="modalFormTabCont"> 
		
		<div id="formSegment">
		
		<label>Contact Person</label>
			<input type="text" id="contactPerson">		
		
		<label>Position</label>
			<input type="text" id="position">
		</div>
		
		<div id="formSegment">
		<label>Department</label>
			<input type="text" id="dept">		
			
		<label>Email</label>
			<input type="text" id="email">	
			
		<label>Phone No</label>
			<input type="text" id="phoneNo">	
		
		<label>Fax No</label>
			<input type="text" id="faxNo">		
		
		</div>
</div>


<div id="accountInfo" class="modalFormTabCont"> 
		
	<div id="formSegment">
		<label>Account Name</label>
		<input type="text" id="acctName">
		
		<label>Account No</label>
		<input type="text" id="acctNo">
		
		<label>Account Type</label>
		<select id="acctType">
			<option value="current">Current</option>
			<option value="savings">Savings</option>
		</select>
	
	<div id="formSegment" style="margin-left:-30px">
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" type="reset" id="clearDetailBtn">Clear</button>
		<button class="formButton" id="saveDetailBtn">Save</button>
		</div>
	</div>
	
	</div>
	
	
	<div id="formSegment" style="width:300px">
		<div id="formDataCont" style="width:300px">
			<table>
				<th style='width:16px;padding:0;'></th>
				<th>Account Name</th>
				<th>Account No</th>
				<th>Account Type</th>
				
				
				<tbody id="acctDetails">
					
				</tbody>
			</table>
		</div>
	</div>
</div>


	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>	
	

</div>

<div id="edit_bank" class="modalForm" w=650>
<div id="modalTitle">Bank Records</div>

<div id="modalTabControl">
		<ul class="modalTabNav">
			<li id="modalTabList">
				<a href="#generalInfo" id="modalTabLink" class="modalTabActive">
				General
				</a>
			</li>
			<li id="modalTabList">
				<a href="#contactInfo" id="modalTabLink">
				Contact
				</a>
			</li>
			<li id="modalTabList">
				<a href="#accountInfo" id="modalTabLink">
				Account No.
				</a>
			</li>
			
</div>

<div id="generalInfo" class="modalFormTabCont"> 
		
		<div id="formSegment">
		
		<label>Bank Name</label>
			<input type="text" id="bankName">		
		
		<label>Address</label>
			<textarea id="bankAddress"></textarea>
		
		</div>
		
		<div id="formSegment">
		<label>Website</label>
			<input type="text" id="website">		
			
		<label>Email</label>
			<input type="text" id="email">	
			
		<label>Phone No</label>
			<input type="text" id="phoneNo">	
		
		<label>Fax No</label>
			<input type="text" id="faxNo">		
		
		</div>
</div>


<div id="contactInfo" class="modalFormTabCont"> 
		
		<div id="formSegment">
		
		<label>Contact Person</label>
			<input type="text" id="contactPerson">		
		
		<label>Position</label>
			<input type="text" id="position">
		</div>
		
		<div id="formSegment">
		<label>Department</label>
			<input type="text" id="dept">		
			
		<label>Email</label>
			<input type="text" id="email">	
			
		<label>Phone No</label>
			<input type="text" id="phoneNo">	
		
		<label>Fax No</label>
			<input type="text" id="faxNo">		
		
		</div>
</div>


<div id="accountInfo" class="modalFormTabCont"> 
		
	<div id="formSegment">
		<label>Account Name</label>
		<input type="text" id="acctName">
		
		<label>Account No</label>
		<input type="text" id="acctNo">
		
		<label>Account Type</label>
		<select id="acctType">
			<option value="current">Current</option>
			<option value="savings">Savings</option>
		</select>
	
	<div id="formSegment" style="margin-left:-30px">
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" type="reset" id="clearDetailBtn">Clear</button>
		<button class="formButton" id="saveDetailBtn">Save</button>
		</div>
	</div>
	
	</div>
	
	
	<div id="formSegment" style="width:300px">
		<div id="formDataCont" style="width:300px">
			<table>
				<th style='width:16px;padding:0;'></th>
				<th>Account Name</th>
				<th>Account No</th>
				<th>Account Type</th>
				
				
				<tbody id="acctDetails">
					
				</tbody>
			</table>
		</div>
	</div>
</div>


	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>	
	

</div>




<div id="delete_bank" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
</div>

<div id="restore_bank" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
</div>

<div id="new_bankDeposit" class="modalForm" w=300>
<div id="modalTitle">Bank Deposit</div>


<div id="formSegment">
		<label>Date</label>
		<input type="text" datepicker=true id="depDate">
		
		<label>Account Type</label>
		<select id="acctType">
		</select>
		
		<label>Account No</label>
		<select id="acctNo">
		</select>
		
		<label>Deposited By</label>
		<select id="withdrawnBy">
		</select>
		
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
</div>


	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>	

</div>


<div id="new_bankWithdrawal" class="modalForm" w=300>
<div id="modalTitle">Bank Withdrawal</div>

	<div id="formSegment">
		<label>Date</label>
		<input type="text" datepicker=true id="withDate">
		
		<label>Account Type</label>
		<select id="acctType">
		</select>
		
		<label>Account No</label>
		<select id="acctNo">
		</select>
		
		<label>Amount</label>
		<input type="number" id="amount">
		
		
		<label>Withdrawn By</label>
		<select id="withdrawnBy">
		</select>
		
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
	</div>
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	
</div>


