
<!-- dfdf
!-->

<div id="new_bank" class="modalForm" w=650>
<div id="modalTitle">Bank Records</div>

		<fieldset><legend>General</legend>
		<div id="formSegment">
		
		<label>Bank Name</label>
			<input type="text" id="bankName">		
		
		<label>Address</label>
			<textarea id="bankAddress"></textarea>
		
		</div>
		
		<div id="formSegment">
		<label>Website</label>
			<input type="text" id="website">		
			
		<label>Email</label>
			<input type="text" id="email">	
			
		<label>Phone No</label>
			<input type="text" id="phoneNo">	
		
		<label>Fax No</label>
			<input type="text" id="faxNo">		
		
		</div>
		</fieldset>

		<fieldset><legend>Contact Info</legend>
		<div id="formSegment">
		
		<label>Contact Person</label>
			<input type="text" id="contactPerson">		
		
		<label>Position</label>
			<input type="text" id="position">
		</div>
		
		<div id="formSegment">
		<label>Department</label>
			<input type="text" id="dept">		
			
		<label>Email</label>
			<input type="text" id="contactEmail">	
			
		<label>Phone No</label>
			<input type="text" id="contactPhoneNo">	
		
		<label>Mobile No</label>
			<input type="text" id="contactMobileNo">		
		
		</div>
		</fieldset>

		<fieldset><legend>Account Info</legend>
		<div id="formSegment">
		<label>Account Name</label>
		<input type="text" id="acctName">
		
		<label>Account No</label>
		<input type="text" id="acctNo">
		
		<label>Account Type</label>
		<select id="acctType">
			<option value="Current">Current</option>
			<option value="Savings">Savings</option>
		</select>
	
	<div id="formSegment" style="margin-left:-30px">
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" type="reset" id="clearDetailBtn">Clear</button>
		<button class="formButton" id="saveDetailBtn">Save</button>
		</div>
	</div>
	
	</div>
		
	<div id="formSegment" style="width:300px">
		<div id="formDataCont" style="width:300px">
			<table>
				<th style='width:16px;padding:0;'></th>
				<th>Account Name</th>
				<th>Account No</th>
				<th>Account Type</th>
				
				
				<tbody id="acctDetails">
					
				</tbody>
			</table>
		</div>
	</div>

	</fieldset>
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>	
	

</div>

<div id="edit_bank" class="modalForm" w=650>
<div id="modalTitle">Bank Records</div>

		<fieldset><legend>General</legend>
		<div id="formSegment">
		
		<label>Bank Name</label>
			<input type="text" id="bankName">		
		
		<label>Address</label>
			<textarea id="bankAddress"></textarea>
		
		</div>
		
		<div id="formSegment">
		<label>Website</label>
			<input type="text" id="website">		
			
		<label>Email</label>
			<input type="text" id="email">	
			
		<label>Phone No</label>
			<input type="text" id="phoneNo">	
		
		<label>Fax No</label>
			<input type="text" id="faxNo">		
		
		</div>
		</fieldset>

		<fieldset><legend>Contact Info</legend>
		<div id="formSegment">
		
		<label>Contact Person</label>
			<input type="text" id="contactPerson">		
		
		<label>Position</label>
			<input type="text" id="position">
		</div>
		
		<div id="formSegment">
		<label>Department</label>
			<input type="text" id="contactDept">		
			
		<label>Email</label>
			<input type="text" id="contactEmail">	
			
		<label>Phone No</label>
			<input type="text" id="contactPhoneNo">	
		
		<label>Mobile No</label>
			<input type="text" id="contactMobileNo">		
		
		</div>
		</fieldset>

		<fieldset style="height:200px"><legend>Account Info</legend>
			<div class="tabButtonPanel" style="margin-top:-21px;right:500px">
			<button id="editAcctInfo" style="width:25px" title='Edit' disabled>✎</button>
			<button id="newAcctInfo" style="width:25px" title='New'>✚</button>
			<!--
			<button id="deleteFileLeave" class="callModalForm" style="width:25px" ref="delete_fileLeave" onclick="callModal('#deleteFileLeave')" title='Delete' disabled>✖</button>
			<button id="restoreFileLeave" class="callModalForm" style="width:25px" ref="restore_fileLeave" onclick="callModal('#restoreFileLeave')" title='Restore' disabled>➲</button>
			-->
			</div>
			
			
			<div id="formSegment" style="width:620px">
			
			<div id="acctInfo" class="scrollable" style="width:630px;height:190px">
			</div>
			
			</div>
		
		</fieldset>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>	
	

</div>


<div id="delete_bank" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
</div>

<div id="restore_bank" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
</div>

<div id="new_bankDeposit" class="modalForm" w=300>
<div id="modalTitle">Bank Deposit</div>


<div id="formSegment">
		<label>Deposit From</label>
		<input type="text" id="depositFrom" value="Cash On Hand" disabled>
		
		<label>Reference Type</label>
		<input type="text" id="refType" value="Cash On Hand" disabled>
		
		<label>Deposit Amount</label>
		<input type="text" id="depositAmount">
		<script>
			$.post("/ebms/apps/view/accounting/cashOnHand/cashOnHand.php",
				function(response){
					$("#depositAmount").val(response);
				});
		</script>
		
		<label>Date</label>
		<input type="text" datepicker=true id="depDate">
		
		<label>Account Type</label>
		<select id="acctType">
			<option value="Current">Current</option>
			<option value="Savings">Savings</option>
		</select>
		
		<label>Account No</label>
		<select id="acctNo">
		</select>
		
		<label>Deposited By</label>
		<select id="depositedBy">
			<script>
					$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",
						{role:"VIEW",viewType:"comboBox"},
						function(response)
						{
							$("#new_bankDeposit #depositedBy").html(response);
							
						});
			</script>
		</select>
		
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
</div>


	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>	

</div>

<div id="new_bankWithdrawal" class="modalForm" w=300>
<div id="modalTitle">Bank Withdrawal</div>

	<div id="formSegment">
		<label>Date</label>
		<input type="text" datepicker=true id="withDate" value="<?php echo date("Y-m-d"); ?>">
		
		<label>Account Type</label>
		<select id="acctType">
			<option value="Current">Current</option>
			<option value="Savings">Savings</option>
		</select>
		
		<label>Account No</label>
		<select id="acctNo">
			
		</select>
		
		<label>Amount</label>
		<input type="text" id="amount">
		
		
		<label>Withdrawn By</label>
		<select id="withdrawnBy">
			<script>
					$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",
						{role:"VIEW",viewType:"comboBox"},
						function(response)
						{
							$("#new_bankWithdrawal #withdrawnBy").html(response);
							
						});
			</script>
		</select>
		
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
	</div>
	
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	
</div>


