<div id="new_owners-equity" class="modalForm" w=300>
	<div id="modalTitle">Owner's Equity Entry</div>

	<div id="formSegment" style="width:95%;">
		
		<label>Equity Type:</label>
		<select id="cashorbank">
			<option value="cash">Cash</option>
			<option value="bank">Bank</option>
		</select><br>
		
		<label>Amount:</label>
		<input type="text" id="amount"  maxlength="18"/><br>
		
		<label>Bank Name:</label>
		<select id="bankName">
		
		</select><br>
		
		<label>Account Type:</label>
		<select id="accountType">
		
		</select><br>
		
		<label>Account Number:</label>
		<select id="accountNumber">
		
		</select><br>
		
		<label>Remarks:</label>
		<textarea id="remarks"></textarea>
		
	</div>
	
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</div>