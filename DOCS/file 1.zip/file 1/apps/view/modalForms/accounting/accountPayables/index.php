<div id="new_payables" class="modalForm" w=650>
	<div id="modalTitle">Company Payables</div>		
	<div id="formSegment" style="width:100%; margin-top:0px">		
		<div id="formSegment" style="overflow:auto; height:200px; width:645px; margin-left:-5px">
			<div id="formSegment">
				<label style="width:70px">Due Date</label>
				<input type="text" id="datepicker">
			</div>
		
			<div id="formSegment" style="width:620px; margin-top:10px">
				<div id="formDataCont" style="height:180px;">	
					<div id="formDataContMenu">
						<select id="importFrom" style="font-size:12px">
							<option value="">Import From</option>
							<option value="PO">PO</option>				
						</select>
						
					</div>
						
					<table id='poHdr'>
						<tbody id="header">
							<th>PO Code</th>
							<th>Date Needed</th>
							<th>Payment Type</th>
							<th>Net Amount</th>
						</tbody>
						
						<tbody id="poItems">
							
						</tbody>
						
					</table>
				</div>
					
				<div id="formSegment" style="width:93%; margin-top:-5px">
				
					<h5>PO Detail</h5>
					
					<div style="overflow:auto; height:200px">
						<div id="formSegment" style="width:98%">
							<div id="formDataCont" ref="itemList" style="overflow:auto;height:150px; margin-top:-10px">
								<div id="formDataContMenu">
									<label style="font-size:12px">Item List</label>
									<div id="pagingCont">
										<button id="first" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;"></button>
										<button id="prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;"></button>
										<button id="next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;"></button>
										<button id="last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;"></button>
										
									</div>
								</div>
								
								<ul class="gridViewNav">
								
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
	</div>
	
	<div id="formSegment" style="margin-top:0px; margin-left:20px">
		<label>Account Type</label>
		<select id = "accountType">
		</select>
	</div>
	
	<div id="formSegment" style="margin-top:0px">
		<label>Amount</label>
		<input id = "amount" type = "text">
	</div>
	
	<div id="formSegment" style="width:600px; margin-left:20px; margin-top:-2px">
		<label>Description</label>
		<textarea id = "description" style="width:575px; min-height:20px"></textarea>
	</div>
	
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="remove">Remove</button>
		<button class="formButton" id="add">Add</button>
	</div>
	
	<div id="formSegment" style="width:620px; margin-top:10px">
		<div id="formDataCont" style="height:140px; margin-left:10px">				
			<table id="payables">
				<tbody id="header">
					<th>Account Type</th>
					<th>Description</th>
					<th>Amount</th>
				</tbody>
				
				<tbody id="items">
					
				</tbody>
				
			</table>
		</div>
	</div>
	
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	
</div>

<div id="edit_payables" class="modalForm" w=650>
	<div id="modalTitle">Company Payables</div>		
	<div id="formSegment" style="width:100%; margin-top:0px">		
		<div id="formSegment" style="overflow:auto; height:200px; width:645px; margin-left:-5px">
			<div id="formSegment">
				<label style="width:70px">Due Date</label>
				<input type="text" id="datepickerEdit">
			</div>
		
			<div id="formSegment" style="width:620px; margin-top:10px">
				<div id="formDataCont" style="height:180px;">	
					<div id="formDataContMenu">
						<select id="importFrom" style="font-size:12px">
							<option value="">Import From</option>
							<option value="PO">PO</option>				
						</select>
						
					</div>
						
					<table id='poHdr'>
						<tbody id="header">
							<th>PO Code</th>
							<th>Date Needed</th>
							<th>Payment Type</th>
							<th>Net Amount</th>
						</tbody>
						
						<tbody id="poItems">
							
						</tbody>
						
					</table>
				</div>
					
				<div id="formSegment" style="width:93%; margin-top:-5px">
				
					<h5>PO Detail</h5>
					
					<div style="overflow:auto; height:200px">
						<div id="formSegment" style="width:98%">
							<div id="formDataCont" ref="itemList" style="overflow:auto;height:150px; margin-top:-10px">
								<div id="formDataContMenu">
									<label style="font-size:12px">Item List</label>
									<div id="pagingCont">
										<button id="first" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;"></button>
										<button id="prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;"></button>
										<button id="next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;"></button>
										<button id="last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;"></button>
										
									</div>
								</div>
								
								<ul class="gridViewNav">
								
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
	</div>
	
	<div id="formSegment" style="margin-top:0px; margin-left:20px">
		<label>Account Type</label>
		<select id = "accountType">
		</select>
	</div>
	
	<div id="formSegment" style="margin-top:0px">
		<label>Amount</label>
		<input id = "amount" type = "text">
	</div>
	
	<div id="formSegment" style="width:600px; margin-left:20px; margin-top:-2px">
		<label>Description</label>
		<textarea id = "description" style="width:575px; min-height:20px"></textarea>
	</div>
	
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="remove">Remove</button>
		<button class="formButton" id="add">Add</button>
	</div>
	
	<div id="formSegment" style="width:620px; margin-top:10px">
		<div id="formDataCont" style="height:140px; margin-left:10px">				
			<table id="payables">
				<tbody id="header">
					<th>Account Type</th>
					<th>Description</th>
					<th>Amount</th>
				</tbody>
				
				<tbody id="items">
					
				</tbody>
				
			</table>
		</div>
	</div>
	
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	
</div>

<div id="delete_payables" class="modalForm" w=650>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	
</div>

<div id="restore_payables" class="modalForm" w=650>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	
</div>































