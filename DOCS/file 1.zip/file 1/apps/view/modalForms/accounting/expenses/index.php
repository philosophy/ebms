<div id="new_expense" class="modalForm" w=650>
	<div id="modalTitle">Entry Window</div>
	<form method="POST" action="" class="crudOS">	
	<div id="formSegment" style="width:100%; margin-top:3px;">		
		<div id="formSegment" style="width:20%;">	
			<button id="btnImport" style="float:left; width:100px; padding:0px;" class="callModalForm" title="Import from PO">Import from PO</button>
		</div>
		<div id="formSegment" style="width:70%;">	
			<!--<div id="formSegment" style="margin-left: 150px;">	
				<label>Transaction Number:</label>
				<input id = "transactionNumber" type = "text" value="<Auto>"disabled/>
			</div>-->
		</div>
	</div>
	
	<div id="formSegment" style="width:100%; margin-top:-30px;">
		<div id="formSegment" style="width:45%;">
			<label>Name:</label>
			<select id = "empName">
				<option value="0">...</option>
			</select>
			<label>Particular:</label>
			<input id = "particular" type = "text" />
		</div>
		<div id="formSegment" style="float:left;width:45%;">
			<label>Reference #:</label>
			<input id = "refNo" type = "text" disabled/>
			<label>Vendor:</label>
			<select id = "vendor">
				<option value='0'>...</option>
			</select>
		</div>
	</div>
	
	<div id="formSegment" style="width:100%; margin-top:0px;">
		<div id="formSegment" style="width:45%; margin-top:0px;">	
			<label>Account Type</label>
			<select id = "accountType">
			</select>
		
			<label>Amount</label>
			<input id = "amount" type = "text" value="0">
		
			<label>Description</label>
			<textarea id = "description"></textarea>
		
			<button class="formButton" style="float:left; margin-left:56%;" id="add">Add</button>
		</div>
		<div id="formSegment" style="width:45%; margin-top:0px;">
			<div id="formDataCont" style="height:200px">				
				<table id="expense">
					<tbody id="header">
						<th></th>
						<th>Account Type</th>
						<th>Description</th>
						<th>Amount</th>
					</tbody>
					
					<tbody id="poDetails">
						
					</tbody>
					
				</table>
			</div>
		</div>
	</div>
	
	<div id="formSegment" style="width:100%; margin-top:-15px;">
		<div id="formSegment" style="width:45%; margin-top:-25px;">
			<label>Type of Payment:</label>
			<select id = "payment">
				<option val="Cash">Cash</option>
				<option val="Check">Check</option>
			</select>
			<label>Amount:</label>
			<input id = "totalAmount" type = "text" value="0" disabled>
			<label>Bank Name:</label>
			<select id = "bankName" disabled>
				
			</select>
			<label>Account Type:</label>
			<select id = "bankAccountType" disabled>
				
			</select>
			<label>Account Number:</label>
			<select id = "accountNumber" disabled>
				
			</select>
			<label>Account Name:</label>
			<input id = "accountName" type = "text" disabled>
			
		</div>
		<div id="formSegment" style="width:45%;">
			<label>Check Number:</label>
			<input id = "checkNumber" type = "text" disabled>
			<label>Check Type:</label>
			<select id = "checkType" disabled>
				<option value="On-Dated">ON DATED CHECK</option>
				<option value="Post-Dated">POST DATED CHECK</option>
			</select>
			<label>Check Date Issue:</label>
			<input type="text" id="checkDateIssue" datepicker=true maxlength=10 disabled>
			<label>Check Due Date:</label>
			<input type="text" id="checkDueDate" datepicker=true maxlength=10 disabled>
		</div>
	</div>
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
	</form>
</div>

<div id="edit_expense" class="modalForm" w=600>
	<div id="modalTitle">Edit Expense</div>
	<div id="formSegment" style="width:100%; margin-top:3px;">	
	
	</div>
	
	<div id="formSegment" style="width:100%; margin-top:-10px;">
		<div id="formSegment" style="width:45%;">
			<label>Name:</label>
			<select id = "empName">
				<option value="0">...</option>
			</select>
			<label>Particular:</label>
			<input id = "particular" type = "text" />
		</div>
		<div id="formSegment" style="float:left;width:45%;">
				<label>Transaction Number:</label>
				<input id = "transactionNumber" type = "text" value="<Auto>"disabled/>
			<label>Reference #:</label>
			<input id = "refNo" type = "text" disabled/>
		</div>
	</div>
	
	<div id="formSegment" style="width:100%; margin-top:0px;">
		<div id="formSegment" style="width:45%; margin-top:0px;">	
			<label>Type of Payment:</label>
			<input id = "payment" type = "text" value="" disabled>
			<label>Amount:</label>
			<input id = "totalAmount" type = "text" value="0" disabled>
			<label>Bank Name:</label>
			<input id = "bankName" type = "text" disabled>
			<label>Account Type:</label>
			<input id = "bankAccountType" type = "text" disabled>
			<label>Account Number:</label>
			<input id = "accountNumber" type = "text" disabled>
			<label>Account Name:</label>
			<input id = "accountName" type = "text" disabled>
			<label>Check Number:</label>
			<input id = "checkNumber" type = "text" disabled>
			<label>Check Type:</label>
			<input id = "checkType" type = "text" disabled>
			<label>Check Date Issue:</label>
			<input type="text" id="editCheckDateIssue" datepicker=true maxlength=10 disabled>
			<label>Check Due Date:</label>
			<input type="text" id="editCheckDueDate" datepicker=true maxlength=10 disabled>
			<br><br><h5><font color="red">Particular and employee fields are the only editable fields.</font></h5>
		</div>
		<div id="formSegment" style="width:45%; margin-top:0px;">
			<div id="formDataCont" style="height:275px">				
				<table id="expense">
					
				</table>
			</div>
		</div>
	</div>
	<div id="formSegment" style="margin-top:0px" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
	</div>
</div>
