
<!--form for Create/Edit OS-->
<div id="new_OS" class="modalForm" w=1000>
	<div id="modalTitle">Order Slip</div>
	<form method="POST" action="" class="crudOS">
		
		<div id="formSegment">
		<h5>Customer Information</h5>
			<label>Customer</label>
				<select id = "customer">
				</select>
			<label>Location</label>
				<select id = "location">
				</select>
		</div>
		
		
		<div id="formSegment">
		<h5>Other Information</h5>
			<label>Sales Person</label>
				<input type="text" id="salesPerson">
			
			<label>Remarks</label>
				<textarea id="remarks"></textarea>
			
		</div>
		
		
		<div id="formSegment">
		<h5>Payment Information</h5>
			
			<input type="number" id="terms" style="width:70px">
			<br/>
			<input type="number" id="deposit" style="width:70px">
			<br/>
			<label>Gross Amount</label>
			<input type="text" id="grossAmount">
			
			<label>Net Amount</label>
			<input type="text" id="netAmount">
			
			<label>
			<input type="checkbox" id="is_discounted">
			Discount(%)
			</label>
			<input type="number" id="discount" style="width:70px">
		</div>
		
		<div id="formSegment" style="width:55%;margin-top:-20px">
		<h5>Product List</h5>
			<div id="formDataCont" ref="orderItemsList" style="overflow:hidden;height:230px;">
			<div id="formDataContMenu">
				<input type="text" id="formDataContSearch" value="Search">
				<div id="pagingCont">
					<button id="first" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;"></button>
					
				</div>
			</div>
				<ul class="gridViewNav">
				</ul>
					
			</div>
			
		</div>
		
		<div id="formSegment" style="width:40%;margin-top:-20px">
		<h5>Ordered Items</h5>
			<div id="formDataCont" style="height:230px;">
				<table>
					<th>Quantity</th>
					<th>Unit Price</th>
					<th>Stock on Hand</th>
					<th>Item Description</th>
					
					<tbody id="orderedItems">
						
					</tbody>
					
				</table>
			</div>
		</div>
		
		<div class="itemDetails">
		<label class="itemCode">Item Code</label>
		<span class="itemDesc">Sample sample</span>
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>

<!--form for Create/Edit DR-->




<div id="import_OS" class="modalForm" w=650>
	
	<div id="modalTitle">Delivery Receipt</div>
	<form method="POST" action="">
		
		<div id="formSegment">
		<h5>Delivery Receipt Information</h5>
			
			<label>DR No.</label>
			<input type="text" id="drNo">
			
			<label>Reference No.</label>
			<input type="text" id="refNo">
			
			<label>Delivered By<span>*</span></label>
			<select id="deliveredBy">
				<option value="">...</option>
			</select>
			<label>Sales Person</label>
			<input type="text" id="salesPerson">
			
		</div>
		
		<div id="formSegment">
		<h5>Customer Information</h5>
			<label>Customer</label>
			<select id="customer">
				<option value="">...</option>
			</select>
			<label>City</label>
			<select id="city">
				<option value="">...</option>
			</select>
			
			<label>Barangay</label>
			<select id="barangay">
				<option value="">...</option>
			</select>
			
			<label>Address</label><textarea id="address"></textarea>
			
			<label>Area</label>
			<select id="area1">
				<option value="">...</option>
			</select>
			
			
		</div>
		
		<div id="formSegment">
		<h5>Other Information</h5>
		
		<label>Location<span>*</span></label>
			<select id="location">
				<option value="">...</option>
			</select>
		<label>Ship To</label>
			<textarea id="shipTo"></textarea>
		
		<label>Area<span>*</span></label>
			<select id="area2">
				<option value="">...</option>
			</select>
			
			
		<label>Attention<span>*</span></label>
			<select id="contact">
				<option value="">...</option>
			</select>
		</div>
		
		<div id="formSegment">
		<h5>Ordered Item</h5>
			<div id="formDataCont">
				<table>
					<th>Qty</th>
					<th>Item Code</th>
					<th>Unit Price</th>
					<th>Item Description</th>
					<tbody id="orderedItems">						
					</tbody>	
				</table>
			</div>
		</div>
		
		<div id="formSegment">
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
		<label>Gross Amount</label>
		<input type="text" id="grossAmount">
		
		<label>Discount</label>
		<input type="text" id="discount">
		
		<label>Net Amount</label>
		<input type="text" id="netAmount">
		
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>












<div id="new_dr" class="modalForm" w=650>
	
	<div id="modalTitle">Delivery Receipt</div>
	<form method="POST" action="">
		
		<div id="formSegment">
		<h5>Delivery Receipt Information</h5>
			
			<label>DR No.</label>
			<input type="text" id="drNo">
			
			<label>Reference No.</label>
			<input type="text" id="refNo">
			
			<label>Delivered By</label>
			<input type="text" id="deliveredBy">
			
			<label>Sales Person</label>
			<input type="text" id="salesPerson">
			
		</div>
		
		<div id="formSegment">
		<h5>Customer Information</h5>
			<label>Customer</label>
			<input type="text" id="customer">
			
			<label>City</label>
			<select id="city">
				<option value="">...</option>
			</select>
			
			<label>Barangay</label>
			<select id="barangay">
				<option value="">...</option>
			</select>
			
			<label>Address</label><textarea id="address"></textarea>
			
			<label>Area</label>
			<select id="area">
				<option value="">...</option>
			</select>
			
			
		</div>
		
		<div id="formSegment">
		<h5>Other Information</h5>
		
		<label>Location</label>
			<input type="text" id="location">
			
		<label>Ship To</label>
			<textarea id="shipTo"></textarea>
		
		<label>Area</label>
			<input type="text" id="area">
			
		<label>Attention</label>
			<input type="text" id="attention">
		</div>
		
		<div id="formSegment">
		<h5>Ordered Item</h5>
			<div id="formDataCont">
			</div>
		</div>
		
		<div id="formSegment">
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
		<label>Gross Amount</label>
		<input type="text" id="grossAmount">
		
		<label>Discount</label>
		<input type="text" id="discount">
		
		<label>Net Amount</label>
		<input type="text" id="netAmount">
		
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>

<div id="edit_dr" class="modalForm" w=650>
	<div id="modalTitle">Delivery Receipt</div>
	<form method="POST" action="">
		
		<div id="formSegment">
		<h5>Delivery Receipt Information</h5>
			
			<label>DR No.</label>
			<input type="text" id="drNo">
			
			<label>Reference No.</label>
			<input type="text" id="refNo">
			
			<label>Delivered By<span>*</span></label>
			<select id="deliveredBy">
				<option value="">...</option>
			</select>
			<label>Sales Person</label>
			<input type="text" id="salesPerson">
			
		</div>
		
		<div id="formSegment">
		<h5>Customer Information</h5>
			<label>Customer</label>
			<select id="customer">
				<option value="">...</option>
			</select>
			<label>City</label>
			<select id="city">
				<option value="">...</option>
			</select>
			
			<label>Barangay</label>
			<select id="barangay">
				<option value="">...</option>
			</select>
			
			<label>Address</label><textarea id="address"></textarea>
			
			<label>Area</label>
			<select id="area1">
				<option value="">...</option>
			</select>
			
			
		</div>
		
		<div id="formSegment">
		<h5>Other Information</h5>
		
		<label>Location<span>*</span></label>
			<select id="location">
				<option value="">...</option>
			</select>
		<label>Ship To</label>
			<textarea id="shipTo"></textarea>
		
		<label>Area<span>*</span></label>
			<select id="area2">
				<option value="">...</option>
			</select>
			
			
		<label>Attention<span>*</span></label>
			<select id="contact">
				<option value="">...</option>
			</select>
		</div>
		
		<div id="formSegment">
		<h5>Ordered Item</h5>
			<div id="formDataCont">
				<table>
					<th>Qty</th>
					<th>Item Code</th>
					<th>Unit Price</th>
					<th>Item Description</th>
					<tbody id="orderedItems">						
					</tbody>	
				</table>
			</div>
		</div>
		
		<div id="formSegment">
		<label>Remarks</label>
		<textarea id="remarks"></textarea>
		
		<label>Gross Amount</label>
		<input type="text" id="grossAmount">
		
		<label>Discount</label>
		<input type="text" id="discount">
		
		<label>Net Amount</label>
		<input type="text" id="netAmount">
		
		</div>
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>

	<div id="delete_OS" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
	<div id="delete_dr" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to delete?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Delete</button>
	</div>
	</div>
	
	
	<div id="restore_OS" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>
	
	<div id="restore_dr" class="modalForm" w=500>
	<div id="formSegment">
		<h4>Are you sure you want to restore?</h4>
	</div>
	<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Restore</button>
	</div>
	</div>
	
	
<div id="edit_OS" class="modalForm" w=9000>
	<div id="modalTitle">Order Slip</div>
	<form method="POST" action="" class="crudOS">
		
		<div id="formSegment">
		<h5>Customer Information</h5>
			<label>Customer</label>
				<select id = "customer">
				</select>
			<label>Location</label>
				<select id = "location">
				</select>
		</div>
		
		
		<div id="formSegment">
		<h5>Other Information</h5>
			<label>Sales Person</label>
				<input type="text" id="salesPerson">
			
			<label>Remarks</label>
				<textarea id="remarks"></textarea>
			
		</div>
		
		
		<div id="formSegment">
		<h5>Payment Information</h5>
			<label>Terms</label>
			<input type="number" id="terms" style="width:70px">
			<br/>
			<label>Deposit</label>
			<input type="number" id="deposit" style="width:70px">
			<br/>
			<label>Gross Amount</label>
			<input type="text" id="grossAmount">
			
			<label>Net Amount</label>
			<input type="text" id="netAmount">
			
			<label>
			<input type="checkbox" id="is_discounted">
			Discount(%)
			</label>
			<input type="number" id="discount" style="width:70px">
		</div>
		
		<div id="formSegment" style="width:55%;margin-top:-20px">
		<h5>Product List</h5>
			<div id="formDataCont" ref="orderItemsList" style="overflow:auto;height:230px;">
			<div id="formDataContMenu">
				<input type="text" id="editFormDataContSearch" value="Search">
				<div id="pagingCont">
					<button id="first" style="background:url('/EBMS/images/icons/first-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="prev" style="background:url('/EBMS/images/icons/prev-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="next" style="background:url('/EBMS/images/icons/next-icon.png') no-repeat;background-size:100% 100%;"></button>
					<button id="last" style="background:url('/EBMS/images/icons/last-icon.png') no-repeat;background-size:100% 100%;"></button>
					
				</div>
			</div>
				<ul class="gridViewNav">
				</ul>
					
			</div>
			
		</div>
		
		<div id="formSegment" style="width:40%;margin-top:-20px">
		<h5>Ordered Items</h5>
			<div id="formDataCont" style="height:230px;">
				<table>
					<th>Quantity</th>
					<th>Unit Price</th>
					<th>Stock on Hand</th>
					<th>Item Description</th>
					
					<tbody id="orderedItems">
						
					</tbody>
					
				</table>
			</div>
		</div>
		
		
		<div id="formSegment" class="buttonPanel">
		<button class="formButton" id="cancel">Cancel</button>
		<button class="formButton" id="save">Save</button>
		</div>
	</form>
	

</div>
