
<script>
	
	$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseOrder/soldToList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
			$("#poSoldTo").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseOrder/supplierList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
			$("#poSupplier").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseOrder/refNoList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
			$("#cboRefNo").html(response);
			}
			
		});
</script>