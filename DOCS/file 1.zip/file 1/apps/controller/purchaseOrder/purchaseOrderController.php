<script>

var init,page;

var searchQuery="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	$("#new").attr('title', 'New Purchase Order Record');
	$('#edit').attr('title', 'Edit Purchase Order Record');
	$('div.datagrid-crud-menu #delete').attr('title', 'Delete Purchase Order Record');
	$('div.datagrid-crud-menu #restore').attr('title', 'Restore Purchase Order Record');
	
	$('#edit').attr('disabled',true);
	$('div.datagrid-crud-menu #delete').attr('disabled',true);
	$('div.datagrid-crud-menu #restore').attr('disabled',true);
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	$.ajax({
		url:'/EBMS/apps/view/purchasing/purchaseOrder/poList.php', 
		type: "POST",
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]);
				
			$('#purchaseOrder').html(arrResponse[0]);
			datagrid('purchaseOrder', true);
			setPageResponse(arrResponse[1]);
				
			$("#purchaseOrder table tr").click(function()
			{
			setCellContentValue($(this));
						
			});
			
			}
			});
}

			
			$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
						
					});
			
	$('#new_po #save').click(function(){
	
		var dateNeeded = $('#new_po #poDateNeeded').val();
		var soldTo = $('#new_po #poSoldTo').val();
		var supplier = $('#new_po #poSupplier').val();
		var suppname = $('#new_po #poSupplier').text();
		var paymentType = $('#new_po #poPaymentType').val();
		var terms = $('#new_po #poTerms').val();
		var disc = ($('#new_po #poGrossAmount').val()*($('#new_po #poDiscount').val()/100));
		var gross = $('#new_po #poGrossAmount').val();
		var net = $('#new_po #poNetAmount').val();
		var remarks = $('#new_po #poRemarks').val();
		
		if($('#new_po #poDateNeeded').val()=="")
		{
			alert("Please specify the date.");
		}
		else if($('#new_po #formDataCont table tr').length == 1)
		{
			alert("Please select item/s to be purchased.");
		}
		else
		{
			var poHeaderDataString = "dateNeeded="+dateNeeded+"&soldToId="+soldTo+"&supplier="+supplier+"&paymentType="+paymentType+"&terms="+terms+"&disc="+disc+"&gross="+gross+"&net="+net+"&remarks="+remarks+"&suppname="+suppname;
			$.ajax({
			url:"/ebms/apps/view/purchasing/purchaseOrder/insertPOHeader.php",
			type:"POST",
			data: poHeaderDataString,
			cache: false,
			success:
				function(response)
				{
			
					$('#new_po #orderedItems tr').map(function(index) {
						// var testArray = new Array();
						// testArray[index] = $(this).find("#qty").val()+$(this).text();
						// prItems = testArray[index].split(';');
						
						// qty = prItems[0];
						// unit = prItems[1];
						// refno = prItems[2];
						// code = prItems[3];
						// desc = prItems[6];
					
						var poDetailDataString = "qty=" + $(this).find('#qty').val() + "&unit=" + $(this).find('#itemUnit').text() + "&refno=" + $(this).find('#refNo').text() + "&code=" + $(this).find('#itemCode').text() + "&desc=" + $(this).find('#itemDesc').text();
						$.ajax({
							url:"/ebms/apps/view/purchasing/purchaseOrder/insertPODetail.php",
							type:"POST",
							data: poDetailDataString,
							cache: false,
							success:
								function(response)
								{
							
								}
						});
					
					});
					
					dataString = "role=" + "New" + "&noun=" + "Purchase order record";
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
						
						}
					});
					
					alert('Purchase Order successfully created!');
					$('#new_po #poDateNeeded').val('');
					$('#new_po #poRemarks').val('');
					$('#new_po #poTerms').val(0);
					$('#new_po #poGrossAmount').val(0);
					$('#new_po #poNetAmount').val(0);
					$('#new_po #poDiscount').val(0);
					$('#new_po #orderedItems').html('');
					loadData(1,searchQuery);
						$("div#new_po.modalForm").fadeOut("slow",0,
							function()
							{
								$(".formFade").fadeOut(300,
									function(){
										$(".formFade").remove();
									});
								$("div#new_po.modalForm").hide();
						
							});
				}
			});
		}
		
	});
	
	$('#edit_po #save').click(function(){

		var dateNeeded = $('#edit_po #poEditDateNeeded').val();
		var paymentType = $('#edit_po #poPaymentType').val();
		var terms = $('#edit_po #poTerms').val();
		var gross = $('#edit_po #poGrossAmount').val();
		var net = $('#edit_po #poNetAmount').val();
		var disc = ($('#edit_po #poGrossAmount').val()*($('#edit_po #poDiscount').val()/100));
		var remarks = $('#edit_po #poRemarks').val();
		var id = $('#edit').attr('poCode');
		
		
		var poEditHeaderDataString = "dateNeeded="+dateNeeded+"&paymentType="+paymentType+"&terms="+terms+"&disc="+disc+"&gross="+gross+"&net="+net+"&remarks="+remarks+"&id="+id;
		$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseOrder/editPOHeader.php",
		type:"POST",
		data: poEditHeaderDataString,
		cache: false,
		success:
			function(response)
			{
				$('#edit_po #orderedItems tr').map(function(index) {
						var testArray = new Array();
						testArray[index] = $(this).find("#qty").val()+$(this).text();
						prItems = testArray[index].split(';');
						
						qty = prItems[0];
						refno = prItems[2];
						code = prItems[3];
						var id = $('#edit').attr('poCode');
					
						var poEditDetailDataString = "qty="+qty+"&refno="+refno+"&code="+code+"&id="+id;
						$.ajax({
							url:"/ebms/apps/view/purchasing/purchaseOrder/editPODetails.php",
							type:"POST",
							data: poEditDetailDataString,
							cache: false,
							success:
								function(response)
								{
								}
						});
					
					});
					
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
					type:"POST",
					data:"module=" + "Purchase Order" + "&id=" + editPoId,
					success:
					function(response)
					{
						dataString = "role=" + "Edit" + "&noun=" + "Purchase order record" + "&code=" + response;
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
								
							}
						});
					}
				});
					
				alert("Purchase Order record succesfully updated!");
				loadData(1,searchQuery);
				$('#itemDetails').html('');
				$("div#edit_po.modalForm").fadeOut("slow",0,
				function()
				{
					$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
					$("div#edit_po.modalForm").hide();
						
				});
			}
		});
		
	});
	
	
	function setCellContentValue(selector)
	{
		if ($(selector).attr("deleted") == "false")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",false);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
		}
		else if ($(selector).attr("deleted") == "true")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",false);
		}
		
		//remove all active classes in tr element
		$("#purchaseOrder table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		$("#edit").attr("poCode",$(selector).attr("a"));
		$("#delete_po #delete").attr("poCode",$(selector).attr("a"));
		$("#restore_po #restore").attr("poCode",$(selector).attr("a"));
		editPoId = $(selector).attr('a');
		// alert(editPoId);
		
		if ($(selector).attr("b") == '0')
		{
			$('#edit').attr('disabled',false);
		}
		else
		{
			$('#edit').attr('disabled',true);
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
		}
		
		
		
		$('#delete_po #delete').click(function()
		{
			$.post('../../../controller/purchaseOrder/poDelete.php',{poCode:$(this).attr('poCode')},
				function()
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Purchase Order" + "&id=" + editPoId,
						success:
						function(response)
						{
							dataString = "role=" + "Delete" + "&noun=" + "Purchase order record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									
								}
							});
						}
					});
				
					$("div#delete_po.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#delete_po.modalForm").hide();
					});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#restore_po #restore').click(function()
		{
			$.post('../../../controller/purchaseOrder/poRestore.php',{poCode:$(this).attr('poCode')},
				function()
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Purchase Order" + "&id=" + editPoId,
						success:
						function(response)
						{
							dataString = "role=" + "Restore" + "&noun=" + "Purchase order record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									
								}
							});
						}
					});
				
					$("div#restore_po.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#restore_po.modalForm").hide();
					});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$.post('/EBMS/apps/view/purchasing/purchaseOrder/poDetails.php', {poCode:$(selector).attr('a')},
		function(response)
		{
			$('#itemDetails').html(response);
			datagrid('itemDetails', true);
		});
		
		
		$('#edit').click(function()
		{
			// alert('click');
			$.post('../../purchasing/purchaseOrder/headerFill.php',{poCode:$(this).attr('poCode')},function(response){ 
					
					
					// alert(response);
					obj = JSON.parse(response);
					$("div#edit_po #poNo").val(obj.values["code"]);
					$("div#edit_po #poSoldTo").val(obj.values["soldTo"]);
					$("div#edit_po #poDate").val(obj.values["dateRequested"]);
					$("div#edit_po #poEditDateNeeded").val(obj.values["dateNeeded"]);
					$("div#edit_po #poRemarks").val(obj.values["remarks"]);
					$("div#edit_po #poSupplier").val(obj.values["supp"]);
					$("div#edit_po #poTerms").val(obj.values["terms"]);
					$("div#edit_po #poGrossAmount").val(obj.values["gross"]);
					$("div#edit_po #poNetAmount").val(obj.values["net"]);
					$("div#edit_po #poDiscount").val(obj.values["discPercent"]);

					$.post('../../purchasing/purchaseOrder/detailFill.php',{poCode:$("#edit").attr('poCode')},function(response){
						$("#edit_po #orderedItems").html(response);
						
						$("#edit_po #orderedItems").find("#qty").focus(function(){
						
							var select = $(this).attr("select");
								
								$("#edit_po #orderedItems").find("#qty[select='"+select+"']").bind("keyup input",	function(){
									if($(this).val() == "0")
									{
										$(this).val(1);
									}
									var temp = 0;
									$('#edit_po #orderedItems tr').map(function(index) {
										// var testArray = new Array();
										// testArray[index] = $(this).find("#qty").val()+$(this).text();
										// prItems = testArray[index].split(';');
										// qty = prItems[0];
										// price = prItems[4].replace(/,/g, "");
										
										qty = $(this).find('#qty').val();
										price = $(this).find('#itemPrice').text().replace(/,/g, "")
							
										var gross = (parseFloat(qty)) * (parseFloat(price));
						
										temp = temp + gross;
										gross = 0;
							
										$('#edit_po #poGrossAmount').val(parseFloat(temp));
									
										discAmount = ($('#edit_po #poGrossAmount').val()*($('#edit_po #poDiscount').val()/100));
										$('#edit_po #poNetAmount').val($('#edit_po #poGrossAmount').val()-discAmount);
									
									});
						
						
								});	
							
						});
						
					});
			});
		});
	}

</script>