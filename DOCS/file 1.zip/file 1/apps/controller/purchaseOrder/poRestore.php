<?php
session_start();
include("../../../config/config.php");

$poCode = $_POST['poCode'];

mysql_query("UPDATE po_header SET is_deleted = '0' WHERE po_hdr_id='".$poCode."'");
?>