<script>
		$(document).ready(function(){
		$("#new").click(function()
		{
			$('#new_po #poGrossAmount').val("0");
			$('#new_po #poNetAmount').val("0");
			$('#new_po #poRemarks').val("");
			$('#new_po #poDiscount').val("0");
			$('#new_po #poTerms').val("0");
			$('#new_po #poDateNeeded').val("");
			$("#orderedItems").html("");
			itemList($("#cboRefNo").val());
		});
		
		inputMask("formDataContSearch","Search");
		
		
		
		var discAmount = 0;
		var temp = 0;
		
		itemList($("#cboRefNo").val());
		$("#cboRefNo").change(function(){
			itemList($("#cboRefNo").val());
		});
		
		$('#new_po #poDiscount').keyup(function(){
		
			if($(this).val() > 100)
			{
				$(this).val(100);
			}
			else if($(this).val() < 0)
			{
				$(this).val(100);
			}
			else if($(this).val() == "")
			{
				$(this).val(0);
			}
			
			discAmount = ($('#new_po #poGrossAmount').val()*($('#new_po #poDiscount').val()/100));
			$('#new_po #poNetAmount').val($('#new_po #poGrossAmount').val()-discAmount);
		});
		
		$('#edit_po #poDiscount').keyup(function(){
		
			if($(this).val() > 100)
			{
				$(this).val(100);
			}
			else if($(this).val() < 0)
			{
				$(this).val(100);
			}
			else if($(this).val() == "")
			{
				$(this).val(0);
			}
			
			discAmount = ($('#edit_po #poGrossAmount').val()*($('#edit_po #poDiscount').val()/100));
			$('#edit_po #poNetAmount').val($('#edit_po #poGrossAmount').val()-discAmount);
		});
		
		var ctr = 0;
		function itemList(type)
		{
		ctr++;
		var dataString = "cboRefNo="+type;
		$.ajax({
			url:"/ebms/apps/view/purchasing/purchaseOrder/purchaseItemList.php",
			type:"POST",
			data:dataString,
			success:
			function(response){
			$("div#new_po div[ref=orderItemsList] ul").html(response);
				
				$("div#new_po div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function(){
					
					$(this).trigger("click");
					return false;
					
				});
				
				var code = "", desc = "", refno = "";
				$("div#new_po div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						code = $(this).attr("code");
						desc = $(this).attr("desc");
						refno = $(this).attr("refno");
						
						if($("div#new_po #orderedItems").find("tr[code="+code+refno+"] td").size() > 0)
						{
						
						$("div#new_po #orderedItems tr td").removeClass("itemActive");
						$("div#new_po #orderedItems").find("tr[code="+code+refno+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("div.itemDetails").stop().animate({bottom:"10px",opacity:0.8},"1000").show();
						
						
						},function(){
						
						if($("div#new_po #orderedItems").find("tr[code="+code+refno+"] td").size() > 0)
						$("div#new_po #orderedItems").find("tr[code="+code+refno+"] td").removeClass("itemActive");
						
						$("div#new_po div.itemDetails").stop().animate({bottom:"0px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
						
				$("div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function(){
						
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						
						if($(this).find(".addItem").css("display") == "none")
						{
						var code = $(this).attr("code");
						var unitPrice = $(this).attr("unitPrice");
						var desc = $(this).attr("desc");
						var unit = $(this).attr("unit");
						var cat = $(this).attr("cat");
						var refno = $(this).attr("refno");
						var qty = $(this).attr("qty");
						
							$("#orderedItems").append("<tr code='"+code+refno+"'><td><input type='number' id='qty' value="+qty+"></td><td id='itemUnit'>"+unit+"</td><td id='refNo'>"+refno+"</td><td id='itemCode'>"+code+"</td><td id='itemPrice'>"+unitPrice+"</td><td id='itemCategory'>"+cat+"</td><td id='itemDesc'>"+desc+"</td></tr>");
							
							
							$("#new_po #orderedItems").find("tr[code='"+code+refno+"'] input").bind("keyup input",function(){
								if($(this).val() == "0")
								{
									$(this).val(1);
								}
						
								temp = 0;
								$('#new_po #orderedItems tr').map(function(index) {
									// var testArray = new Array();
									// testArray[index] = $(this).find("#qty").val()+$(this).text();
									// prItems = testArray[index].split(';');
						
									// qty = prItems[0];
									// price = prItems[4].replace(/,/g, "");
									
									qty = $(this).find('#qty').val();
									price = $(this).find('#itemPrice').text().replace(/,/g, "");
							
									var gross = (parseFloat(qty)) * (parseFloat(price));
						
									temp = temp + gross;
									gross = 0;
							
									$('#new_po #poGrossAmount').val(parseFloat(temp));
									
									discAmount = ($('#new_po #poGrossAmount').val()*($('#new_po #poDiscount').val()/100));
									$('#new_po #poNetAmount').val($('#new_po #poGrossAmount').val()-discAmount);
									
								});
								
							});
						}
						
						//eto yung pagpasok
						temp = 0;
						$('#new_po #orderedItems tr').map(function(index) {
							// var testArray = new Array();
							// testArray[index] = $(this).find("#qty").val()+$(this).text();
							// prItems = testArray[index].split(';');
							
							
							qty = $(this).find('#qty').val();
							price = $(this).find('#itemPrice').text().replace(/,/g, "");
							
							
							var gross = (parseFloat(qty)) * (parseFloat(price));
						
							temp = temp + gross;
							gross = 0;
						
							$('#new_po #poGrossAmount').val(parseFloat(temp));
							$('#new_po #poNetAmount').val($('#new_po #poGrossAmount').val()-discAmount);
							discAmount = ($('#new_po #poGrossAmount').val()*($('#new_po #poDiscount').val()/100));
							$('#new_po #poNetAmount').val($('#new_po #poGrossAmount').val()-discAmount);
						});
						
						
						
						$(this).hover(function(){
						
						
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						},function(){
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						}
						
						else
						{
						
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						});
						
						
				return false;	
				},
				function()
				{
				var code = $(this).attr("code");
				var refno = $(this).attr("refno");
				
					//kapag tinanggal
					$("#orderedItems").find("tr[code="+code+refno+"]").fadeOut("fast",
						function()
						{
							if($('#new_pr #formDataCont table tr').length == 1)
							{
								$('#new_po #poGrossAmount').val(0);
								$('#new_po #poNetAmount').val($('#new_po #poGrossAmount').val());
								temp = 0;
							}
							
							$("#orderedItems").find("tr[code="+code+refno+"]").remove();
							
						
							$('#new_po #orderedItems tr').map(function(index) {
							// var testArray = new Array();
							// testArray[index] = $(this).find("#qty").val()+$(this).text();
							// prItems = testArray[index].split(';');
						
							qty = $(this).find('#qty').val();
							price = $(this).find('#itemPrice').text().replace(/,/g, "")
							
							var gross = (parseFloat(qty)) * (parseFloat(price));
						
							temp = temp + gross;
							gross = 0;
							
							$('#new_po #poGrossAmount').val(parseFloat(temp));
							discAmount = ($('#new_po #poGrossAmount').val()*($('#new_po #poDiscount').val()/100));
							$('#new_po #poNetAmount').val($('#new_po #poGrossAmount').val()-discAmount);
							
							});
						});

						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						
				});
				
				if(ctr > 1)
				{
					var arr1 = new Array(),arr2 = new Array(),arr3 = new Array();
					$("div#new_po div[ref=orderItemsList] ul li a").each(function(index){

					var itemListCode = $(this).attr("code");
					var itemListRefNo = $(this).attr("refno");
					arr1[index] = itemListCode+itemListRefNo;
					arr3[index] = itemListCode;

				});	

				$("div#new_po #orderedItems tr").each(function(index)
				{
					var orderedItemsCode = $(this).attr("code");
					arr2[index] = orderedItemsCode;
				});

				for(i=0;i<arr1.length;i++)
				{
					for(x=0;x<arr2.length;x++)
					if(arr1[i] == arr2[x])
					{
						$("div#new_po div[ref=orderItemsList] ul li a[code='"+arr3[i]+"']").click();
						$("div#new_po #orderedItems").find("tr[code="+arr1[i]+"]:last-child").remove();
					}
				}
				}
				
				
			}
		});
		}
		
		});
</script>
