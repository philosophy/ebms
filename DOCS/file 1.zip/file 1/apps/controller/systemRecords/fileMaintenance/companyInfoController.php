<script>

$(document).ready(function(){
	
	dbRequest("role=VIEW");
	
	$("#saveBtn").click(function(){
	var compName = $("#compName").val().trim();
	var compAddress = $("#compAddress").val().trim();
	var compPhoneNo = $("#compPhoneNo").val().trim();
	var compMobileNo = $("#compMobileNo").val().trim();
	var compFaxNo = $("#compFaxNo").val().trim();
	var compEmail = $("#compEmail").val().trim();
	var compWebsite = $("#compWebsite").val().trim();
	var tmp = $("#compLogo").val().trim();

	var compLogo = tmp.replace(/C:\\fakepath\\/i, '');
	
	
	$("#compLogo").submit();

	var dataString = "role=SAVE"+"&compName="+compName+"&compAddress="+compAddress+"&compPhoneNo="+compPhoneNo+"&compMobileNo="+compMobileNo+"&compFaxNo="+compFaxNo+"&compEmail="+compEmail+"&compWebsite="+compWebsite+"&compLogo="+compLogo;
	
	if(compLogo != "")
	{
	dbRequest(dataString);
	}
	
	else 
	{
	alert("Please upload an image for your company logo");
	}
	
	return false;
	});
	
	$("#editBtn").click(function(){
		
		$("#formContent").find("input,textarea").attr("disabled",false);
		
	});
	
	$("#cancelBtn").click(function(){
		$("#formContent").find("input,textarea").attr("disabled",true);
	});
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/companyInformation/companyInfo.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			if(response == "SAVE")
			{
			alert("Company Information Successfully Saved");
			
			if($("#compLogo").val().trim() != "")
			$("#logo").ajaxForm().submit();
			
			}
			
			else 
			{
				obj = JSON.parse(response);
			
			$("#compName").val(obj.data['compName']);
			$("#compAddress").val(obj.data['compAddress']);
			$("#compPhoneNo").val(obj.data['compPhoneNo']);
			$("#compMobileNo").val(obj.data['compMobileNo']);
			$("#compFaxNo").val(obj.data['compFaxNo']);
			$("#compEmail").val(obj.data['compEmail']);
			$("#compWebsite").val(obj.data['compWebsite']);
			
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>