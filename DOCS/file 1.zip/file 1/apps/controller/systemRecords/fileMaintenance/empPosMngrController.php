<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var deptID = $("#deptID").val().trim();
	var empPosID = $("#empPosID").val().trim();
	var empPosName = $("#empPosName").val().trim();
	var empPosDesc = $("#empPosDesc").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&deptID="+deptID+"&empPosID="+empPosID+"&empPosName="+empPosName+"&empPosDesc="+empPosDesc;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var empPosID = $(this).attr("empPosID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&empPosID="+empPosID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var empPosID = $(this).attr("empPosID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&empPosID="+empPosID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#empPosName").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#deptID").attr("disabled",false);
		$("#empPosName").attr("disabled",false);
		$("#empPosDesc").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
		$("#deptID").attr("disabled",true);
		$("#empPosName").attr("disabled",true);
		$("#empPosDesc").attr("disabled",true);
		$("#saveBtn").attr("disabled",true);
		$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/employeePositionManager/employeePositionManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#deptID").val("");
			$("#empPosID").val("");
			$("#empPosName").val("");
			$("#empPosDesc").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Employee Status record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Employee Status record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Employee Status record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Employee Status successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("empPosID",$(this).attr("empPosID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("empPosID",$(this).attr("empPosID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#empPosName").val($(this).attr("empPosName"));
				$("#deptID").val($(this).attr("deptID"));
				$("#empPosID").val($(this).attr("empPosID"));
				$("#empPosDesc").val($(this).attr("empPosDesc"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>