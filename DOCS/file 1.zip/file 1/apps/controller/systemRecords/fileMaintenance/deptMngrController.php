<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var deptID = $("#deptID").val().trim();
	var deptCode = $("#deptCode").val().trim();
	var deptName = $("#deptName").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&deptID="+deptID+"&deptName="+deptName+"&deptCode="+deptCode;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var deptID = $(this).attr("deptID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&deptID="+deptID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var deptID = $(this).attr("deptID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&deptID="+deptID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#deptName").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#deptName").attr("disabled",false);
		$("#deptCode").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#deptName").attr("disabled",true);
			$("#deptCode").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/departmentManager/departmentManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#deptID").val("");
			$("#deptCode").val("");
			$("#deptName").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Department record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Department record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Department record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Department successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("deptID",$(this).attr("deptID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("deptID",$(this).attr("deptID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#deptName").val($(this).attr("deptName"));
				$("#deptCode").val($(this).attr("deptCode"));
				$("#deptID").val($(this).attr("deptID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>