<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var areaTypeID = $("#areaTypeID").val().trim();
	var areaTypeName = $("#areaTypeName").val().trim();
	var areaTypeDesc = $("#areaTypeDesc").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&areaTypeID="+areaTypeID+"&areaTypeName="+areaTypeName+"&areaTypeDesc="+areaTypeDesc;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var areaTypeID = $(this).attr("areaTypeID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&areaTypeID="+areaTypeID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var areaTypeID = $(this).attr("areaTypeID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&areaTypeID="+areaTypeID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#areaTypeID").val("");
		$("#areaTypeName").val("");
		$("#areaTypeDesc").val("");
		$("#editBtn").attr("disabled",true);
		$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#areaTypeName").attr("disabled",false);
		$("#areaTypeDesc").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
	}
	
	function fieldDisable()
	{
			$("#areaTypeName").attr("disabled",true);
			$("#areaTypeDesc").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/areaTypeManager/areaTypeManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#areaTypeID").val("");
			$("#areaTypeName").val("");
			$("#areaTypeDesc").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Area Type record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Area Type record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Area Type record successfully deleted");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",true);
			$("#deleteBtn").attr("disabled",true);
			$("#restoreBtn").attr("disabled",false);
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Area Type record successfully restored");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",false);
			$("#deleteBtn").attr("disabled",false);
			$("#restoreBtn").attr("disabled",true);
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("areaTypeID",$(this).attr("areaTypeID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("areaTypeID",$(this).attr("areaTypeID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#areaTypeName").val($(this).attr("areaTypeName"));
				$("#areaTypeDesc").val($(this).attr("areaTypeDesc"));
				$("#areaTypeID").val($(this).attr("areaTypeID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>