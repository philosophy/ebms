<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var acctSubCatID = $("#acctSubCatID").val().trim();
	var acctTypeID = $("#acctTypeID").val().trim();
	var acctCatID = $("#acctCatID").val().trim();
	var acctSubCatName = $("#acctSubCatName").val().trim();
	var allowDelete;
	
		
		if($("#allowDelete").is(":checked"))
		{
			allowDelete = 1;
		}
	
		else
		{
			allowDelete = 0;
		}
	
	//alert(allowDelete);
	var dataString = "role="+($(this).attr("role"))+"&acctSubCatID="+acctSubCatID+"&acctTypeID="+acctTypeID+"&acctCatID="+acctCatID+"&acctSubCatName="+acctSubCatName+"&allowDelete="+allowDelete;
	
	dbRequest(dataString);
	
	return false;
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#acctCatID").val("");
		$("#acctTypeID").val("");
		$("#acctSubCatName").val("");
		$("#allowDelete").removeAttr("checked");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
		$("#acctCatID").attr("disabled",false);
		$("#acctTypeID").attr("disabled",false);
		$("#allowDelete").attr("disabled",false);
		$("#acctSubCatName").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#acctCatID").attr("disabled",true);
			$("#acctTypeID").attr("disabled",true);
			$("#allowDelete").attr("disabled",true);
			$("#acctSubCatName").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/accountSubCategoryManager/accountSubCategoryManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			//alert(dataString);
			
			$("#acctCatID").val("");
			$("#acctTypeID").val("");
			$("#allowDelete").removeAttr("checked");
			$("#acctSubCatName").val("");
		
			//$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Account sub category successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Account sub category record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			/*
			else if(response == "delete")
			{
			alert("Account sub category record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Account sub category record successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			*/
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				
				$("#acctCatID").val($(this).attr("acctCatID"));
				$("#acctTypeID").val($(this).attr("acctTypeID"));
				$("#acctSubCatName").val($(this).attr("acctSubCatName"));
				$("#acctSubCatID").val($(this).attr("acctSubCatID"));
				
				
				if($(this).attr("allowDlt")== 1)
				{
					$("#allowDelete").attr("checked",true);
				}
				
				else 
				{	
					$("#allowDelete").removeAttr("checked");
				}
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>