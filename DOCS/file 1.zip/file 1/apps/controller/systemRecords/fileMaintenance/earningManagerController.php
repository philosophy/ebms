<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var earnNo = $("#earnNo").val().trim();
	var earnName = $("#earnName").val().trim();
	var earnDesc = $("#earnDesc").val().trim();
	var isFlag;
	if($("#addToPayroll").attr("checked")!=undefined)
	{
	 isFlag=1;
	}
	else
	{
	 isFlag=0;
	}
	var dataString = "role="+($(this).attr("role"))+"&earnNo="+earnNo+"&earnName="+earnName+"&earnDesc="+earnDesc+"&isFlag="+isFlag;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var earnNo = $(this).attr("earnNo");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
		{
			dbRequest("role=delete&earnNo="+earnNo);
		}
		else
		{
			fieldDisable();
		}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var earnNo = $(this).attr("earnNo");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
		{
			dbRequest("role=restore&earnNo="+earnNo);
		}
		else
		{
			fieldDisable();
		}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#earnNo").val("");
		$("#earnName").val("");
		$("#earnDesc").val("");
		$("#addToPayroll").attr("checked",false);
		$("#editBtn").attr("disabled",true);
		$("#deleteBtn").attr("disabled",true);
		$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#earnName").attr("disabled",false);
		$("#earnDesc").attr("disabled",false);
		$("#addToPayroll").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
	}
	
	function fieldDisable()
	{
			$("#earnName").attr("disabled",true);
			$("#earnDesc").attr("disabled",true);
			$("#addToPayroll").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
			$("#deleteBtn").attr("disabled",true);
			$("#editBtn").attr("disabled",true);
			$("#addToPayroll").attr("checked",false);
			$("#earnNo").val("");
			$("#earnName").val("");
			$("#earnDesc").val("");
			$("#formDataGrid tr").removeClass("activeTr");
			
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/earningManager/earningManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{	
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Earning record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Earning record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Earning record successfully deleted");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",true);
			$("#deleteBtn").attr("disabled",true);
			$("#restoreBtn").attr("disabled",false);
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Earning record successfully restored");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",false);
			$("#deleteBtn").attr("disabled",false);
			$("#restoreBtn").attr("disabled",true);
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("earnNo",$(this).attr("earnNo"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("earnNo",$(this).attr("earnNo"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				if($(this).attr("flag") == "false")
				{
				$("#addToPayroll").attr("checked",false);
				}
				
				else if($(this).attr("flag") == "true")
				{
				$("#addToPayroll").attr("checked",true);
				}
		
				$("#earnName").val($(this).attr("earnName"));
				$("#earnDesc").val($(this).attr("earnDesc"));
				$("#earnNo").val($(this).attr("earnNo"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>