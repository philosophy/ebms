<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var leaveID = $("#leaveID").val().trim();
	var leaveName = $("#leaveName").val().trim();
	var leaveMaxDays = $("#leaveMaxDays").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&leaveID="+leaveID+"&leaveName="+leaveName+"&leaveMaxDays="+leaveMaxDays;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var leaveID = $(this).attr("leaveID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&leaveID="+leaveID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var leaveID = $(this).attr("leaveID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&leaveID="+leaveID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#leaveID").val("");
		$("#leaveName").val("");
		$("#leaveMaxDays").val("");
		$("#editBtn").attr("disabled",true);
		$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#leaveName").attr("disabled",false);
		$("#leaveMaxDays").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
	}
	
	function fieldDisable()
	{
			$("#leaveName").attr("disabled",true);
			$("#leaveMaxDays").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/employeeLeaveManager/employeeLeaveManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#leaveID").val("");
			$("#leaveName").val("");
			$("#leaveMaxDays").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Leave record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Leave record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Leave record successfully deleted");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",true);
			$("#deleteBtn").attr("disabled",true);
			$("#restoreBtn").attr("disabled",false);
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Leave record successfully restored");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",false);
			$("#deleteBtn").attr("disabled",false);
			$("#restoreBtn").attr("disabled",true);
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("leaveID",$(this).attr("leaveID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("leaveID",$(this).attr("leaveID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#leaveName").val($(this).attr("leaveName"));
				$("#leaveMaxDays").val($(this).attr("leaveMaxDays"));
				$("#leaveID").val($(this).attr("leaveID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>