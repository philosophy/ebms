<script>

$(document).ready(function(){
	
	var subCategoryID,itemFieldName,itemFieldID;
	$("#saveBtn").click(function(){
	itemFieldID = $("#itemFieldID").val().trim();
	subCategoryID = $("#subCategoryID").val().trim();
	itemFieldName = $("#itemFieldName").val().trim();
	
	var dataString = "role="+($(this).attr("role"))+"&itemFieldID="+itemFieldID+"&subCategoryID="+subCategoryID+"&itemFieldName="+itemFieldName;
	dbRequest(dataString);
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var itemFieldID = $(this).attr("itemFieldID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&itemFieldID="+itemFieldID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var itemFieldID = $(this).attr("itemFieldID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&itemFieldID="+itemFieldID);
			}
	
	});
	
	$("#subCategoryID").change(function(){
		var subCategoryID = $(this).val();
		
		$.post("../../../systemRecords/fileMaintenance/subCategoryManager/subCategoryManager.php",{role:"Search",subCategoryID:subCategoryID},
			function(response)
			{
				$("#categoryID").val(response);
			});
	});
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#itemFieldName").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
		$("#itemFieldName").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#itemFieldName").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function rowClick()
	{
		$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("itemFieldID",$(this).attr("itemFieldID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("itemFieldID",$(this).attr("itemFieldID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#itemFieldName").val($(this).attr("itemFieldName"));
				$("#subCategoryID").val($(this).attr("subCategoryID"));
				$("#itemFieldID").val($(this).attr("itemFieldID"));
				
					
				});
	}
	
	$.post("../categoryManager/categoryManager.php",{role:"VIEW",viewType:"comboBox"},
			function(response)
			{
				$("#categoryID").html(response);
					$("#categoryID").change(function(){
					
					$("#formDataGrid").html("");
						$.post("../subCategoryManager/subCategoryManager.php",{role:"SearchMultiple",categoryID:$(this).val()},
						function(response)
						{	
							//alert($(this).val());
							$("#subCategoryID").html(response);
							
							$("#subCategoryID").change(function(){
								$.post("../itemFieldManager/itemFieldManager.php",{role:"SearchMultiple",subCategoryID:$(this).val()},
									function(response)
									{
									$("#formDataGrid").html(response);
									datagrid("formDataGrid",true);
									
									rowClick();
									}
								);
							});
							//alert("Response: "+response);
						});
					
					});
			});
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/itemFieldManager/itemFieldManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#itemFieldName").val("");
			$("#itemFieldID").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Item Field record successfully created");
			//alert(subCategoryID);
			dbRequest("role=SearchMultiple&subCategoryID="+subCategoryID);
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Item Field record successfully saved");
			dbRequest("role=SearchMultiple&itemFieldID="+itemFieldID+"&subCategoryID="+subCategoryID);
			//$("#formDataGrid tr[itemFieldID="+itemFieldID+"]").click();
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Item Field record successfully deleted");
			dbRequest("role=SearchMultiple&itemFieldID="+itemFieldID+"&subCategoryID="+subCategoryID);
			
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Item Field record successfully restored");
			dbRequest("role=SearchMultiple&itemFieldID="+itemFieldID+"&subCategoryID="+subCategoryID);
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				rowClick();
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>