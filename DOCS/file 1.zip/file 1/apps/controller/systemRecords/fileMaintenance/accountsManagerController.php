<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var acctID = $("#acctID").val().trim();
	var acctName = $("#acctName").val().trim();
	var acctDesc = $("#acctDesc").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&acctID="+acctID+"&acctName="+acctName+"&acctDesc="+acctDesc;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var acctID = $(this).attr("acctID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&acctID="+acctID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var acctID = $(this).attr("acctID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&acctID="+acctID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#acctID").val("");
		$("#acctName").val("");
		$("#acctDesc").val("");
		$("#editBtn").attr("disabled",true);
		$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#acctName").attr("disabled",false);
		$("#acctDesc").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
	}
	
	function fieldDisable()
	{
			$("#acctName").attr("disabled",true);
			$("#acctDesc").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/accountsManager/accountsManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#acctID").val("");
			$("#acctName").val("");
			$("#acctDesc").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Account record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Account record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Account record successfully deleted");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",true);
			$("#deleteBtn").attr("disabled",true);
			$("#restoreBtn").attr("disabled",false);
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Account record successfully restored");
			dbRequest("role=VIEW");
			$("#editBtn").attr("disabled",false);
			$("#deleteBtn").attr("disabled",false);
			$("#restoreBtn").attr("disabled",true);
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("acctID",$(this).attr("acctID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("acctID",$(this).attr("acctID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#acctName").val($(this).attr("acctName"));
				$("#acctDesc").val($(this).attr("acctDesc"));
				$("#acctID").val($(this).attr("acctID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>