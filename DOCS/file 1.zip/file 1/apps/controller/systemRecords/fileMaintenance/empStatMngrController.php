<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var empStatID = $("#empStatID").val().trim();
	var empStatName = $("#empStatName").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&empStatID="+empStatID+"&empStatName="+empStatName;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var empStatID = $(this).attr("empStatID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&empStatID="+empStatID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var empStatID = $(this).attr("empStatID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&empStatID="+empStatID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#empStatName").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#empStatName").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#empStatName").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/employeeStatusManager/employeeStatusManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#empStatID").val("");
			$("#empStatName").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Employee Status record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Employee Status record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Employee Status record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Employee Status successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("empStatID",$(this).attr("empStatID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("empStatID",$(this).attr("empStatID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#empStatName").val($(this).attr("empStatName"));
				$("#empStatID").val($(this).attr("empStatID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>