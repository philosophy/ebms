<script>

$(document).ready(function(){
	
	$("#saveBtn").click(function(){
	var curID = $("#curID").val().trim();
	var curName = $("#curName").val().trim();
	var curSymbol = $("#curSymbol").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&curID="+curID+"&curName="+curName+"&curSymbol="+curSymbol;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var curID = $(this).attr("curID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
		{
			if($(this).attr("flag")=="true")
			{
				alert("Can't be deleted because it was set as currency!");
				fieldDisable();
			}
			else
			{
				dbRequest("role=delete&curID="+curID);
			}
		}
		else
		{
			fieldDisable();
		}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var curID = $(this).attr("curID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
		{
			dbRequest("role=restore&curID="+curID);
		}
		else
		{
			fieldDisable();
		}
	
	});
	
	function setNewCurrency(setID,del){

		var ans = confirm("Set new currency?");
		
		if(ans)
		{
		    if(del=="true")
			{
				alert("Can't set this currency because it was deleted! Restore it first.");
				fieldDisable();
				dbRequest("role=VIEW");
			}
			else
			{
				dbRequest("role=setCur&curID="+setID);
			}
		}
		else
		{
			dbRequest("role=VIEW");
			fieldDisable();
		}
	}
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#curID").val("");
		$("#curName").val("");
		$("#curSymbol").val("");
		$("#editBtn").attr("disabled",true);
		$("#deleteBtn").attr("disabled",true);
		$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#curName").attr("disabled",false);
		$("#curSymbol").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
			$("#editBtn").attr("disabled",true);
			$("#deleteBtn").attr("disabled",true);
			$("#restoreBtn").attr("disabled",true);
			$("#curID").val("");
			$("#curName").val("");
			$("#curSymbol").val("");
			$("#curName").attr("disabled",true);
			$("#curSymbol").attr("disabled",true);
			$("#formDataGrid tr").removeClass("activeTr");
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/currencyManager/currencyManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Currency record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Currency record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "setCur")
			{
			alert("New Currency has been set!");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Currency record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Currency successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$(".setCur").click(function(){
				setNewCurrency($(this).attr("curId"),$(this).attr("deleted"));
				});
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("curID",$(this).attr("curID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("curID",$(this).attr("curID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				if($(this).attr("flag") == "false")
				{
				$("#deleteBtn").attr("flag",$(this).attr("flag"));
				}
				
				else if($(this).attr("flag") == "true")
				{
				$("#deleteBtn").attr("flag",$(this).attr("flag"));
				}
				
				$("#curID").val($(this).attr("curID"));
				$("#curName").val($(this).attr("curName"));
				$("#curSymbol").val($(this).attr("curSymbol"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>