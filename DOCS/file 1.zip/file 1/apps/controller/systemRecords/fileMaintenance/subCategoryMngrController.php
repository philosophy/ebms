<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var categoryID = $("#categoryID").val().trim();
	var subCategoryID = $("#subCategoryID").val().trim();
	var subCategoryCode = $("#subCategoryCode").val().trim();
	var subCategoryName = $("#subCategoryName").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&subCategoryCode="+subCategoryCode+"&categoryID="+categoryID+"&subCategoryID="+subCategoryID+"&subCategoryName="+subCategoryName;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var subCategoryID = $(this).attr("subCategoryID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&subCategoryID="+subCategoryID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var subCategoryID = $(this).attr("subCategoryID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&subCategoryID="+subCategoryID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#subCategoryName").val("");
		$("#categoryID").val("");
		$("#subCategoryCode").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#categoryID").attr("disabled",false);
		$("#subCategoryName").attr("disabled",false);
		$("#subCategoryCode").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#categoryID").attr("disabled",true);
			$("#subCategoryCode").attr("disabled",true);
			$("#subCategoryName").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/subCategoryManager/subCategoryManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#categoryID").val("");
			$("#subCategoryCode").val("");
			$("#subCategoryName").val("");
			$("#subCategoryID").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Sub Category record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Sub Category record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Sub Category record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Sub Category record successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("subCategoryID",$(this).attr("subCategoryID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("subCategoryID",$(this).attr("subCategoryID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#subCategoryCode").val($(this).attr("subCategoryCode"));
				$("#subCategoryName").val($(this).attr("subCategoryName"));
				$("#subCategoryID").val($(this).attr("subCategoryID"));
				$("#categoryID").val($(this).attr("categoryID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>