<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var locTypeID = $("#locTypeID").val().trim();
	var locTypeName = $("#locTypeName").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&locTypeID="+locTypeID+"&locTypeName="+locTypeName;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var locTypeID = $(this).attr("locTypeID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&locTypeID="+locTypeID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var locTypeID = $(this).attr("locTypeID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&locTypeID="+locTypeID);
			}
	
	});
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#locTypeName").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
	
		$("#locTypeName").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#locTypeName").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/locationTypeManager/locationTypeManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#locTypeID").val("");
			$("#locTypeName").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Location Type record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Location Type record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Location Type record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Location Type successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("locTypeID",$(this).attr("locTypeID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("locTypeID",$(this).attr("locTypeID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#locTypeName").val($(this).attr("locTypeName"));
				$("#locTypeID").val($(this).attr("locTypeID"));
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>