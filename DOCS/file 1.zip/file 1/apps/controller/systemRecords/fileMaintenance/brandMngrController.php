<script>

$(document).ready(function(){
	
	
	$("#saveBtn").click(function(){
	var brandID = $("#brandID").val().trim();
	var categoryID = $("#categoryID").val().trim();
	var subCategoryID = $("#subCategoryID").val().trim();
	var brandName = $("#brandName").val().trim();
	
	
	var dataString = "role="+($(this).attr("role"))+"&categoryID="+categoryID+"&brandID="+brandID+"&subCategoryID="+subCategoryID+"&brandName="+brandName;
	
	dbRequest(dataString);
	
	return false;
	});
	
	$("#deleteBtn").click(function(){
		
	var brandID = $(this).attr("brandID");
	
	var ans = confirm("Do you want to delete this record?");
		
		if(ans)
			{
			dbRequest("role=delete&brandID="+brandID);
			}
	
	});
	
	$("#restoreBtn").click(function(){
		
	var brandID = $(this).attr("brandID");
	
	var ans = confirm("Do you want to restore this record?");
		
		if(ans)
			{
			dbRequest("role=restore&brandID="+brandID);
			}
	
	});
	
	$("#subCategoryID").change(function(){
		var subCategoryID = $(this).val();
		
		$.post("../../../systemRecords/fileMaintenance/subCategoryManager/subCategoryManager.php",{role:"Search",subCategoryID:subCategoryID},
			function(response)
			{
				$("#categoryID").val(response);
			});
	});
	
	
	dbRequest("role=VIEW");
	
	$("#newBtn,#editBtn").click(function(){
		
		var id = $(this).attr("id");
		
		if(id == "newBtn")
		{
		$("#saveBtn").attr("role","new");
		$("#brandName").val("");
		$("#subCategoryID").val("");
		$("#categoryID").val("");
		//$("#formDataGrid tr").removeClass("activeTr");
		}
		
		else if(id == "editBtn")
		$("#saveBtn").attr("role","edit");
		
		fieldEnable();
		
			$("#cancelBtn").click(function(){
			
			fieldDisable();
		
			});
		
	});
	
	function fieldEnable()
	{
		$("#subCategoryID").attr("disabled",false);
		$("#brandName").attr("disabled",false);
		$("#saveBtn").attr("disabled",false);
		$("#cancelBtn").attr("disabled",false);
		
	}
	
	function fieldDisable()
	{
			$("#subCategoryID").attr("disabled",true);
			$("#brandName").attr("disabled",true);
			$("#saveBtn").attr("disabled",true);
			$("#cancelBtn").attr("disabled",true);
	}
	
	function dbRequest(dataString)
	{
	$.ajax({
		url:"/ebms/apps/view/systemRecords/fileMaintenance/brandManager/brandManager.php",
		type:"POST",
		data:dataString,
		cache:false,
		success:
			function(response)
			{
			
			$("#subCategoryID").val("");
			$("#categoryID").val("");
			$("#brandName").val("");
			$("#brandID").val("");
			
			$("#formDataGrid").animate({scrollTop:"+=5000"},"slow");
			
			if(response == "new")
			{
			alert("Brand record successfully created");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "edit")
			{
			alert("Brand record successfully saved");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "delete")
			{
			alert("Brand record successfully deleted");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else if(response == "restore")
			{
			alert("Brand record successfully restored");
			dbRequest("role=VIEW");
			fieldDisable();
			}
			
			else
			{
				$("#formDataGrid").html(response);
				datagrid("formDataGrid",true);
				
				$("#formDataGrid tr").click(function(){
				$("#formDataGrid tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$("#editBtn").attr("disabled",false);
				
				if($(this).attr("deleted") == "false")
				{
				$("#restoreBtn").attr("disabled",true);
				$("#deleteBtn").attr("disabled",false);
				$("#deleteBtn").attr("brandID",$(this).attr("brandID"));
				$("#editBtn").attr("disabled",false);
				}
				
				else if($(this).attr("deleted") == "true")
				{
				$("#restoreBtn").attr("brandID",$(this).attr("brandID"));
				$("#deleteBtn").attr("disabled",true);
				$("#restoreBtn").attr("disabled",false);
				$("#editBtn").attr("disabled",true);
				}
				
				
				$("#brandName").val($(this).attr("brandName"));
				$("#subCategoryID").val($(this).attr("subCategoryID"));
				$("#categoryID").val($(this).attr("categoryID"));
				$("#brandID").val($(this).attr("brandID"));
				
					
				});
			}
			
			}
			
		});
		
	}
	
	
	
	});


</script>