
<script>

$(document).ready(function(){

		var moduleId;
		var moduleIdPos;
		var href = $(".formNav #formNavList a.formActive").attr("href");
		$("div"+href+".formRef").show();

		$(".formNav #formNavList a").click(function(){
			$('div.formRef').hide();
			var href = $(this).attr("href");
			$("div"+href+".formRef").show();
			$(".formNav #formNavList a").removeClass("formActive");
			$(this).addClass("formActive");

		return false;
		});
		
		//search function
		$('#userAccessLevel #user').keyup(function()
		{
			$.post('userList.php',	{keyword: $(this).val().trim()},
			function(response)
			{
				obj = JSON.parse(response);
				
				$('#user').autocomplete({
					source: obj,
					select: function(event, ui) 
					{ 
						//Set attr name
						$('#user').attr('a', ui.item.empId);
						$('#user').attr('b', ui.item.userId);
						$('#position').attr('a', ui.item.posId);
						$('#position').val(ui.item.pos);
					}
				});
				
				if($("#userAccessLevel #user").val().trim() != "")
				{
					//userAccess
					$.post('modules.php',
					function(response)
					{
						$('#userAccessLevel div#panelLeft ul').html(response);
						$('#userAccessLevel div#panelLeft ul li a').click(function()
						{
							setButtonContentValue($(this));
							return false;
						});
					});
				}
				else
				{
					$('#userAccessLevel div#panelLeft ul').html("");
					$('#userAccessLevel div#panelRight ul').html("");
					$("#position").val("");
				}
			});
		});
		
		//position list
		$.post('comboboxContent.php', 
		function(response)
		{
			$('select#positionList').append(response);
		});
		
		//userAccess
		function setButtonContentValue(selector)
		{
			$('#userAccessLevel div#panelLeft ul li').find('a').removeClass('moduleActive');
			$(selector).addClass('moduleActive');
			
			moduleId = $(selector).attr('a');
			$.post('modulesTasks.php', {moduleId: $(selector).attr('a'), userId: $('#user').attr('b'), positionId:$('#position').attr('a')},
			function(response)
			{
				$('#userAccessLevel div#panelRight ul.subModule').html(response);
			});
		}
		
		//userAccess
		$('#userAccessLevel #saveBtn').click(function()
		{
			$('#userAccessLevel #panelRight ul.subModule input[type=checkbox]').each(function()
			{
				if($(this).attr('disabled') == null)
				{
					if($(this).is(':checked'))
					{
						state = 'true';
					}
					else
					{
						state = 'false';
					}
					$.post('saveAccessRights.php', {userId:$('#user').attr('b'), moduleId:moduleId, buttonId:$(this).attr('id'), state:state});
				}
			});
			
			alert('Record successfully saved.');
			return false;
		});
		
		//positionRights
		$('#positionList').change(function()
		{
			if($("select#positionList option:selected").text() != "...")
			{
				$.post('modules.php',
				function(response)
				{
					$('#positionAccessRights div#panelLeft ul').html(response);
					$('#positionAccessRights div#panelLeft ul li a').click(function()
					{
						setPositionContentValue($(this));
						return false;
					});
				});
			}
			else
			{
				$('#positionAccessRights div#panelLeft ul').html("");
				$('#positionAccessRights div#panelRight ul').html("");
			}
		});
		
		//positionRights
		function setPositionContentValue(selector)
		{
			$('#positionAccessRights div#panelLeft ul li').find('a').removeClass('moduleActive');
			$(selector).addClass('moduleActive');

			moduleIdPos = $(selector).attr('a');
			$.post('modulesTasksPosition.php', {moduleId: $(selector).attr('a'), positionId:$('#positionList').val().trim()},
			function(response)
			{
				$('#positionAccessRights div#panelRight ul.subModule').html(response);
			});
		}
		
		//positionRights
		$('#positionAccessRights #saveBtn').click(function()
		{
			$('#positionAccessRights #panelRight ul.subModule input[type=checkbox]').each(function()
			{
				if($(this).is(':checked'))
				{
					state = 'true';
				}
				else
				{
					state = 'false';
				}
				$.post('savePositionRights.php', {positionId:$('#positionList').val().trim(), moduleId:moduleIdPos, buttonId:$(this).attr('id'), state:state});
			});
			alert('Record successfully saved.');
			return false;
		});
	
		passwordSettings(true);
		secQuestionSettings(true);
		
		//textbox states [enable/disable]
		function passwordSettings(state)
		{
			$('div#passwordSettings #nPword').attr('disabled', state);
			$('div#passwordSettings #vPword').attr('disabled', state);
		}
		
		var href = $(".formNav #formNavList a.formActive").attr("href");
		$("div"+href+".formRef").show();

		$(".formNav #formNavList a").click(function(){
			$("div.formRef").hide();
			var href = $(this).attr("href");
			$("div"+href+".formRef").show();
			
			$(".formNav #formNavList a").removeClass("formActive");
			$(this).addClass("formActive");
			
		return false;
		});
		
		$('#empName').keyup(function()
		{
			$.post('employeeList.php',	{keyword: $('#empName').val().trim()},
			function(response)
			{
				obj = JSON.parse(response);
				
				$('#empName').autocomplete({
					source: obj,
					select: function(event, ui) 
					{ 
						$('#empName').attr('a', ui.item.idx);
					}
				});
				
			});
		});
		
		$('div#createUser input#saveBtn').click(function()
		{
			empId = $('#empName').attr('a');
			username = $('#uname').val().trim();
			password = $('#pword').val().trim();
			cPassword = $('#vPword').val().trim();
			secQ = $('select#secQuestion option:selected').text().trim();
			answer = $('#secAnswer').val().trim();
			
			if(password == cPassword)
			{
				dataString = 'empId=' + empId + '&username=' + username + '&password=' + password + '&secQ=' + secQ + '&answer=' + answer;
				$.ajax({
					type: 'POST',
					url: 'createUser.php',
					cache: false,
					data: dataString,
					success: function(response)
					{
						$('div#createUser input[type=text], div#createUser input[type=password]').val('');
						alert(response);
					}
				});
			}
			else
			{
				alert('Passwords do not match!');
			}
			return false;
		});
		
		$('div#passwordSettings #cPword').blur(function()
		{
			$.post('checkUsername.php', {pword:$('div#passwordSettings #cPword').val().trim()},
			function(response)
			{
				if(response != '')
				{
					alert(response);
					passwordSettings(true);
				}
				else
				{
					passwordSettings(false);
				}
			});
		});
		
		$('div#passwordSettings #saveBtn').click(function()
		{
			nPword = $('div#passwordSettings #nPword').val().trim();
			vPword = $('div#passwordSettings #vPword').val().trim();
			
			if((nPword != '' || vPword != '') || (nPword == vPword))
			{
				$.post('changePassword.php', {vPword:vPword},
				function(response)
				{
					$('div#passwordSettings input[type=text], div#passwordSettings input[type=password]').val('');
					passwordSettings(true);
					alert(response);
				});
			}
			return false;
		});
		
		function secQuestionSettings(state)
		{
			$('#securityQuestionSettings #secQuestionList').attr('disabled', state);
			$('#securityQuestionSettings #nSecAnswer').attr('disabled', state);
		}
		
		$('div#securityQuestionSettings #cSecAnswer').blur(function()
		{
			secQuestion = $('#secCurrentQuestionList option:selected').text().trim();
			secAnswer = $('#securityQuestionSettings input#cSecAnswer').val().trim();
			
			$.post('checkSecurityQuestion.php', {secQuestion:secQuestion, secAnswer:secAnswer},
			function(response)
			{
				if(response != '')
				{
					alert(response);
					secQuestionSettings(true);
				}
				else
				{
					secQuestionSettings(false);
				}
			});
		});
		
		$('#securityQuestionSettings #saveBtn').click(function()
		{
			newSecQuestion = $('#secQuestionList option:selected').text().trim();
			newSecAnswer = $('#nSecAnswer').val().trim();
			
			$.post('changeSecurityQuestion.php', {newQuestion:newSecQuestion, newAnswer:newSecAnswer},
			function(response)
			{
				$('div#securityQuestionSettings input[type=text]').val('');
				secQuestionSettings(true);
				alert(response);
			});
			return false;
		});
});

</script>