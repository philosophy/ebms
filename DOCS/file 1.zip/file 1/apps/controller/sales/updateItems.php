<script>
		var osHdrId = "";
		var locationId = "";
		

		$("#osList table tr").click(function()
		{
		os = $(this).attr('a');	
		});
		
		

	function loadData(page,searchQuery)
	{
	initialize();
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}
			
		$.ajax({
			url:'/EBMS/apps/view/sales/orderSlip/osList.php', 
			type: "POST",
			data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
			success:
				function(response)
				{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
					
				//setPageBtnValue(arrResponse[2],arrResponse[3]);
					
				$('#osList').html(arrResponse[0]);
				datagrid('osList', true);
				//setPageResponse(arrResponse[0]);
					
				$("#osList table tr").click(function()
				{
				setCellContentValue($(this));
				os = $(this).attr('a');	
				});
				}
				});
	}

	
		
	function updateInventory()
		{
			$('#orderedItems tr').each(function(index){
			item = $(this).attr("code");
			qty = $(this).find("#qty").val(); 
			stock = $(this).find("#stock").text();
			dataString = "itemCode="+item+"&qty="+qty+"&stock="+stock;
				$.ajax({
					type: "POST",
					url: "../orderSlip/updateInventory.php",
					data: dataString,
					cache: false
				});	
			
			});
			
		}		
	
	function addToInventory()
			{
				$('#orderedItems tr').each(function(index){
				item = $(this).attr("code");
				qty = $(this).find("#qty").attr("oldValue"); 
				stock = $(this).find("#stock").text();
				dataString = "itemCode="+item+"&qty="+qty+"&stock="+stock;
				$.ajax({
						type: "POST",
						url: "../orderSlip/addToInventory.php",
						data: dataString,
						cache: false
					});	
				
				});
				
			}	

		$("#edit_OS #discount").attr("disabled", true);
		
		$("div#edit_OS button#cancel").click(function()
		{	
			window.location.reload();
		});
		
		
		
		$("div#edit_OS button#save").click(function()
		{	
			var y = 0;
			$.post('/EBMS/apps/view/sales/orderSlip/deleteOsDetails.php',{osCode:os});	
			$('#edit_OS #orderedItems tr').each(function(index){
			qty = $(this).find("#qty").val(); 
			stock = $(this).find("#stock").text();
			if(parseInt(qty) > parseInt(stock))
			{
				
				y = 1;
			}
			});
			
			if(y == 1)
			alert("Insufficient Stock. Please check your entries.");
			else{

			if($("div#edit_OS #customer").val() == '...')
				alert("Please select a customer.");
			else
				if($("div#edit_OS #location").val() == '...')
				 alert("Please select a location.");
				else
					if($('div#edit_OS #grossAmount').val() == 0)
						alert("No items selected.");
					else
					{
						x = confirm("Save with Payment?");
						if(x = "1")
							isAR = 1;
						else
							isAR = 0;
						
						customerId = $("div#edit_OS #customer").val(); 
						locationId = $("div#edit_OS #location").val();
						remarks = $("div#edit_OS #remarks").val();
						terms = $("div#edit_OS #terms").val();
						deposit = $("div#edit_OS #deposit").val();
						grossAmount = $("div#edit_OS #grossAmount").val();
						netAmount = $("div#edit_OS #netAmount").val();
						discountPercent = $("div#edit_OS #discount").val();
						osCode = os;
						dataString = "custId="+customerId+"&locId="+locationId+"&remarks="+remarks+"&terms="+terms+"&deposit="+deposit+"&grossAmount="+grossAmount+"&netAmount="+netAmount+"&discountPercent="+discountPercent+"&isAR="+isAR+"&osCode="+osCode;
					
							$.ajax({
							url: "../orderSlip/updateOrderSlip.php",
							type: "POST",
							data: dataString,
							cache: false,
							success:
								function(response){ 
								osHdrId = response;
								details();
								$("div#edit_OS.modalForm").fadeOut("slow",0,
								function()
								{	
									$(".formFade").fadeOut(300,
								function(){
									$(".formFade").remove();
								});
									$("div#edit_OS.modalForm").hide();
								});
								
								$("div#osList table tr.activeTr").trigger("click");
								}
							
							});
							
						var x = confirm("Do you want to print order slip?")
						if(x == true)
						{	
							window.open('/EBMS/apps/view/reports/sales/orderSlip.php', 'Order Slip');								
						}
						loadData(1,searchQuery);
						window.location.reload();
						addToInventory();
						updateInventory();
					}
					
				}	
			});

		function getNetAmt()
		{
			var total = 0; 
			$('div#edit_OS #orderedItems tr').each(function(index) {
			var qty = $(this).find("#qty").val(); 
			var price = $(this).find("#price").text().replace(",", "");
			var tmp = parseFloat(qty) * parseFloat(price);
			total = parseFloat(total) + parseFloat(tmp); 
			$('div#edit_OS #grossAmount').val(total).attr("disabled", true);
			$('div#edit_OS #netAmount').val(total).attr("disabled", true);
			});
			discount(total);
		}
		
		
		function details()
		{
			$('div#edit_OS #orderedItems tr').each(function(index){
			item = $(this).attr("code");
			quantity = $(this).find("#qty").val(); 
			desc = $(this).find("#desc").text(); 
			dataString = "itemCode="+item+"&qty="+quantity+"&desc="+desc+"&osHdrId="+osHdrId.trim();

			$.ajax({
				type: "POST",
				url: "../orderSlip/updateOsDetails.php",
				data: dataString,
				cache: false
				});	
			});
		}
		
		
		
		function discount(num)	
		{
			var percent = $("#edit_OS #discount").val();
			if(percent == "")
				percent = 0;
			var net = num - (num * (percent / 100));
			$('#edit_OS #netAmount').val(net).attr("disabled", true);
			
			if($('#edit_OS #netAmount').val() == 0)
					$('#edit_OS #grossAmount').val(0);
		}	
		
		$("#edit_OS").find("input[type=number]").bind("keyup input",function(){
			
			getNetAmt();
			if($(this).val() == "0" || $(this).val() == "-1")
			{
				$(this).val(0);
			}	
		});
		
		
		$("#edit_OS #is_discounted").click(function(){
			if($("#edit_OS #is_discounted").attr("checked") != undefined)
				{	
					$("#edit_OS #discount").attr("disabled", false);
				}
			else
				{
					$("#edit_OS #discount").attr("disabled", true);
					$("#edit_OS #discount").val(0);
				}
		});
						
		
		
		
		$("#edit").click(function(){		
		
		$("#edit_OS div[ref=orderItemsList] ul").find(".addItem").show();
		$("#edit_OS div[ref=orderItemsList] ul").find(".selectedItem").hide();
		$("#edit_OS #orderedItems").html("");
		$("div#edit_OS #deposit").attr("disabled", true);
		$("div#edit_OS #terms").attr("disabled", true);
		

		$("div#edit_OS #customer").empty();
		$.post("getCustomer.php", function(response){
		$("div#edit_OS #customer").append("<option value='...'>...</option>");
		$("div#edit_OS #customer").append(response);
		});	
		$.post("activeUser.php", function(response){
		$("div#edit_OS #salesPerson").val(response).attr("disabled", true);
		});	

		
		$("#edit_OS #customer").change(function(){
		
			$("#edit_OS #location").empty();
			$.post("getLocation.php",{customer:$("div#edit_OS #customer").val()}, 
			function(response){
				$("#edit_OS #location").empty();
				$("#edit_OS #location").append("<option value='...'>...</option>");
				$("#edit_OS #location").append(response);
				$("#edit_OS #location").val(locationId);
			});		
		});

		
		$.post("getData.php",{osCode:os}, function(response){
		//alert(response);
		obj = JSON.parse(response);
		$("div#edit_OS #customer").val(obj.values["name"]);
		$("div#edit_OS #customer").attr("disabled", true);
		$("#edit_OS #customer").trigger("change");
		$("div#edit_OS #location").val(obj.values["location"]);
		locationId = obj.values["location"];
		$("div#edit_OS #remarks").text(obj.values["remarks"]);
		$("div#edit_OS #grossAmount").val(obj.values["gross"]);
		$("div#edit_OS #netAmount").val(obj.values["net"]);
		$("div#edit_OS #discount").val(obj.values["discount"]);
		// $("div#edit_OS #deposit").val(obj.values["deposit"]);
		// $("div#edit_OS #terms").val(obj.values["terms"]);
		
		for(x = 0; x < obj.item.length; x++)
			{
				code = obj.item[x].substring(0, obj.item[x].indexOf(","));
				qty = obj.item[x].substring(obj.item[x].indexOf(",")).replace(",","");
				$("#edit_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a[code = '"+code+"']").trigger("click");
				$("#edit_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").trigger("toggle");
				$("#edit_OS #orderedItems tr[code='"+code+"'] input#qty").val(qty);
				
			}
		});	
		
		});
		
	
		inputMask("editFormDataContSearch","Search");
		
		$(document).ready(function(){
		
		$("#edit_OS #editFormDataContSearch").keyup(function(){
			
			var q = $(this).val().trim();
			loadItems(q);
			
		});
		
		loadItems("");
		});
		
		function loadItems(q)
		{
		
		$.ajax({
			url:"/ebms/apps/view/sales/orderSlip/orderedItemsList.php",
			type:"POST",
			data:"q="+q,
			success:
			function(response){
			$("#edit_OS div[ref=orderItemsList] ul").html(response);
				
				$("#edit_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function(){
					
					$(this).trigger("click");
					return false;
					
				});
				
				$("#edit_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						var code = $(this).attr("itemCode");
						var desc = $(this).attr("itemDesc");
						
						if($("#edit_OS #orderedItems").find("tr[code="+code+"] td").size() > 0)
						{
						$("#edit_OS #orderedItems tr td").removeClass("itemActive");
						$("#edit_OS #orderedItems").find("tr[code="+code+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("div.itemDetails").stop().animate({bottom:0,opacity:0.8},"1000").show();
						
						
						},function(){
						
						if($("#edit_OS #orderedItems").find("tr[code="+code+"] td").size() > 0)
						$("#edit_OS #orderedItems").find("tr[code="+code+"] td").removeClass("itemActive");
						
						$("div.itemDetails").stop().animate({bottom:"-30px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
						
						
				
				$("#edit_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function(){
						
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						if($(this).find(".addItem").css("display") == "none")
						{
						var code = $(this).attr("code");
						var unitPrice = $(this).attr("unitPrice");
						var desc = $(this).attr("desc");
						var stock = $(this).attr("stock");
						
							$("#edit_OS #orderedItems").append("<tr id='code' code='"+code+"'><td><input type='number' oldValue='' id='qty' value=1 style='width:70px;'></td><td id='price'>"+unitPrice+"</td><td id='stock'>"+stock+"</td><td id = 'desc'>"+desc+"</td></tr>");
							getNetAmt();
							$("#edit_OS #orderedItems").find("tr[code='"+code+"'] input").bind("keyup input",function(){
							getNetAmt();
							
								if($(this).val() == "0" || $(this).val() == "")
								{
									$(this).val("1");
								}								
							});
							
							
							if(stock == 0)
							{
								alert("Out of stock");
								$("#edit_OS #orderedItems").find("tr[code="+code+"]").fadeOut("slow",
								function()
								{
									$("#edit_OS #orderedItems").find("tr[code="+code+"]").remove();
									getNetAmt();
								});
								
								
								$(this).find(".addItem").show();
								$(this).find(".removeItem").hide();
								$(this).find(".selectedItem").hide();
								
							}
							
						}

					
						
						$("#edit_OS").find("#edit_OS #discount").bind("keyup input",function(){
							getNetAmt();
						});

		
						$("input[type=number]").bind("keypress", function(e) { 
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
						});
							
					
						
						$(this).hover(function(){
						
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						},function(){
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						});
						
				return false;	
				},
				function()
				{
				var code = $(this).attr("code");
					$("#edit_OS #orderedItems").find("tr[code="+code+"]").fadeOut("slow",
						function()
						{
							$("#edit_OS #orderedItems").find("tr[code="+code+"]").remove();
							getNetAmt();
						});
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						
				});
				
			}
		});
		}
		
</script>

