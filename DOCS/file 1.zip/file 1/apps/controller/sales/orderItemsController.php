<script>
		var osHdrId = "";
		var osCode = "";
		var ctr = 0;
		var customerId = "";		
		var customerCode = "";
		var init,page;
				
		var searchQuery="";
		
		$("#deposit").hide();
		$("#terms").hide();
		function initialize()
			{
			//initialize search input value 
			init = $("#datagrid-search-box").val().trim();
			}
		//by default, the first page will be displayed
		loadData(1,searchQuery);
		
		$("#new").attr('title', 'New Order');
		$("#edit").attr('title', 'Edit Order');
		$("#delete").attr('title', 'Delete Order');
		$("#restore").attr('title', 'Restore Order');
		$("#import").attr('title', 'Import to D.R.');
				
		function loadData(page,searchQuery)
		{
		initialize();
			if(init == "" || init == "Search...")
				{
				searchQuery = "";
				}
			
			else 
				{
				searchQuery = init;
				}
				
			$.ajax({
				url:'/EBMS/apps/view/sales/orderSlip/osList.php', 
				type: "POST",
				data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
				success:
					function(response)
					{
					$("#loading").fadeTo("slow",0).hide();
					var arrResponse = response.split('&');
					setPageBtnValue(arrResponse[2],arrResponse[3]); 
						
					$('#osList').html(arrResponse[0]);
					datagrid('osList', true);
					setPageResponse(arrResponse[1]);
					//alert(arrResponse[1]);
					$("#osList table tr").click(function()
					{
					setCellContentValue($(this));
					os = $(this).attr('a');	
					});
					}
					});
					
					
		
		}

		$(".page-nav li button").click(function(){
							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
		});

		$("#discount").attr("disabled", true);
		$("div#new_OS button#save").click(function()
		{ 	var y = 0;
			$('#orderedItems tr').each(function(index){
			qty = $(this).find("#qty").val(); 
			stock = $(this).find("#stock").text();
			if(parseInt(qty) > parseInt(stock))
			{
				y = 1;
			}		
			});
			
			if(y == 1)
			alert("Insufficient Stock. Please check your entries.");
			else
			{
			
			if($("div#new_OS #customer").val() == '...')
				alert("Please select a customer.");
			else
				if($("div#new_OS #location").val() == '...')
				 alert("Please select a location.");
				else
					if($('#grossAmount').val() == 0)
						alert("No items selected.");
					else
					{
						x = confirm("Save with Payment?");
						if(x)
							{
								isAR = 0;
								var btn = "<button id=custPayment class=callModalForm ref=new_custPayment style='visibility:hidden'>New Payment</button>";
								$("body").append(btn);
								$("button#custPayment").click(function(){
								callModal("#custPayment");
								passValues();
								return false;
								});
								$("button#custPayment").click();
								
								var x = confirm("Do you want to print order slip?")
								if(x == true)
								{
									window.open('/EBMS/apps/view/reports/sales/orderSlip.php', 'Order Slip');						
								}
								
							}
						else
						
							{
							isAR = 1;
							$('.formClose').click();
							}
							
						customerId = $("div#new_OS #customer").val(); 
						locationId = $("div#new_OS #location").val();
						remarks = $("div#new_OS #remarks").val();
						terms = $("div#new_OS #terms").val();
						deposit = $("div#new_OS #deposit").val();
						grossAmount = $("div#new_OS #grossAmount").val();
						netAmount = $("div#new_OS #netAmount").val();
						discountPercent = $("div#new_OS #discount").val();
						if($("div#new_OS #deposit").val() == "")
							deposit = 0;
						else
						deposit = $("div#new_OS #deposit").val();
						if($("div#new_OS #terms").val() == "")
							terms = 0;
						else
						terms = $("div#new_OS #terms").val();
						
						dataString = "custId="+customerId+"&locId="+locationId+"&remarks="+remarks+"&terms="+terms+"&deposit="+deposit+"&grossAmount="+grossAmount+"&netAmount="+netAmount+"&discountPercent="+discountPercent+"&isAR="+isAR+"&deposit="+deposit+"&terms="+terms;
					
						$.ajax(
						{
							type: "POST",
							url: "../orderSlip/newOrderSlip.php",
							data: dataString,
							cache: false,
							success:
							function(response)
							{ 
								osHdrId = response;							
								details();
								
								if ($("#new_custPayment.modalForm").size() == 0)
								{
									$(".formFade").fadeOut(300,
									function()
									{
										$(".formFade").remove();
									});
								}
								
								osCode = response;
								passValues(osCode);

								$("div#new_OS.modalForm").fadeOut("slow",0,
								function()
								{	
									$("div#new_OS.modalForm").hide();
								});
							}
							
						});	
						
						dataString = "role=" + "New" + "&noun=" + "Order slip record";
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
							
							}
						});
					}
				loadData(1,searchQuery);
			}
		});
		
		
	function passValues(code)
	{
		$('#new_custPayment #custName').val($('#new_OS #customer option:selected').text());
		$('#new_custPayment #custLocation').val($('#new_OS #location option:selected').text());
		$('#new_custPayment #balance').val($('#new_OS #grossAmount').val());
		$('#new_custPayment #amount').val($('#new_OS #grossAmount').val());
		$('#new_custPayment #refNo').val(code);
	}
	
	$('#new_custPayment #cancel').click(function(){
		var x = confirm("Do you want to save payment?")
		if(x == true)
		{
			$('#new_custPayment #save').trigger("click");						
		}
	    else
		{
			windows.location.reload();
		}
	});
	
	
	$('#new_custPayment #save').click(function(){
		
	
		
		refNo = $('#new_custPayment #refNo').val().trim();
		particular = $('#particular').val().trim();
		paymentType = $('#paymentType').val().trim();
		amount = $('#amount').val().trim();
		checkNo = $('#checkNo').val().trim();
		checkDueDate = $('#checkDueDate').val().trim();
		checkDateIssue = $('#checkDateIssue').val().trim();
		checkType = $('#checkType').val();
		accountNo = $('#accountNo option:selected').attr('accountNo');
		accountName = $('#accountName').val().trim();
		bankId = $('#bankName option:selected').attr('bankId');
		
		if($('#fromCol').is(':checked'))
		{
			fromCollection = 1;
		}
		else
		{
			fromCollection = 0;
		}
		refType = $('#docType').val().trim();
		
		dataString = "refType=" + refType + "&particular=" + particular +
					"&paymentType=" + paymentType + "&amount=" + amount + "&fromCol=" + fromCollection +
					"&refNo=" + refNo + "&osNo=" + refNo + "&checkNo=" + checkNo +
					"&checkDueDate=" + checkDueDate + "&checkDateIssue=" + checkDateIssue +
					"&checkType=" + checkType + "&accountNo=" + accountNo + "&accountName=" + accountName +
					"&bankId=" + bankId + "&customerId=" + customerId; 
	   
	   if($('#new_custPayment #amount').val() >  $('#new_custPayment #balance').val())
	   {
			alert("Please check your entry. Amount is greater than the balance.");
			$('#new_custPayment #amount').focus();
	   }
	   else
	   {
			$.ajax({
				type: "POST",
				url: "insertPayment.php",
				data: dataString,
				cache: false,
				success: function(response)
				{
					alert(response);
					
					$("div#new_custPayment modalForm").fadeOut("slow",0,
					function()
					{	
						$("div#new_OS.modalForm").hide();
					});
				}
			});
			
			dataString = "role=" + "New Payment" + "&noun=" + "Payment" + "&code=" + refNo;
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
		}
	});
	
	
	
				$('#paymentType').change(function()
				{
					if($(this).val() == "cheque")
					{
						$('#checkType').attr('disabled', false);
						$('#bankName').attr('disabled', false);
						$('#accountType').attr('disabled', false);
						$('#accountNo').attr('disabled', false);
						$('#checkNo').attr('disabled', false);
						$('#checkDateIssue').attr('disabled', false);
						$('#checkDueDate').attr('disabled', false);
						

						$.post('/EBMS/apps/view/accounting/companyReceivables/bankList.php', {custCode:customerCode},
						function(response)
						{
							$('#bankName').html("<option>...</option>");
							$('#bankName').append(response);
						});
					}
					else if($(this).val() == "cash")
					{
						$('#checkType').attr('disabled', true);
						$('#bankName').attr('disabled', true);
						$('#bankName').html("<option>...</option>");
						$('#address').val('');
						$('#accountType').attr('disabled', true);
						$('#accountNo').attr('disabled', true);
						$('#accountNo').html("<option>...</option>");
						$('#accountName').val('');
						$('#checkNo').attr('disabled', true);
						$('#checkNo').val('');
						$('#checkDateIssue').val('');
						$('#checkDueDate').val('');
						$('#checkDateIssue').attr('disabled', true);
						$('#checkDueDate').attr('disabled', true);
					}
				});
				
				$('#bankName, #accountType').change(function()
				{
					
					$('#address').val($('#bankName option:selected').attr('bankAddress'));
					$.post('/EBMS/apps/view/accounting/companyReceivables/bankAccounts.php', {bankId:$('#bankName option:selected').attr('bankId'), accountType: $('#accountType').val()},
					function(response)
					{
						$('#accountNo').html("<option>...</option>");
						$('#accountNo').append(response);
					});
				});
				
				$('#accountNo').change(function()
				{
					$('#accountName').val($('#accountNo option:selected').attr('accountName'));
				});
	

		
	function getNetAmt()
		{
			var total = 0; 
			$('#orderedItems tr').each(function() {
			var qty = $(this).find("#qty").val(); 
			var price = $(this).find("#price").text().replace(/,/g, "");
			var tmp = parseFloat(qty) * parseFloat(price);
			total = parseFloat(total) + parseFloat(tmp); 
			$('#grossAmount').val(total).attr("disabled", true);
			$('#netAmount').val(total).attr("disabled", true);
			});
			discount(total);
		}
		
		function details()
		{
			$('#orderedItems tr').each(function(index){
			item = $(this).attr("code");
			qty = $(this).find("#qty").val(); 
			desc = $(this).find("#desc").text(); 
			stock = $(this).find("#stock").text();
			dataString = "itemCode="+item+"&qty="+qty+"&desc="+desc+"&osHdrId="+osHdrId.trim();
			
				$.ajax({
					type: "POST",
					url: "../orderSlip/insertOsDetails.php",
					data: dataString,
					cache: false
				});	
			
			});
			updateInventory();
		}
		
		
		function updateInventory()
		{
			$('#orderedItems tr').each(function(index){
			item = $(this).attr("code");
			qty = $(this).find("#qty").val(); 
			stock = $(this).find("#stock").text();
			dataString = "itemCode="+item+"&qty="+qty+"&stock="+stock;

				$.ajax({
					type: "POST",
					url: "../orderSlip/updateInventory.php",
					data: dataString,
					cache: false
				});	
			
			});
			
		}
	
			
		
		
		
		function discount(num)	
		{
			var percent = $("#discount").val();
			if(percent == "")
				percent = 0;
			var net = num - (num * (percent / 100));
			$('#netAmount').val(net).attr("disabled", true);
			
			if($('#netAmount').val() == 0)
					$('#grossAmount').val(0);
		}	
		
		$("#new_OS").find("input[type=number]").bind("keyup input",function(){
			
			getNetAmt();
			if($(this).val() == "0" || $(this).val() == "-1")
			{
				$(this).val(0);
			}	
		});
		
		
		$("#is_discounted").click(function(){
			if($("#is_discounted").attr("checked") != undefined)
				{	
					$("#discount").attr("disabled", false);
				}
			else
				{
					$("#discount").attr("disabled", true);
					$("#discount").val(0);
				}
		});
						
		
		$("#new").click(function(){
			
			$("div#new_OS #customer").empty();
			$.post("getCustomer.php", function(response){
			$("div#new_OS #customer").append("<option value='...'>...</option>");
			$("div#new_OS #customer").append(response);
			});	
			
			$.post("activeUser.php", function(response){
			$("div#new_OS #salesPerson").val(response).attr("disabled", true);
			});		
			
		});
	
		$("div#new_OS #customer").change(function(){
		
			$("div#new_OS #location").empty();
			$.post("getLocation.php",{customer:$("div#new_OS #customer").val()}, 
			function(response){
				$("div#new_OS #location").append("<option value='...'>...</option>");
				$("div#new_OS #location").append(response);
			});	
		customerCode = $("div#new_OS #customer option:selected").attr("code");			
		});

		inputMask("formDataContSearch","Search"); 
	
		
		$(document).ready(function(){
		
		$("#formDataContSearch").keyup(function(){
			
			var q = $(this).val().trim();
			loadItems(q);
			
		});
		
		loadItems("");
		});
		
		function loadItems(q)
		{
		ctr++;
		$.ajax({
			url:"/ebms/apps/view/sales/orderSlip/orderedItemsList.php",
			type:"POST",
			data:"q="+q,
			success:
			function(response){
			$("div[ref=orderItemsList] ul").html(response);
				
				$("#new_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function(){
					
					$(this).trigger("click");
					return false;
					
				});
				
				
						$("#new_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						var code = $(this).attr("itemCode");
						var desc = $(this).attr("itemDesc");
						
						if($("#new_OS #orderedItems").find("tr[code="+code+"] td").size() > 0)
						{
						
						$("#new_OS #orderedItems tr td").removeClass("itemActive");
						$("#new_OS #orderedItems").find("tr[code="+code+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("div.itemDetails").stop().animate({bottom:0,opacity:0.8},"1000").show();
						
						
						},function(){
						
						if($("#new_OS #orderedItems").find("tr[code="+code+"] td").size() > 0)
						$("#new_OS #orderedItems").find("tr[code="+code+"] td").removeClass("itemActive");
						
						$("#new_OS div.itemDetails").stop().animate({bottom:"-30px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
						
				
				$("#new_OS div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function(){
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						
						if($(this).find(".addItem").css("display") == "none")
						{
						var code = $(this).attr("code");
						var unitPrice = $(this).attr("unitPrice");
						var desc = $(this).attr("desc");
						var stock = $(this).attr("stock");
						
							$("#new_OS #orderedItems").append("<tr id='code' code='"+code+"'><td><input type='number' id='qty' value=1 style='width:70px;'></td><td id='price'>"+unitPrice+"</td><td id='stock'>"+stock+"</td><td id = 'desc'>"+desc+"</td></tr>");
							
							getNetAmt();
							$("#new_OS #orderedItems").find("tr[code='"+code+"'] input").bind("keyup input",function(){
							getNetAmt();
							
								if($(this).val() == "0" || $(this).val() == "")
								{
									$(this).val("1");
								}	
	
							});
							
							
							if(stock == 0)
							{
								alert("Out of stock");
								$("#new_OS #orderedItems").find("tr[code="+code+"]").fadeOut("slow",
								function()
								{
									$("#new_OS #orderedItems").find("tr[code="+code+"]").remove();
									getNetAmt();
								});
								
								
								$(this).find(".addItem").show();
								$(this).find(".removeItem").hide();
								$(this).find(".selectedItem").hide();
								
							}

						}

						
						$("#new_OS").find("#discount").bind("keyup input",function(){
							getNetAmt();
						});

		
						$("input[type=number]").bind("keypress", function(e) { 
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
						});
					
						
						$(this).hover(function(){
						
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						},function(){
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						});
						
				return false;	
				},
				function()
				{
				var code = $(this).attr("code");
					$("#new_OS #orderedItems").find("tr[code="+code+"]").fadeOut("slow",
						function()
						{
							$("#new_OS #orderedItems").find("tr[code="+code+"]").remove();
							getNetAmt();
						});
						
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						
				});
				
				if(ctr > 1)
				{
				var arr1 = new Array(),arr2 = new Array();
				$("div#new_OS div[ref=orderItemsList] ul li a").each(function(index){
						
						var itemListCode = $(this).attr("code");
						arr1[index] = itemListCode;
							
					});	
					
				$("div#new_OS #orderedItems tr").each(function(index){
						var orderedItemsCode = $(this).attr("code");
						arr2[index] = orderedItemsCode;
				});
				
				for(i=0;i<arr1.length;i++)
					{
						for(x=0;x<arr2.length;x++)
						if(arr1[i] == arr2[x])
							{
							$("div#new_OS div[ref=orderItemsList] ul li a[code='"+arr1[i]+"']").click();
							$("#orderedItems").find("tr[code="+arr1[i]+"]:last-child").remove();
							}
					}
					
					
				}
			}
		});
		
		}
		
		
</script>
