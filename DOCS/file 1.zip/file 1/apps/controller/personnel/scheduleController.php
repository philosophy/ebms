﻿	<script type="text/javascript" src="/EBMS/js/timepicker1.js"></script>
	
<script>
		$("#new").attr('title', 'New Schedule');
		$("#edit").attr('title', 'Edit Schedule');
		$("#multipleEdit").attr('title', 'Edit Multiple Schedule');
		$("#delete").attr('title', 'Delete Schedule');
		
		$("#pdf").load(
		function(){
		$(this).unbind('click'); 
		});
		
		$("div#new_schedule .formFade,div#new_schedule .formClose, div#new_schedule #cancel, div#multipleEdit_schedule .formFade,div#multipleEdit_schedule .formClose, div#multipleEdit_schedule #cancel, div#edit_schedule .formFade,div#edit_schedule .formClose, div#edit_schedule #cancel").click(function(){
		disableFields();
		});															
																	
		$('#timeInSchedNN,#timeOutSchedNN,#startBreakTimeNN,#endBreakTimeNN,#timeInSchedN,#timeOutSchedN,#startBreakTimeN,#endBreakTimeN,#timeInSchedE,#timeOutSchedE,#startBreakTimeE,#endBreakTimeE').timepicker({
		ampm: true});
		
		$("#timeInSchedN,#timeOutSchedN,#startBreakTimeN,#endBreakTimeN,#timeInSchedE,#timeOutSchedE,#startBreakTimeE,#endBreakTimeE").bind("keypress", function(e) 
		{ 
			return(false);
		});
		
		$("button#delete,button#edit,button#multipleEdit").attr("disabled",true);
		var dataString="";
		
		var monday,tuesday,wednesday,thursday,friday,saturday,sunday; 
		function getCheckDays()
		{
			if($('#mondayN').attr('checked')==undefined)
			{monday="uncheck";}
			else
			{monday="check";}
			if($('#tuesdayN').attr('checked')==undefined)
			{tuesday="uncheck";}
			else
			{tuesday="check";}
			if($('#wednesdayN').attr('checked')==undefined)
			{wednesday="uncheck";}
			else
			{wednesday="check";}
			if($('#thursdayN').attr('checked')==undefined)
			{thursday="uncheck";}
			else
			{thursday="check";}
			if($('#fridayN').attr('checked')==undefined)
			{friday="uncheck";}
			else
			{friday="check";}
			if($('#saturdayN').attr('checked')==undefined)
			{saturday="uncheck";}
			else
			{saturday="check";}
			if($('#sundayN').attr('checked')==undefined)
			{sunday="uncheck";}
			else
			{sunday="check";}
		}
		
		var mondayN,tuesdayN,wednesdayN,thursdayN,fridayN,saturdayN,sundayN; 
		function getCheckDaysN()
		{
			if($('#mondayNN').attr('checked')==undefined)
			{mondayN="uncheck";}
			else
			{mondayN="check";}
			if($('#tuesdayNN').attr('checked')==undefined)
			{tuesdayN="uncheck";}
			else
			{tuesdayN="check";}
			if($('#wednesdayNN').attr('checked')==undefined)
			{wednesdayN="uncheck";}
			else
			{wednesdayN="check";}
			if($('#thursdayNN').attr('checked')==undefined)
			{thursdayN="uncheck";}
			else
			{thursdayN="check";}
			if($('#fridayNN').attr('checked')==undefined)
			{fridayN="uncheck";}
			else
			{fridayN="check";}
			if($('#saturdayNN').attr('checked')==undefined)
			{saturdayN="uncheck";}
			else
			{saturdayN="check";}
			if($('#sundayNN').attr('checked')==undefined)
			{sundayN="uncheck";}
			else
			{sundayN="check";}
		}
		
        $("div#new_schedule #save").click(function()
		{
        	if($('#empNameSNewN').val()=="none")
			{
				alert("Please select employee first!");
			}
			else
			{
				getCheckDaysN();
				if($('#timeInSchedNN').val().trim()==""|| $('#timeOutSchedNN').val().trim()=="" || $('#startBreakTimeNN').val().trim()==""|| $('#endBreakTimeNN').val().trim()=="")
				{
					alert("Missed input!");
				}
				else
				{
					dataString = "role=news&schedEmpID="+($('#empNameSNewN').val())+"&stime="+$('#timeInSchedNN').val()+"&etime="+$('#timeOutSchedNN').val()+"&sbreak="+$('#startBreakTimeNN').val()+"&ebreak="+$('#endBreakTimeNN').val()+"&mon="+mondayN+"&tue="+tuesdayN+"&wed="+wednesdayN+"&thu="+thursdayN+"&fri="+fridayN+"&sat="+saturdayN+"&sun="+sundayN;
					employeeId = $('#empNameSNewN').val();
					
					loadData(dataString,1,"");
				}
			}	
		return false;
		});
		
		$("div#multipleEdit_schedule #save").click(function()
		{
        	if($('#empNameSNew').val()==null || $('#empNameSNew').val()=="")
			{
				alert("Please select employee first!");
			}
			else
			{
				getCheckDays();
				if($('#timeInSchedN').val().trim()==""|| $('#timeOutSchedN').val().trim()=="" || $('#startBreakTimeN').val().trim()==""|| $('#endBreakTimeN').val().trim()=="")
				{
					alert("Missed input!");
				}
				else
				{
					dataString = "role=new&schedEmpID="+($(this).attr("schedEmpID"))+"&stime="+$('#timeInSchedN').val()+"&etime="+$('#timeOutSchedN').val()+"&sbreak="+$('#startBreakTimeN').val()+"&ebreak="+$('#endBreakTimeN').val()+"&mon="+monday+"&tue="+tuesday+"&wed="+wednesday+"&thu="+thursday+"&fri="+friday+"&sat="+saturday+"&sun="+sunday;
									
					loadData(dataString,1,"");
				}
			}	
		return false;
		});

		$("div#edit_schedule #save").click(function()
		{	
			if($('#empNameS').val()==null || $('#empNameS').val()=="")
			{
				alert("Please select schedule first!");
			}
			else
			{
				if($('#timeInSchedE').val().trim()==""|| $('#timeOutSchedE').val().trim()=="" || $('#startBreakTimeE').val().trim()==""|| $('#endBreakTimeE').val().trim()=="")
				{
					alert("Missed input!");
				}
				else
				{
					dataString = "role=edit&schedID="+($(this).attr("sched"))+"&stime="+$('#timeInSchedE').val()+"&etime="+$('#timeOutSchedE').val()+"&sbreak="+$('#startBreakTimeE').val()+"&ebreak="+$('#endBreakTimeE').val();
									
					loadData(dataString,1,"");
				}
			}
		return false;
		});
		
		$("div#delete_schedule #save").click(function()
		{
			if($('#empNameS').val()==null || $('#empNameS').val()=="")
			{
				alert("Please select schedule first!");
			}
			else
			{
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
					type:"POST",
					data:"module=" + "Delete Personnel Schedule" + "&id=" + editScheduleId,
					success:
					function(response)
					{
						dataString2 = "role=" + "Delete Employee Schedule" + "&noun=" + "Employee schedule" + "&code=" + response;
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
							type:"POST",
							data:dataString2,
							success:
							function(response)
							{
								
							}
						});
					}
				});
			
				 dataString = "role=delete&schedID="+($(this).attr("sched"));
				 loadData(dataString,1,"");
			}
		return false;
		});
		
		function disableFields()
		{
		 	$("#mondayN").attr("checked",false);
			$("#tuesdayN").attr("checked",false);
			$("#wednesdayN").attr("checked",false);
			$("#thursdayN").attr("checked",false);
			$("#fridayN").attr("checked",false);
			$("#saturdayN").attr("checked",false);
			$("#sundayN").attr("checked",false);
			
			$("#mondayNN").attr("checked",false);
			$("#tuesdayNN").attr("checked",false);
			$("#wednesdayNN").attr("checked",false);
			$("#thursdayNN").attr("checked",false);
			$("#fridayNN").attr("checked",false);
			$("#saturdayNN").attr("checked",false);
			$("#sundayNN").attr("checked",false);
			
			$("#mondayE").attr("checked",false);
			$("#tuesdayE").attr("checked",false);
			$("#wednesdayE").attr("checked",false);
			$("#thursdayE").attr("checked",false);
			$("#fridayE").attr("checked",false);
			$("#saturdayE").attr("checked",false);
			$("#sundayE").attr("checked",false);
			
			$('#timeInSchedE').val('');
			$('#timeOutSchedE').val('');
			$('#startBreakTimeE').val('');
			$('#endBreakTimeE').val('');
			
			$('#timeInSchedN').val('');
			$('#timeOutSchedN').val('');
			$('#startBreakTimeN').val('');
			$('#endBreakTimeN').val('');
			
			$('#timeInSchedNN').val('');
			$('#timeOutSchedNN').val('');
			$('#startBreakTimeNN').val('');
			$('#endBreakTimeNN').val('');
			
			$('#empNameSNewN').val('none');
			$('#empNameSNew').val('');
			$('#empNameS').val('');
			$("button#delete,button#edit,button#multipleEdit").attr("disabled",true);
			loadData("role=VIEW",1,"");
		}
		
		loadData("role=VIEW",1,"");
	    
		function clearCheck()
		{
				$("#mondayE").attr("checked",false);
				$("#tuesdayE").attr("checked",false);
				$("#wednesdayE").attr("checked",false);
				$("#thursdayE").attr("checked",false);
				$("#fridayE").attr("checked",false);
				$("#saturdayE").attr("checked",false);
				$("#sundayE").attr("checked",false);
		}
		function editDaysSched(day)
		{
			if(day=="Monday")
			{
				$("#mondayE").attr("disabled",true);
				$("#mondayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
			else if(day=="Tuesday")
			{
				$("#mondayE").attr("disabled",true);
				$("#tuesdayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
			else if(day=="Wednesday")
			{
				$("#mondayE").attr("disabled",true);
				$("#wednesdayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
			else if(day=="Thursday")
			{
				$("#mondayE").attr("disabled",true);
				$("#thursdayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
			else if(day=="Friday")
			{
				$("#mondayE").attr("disabled",true);
				$("#fridayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
			else if(day=="Saturday")
			{
				$("#mondayE").attr("disabled",true);
				$("#saturdayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
			else if(day=="Sunday")
			{
				$("#mondayE").attr("disabled",true);
				$("#sundayE").attr("checked",true);
				$("#tuesdayE").attr("disabled",true);
				$("#wednesdayE").attr("disabled",true);
				$("#thursdayE").attr("disabled",true);
				$("#fridayE").attr("disabled",true);
				$("#saturdayE").attr("disabled",true);
				$("#sundayE").attr("disabled",true);
			}
		}
		var page,init,searchQuery="";

		function initialize()
			{
			//initialize search input value 
			init = $("#datagrid-search-box").val().trim();
			}
			
		function loadData(dataString,page,searchQuery)
	    {
		initialize();
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}
			
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeeSchedule/schedule.php",
			type:"POST",
			data:dataString+"&page="+page+"&searchQuery="+searchQuery,
			cache:false,
			beforeSend:
				function()
				{
				//$("#loading").fadeTo("slow",0.7).show();
				},
			success:
				function(response)
				{
				
				    if(response=="news")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data:"module=" + "Personnel Schedule" + "&id=" + employeeId,
							success:
							function(response)
							{
								dataString2 = "role=" + "New Employee Schedule" + "&noun=" + "Employee schedule" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString2,
									success:
									function(response)
									{
										
									}
								});
							}
						});
					
					  alert("Schedule added!");
					  disableFields();
					  $("#new_schedule .formClose").click();
					  loadData("role=VIEW",1,"");
					}
				    else if(response=="new")
					{
						alert($("div#multipleEdit_schedule #save").attr('schedempid'));
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data:"module=" + "Edit Multiple Personnel Schedule" + "&id=" + $("div#multipleEdit_schedule #save").attr('schedempid'),
							success:
							function(response)
							{
								alert(response);
								dataString = "role=" + "Edit Multiple Schedule" + "&noun=" + "Multiple employee schedule" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
									
									}
								});
							}
						});
					
					  alert("Schedule updated!");
					  disableFields();
					  $("#multipleEdit_schedule .formClose").click();
					  loadData("role=VIEW",1,"");
					}
				    else if(response=="update")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data:"module=" + "Edit Personnel Schedule" + "&id=" + editScheduleId,
							success:
							function(response)
							{
								dataString2 = "role=" + "Edit Employee Schedule" + "&noun=" + "Employee schedule" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString2,
									success:
									function(response)
									{
										
									}
								});
							}
						});
					
					  alert("Schedule updated!");
					  disableFields();
					  $("#edit_schedule .formClose").click();
					  loadData("role=VIEW",1,"");
					}
				    else if(response=="delete")
					{					
					  alert("Schedule deleted!");
					  loadData("role=VIEW",1,"");
					  $("#delete_schedule .formClose").click();
					}
					else
					{
						$("#loading").fadeTo("slow",0).hide();
						var arrResponse = response.split('&');
						$('#employee-sched').html(arrResponse[0]);
						setPageBtnValue(arrResponse[2],arrResponse[3]);
						datagrid("employee-sched",true);
						setPageResponse(arrResponse[1]);
						
						$(".empR").click(function(){
						$('#empNameSNew').val($('.empR:checked').attr("empName"));
						$("div#multipleEdit_schedule #save").attr("schedEmpID",$(this).attr("id"));
						$("button#multipleEdit").attr("disabled",false);
						$("button#delete,button#edit").attr("disabled",true);
						$(".selSched").removeClass("activeTr");
						
						});
						
						$(".selSched").click(function(){
						$(".empR").attr("checked",false);
						$(".selSched").removeClass("activeTr");
						$('#empNameS').val($(this).attr("userSched"));
						$("div#edit_schedule #save").attr("sched",$(this).attr("name"));
						$("div#delete_schedule #save").attr("sched",$(this).attr("name"));
						$("button#delete,button#edit").attr("disabled",false);
						$("button#multipleEdit").attr("disabled",true);
						$('#timeInSchedE').val($(this).attr("startT"));
						$('#timeOutSchedE').val($(this).attr("endT"));
						$('#startBreakTimeE').val($(this).attr("startB"));
						$('#endBreakTimeE').val($(this).attr("endB"));
						editScheduleId = $(this).attr('name');
						// alert(editScheduleId);
						
						clearCheck();
						editDaysSched($(this).attr("days"));
						$(this).addClass("activeTr");

						});
					}
				}

			});
		}
		
		$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData("role=VIEW",page,searchQuery);
					$("button#delete,button#edit,button#multipleEdit").attr("disabled",true);	
					});

		
</script>
