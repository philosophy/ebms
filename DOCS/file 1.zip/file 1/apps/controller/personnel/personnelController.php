<script>

var init,page;

//counter variables
var ctr=0;
var ctr2=0;
var ctr3=0;

var shown = false;

var workDetails = new Array();
var educDetails = new Array();

//dataString variables
var dataString1 = "";//dataString var for general Info
var dataString2 = "";//dataString var for educ background info
var dataString3 = "";//dataString var for employee Info
var dataString4 = "";//dataString var for payroll Info


var searchQuery="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	}
//by default, the first page will be displayed
loadData(1,searchQuery);
$("button#edit,button#delete,button#restore").attr("disabled",true);
$("button#new").attr("title","New Employee Record");	
$("button#edit").attr("title","Edit Employee Record");	
$("button#delete").attr("title","Delete Employee Record");	
$("button#restore").attr("title","Restore Employee Record");	

$("#new_personnel #homePhoneNumber").mask("(+99)-999-9999999");
$("#new_personnel #workPhoneNumber").mask("(+99)-999-9999999");
$("#edit_personnel #homePhoneNumber").mask("(+99)-999-9999999");
$("#edit_personnel #workPhoneNumber").mask("(+99)-999-9999999");

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}

		$.ajax({
				type: "POST",
				url: "../../personnel/employeeProfile/personnel.php",
				data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
				success:
				function(response)
				{
		
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				
				setPageBtnValue(arrResponse[2],arrResponse[3]);
			
					$("#employeeProfile").html(arrResponse[0]);
					
					//alert(arrResponse[0]);
					datagrid("employeeProfile",true);
					setPageResponse(arrResponse[1]);
					
					$("#employeeProfile table tr").click(function()
					{
						setCellContentValue($(this));
						
						//educBackground buttons
						$("button#editEducBackgroundForm").attr("disabled",true);
						$("button#restoreEducBackgroundForm").attr("disabled",true);
						$("button#deleteEducBackgroundForm").attr("disabled",true);
						
						//workExp buttons
						$("button#editWorkExpForm").attr("disabled",true);
						$("button#restoreWorkExpForm").attr("disabled",true);
						$("button#deleteWorkExpForm").attr("disabled",true);
						
						//fileLeave buttons
						$("button#editFileLeave").attr("disabled",true);
						$("button#restoreFileLeave").attr("disabled",true);
						$("button#deleteFileLeave").attr("disabled",true);
						
						//fileOvertime buttons
						$("button#editFileOvertime").attr("disabled",true);
						$("button#restoreFileOvertime").attr("disabled",true);
						$("button#deleteFileOvertime").attr("disabled",true);
						
									if($(this).attr("deleted") == "true")
									{
									$("button#restore").removeAttr("disabled");
									$("button#delete").attr("disabled",true);
									$("button#edit").attr("disabled",true);
									$("button#newFileLeave").attr("disabled",true);
									$("button#newFileOvertime").attr("disabled",true);
									$("button#newWorkExpForm").attr("disabled",true);
									$("button#newEducBackgroundForm").attr("disabled",true);
									}
									else if($(this).attr("deleted") == "false")
									{
									$("button#edit").removeAttr("disabled");
									$("button#delete").removeAttr("disabled");
									$("button#newFileLeave").removeAttr("disabled");
									$("button#newFileOvertime").removeAttr("disabled");
									$("button#newWorkExpForm").removeAttr("disabled");
									$("button#newEducBackgroundForm").removeAttr("disabled");
									$("button#restore").attr("disabled",true);
									}
									else
									{
									$("button#delete").attr("disabled",true);
									$("button#restore").attr("disabled",true);
									$("button#edit").attr("disabled",true);
									$("button#newFileLeave").attr("disabled",true);
									$("button#newFileOvertime").attr("disabled",true);
									$("button#newWorkExpForm").attr("disabled",true);
									$("button#newEducBackgroundForm").attr("disabled",true);
									}
							
					});
					
				}
			});
}

			
			$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
						
					});
			
			function updateEducDetails(selector)
			{
				$.post('../../../view/personnel/employeeProfile/educBackground.php', {empCode:$(selector).attr('a')},
				function(response)
				{
					$("#educBackgroundGrid").html(response);
					datagrid('educBackgroundGrid', true);
						
						
								$("#educBackgroundGrid table tr").click(function(){
								$("#educBackgroundGrid table tr").removeClass("activeTr");
								$(this).addClass("activeTr");
								
									$("#restoreEducBackgroundForm").attr("educID",$(this).attr("educBackgroundID"));
									$("#deleteEducBackgroundForm").attr("educID",$(this).attr("educBackgroundID"));
									$("#editEducBackgroundForm").attr("educID",$(this).attr("educBackgroundID"));
									
									
									if($(this).attr("deleted") == "true")
									{
									$("#restoreEducBackgroundForm").removeAttr("disabled");
									$("#deleteEducBackgroundForm").attr("disabled",true);
									$("#editEducBackgroundForm").attr("disabled",true);
									}
									else if($(this).attr("deleted") == "false")
									{
									$("#editEducBackgroundForm").removeAttr("disabled");
									$("#deleteEducBackgroundForm").removeAttr("disabled");
									$("#restoreEducBackgroundForm").attr("disabled",true);
									}
									else
									{
									$("#deleteEducBackgroundForm").attr("disabled",true);
									$("#restoreEducBackgroundForm").attr("disabled",true);
									$("#editEducBackgroundForm").attr("disabled",true);
									}
									
								$("#edit_educBackground #schoolName").val($(this).attr("schoolName")).removeAttr("disabled");
								$("#edit_educBackground #yearGraduated").val($(this).attr("yearGraduated")).removeAttr("disabled");
								$("#edit_educBackground #remarks").val($(this).attr("remarks")).removeAttr("disabled");
								
								shown = false;
								
									
								});
				
				});
			}

			function appendWorkHistory(container,empCompName,empWorkDesc,empWorkExpFrom,empWorkExpTo)
				{
				var tblData = "";
				ctr2++;
					if(empCompName != "" && empWorkDesc != "")
					{
					tblData = "<tr rowNum="+ctr2+"><td class='option'><img ref="+ctr2+" title='Remove Detail' src='/ebms/images/remove.png' class='removeDetail'></td><td><input type='text' id='dataCompName' value='"+empCompName+"' disabled></td><td><input type='text' id='dataWorkExpFrom' datepicker=true value='"+empWorkExpFrom+"'></td><td><input type='text' id='dataWorkExpTo' datepicker=true value='"+empWorkExpTo+"'></td> <td><input type='text' id='dataWorkDesc' value='"+empWorkDesc+"' disabled></td></tr>";
					$(container+" #workDetails").append(tblData);
					
					$(container+" #companyName").val("").focus();
					$(container+" #workDescription").val("");
					$(container+" #workExpFrom").val("");
					$(container+" #workExpTo").val("");
					
					$(container+" #newWorkExpFrom").val("");
					$(container+" #newWorkExpTo").val("");
					
					$(container+" tr").dblclick(function(){
					$(container+" tr").find("td").css({"-webkit-box-shadow":"0 0 35px transparent inset","-moz-box-shadow":"0 0 35px transparent inset","box-shadow":"0 0 35px transparent inset"});
						$(this).find("input").removeAttr("disabled");
						$(this).find("td").css({"-webkit-box-shadow":"0 0 35px silver inset","-moz-box-shadow":"0 0 35px silver inset","box-shadow":"0 0 35px silver inset"});
							
					});
					
					$(container+" .removeDetail").click(function(){
				
					var ref = $(this).attr("ref");
					
						$(container+" #workDetails").find("tr[rowNum="+ref+"]").remove();
					});
					}
					
					else
					{
						//alert("Please specify necessary details");
					}
				}
				
			function formReset(container)
			{
					$(container+" #general #empFname").val("");
					$(container+" #general #empMname").val("");
					$(container+" #general #empLname").val("");
				
					$(container+" #general #empAddress").val("");
					$(container+" #general #empBday").val("");
					$(container+" #general .empGender").removeAttr("checked");
					$(container+" #general #empMaritalStatus").val("");
				
					$(container+" #general #homePhoneNumber").val("");
					$(container+" #general #workPhoneNumber").val("");
					
					$(container+" #educationalBackground #schoolName").val("");
					$(container+" #educationalBackground #yearGraduated").val("");
					$(container+" #educationalBackground #remarks").val("");
					
					$(container+" #educationalBackground #educDetails").html("");
					
					$(container+" #employmentInfo #dateHired").val("");
					$(container+" #employmentInfo #department").val("");
					$(container+" #employmentInfo #position").val("");
					$(container+" #employmentInfo #employmentStatus").val("");
					
					$(container+" #employmentInfo #workDetails").html("");
					
					$(container+" #payrollInfo #regSal").val(0);
					
					$(container+" #payrollInfo #sssNo").val("");
					$(container+" #payrollInfo #philHealthNo").val("");
					$(container+" #payrollInfo #tinNo").val("");
					$(container+" #payrollInfo #pagibigNo").val("");
					
					
					$(container+" .modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
					$(container+" a[href='#general']").click().addClass("modalTabActive");
					
					ctr = 0;
					ctr2 = 0;
					ctr3 = 0;
			}
				
			function appendEducBackground(container,schoolName,yearGraduated,remarks)
				{
				
				var tblData = "";
				ctr++;
					if(schoolName != "" && yearGraduated != "")
					{
					tblData = "<tr rowNum="+ctr+"><td class='option'><img ref="+ctr+" title='Remove Detail' src='/ebms/images/remove.png' class='removeDetail'></td><td><input type='text' id='dataSchName' value='"+schoolName+"' disabled></td><td><input type='text' id='dataYrGrad' datepicker=true value='"+yearGraduated+"' disabled></td><td><input type='text' id='dataRemarks' value='"+remarks+"' disabled></td></tr>";
					$(container+" #educDetails").append(tblData);
					
					$(container+" #schoolName").val("").focus();
					$(container+" #yearGraduated").val("");
					$(container+" #remarks").val("");
					
					$(container+" tr").dblclick(function(){
					$(container+" tr").find("td").css({"-webkit-box-shadow":"0 0 35px transparent inset","-moz-box-shadow":"0 0 35px transparent inset","box-shadow":"0 0 35px transparent inset"});
						$(this).find("input").removeAttr("disabled");
						$(this).find("td").css({"-webkit-box-shadow":"0 0 35px silver inset","-moz-box-shadow":"0 0 35px silver inset","box-shadow":"0 0 35px silver inset"});
							
					});
					
					$(container+" .removeDetail").click(function(){
				
					var ref = $(this).attr("ref");
					
						$(container+" #educDetails").find("tr[rowNum="+ref+"]").remove();
					});
					}
					
					else
					{
						//alert("Please specify necessary details");
					}
				}
			
			function updateWorkDetails(selector)
			{
				$.ajax({
					url:'../../../view/personnel/employeeProfile/workExperience.php', 
					type:'POST',
					data:{empCode:$(selector).attr('a')},
					success:
						function(response)
						{
							$("#workExpGrid").html(response);
							datagrid('workExpGrid', true);
							
								
								$("#workExpGrid table tr").click(function(){
									$("#workExpGrid table tr").removeClass("activeTr");
									$(this).addClass("activeTr");
									
									$("#restoreWorkExpForm").attr("workExpID",$(this).attr("workExpID"));
									$("#deleteWorkExpForm").attr("workExpID",$(this).attr("workExpID"));
									$("#editWorkExpForm").attr("workExpID",$(this).attr("workExpID"));
									
									
									if($(this).attr("deleted") == "true")
									{
									$("#restoreWorkExpForm").removeAttr("disabled");
									$("#deleteWorkExpForm").attr("disabled",true);
									$("#editWorkExpForm").attr("disabled",true);
									}
									else if($(this).attr("deleted") == "false")
									{
									$("#editWorkExpForm").removeAttr("disabled");
									$("#deleteWorkExpForm").removeAttr("disabled");
									$("#restoreWorkExpForm").attr("disabled",true);
									}
									else
									{
									$("#deleteWorkExpForm").attr("disabled",true);
									$("#restoreWorkExpForm").attr("disabled",true);
									$("#editWorkExpForm").attr("disabled",true);
									}
									
									$("#edit_workExp #companyName").val($(this).attr("compName")).removeAttr("disabled");
									$("#edit_workExp #updateWorkExpFrom").val($(this).attr("workExpFrom")).removeAttr("disabled");
									$("#edit_workExp #updateWorkExpTo").val($(this).attr("workExpTo")).removeAttr("disabled");
									$("#edit_workExp #workDescription").val($(this).attr("workDesc")).removeAttr("disabled");
									
								});
								
						}
				});
			}
			function getDateObject(str) {
				  var arr = str.split("-");
				  return new Date( arr[0], arr[1], arr[2]);
			}
			
						$(document).ready(function(){
								
								//work experience
								$("#new_workExp #save").click(function(){
										
										if($("#new_workExp #workDetails tr").length > 0)
										{
										if(confirm("We are now saving this record. Would you like to proceed?") == true)
										{
										
										empCompName = $("#new_workExp #companyName").val().trim();
										empWorkDesc = $("#new_workExp #workDescription").val().trim();
										empWorkExpFrom = $("#new_workExp #newWorkExpFrom").val().trim();
										empWorkExpTo = $("#new_workExp #newWorkExpTo").val().trim();
										
										$("#new_workExp #workDetails tr").each(function(index){
										workDetails[index] = new Array();
												$("#new_workExp #workDetails tr:eq("+index+") td").each(function(index2){
												
												if(index2 > 0)
												{
												//alert(index2+": "+$(this).find("input").val());
												workDetails[index][index2-1] = $(this).find("input").val();
												}
												});
										});
										
										workDetails = JSON.stringify(workDetails);
										dataString = "empID="+$("#employeeProfile table tr.activeTr").attr("a")+"&workDetails="+workDetails;
										
											$.ajax({
											url:"../../../view/personnel/employeeProfile/workExperience.php",
											type:"POST",
											cache:false,
											data:dataString+"&role=new",
											success:
												function(){
												alert("Work History records successfully added");
												$(".formClose,.formFade, #cancel").click();
												
												$("#employeeProfile table tr.activeTr").click();
												//alert($("#employeeProfile table tr.activeTr").attr("a"));
												//alert(dataString);
												workDetails = new Array();
													//updateWorkDetails(selector);
												}
											});
										}
										
										
										}
										
										else
										{
										alert("Please fill necessary fields");
										}

										
										});
																		
								//educ background 
								
								$("#new_educBackground #save").click(function(){
								
								if($("#new_educBackground #educDetails tr").length > 0)
								{
								if(confirm("We are now saving this record. Would you like to proceed?") == true)
								{
								
								
								$("#new_educBackground #educDetails tr").each(function(index){
								educDetails[index] = new Array();
										$("#new_educBackground #educDetails tr:eq("+index+") td").each(function(index2){
										
										if(index2 > 0)
										{
										//alert(index2+": "+$(this).find("input").val());
										educDetails[index][index2-1] = $(this).find("input").val();
										}
										});
								});
								
								educDetails = JSON.stringify(educDetails);
								dataString = "empID="+$("#employeeProfile table tr.activeTr").attr("a")+"&educDetails="+educDetails;
								
									$.ajax({
									url:"../../../view/personnel/employeeProfile/educBackground.php",
									type:"POST",
									cache:false,
									data:dataString+"&role=new",
									success:
										function(){
										alert("Education records successfully added");
										$(".formClose,.formFade, #cancel").click();
										$("#employeeProfile table tr.activeTr").click();
										educDetails = new Array();
											//updateEducDetails(selector);
										}
									});
								}
								
								}
								
								else 
								{
								alert("Please fill necessary fields");
								}
								
							});
							
								//file leave
								$("#new_fileLeave #save").click(function(){
									empID = $("#new_fileLeave #empName").attr("empID");
									leaveType = $("#new_fileLeave #leaveType").val();
									maxDays = $("#new_fileLeave #maxDays").val();
									dateFrom = $("#new_fileLeave #dateFrom").val();
									dateTo = $("#new_fileLeave #dateTo").val();
									
									dateDiff = (getDateObject(dateTo) - getDateObject(dateFrom)) / 86400000;
									
									
									if(leaveType == "" && dateFrom == "" && dateTo == "")
									{
										alert("Please fill necessary fields");
									}
									
									else
									{
										if(dateDiff > maxDays)
										{
											alert("Date range exceeds maximum days allowed.");
										
										}
										
										else
										{
										dataString = "empID="+empID+"&leaveType="+leaveType+"&maxDays="+maxDays+"&dateFrom="+dateFrom+"&dateTo="+dateTo;
											
											//alert(dataString);
											
											$.ajax({
												url:"/ebms/apps/view/personnel/employeeProfile/leave.php",
												type:"POST",
												data:dataString+"&role=new",
												success:
													function(response)
													{
													alert("File leave record successfully added");
													$("#new_fileLeave #empName").removeAttr("empID");
													$("#new_fileLeave #leaveType").val("");
													$("#new_fileLeave #maxDays").val("");
													$("#new_fileLeave #dateFrom").val("");
													$("#new_fileLeave #dateTo").val("");
													$("#new_fileLeave .formClose").click();
													$("#employeeProfile table tr.activeTr").click();
													}
												});
											
										}
									}
									
								});
								
								//file overtime
								$("#new_fileOvertime #save").click(function(){
									
									h = $("#new_fileOvertime #overtimeHours").val().replace(" hours","");
									m = $("#new_fileOvertime #overtimeMinutes").val().replace(" minutes","");
									
									h = (Number(h) * 60);
									overtimeMin = parseInt(h + Number(m));
									empID = $("#new_fileOvertime #empName").attr("empID");
									overtimeDate = $("#new_fileOvertime #overtimeDate").val();
									
									if(overtimeMin == 0 || overtimeDate == "")
									{
										if(overtimeDate == "" && overtimeMin > 0)
										alert("Please specify overtime date");
										
										else if(overtimeDate != "" && overtimeMin == 0)
										alert("Please specify overtime hours");
										
										else if(overtimeDate == "" && overtimeMin == 0)
										alert("Please fill necessary fields");
									}
									
									else 
									{
										dataString = "empID="+empID+"&overtimeMin="+overtimeMin+"&overtimeDate="+overtimeDate+"&role=new";
										
										$.ajax({
												url:"/ebms/apps/view/personnel/employeeProfile/overtime.php",
												type:"POST",
												data:dataString,
												success:
													function(response)
													{
													alert("File overtime record successfully added");
													$("#new_fileOvertime #empName").removeAttr("empID");
													$("#new_fileOvertime #overtimeHours").val("0 hours");
													$("#new_fileOvertime #overtimeMinutes").val("0 minutes");
													$("#new_fileOvertime #overtimeDate").val("");
									
													$(".formFade").click();
													$("#employeeProfile table tr.activeTr").click();
													
													//alert(dataString);
													//alert(response);
													
													}
												});
										
									}
									
									
								});
								
								});
			
			
			function setCellContentValue(selector)
			{
				$("#employeeProfile table").find("tr").removeClass("activeTr");
					
				//then, set the active class to the clicked tr element
				$(selector).addClass("activeTr");
				
				$("#edit").attr("empID",$(selector).attr('a'));
				$("#delete").attr("empID",$(selector).attr('a'));
				$("#restore").attr("empID",$(selector).attr('a'));
				editPersonnelId = $(selector).attr('a');
				
				
				$("#new_fileLeave #empName,#edit_fileLeave #empName,#new_fileOvertime #empName,#edit_fileOvertime #empName").attr("empID",$(selector).attr("a"));
				$("#new_fileLeave #empName,#edit_fileLeave #empName,#new_fileOvertime #empName,#edit_fileOvertime #empName").val($(selector).attr("empName"));
					
				
							$("#new_workExp #saveDetailBtn").click(function(){
								empCompName = $("#new_workExp #companyName").val().trim();
								empWorkDesc = $("#new_workExp #workDescription").val().trim();
								empWorkExpFrom = $("#new_workExp #newWorkExpFrom").val().trim();
								empWorkExpTo = $("#new_workExp #newWorkExpTo").val().trim();
								
									appendWorkHistory("#new_workExp",empCompName,empWorkDesc,empWorkExpFrom,empWorkExpTo);	

							});
							
							$("#new_educBackground #saveDetailBtn").click(function(){
								schoolName = $("#new_educBackground #schoolName").val().trim();
								yearGraduated = $("#new_educBackground #yearGraduated").val().trim();
								remarks = $("#new_educBackground #remarks").val().trim();
								
									appendEducBackground("#new_educBackground",schoolName,yearGraduated,remarks);	

							});
							
							
								$(".formClose,.formFade, #cancel").click(function(){
										
								$("#new_workExp #companyName").val("");
								$("#new_workExp #workDescription").val("");
								$("#new_workExp #newWorkExpFrom").val("");
								$("#new_workExp #newWorkExpTo").val("");
									
									$("#new_workExp #workDetails").html("");
									
								$("#new_educBackground #schoolName").val("");
								$("#new_educBackground #yearGraduated").val("");
								$("#new_educBackground #remarks").val("");
							
									$("#new_educBackground #educDetails").html("");
								});			

							
				$.post('../../../view/personnel/employeeProfile/leave.php', {empCode:$(selector).attr('a')},
				function(response)
				{
					$("#fileLeaveGrid").html(response);
					datagrid('fileLeaveGrid', true);
						
						$("#fileLeaveGrid tr").click(function(){
							$("#fileLeaveGrid tr").removeClass("activeTr");
							$(this).addClass("activeTr");
													
							$("#editFileLeave").attr("leaveID",$(this).attr('leaveID'));
							$("#deleteFileLeave").attr("leaveID",$(this).attr('leaveID'));
							$("#restoreFileLeave").attr("leaveID",$(this).attr('leaveID'));
							if($(this).attr("deleted") == "true")
									{
									$("#restoreFileLeave").removeAttr("disabled");
									$("#deleteFileLeave").attr("disabled",true);
									$("#editFileLeave").attr("disabled",true);
									}
									else if($(this).attr("deleted") == "false")
									{
									$("#editFileLeave").removeAttr("disabled");
									$("#deleteFileLeave").removeAttr("disabled");
									$("#restoreFileLeave").attr("disabled",true);
									}
									else
									{
									$("#deleteFileLeave").attr("disabled",true);
									$("#restoreFileLeave").attr("disabled",true);
									$("#editFileLeave").attr("disabled",true);
									}
									
							dateFrom = $(this).attr("dateFrom");
							dateTo = $(this).attr("dateTo");
							leaveType = $(this).attr("leaveTypeID");
							leaveID = $(this).attr("leaveID");
							maxDays = $(this).attr("maxDays");
							empID = $("#edit_fileLeave #empName").attr("empID");
							
							$("#edit_fileLeave #leaveType").val(leaveType);
							$("#edit_fileLeave #maxDays").val(maxDays);
							$("#edit_fileLeave #editDateFrom").val(dateFrom);
							$("#edit_fileLeave #editDateTo").val(dateTo);
							
							
						});
				});
				
				$.post('../../../view/personnel/employeeProfile/overtime.php', {empCode:$(selector).attr('a')},
				function(response)
				{
					$("#fileOvertimeGrid").html(response);
					datagrid('fileOvertimeGrid', true);
					
						$("#fileOvertimeGrid tr").click(function(){
							$("#fileOvertimeGrid tr").removeClass("activeTr");
							$(this).addClass("activeTr");
													
							$("#editFileOvertime").attr("overtimeID",$(this).attr('overtimeID'));
							$("#deleteFileOvertime").attr("overtimeID",$(this).attr('overtimeID'));
							$("#restoreFileOvertime").attr("overtimeID",$(this).attr('overtimeID'));
							if($(this).attr("deleted") == "true")
									{
									$("#restoreFileOvertime").removeAttr("disabled");
									$("#deleteFileOvertime").attr("disabled",true);
									$("#editFileOvertime").attr("disabled",true);
									}
									else if($(this).attr("deleted") == "false")
									{
									$("#editFileOvertime").removeAttr("disabled");
									$("#deleteFileOvertime").removeAttr("disabled");
									$("#restoreFileOvertime").attr("disabled",true);
									}
									else
									{
									$("#deleteFileOvertime").attr("disabled",true);
									$("#restoreFileOvertime").attr("disabled",true);
									$("#editFileOvertime").attr("disabled",true);
									}
									
							overtimeDate = $(this).attr("overtimeDate");
							overtimeHours = $(this).attr("overtimeHours");
							overtimeMins = $(this).attr("overtimeMins");
							empID = $("#employeeProfile table tr.activeTr").attr("empID");
							
							$("#edit_fileOvertime #empName").attr(empID);
							$("#edit_fileOvertime #editOvertimeHours").val(overtimeHours);
							$("#edit_fileOvertime .sliderHour").slider({value:overtimeHours});
							$("#edit_fileOvertime #editOvertimeMinutes").val(overtimeMins);
							$("#edit_fileOvertime .sliderMinute").slider({value:overtimeMins});
							$("#edit_fileOvertime #editOvertimeDate").val(overtimeDate);
			
							
							
						});
				
				});
				
				updateWorkDetails(selector);
				updateEducDetails(selector);
				
				
				
				$.post('../../../view/personnel/employeeProfile/issuedItem.php', {empCode:$(selector).attr('a')},
				function(response)
				{
					$("#issuedItems").html(response);
					datagrid('issuedItems', true);
				});
			}
			
			
			
			$("button[ref=new_personnel]#new").click(function(){
			
			ctr=0;ctr2=0;ctr3=0;
				
				inputMask("empFname","Firstname");
				inputMask("empMname","Middle name");
				inputMask("empLname","Lastname");
				
				
				$("div#new_personnel").find("#save").text("Next");
				
				$("div#new_personnel a[href='#educationalBackground'],div#new_personnel a[href='#employmentInfo'],div#new_personnel a[href='#payrollInfo']").hide();
				formReset("#new_personnel");
				
				$("div#new_personnel .formFade,div#new_personnel .formClose, div#new_personnel #cancel").click(function(){
					formReset("#new_personnel");
					return false;
				
				});
			
				
			function getGeneralInfo()
			{
			//var empFName,empMName,empLName,empAddress,empBday,empGender,empHomePhoneNo,empWorkPhoneNo;
			
				//employee name
				empFName = $("div#new_personnel #empFname").val().trim();
				empMName = $("div#new_personnel #empMname").val().trim();
				empLName = $("div#new_personnel #empLname").val().trim();
				
				empAddress = $("div#new_personnel #empAddress").val().trim();
				empBday = $("div#new_personnel #empBday").val().trim();
				empGender = $("div#new_personnel .empGender:checked").attr("id");
				
				empMaritalStatus = $("div#new_personnel #empMaritalStatus").val();
				
				empHomePhoneNo = $("div#new_personnel #homePhoneNumber").val().trim();
				empWorkPhoneNo = $("div#new_personnel #workPhoneNumber").val().trim();
			
				
					if((empFName == "Firstname" || empFName == "") || (empLName == "" || empLName == "Lastname") || empAddress == "" || empBday == "" || empGender == "" || empHomePhoneNo == "" || empWorkPhoneNo == "" || empMaritalStatus == "")
					{
					return false;
					}
					
					else 
					{
					dataString1 = "fname="+empFName+"&mname="+empMName+"&lname="+empLName+"&address="+empAddress+"&bday='"+empBday+"'&gender="+empGender+"&maritalStatus="+empMaritalStatus+"&homeNo="+empHomePhoneNo+"&workNo="+empWorkPhoneNo;
					return true;
					}
				
			
			
			//return $("div#new_personnel #empFname").val();
			}
			
			/*
			$(document).ready(function(){
				
				$("#educationalBackground .skip").click(function(){
				
				$(this).attr("skipped","true");
				$("#new_personnel #save").trigger("click");
									//$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
									//$("a[href='#employmentInfo']").show("slow").click().addClass("modalTabActive");
				return false;
				
				});
				$("#employmentInfo .skip").click(function(){
				
				$(this).attr("skipped","true");
				$("#new_personnel #save").trigger("click");
									//$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
									//$("a[href='#payrollInfo']").show("slow").click().addClass("modalTabActive");
										
				//$("#new_personnel #save").text("Save");		

				return false;
				
				});
				
			});
			*/
			
			function getEmpBgInfo()
			{
				
				empSchoolName = $("#educationalBackground #schoolName").val().trim();
				empYrGrad = $("#educationalBackground #yearGraduated").val().trim();
				empRemarks = $("#educationalBackground #remarks").val().trim();
				
				
				if((empSchoolName == "" && empYrGrad == "") && ($("#educationalBackground #educDetails tr").length == 0))
				{
					return false;
				}
				
				else 
				{	
				
					$("#educationalBackground #educDetails tr").each(function(index){
						educDetails[index] = new Array();
						$("#educationalBackground #educDetails tr:eq("+index+") td").each(function(index2){
						
						if(index2 > 0)
						{
						//alert(index2+": "+$(this).find("input").val());
						educDetails[index][index2-1] = $(this).find("input").val();
						}
						
						});
						
					});
					dataString2 = "&schName="+empSchoolName+"&yrGrad="+empYrGrad+"&remarks="+empRemarks;
					return true;
				}
				
			}
			
			function getEmpInfo()
			{
			
				empDateHired = $("#employmentInfo #dateHired").val();
				empDeptID = $("#employmentInfo #department").val();
				empPosID = $("#employmentInfo #position").val();
				empStatus = $("#employmentInfo #employmentStatus").val();
				
				
				if((empDateHired == "" && empPosID == "" && empStatus == "") && ($("#employmentInfo #workDetails tr").length == 0))
				{
					return false;
				}
				
				else 
				{
					
					$("#employmentInfo #workDetails tr").each(function(index){
						workDetails[index] = new Array();
						$("#employmentInfo #workDetails tr:eq("+index+") td").each(function(index2){
						
						
						if(index2 > 0)
						{
						//alert(index2+": "+$(this).find("input").val());
						workDetails[index][index2-1] = $(this).find("input").val();
						}
						
						});
						
					});
					
					
					dataString3 = "&dateHired='"+empDateHired+"'&deptID="+empDeptID+"&posID="+empPosID+"&empStatus="+empStatus;
					return true;
				}
				
			}
			
			function getOthers()
			{
				$("#new_personnel #save").text("Save");
				empSSSNo = $("#payrollInfo #sssNo").val();
				empPhilHealthNo = $("#payrollInfo #philHealthNo").val();
				empTinNo = $("#payrollInfo #tinNo").val();
				empPagibigNo = $("#payrollInfo #pagibigNo").val();
				regSal = $("#payrollInfo #regSal").val();
				
				if(regSal==0 && regSal=="")
				{
				return false;
				}
				
				else if(regSal!=0 || regSal!="")
				{
				
				dataString4 = "&regSal="+regSal+"&sssNo="+empSSSNo+"&philHealthNo="+empPhilHealthNo+"&tinNo="+empTinNo+"&pagibigNo="+empPagibigNo;
				return true;
				}
			}
			
			
				$("#educationalBackground #saveDetailBtn").click(function(){
				var tblData = "";
				empSchoolName = $("#educationalBackground #schoolName").val().trim();
				empYrGrad = $("#educationalBackground #yearGraduated").val().trim();
				empRemarks = $("#educationalBackground #remarks").val().trim();
				ctr++;
					if(empSchoolName != "" && empYrGrad != "")
					{
					tblData = "<tr rowNum="+ctr+"><td class='option'><img ref="+ctr+" title='Remove Detail' src='/ebms/images/remove.png' class='removeDetail'></td><td><input type='text' id='dataSchName' value='"+empSchoolName+"' disabled></td><td><input type='text' id='dataYrGrad' datepicker=true value='"+empYrGrad+"' disabled></td><td><input type='text' id='dataRemarks' value='"+empRemarks+"' disabled></td></tr>";
					$("#educationalBackground #educDetails").append(tblData);
					
					$("#educationalBackground #schoolName").val("").focus();
					$("#educationalBackground #yearGraduated").val("");
					$("#educationalBackground #remarks").val("");
					
					$("#educationalBackground tr").dblclick(function(){
					$("#educationalBackground tr").find("td").css({"-webkit-box-shadow":"0 0 35px transparent inset","-moz-box-shadow":"0 0 35px transparent inset","box-shadow":"0 0 35px transparent inset"});
						$(this).find("input").removeAttr("disabled");
						$(this).find("td").css({"-webkit-box-shadow":"0 0 35px silver inset","-moz-box-shadow":"0 0 35px silver inset","box-shadow":"0 0 35px silver inset"});
							
					});
					
					$("#educationalBackground .removeDetail").click(function(){
				
					var ref = $(this).attr("ref");
					
						$("#educationalBackground #educDetails").find("tr[rowNum="+ref+"]").remove();
					});
					}
					
					else
					{
						//alert("Please specify necessary details");
					}
				return false;
				});
				
				
				
				$("#employmentInfo #saveDetailBtn").click(function(){
				empCompName = $("#employmentInfo #companyName").val().trim();
				empWorkDesc = $("#employmentInfo #workDescription").val().trim();
				empWorkExpFrom = $("#employmentInfo #workExpFrom").val().trim();
				empWorkExpTo = $("#employmentInfo #workExpTo").val().trim();
				
					appendWorkHistory("#employmentInfo",empCompName,empWorkDesc,empWorkExpFrom,empWorkExpTo);
				return false;
				});
				
			$("#new_personnel #save").click(function(){
							
				var isComplete = getGeneralInfo();
					
					if(!isComplete)
					{
						alert("Please complete necessary details");
					}
					
					else if(isComplete)
					{
					$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
					$("a[href='#educationalBackground']").show("slow").click().addClass("modalTabActive");
					
							isComplete = getEmpBgInfo();
						if(ctr > 0)
						{
						
								if(!isComplete)
								{
									alert("Please complete necessary details");
								}
								
								else if(isComplete)
								{
									$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
									$("a[href='#employmentInfo']").show("slow").click().addClass("modalTabActive");
									
										isComplete = getEmpInfo();
										
										if(ctr2 > 0)
										{
											if(!isComplete)
											{
												alert("Please complete necessary details");
											}
											
											else if(isComplete)
											{
												$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
												$("a[href='#payrollInfo']").show("slow").click().addClass("modalTabActive");
												
													isComplete = getOthers();
													
													if(ctr3>0)
													{
														if(isComplete)
														{
															var ans = confirm("We are now saving this record. Would you like to proceed?");
															if(ans)
															{
															
															workDetails = JSON.stringify(workDetails);
															educDetails = JSON.stringify(educDetails);
															dataString = dataString1+dataString2+dataString3+dataString4+"&workDetails="+workDetails+"&educDetails="+educDetails+"&role=new";
															
															$.ajax({
																url:"/ebms/apps/view/personnel/employeeProfile/empProfile.php",
																type:"POST",
																data:dataString,
																success:
																	function(response)
																	{
																		// dataString = "role=" + "New" + "&noun=" + "Personnel record";
																		// $.ajax(
																		// {
																			// url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
																			// type:"POST",
																			// data:dataString,
																			// success:
																			// function(response)
																			// {
																			
																			// }
																		// });
																	
																	loadData($(".page-nav li button").attr("cur_page"),"");
																	alert("Employee record successfully created");
																	$("#new_personnel .formClose").click();
																	ctr3 = 0;
																	ctr2 = 0;
																	ctr = 0;
																	window.location.reload();
																	}
																});
															}
															
															else
															{
															}
														}
													
														else if(!isComplete)
														{
															alert("Please complete necessary details");
														}
													
													}
													ctr3++;
													
													
													
													
													
											}
										}
										
					
								}
						}
					}
					
					
				return false;
			});
			
			});
			
			
			function fetchEducDetails()
			{
				$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",{role:"fetchEducDetails",empID:$("button[ref=edit_personnel]#edit").attr("empID")},
								function(response)
								{
								$("div#edit_personnel #educationalBackground #educDetails").html(response);
									
									$("div#edit_personnel #educationalBackground #educDetails tr").click(function(){
									
										$("div#edit_personnel #educationalBackground #educDetails tr").removeClass("activeTr");
										$(this).addClass("activeTr");
										educID = $(this).attr("educID");
										$("div#edit_personnel #educationalBackground #schoolName").val($(this).attr("educSchName")).removeAttr("disabled");
										$("div#edit_personnel #educationalBackground #yearGraduated").val($(this).attr("educYrGrad")).removeAttr("disabled");
										$("div#edit_personnel #educationalBackground #remarks").val($(this).attr("educRemarks")).removeAttr("disabled");
										$("#edit_personnel #educationalBackground button").removeAttr("disabled");
										
										
										$("#edit_personnel #educationalBackground #saveDetailBtn").click(function(){
										
										schName = $("div#edit_personnel #educationalBackground #schoolName").val();
										yrGrad = $("div#edit_personnel #educationalBackground #yearGraduated").val();
										remarks = $("div#edit_personnel #educationalBackground #remarks").val();
										
											$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",
												{role:"editEducDetails",educID:educID,empID:$("button[ref=edit_personnel]#edit").attr("empID"),schName:schName,yrGrad:yrGrad,remarks:remarks},
												function()
												{
													alert("Detail successfully updated");
									
													fetchEducDetails();
												});
										
										});
										
										
									});
								}
							);
			}
			
			
			function fetchWorkDetails()
			{
				
							$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",{role:"fetchWorkDetails",empID:$("button[ref=edit_personnel]#edit").attr("empID")},
								function(response)
								{
								$("div#edit_personnel #employmentInfo #workDetails").html(response);
								
									$("div#edit_personnel #employmentInfo #workDetails tr").click(function(){
									
										$("div#edit_personnel #employmentInfo #workDetails tr").removeClass("activeTr");
										$(this).addClass("activeTr");
										workExpID = $(this).attr("workExpID");
																									
										$("div#edit_personnel #employmentInfo #companyName").val($(this).attr("workCompName")).removeAttr("disabled");
										$("div#edit_personnel #employmentInfo #workDescription").val($(this).attr("workDesc")).removeAttr("disabled");
										$("div#edit_personnel #employmentInfo #editWorkExpFrom").val($(this).attr("workExpFrom")).removeAttr("disabled");
										$("div#edit_personnel #employmentInfo #editWorkExpTo").val($(this).attr("workExpTo")).removeAttr("disabled");
										$("#edit_personnel #employmentInfo button").removeAttr("disabled");
										
										$("#edit_personnel #employmentInfo #saveDetailBtn").click(function(){
										
										compName = $("div#edit_personnel #employmentInfo #companyName").val();
										workDesc = $("div#edit_personnel #employmentInfo #workDescription").val();
										workExpFrom = $("div#edit_personnel #employmentInfo #editWorkExpFrom").val();
										workExpTo = $("div#edit_personnel #employmentInfo #editWorkExpTo").val();
										
											$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",
												{role:"editWorkDetails",workExpID:workExpID,empID:$("button[ref=edit_personnel]#edit").attr("empID"),compName:compName,workDesc:workDesc,workExpFrom:workExpFrom,workExpTo:workExpTo},
												function()
												{
													alert("Detail successfully updated");
									
													fetchWorkDetails();
												});
										
										});
										
									});
								
								}
							);
			}
			
			$("button[ref=edit_personnel]#edit").click(function(){
				shown = false;
				
				$(".formFade,div#edit_personnel .formClose, div#edit_personnel #cancel").click(function(){
					formReset("#edit_personnel");
					return false;
				alert($(this).attr("empID"));
				});
				
				$.ajax({
				url:"/ebms/apps/view/personnel/employeeProfile/empProfile.php",
				type:"POST",
				data:"role=fetchData&empID="+($(this).attr("empID")),
				success:
					function(response)
					{
						var obj = JSON.parse(response);
						//alert(response);
						
						$("#edit_personnel #empFname").val(obj.data['fname']);
						$("#edit_personnel #empMname").val(obj.data['mname']);
						$("#edit_personnel #empLname").val(obj.data['lname']);
						
						$("div#edit_personnel #empAddress").val(obj.data['address']);
						$("div#edit_personnel #editEmpBday").val(obj.data['bday']);
						$("div#edit_personnel input#"+(obj.data['gender'].toString().toLowerCase())+".empGender").click();
						
						$("div#edit_personnel #employmentInfo #editDateHired").val(obj.data['dateHired']);
						$("div#edit_personnel #empMaritalStatus").val(obj.data['mStat'].toString().toLowerCase());
						$("div#edit_personnel #homePhoneNumber").val(obj.data['homeNo']);
						$("div#edit_personnel #workPhoneNumber").val(obj.data['workNo']);
			
						$("div#edit_personnel #employmentInfo #department").val(obj.data['dept']);
						$("div#edit_personnel #employmentInfo #position").val(obj.data['pos']);
						$("div#edit_personnel #employmentInfo #employmentStatus").val(obj.data['empStat']);
				
						$("div#edit_personnel #payrollInfo #sssNo").val(obj.data['sss']);
						$("div#edit_personnel #payrollInfo #philHealthNo").val(obj.data['philhealth']);
						$("div#edit_personnel #payrollInfo #tinNo").val(obj.data['tin']);
						$("div#edit_personnel #payrollInfo #pagibigNo").val(obj.data['pagibig']);
						$("div#edit_personnel #payrollInfo #regSal").val(obj.data['sal']);
				
							
							fetchEducDetails();
							fetchWorkDetails();
					
					$("div#edit_personnel #save").click(function(){
						
						
						empFName = $("div#edit_personnel #empFname").val().trim();
						empMName = $("div#edit_personnel #empMname").val().trim();
						empLName = $("div#edit_personnel #empLname").val().trim();
						
						empAddress = $("div#edit_personnel #empAddress").val().trim();
						empBday = $("div#edit_personnel #editEmpBday").val().trim();
						empGender = $("div#edit_personnel .empGender:checked").attr("id");
						
						empMaritalStatus = $("div#edit_personnel #empMaritalStatus").val();
						
						empHomePhoneNo = $("div#edit_personnel #homePhoneNumber").val().trim();
						empWorkPhoneNo = $("div#edit_personnel #workPhoneNumber").val().trim();
										
								
						empDateHired = $("div#edit_personnel #employmentInfo #editDateHired").val();
						empDeptID = $("div#edit_personnel #employmentInfo #department").val();
						empPosID = $("div#edit_personnel #employmentInfo #position").val();
						empStatus = $("div#edit_personnel #employmentInfo #employmentStatus").val();
												
						empSSSNo = $("div#edit_personnel #payrollInfo #sssNo").val();
						empPhilHealthNo = $("div#edit_personnel #payrollInfo #philHealthNo").val();
						empTinNo = $("div#edit_personnel #payrollInfo #tinNo").val();
						empPagibigNo = $("div#edit_personnel #payrollInfo #pagibigNo").val();
						regSal = $("div#edit_personnel #payrollInfo #regSal").val();
						
						dataString = "empID="+($("button[ref=edit_personnel]#edit").attr("empID"))+"&fname="+empFName+"&mname="+empMName+"&lname="+empLName+"&address="+empAddress+"&bday="+empBday+"&gender="+empGender+"&mStat="+empMaritalStatus+"&homePhoneNo="+empHomePhoneNo+"&workPhoneNo="+empWorkPhoneNo+"&dateHired="+empDateHired+"&deptID="+empDeptID+"&posID="+empPosID+"&empStat="+empStatus+"&sssNo="+empSSSNo+"&philHealthNo="+empPhilHealthNo+"&tinNo="+empTinNo+"&pagibigNo="+empPagibigNo+"&regSal="+regSal;
						
								
						
						$.ajax({
							url:"/ebms/apps/view/personnel/employeeProfile/empProfile.php",
							type:"POST",
							data:dataString+"&role=editEmp",
							cache:false,
							success:
								function(response)
								{
									$("#edit_personnel .formClose").click();
									loadData($(".page-nav li button").attr("cur_page"),"");
								}
							});
							
						if(!shown)
						{
							alert("Employee profile successfully updated");
							//alert(shown);
							shown = true;
						}
						
						
					});
						
						
						
					}
					});
			});
			
			
			
		$("#delete_personnel #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",
				{role:"delete",empID:$("#delete").attr("empID")},
				function(response)
				{
					alert("Employee record successfully deleted");
					$("button#delete").attr("disabled",true);
					$("div#delete_personnel #cancel").click();
					
					loadData($(".page-nav li button").attr("cur_page"),"");
				});
				
			
		});	
		$("#restore_personnel #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/empProfile.php",
				{role:"restore",empID:$("#restore").attr("empID")},
				function(response)
				{
					alert("Employee record successfully restored");
					$("button#restore").attr("disabled",true);
					$("div#restore_personnel #cancel").click();
					
					loadData($(".page-nav li button").attr("cur_page"),"");
				});
				
			
		});
		
			
			
		$("#delete_fileLeave #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/leave.php",
				{role:"delete",leaveID:$("#deleteFileLeave").attr("leaveID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("File leave record successfully deleted");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
				
			
		});	
		$("#restore_fileLeave #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/leave.php",
				{role:"restore",leaveID:$("#deleteFileLeave").attr("leaveID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("File leave record successfully restored");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
				
			
		});
		
		$("#delete_workExp #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/workExperience.php",
				{role:"delete",workExpID:$("#deleteWorkExpForm").attr("workExpID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("Work history record successfully deleted");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
				
			
		});	
		$("#restore_workExp #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/workExperience.php",
				{role:"restore",workExpID:$("#restoreWorkExpForm").attr("workExpID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("Work history record successfully deleted");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
			
		});
		
		$("#delete_educBackground #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/educBackground.php",
				{role:"delete",educID:$("#deleteEducBackgroundForm").attr("educID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("Education record successfully deleted");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
				
			
		});	
		$("#restore_educBackground #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/educBackground.php",
				{role:"restore",educID:$("#deleteEducBackgroundForm").attr("educID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("Education record successfully restored");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
			
		});
	
		$("#edit_fileLeave #save").click(function(){
		
			empID = $("#edit_fileLeave #empName").attr("empID");
			leaveType = $("#edit_fileLeave #leaveType").val();
			maxDays = $("#edit_fileLeave #maxDays").val();
			dateFrom = $("#edit_fileLeave #editDateFrom").val();
			dateTo = $("#edit_fileLeave #editDateTo").val();
			
		dateDiff = (getDateObject(dateTo) - getDateObject(dateFrom)) / 86400000;
			
			if(leaveType == "" && dateFrom == "" && dateTo == "")
			{
				alert("Please fill necessary fields");
			}
			
			else
			{
				if(dateDiff > maxDays)
				{
					alert("Date range exceeds maximum days allowed.");
				
				}
				
				else
				{
				dataString = "empID="+empID+"&leaveID="+$("#editFileLeave").attr("leaveID")+"&leaveType="+leaveType+"&maxDays="+maxDays+"&dateFrom="+dateFrom+"&dateTo="+dateTo;
				//	alert(dataString);
					
					$.ajax({
						url:"/ebms/apps/view/personnel/employeeProfile/leave.php",
						type:"POST",
						data:dataString+"&role=edit",
						success:
							function(response)
							{
							alert("File leave record successfull updated");
							$(".formFade").click();
							$("#employeeProfile tr.activeTr").click();
							}
						});
					
					
				}
			}
		});
		
		
		$("#edit_educBackground #save").click(function(){
								educBackgroundID = $("#educBackgroundGrid table tr.activeTr").attr("educBackgroundID");
								
								schoolName = $("#edit_educBackground #schoolName").val().trim();
								yearGraduated = $("#edit_educBackground #yearGraduated").val();
								remarks = $("#edit_educBackground #remarks").val();
								
								empID = $("#employeeProfile tr.activeTr").attr("a");
								
									dataString = "empID="+empID+"&educID="+$("#editEducBackgroundForm").attr("educID")+"&schoolName="+schoolName+"&yearGraduated="+yearGraduated+"&remarks="+remarks;
									
									$.ajax({
										url:"../../../view/personnel/employeeProfile/educBackground.php",
										type:"POST",
										cache:false,
										data:dataString+"&role=edit",
										success:
											function(response)
											{
												$(".formClose").click();
												$("#employeeProfile table tr.activeTr").click();
													
													alert("Details successfully updated");
													
											}
										});
									
								});
								
		
		$("#edit_workExp").find("#save").click(function(){
		
		workExpID = $("#editWorkExpForm").attr("workExpID");
		compName = $("#edit_workExp #companyName").val().trim();
		workExpFrom = $("#edit_workExp #updateWorkExpFrom").val();
		workExpTo = $("#edit_workExp #updateWorkExpTo").val();
		workDesc = $("#edit_workExp #workDescription").val().trim();
		empID = $("#employeeProfile table tr.activeTr").attr("a");
		
			dataString = "empID="+empID+"&workExpID="+workExpID+"&compName="+compName+"&workExpFrom="+workExpFrom+"&workExpTo="+workExpTo+"&workDesc="+workDesc;
			
			$.ajax({
				url:"../../../view/personnel/employeeProfile/workExperience.php",
				type:"POST",
				cache:false,
				data:dataString+"&role=edit",
				success:
					function(response)
					{
						$("#edit_workExp .formClose").click();
						$("#employeeProfile table tr[a="+empID+"]").click();
						
						alert("Details successfully updated");
						
					}
				});
			
		});
		
		
		$("#edit_fileOvertime #save").click(function(){
		
									h = $("#edit_fileOvertime #editOvertimeHours").val().replace(" hours","");
									m = $("#edit_fileOvertime #editOvertimeMinutes").val().replace(" minutes","");
									
									h = (Number(h) * 60);
									overtimeMin = parseInt(h + Number(m));
									empID = $("#edit_fileOvertime #empName").attr("empID");
									overtimeDate = $("#edit_fileOvertime #editOvertimeDate").val();
									overtimeID = $("#editFileOvertime").attr("overtimeID");
		
									
									if(overtimeMin == 0 || overtimeDate == "")
									{
										if(overtimeDate == "" && overtimeMin > 0)
										alert("Please specify overtime date");
										
										else if(overtimeDate != "" && overtimeMin == 0)
										alert("Please specify overtime hours");
										
										else if(overtimeDate == "" && overtimeMin == 0)
										alert("Please fill necessary fields");
									}
									
									else 
									{
										dataString = "empID="+empID+"&overtimeMin="+overtimeMin+"&overtimeDate="+overtimeDate+"&role=edit"+"&overtimeID="+overtimeID;
										
										$.ajax({
												url:"/ebms/apps/view/personnel/employeeProfile/overtime.php",
												type:"POST",
												data:dataString,
												success:
													function(response)
													{
													alert("File overtime record successfully updated");
													$("#edit_fileOvertime #empName").removeAttr("empID");
													$("#edit_fileOvertime #editOvertimeHours").val("0 hours");
													$("#edit_fileOvertime #editOvertimeMinutes").val("0 minutes");
													$("#edit_fileOvertime #editOvertimeDate").val("");
									
													$(".formFade").click();
													$("#employeeProfile table tr.activeTr").click();
													
													//alert(dataString);
													//alert(response);
													
													}
												});
										
									}
									
								
		
		});
		
		
		$("#delete_fileOvertime #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/overtime.php",
				{role:"delete",overtimeID:$("#deleteFileOvertime").attr("overtimeID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("Overtime record successfully deleted");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
				
			
		});	
		$("#restore_fileOvertime #save").click(function(){
			
			$.post("/ebms/apps/view/personnel/employeeProfile/overtime.php",
				{role:"restore",overtimeID:$("#restoreFileOvertime").attr("overtimeID"),empID:$("#employeeProfile tr.activeTr").attr("a")},
				function(response)
				{
					alert("Overtime record successfully restored");
					$(".formFade").click();
					$("#employeeProfile tr.activeTr").click();
				});
				
		});
		
</script>
				
