﻿<script>

		$(document).ready(function(){
		
		$("#new").attr('title', 'New Payroll Record');
		$("#edit").attr('title', 'Edit Payroll Record');
		$("button#delete").attr('title', 'Delete Payroll Record');
		$("button#restore").attr('title', 'Restore Payroll Record');
		
		var dataString="";
		var totDed=0, totEarn=0;
		var wTax = 0,cLoan = 0,cAdvance = 0,regHol = 0,allow = 0;
		var otherDeduc = 0, otherEarn = 0;
		var netPay=0;
		var work=0;
	    var overtime = 0,overmin = 0;
		var leavePaid = 0;
		var leaveID="";
		var oded="", oearn="";
		
		$("button#delete,button#edit,button#restore").attr("disabled",true);
					  
		$("#netPayN").val("0.00");
		$("#totalEarningsN").val("0.00");
		$("#totalDeductionsN").val("0.00");
		$("#leavePaidN").val("0.00");
			
		$("#withholdingTaxN,#regHolidayN,#allowanceN,#companyLoansN,#withholdingTaxE,#regHolidayE,#allowanceE,#companyLoansE").bind("keypress", function(e) 
		{ 
			if(e.which!=46 && (e.which<48 || e.which>57))
			{
				return(false);
			}
			if(e.which == 46 && $(this).val().indexOf(".") != -1)
			{
				return(false);
			}
		});
		
		$("#new").click(
		function(){
		disableFields();
		}
		);
		
		$("#pdf").load(
		function(){
		$(this).unbind('click'); 
		});
	
		$("#regHolidayN,#allowanceN,#companyLoansN,#withholdingTaxE,#regHolidayE,#allowanceE,#companyLoansE").blur(function() 
		{ 
		if($(this).val()=="")
		{
		$(this).val("0.00");
		}
		var f = parseFloat($(this).val());
		$(this).val(f.toFixed(2));
		});
					
		function totalDeducEarn(){

		totDed = (parseFloat(wTax) + parseFloat(cLoan) + parseFloat(cAdvance) + parseFloat(otherDeduc)).toFixed(2);
		totEarn = (parseFloat(overtime) + parseFloat(leavePaid) + parseFloat(work) + parseFloat(otherEarn) + parseFloat(regHol) + parseFloat(allow)).toFixed(2);
		netPay = (totEarn-totDed).toFixed(2);
		$("#netPayN").val(netPay);
		$("#netPayE").val(netPay);
		}
		
		$("#withholdingTaxNCheck").click(function(){
		if($("#withholdingTaxNCheck").attr("checked")!=undefined)
		{
		$("#withholdingTaxN").attr("disabled",false);
		}
		else
		{
		$("#withholdingTaxN").attr("disabled",true);
		$("#withholdingTaxN").val("0");
		wTax=0;
		totalDeducEarn();
		$("#totalDeductionsN").val(totDed);
		}
		});
		
		$("#withholdingTaxN").click(function(){
		if($(this).val()=="0")
		{
		$(this).val("");
		}
		});
		
		$("#withholdingTaxN").blur(function(){
		if($(this).val().trim()=="")
		{
		$(this).val("0");
		}
		});
		
		$("#withholdingTaxECheck").click(function(){
		if($("#withholdingTaxECheck").attr("checked")!=undefined)
		{
		$("#withholdingTaxE").attr("disabled",false);
		}
		else
		{
		$("#withholdingTaxE").attr("disabled",true);
		$("#withholdingTaxE").val("0");
		wTax=0;
		totalDeducEarn();
		$("#totalDeductionsE").val(totDed);
		}
		});
		
		$("#withholdingTaxE").click(function(){
		if($(this).val()=="0")
		{
		$(this).val("");
		}
		});
		
		$("#withholdingTaxE").blur(function(){
		if($(this).val().trim()=="")
		{
		$(this).val("0");
		}
		});
		
		$("#companyLoansN,#regHolidayN,#allowanceN").click(function(){
		if($(this).val()=="0.00" || $(this).val()=="0")
		{
		$(this).val("");
		}
		});
		
		$("#companyLoansN,#regHolidayN,#allowanceN").blur(function(){
		if($(this).val().trim()=="")
		{
		$(this).val("0.00");
		}
		});
		
		$("#companyLoansE,#regHolidayE,#allowanceE").click(function(){
		if($(this).val()=="0.00" || $(this).val()=="0")
		{
		$(this).val("");
		}
		});
		
		$("#companyLoansE,#regHolidayE,#allowanceE").blur(function(){
		if($(this).val().trim()=="")
		{
		$(this).val("0.00");
		}
		});
		
		$("#withholdingTaxN").keyup(function()
		{
			totDed = totDed - (parseFloat(totEarn)*($(this).val()*0.01));
			wTax = (parseFloat(totEarn)*($(this).val()*0.01));
			totDed += parseFloat(wTax);
			
			totalDeducEarn();
			if(!isNaN(totDed))
			{$("#totalDeductionsN").val(totDed);}
			else
			{
			wTax = 0;
			totalDeducEarn();
			$("#totalDeductionsN").val(totDed);
			}	
		return false;
		});
		
		$("#withholdingTaxE").keyup(function()
		{
			totDed = totDed - (parseFloat(totEarn)*($(this).val()*0.01));
			wTax = (parseFloat(totEarn)*($(this).val()*0.01));
			totDed += parseFloat(wTax);
			
			totalDeducEarn();
			if(!isNaN(totDed))
			{$("#totalDeductionsE").val(totDed);}
			else
			{
			wTax = 0;
			totalDeducEarn();
			$("#totalDeductionsE").val(totDed);
			}	
		return false;
		});
		
		$("#companyLoansN").keyup(function()
		{
			totDed = totDed- $(this).val();
			cLoan = $(this).val();
			totDed += parseFloat(cLoan);
			totalDeducEarn();
			if(!isNaN(totDed))
			{$("#totalDeductionsN").val(totDed);}
			else
			{
			cLoan = 0;
			totalDeducEarn();
			$("#totalDeductionsN").val(totDed);
			}
		return false;
		});
		
		$("#companyLoansE").keyup(function()
		{
			totDed = totDed- $(this).val();
			cLoan = $(this).val();
			totDed += parseFloat(cLoan);
			totalDeducEarn();
			if(!isNaN(totDed))
			{$("#totalDeductionsE").val(totDed);}
			else
			{
			cLoan = 0;
			totalDeducEarn();
			$("#totalDeductionsE").val(totDed);
			}
		return false;
		});
		
		$("#regHolidayN").keyup(function()
		{
			totEarn = totEarn - parseFloat($(this).val());
			regHol = $(this).val();
			totEarn += parseFloat(regHol);
			totalDeducEarn();
			if(!isNaN(totEarn))
			{$("#totalEarningsN").val(totEarn);}
			else
			{
			regHol = 0;
			totalDeducEarn();
			$("#totalEarningsN").val(totEarn);
			}
		return false;
		});
		
		$("#regHolidayE").keyup(function()
		{
			totEarn = totEarn - parseFloat($(this).val());
			regHol = $(this).val();
			totEarn += parseFloat(regHol);
			totalDeducEarn();
			if(!isNaN(totEarn))
			{$("#totalEarningsE").val(totEarn);}
			else
			{
			regHol = 0;
			totalDeducEarn();
			$("#totalEarningsE").val(totEarn);
			}
		return false;
		});
		
		$("#allowanceN").keyup(function()
		{
			totEarn = totEarn -  parseFloat($(this).val());
			allow = $(this).val();
			totEarn += parseFloat(allow);
			totalDeducEarn();
			if(!isNaN(totEarn))
			{$("#totalEarningsN").val(totEarn);}
			else
			{
			allow = 0;
			totalDeducEarn();
			$("#totalEarningsN").val(totEarn);
			}
		return false;
		});
		
		$("#allowanceE").keyup(function()
		{
			totEarn = totEarn -  parseFloat($(this).val());
			allow = $(this).val();
			totEarn += parseFloat(allow);
			totalDeducEarn();
			if(!isNaN(totEarn))
			{$("#totalEarningsE").val(totEarn);}
			else
			{
			allow = 0;
			totalDeducEarn();
			$("#totalEarningsE").val(totEarn);
			}
		return false;
		});
			
		$("#payrollDateToN").change(function()
		{
			dbRequestSelect("role=VIEW&viewType=comboBox&payFrom="+$("#payrollDateFromN").val()+"&payTo="+$("#payrollDateToN").val());
			disableFields();
		});
		
		$("#payrollDateFromN").change(function()
		{
			dbRequestSelect("role=VIEW&viewType=comboBox&payFrom="+$("#payrollDateFromN").val()+"&payTo="+$("#payrollDateToN").val());
			disableFields();
		});
		
		$("#empNamePayN").change(function()
		{
		
        leavePaid=0;		
		cAdvance = 0;
		overtime = 0;
		overmin = 0;
		totDed = 0;
		totEarn = 0;
		work = 0;
		
		
		if($("#empNamePayN").val()!="none")
		{
		    if($("#payrollDateToN").val()=="" || $("#payrollDateFromN").val()=="")
			{
				 alert("Please select date from and to!");
				 $("#empNamePayN").val("none");
			}
			else
			{
				var id = $(this).val();
				var empInfo = id.split("|");
				$("div#new_payroll #save").attr("pEmpNo",empInfo[0]);
				$("div#new_payroll #save").attr("pDeptID",empInfo[11]);
				$("#empNoPayN").val(empInfo[1]);
				$("#empPositionPayN").val(empInfo[2]);
				$("#empDepartmentPayN").val(empInfo[3]);
				$("#regularPayN").val((parseFloat(empInfo[4])).toFixed(2));
				$("#hourRateN").val((parseFloat(empInfo[5])).toFixed(2));
				$("#hoursWorkedN").val(parseFloat(empInfo[9]));
				$("#minRateN").val((parseFloat(empInfo[7])).toFixed(2));
				$("#minsWorkedN").val(parseFloat(empInfo[10]));
				$("#dailyRateN").val((parseFloat(empInfo[6])).toFixed(2));
				$("#daysWorkedN").val(parseFloat(empInfo[8]));
				
				work = parseFloat($("#minRateN").val()) * parseFloat($("#minsWorkedN").val());
				totalDeducEarn();
				$("#totalEarningsN").val(totEarn);
				dbRequestCashAdvance("role=VIEW&viewType=selectCashAdvance&PayEmpID="+empInfo[0]+"&payFrom="+$("#payrollDateFromN").val()+"&payTo="+$("#payrollDateToN").val());
				dbRequestOvertime("role=VIEW&viewType=selectOvertime&PayEmpID="+empInfo[0]+"&payFrom="+$("#payrollDateFromN").val()+"&payTo="+$("#payrollDateToN").val(),empInfo[7]);
				dbRequestLeave("role=VIEW&viewType=selectLeave&PayEmpID="+empInfo[0],empInfo[6]);
			}
		}
		else
		{
		    $("#leavePaidN").val("0.00");
		    $("#overtimeN").val("0.00");
		    $("#cashAdvanceN").val("0.00");
			$("#empNoPayN").val("");
			$("#empPositionPayN").val("");
			$("#empDepartmentPayN").val("");
			$("#regularPayN").val("0.00");
			$("#hourRateN").val("0.00");
			$("#hoursWorkedN").val("0.00");
			$("#minRateN").val("0.00");
			$("#minsWorkedN").val("0.00");
			$("#dailyRateN").val("0.00");
			$("#daysWorkedN").val("0.00");
			$("#leavePaidN").val("0.00");
			$("#totalDeductionsN").val("0.00");
			$("#totalEarningsN").val("0.00");
			$("#netPayN").val("0.00");
			$("#regHolidayN").val("0.00");
			$("#allowanceN").val("0.00");
			$("#companyLoansN").val("0.00");
			$("#withholdingTaxNCheck").attr("checked",false);
			$("#withholdingTaxN").attr("disabled",true);
			$("#withholdingTaxN").val("0");
			$('#new_payroll #formDataCont').html("<table><th>Leave Name</th><th>From</th><th>To</th></table>");

			totalDeducEarn();
			$("#totalEarningsN").val(totEarn);
		}
		return false;
		});
		
		$("div#new_payroll .formFade,div#new_payroll .formClose, div#new_payroll #cancel, div#edit_payroll .formFade,div#edit_payroll .formClose, div#edit_payroll #cancel").click(function(){
		disableFields();
		$("#empNamePayN").val("none");
		$("#payrollDateToN").val("");
		$("#payrollDateFromN").val("");
		$("#empNamePayE").val("");
		$("#payrollDateToE").val("");
		$("#payrollDateFromE").val("");
		$("button#delete,button#edit,button#restore").attr("disabled",true);
		dbRequest("role=VIEW");
		});
		
		$("div#new_payroll #save").click(function()
		{
			if($("#payrollDateToN").val()=="" || $("#payrollDateFromN").val()=="" || $("#empNamePayN").val()=="none")
			{
				alert("Missed input!");
			}
			else
			{
				if($("#payrollDateToN").val()<$("#payrollDateFromN").val())
				{
					alert("Date To must be greater than Date From!");
				}
				else
				{	
					dataString = "role=new&pDateFrom="+$("#payrollDateFromN").val()+
								 "&pDateTo="+$("#payrollDateToN").val()+"&pBasicSal="+$("#regularPayN").val()+
								 "&pDailyRate="+$("#dailyRateN").val()+"&pHourlyRate="+$("#hourRateN").val()+
								 "&pMinutesRate="+$("#minRateN").val()+"&pOverRate="+overtime+
								 "&pOverMin="+overmin+"&pRegHol="+$("#regHolidayN").val()+
								 "&pAllow="+$("#allowanceN").val()+"&pDaysWork="+$("#daysWorkedN").val()+
								 "&pHoursWork="+$("#hoursWorkedN").val()+"&pMinsWork="+$("#minsWorkedN").val()+
								 "&pTotalEarns="+$("#totalEarningsN").val()+"&pWithTax="+wTax+
								 "&pCompLoan="+$("#companyLoansN").val()+"&pTotalDed="+$("#totalDeductionsN").val()+
								 "&pCashAd="+$("#cashAdvanceN").val()+"&pNetPay="+$("#netPayN").val()+
								 "&pDeptID="+$(this).attr("pDeptID")+"&pEmpID="+$(this).attr("pEmpNo")+
								 "&pLeaveID="+leaveID+"&oded="+oded+"&oearn="+oearn+
								 "&pWithTaxPer="+$("#withholdingTaxN").val()+"&pTotalLeave="+$("#leavePaidN").val();
                    //alert(dataString);
					empIdAudit = $(this).attr('pEmpNo');
					
					dbRequest(dataString);
					oded=""; oearn="";
				}
			}
		return false;
		});

		$("div#edit_payroll #save").click(function()
		{	
			dataString = "role=edit&pRegHol="+$("#regHolidayE").val()+"&pAllow="+$("#allowanceE").val()+
								 "&pTotalEarns="+$("#totalEarningsE").val()+"&pWithTax="+wTax+
								 "&pCompLoan="+$("#companyLoansE").val()+"&pTotalDed="+$("#totalDeductionsE").val()+
								 "&pCashAd="+$("#cashAdvanceE").val()+"&pNetPay="+$("#netPayE").val()+
								 "&pLeaveID="+leaveID+"&oded="+oded+"&oearn="+oearn+
								 "&pWithTaxPer="+$("#withholdingTaxE").val()+
								 "&pTotalLeave="+$("#leavePaidE").val()+"&PayrollID="+$(this).attr("pay");
			
			payrollId = $(this).attr('pay');
			
			dbRequest(dataString);
			oded=""; oearn="";
		return false;
		});
		
		$("div#restore_payroll #save").click(function()
		{
			if($(this).attr("pay")==undefined)
			{
				alert("Please select payroll first!");
			}
			else
			{
			     if($(this).attr("del")=="false")
				 {
					alert("Already active!");
				 }
				 else
				 {
				 dataString = "role=restore&PayrollID="+($(this).attr("pay"));
				 payrollId = $(this).attr('pay');
				 
				 dbRequest(dataString);
				 $(this).attr("pay",null);
				 $("div#delete_payroll #save").attr("pay",null);
				 }
			}
		return false;
		});
		
		$("div#delete_payroll #save").click(function()
		{
			if($(this).attr("pay")==undefined)
			{
				alert("Please select payroll first!");
			}
			else
			{
				 if($(this).attr("del")=="true")
				 {
					alert("Already deleted!");
				 }
				 else
				 {
				 dataString = "role=delete&PayrollID="+($(this).attr("pay"));
				 payrollId = $(this).attr('pay');
				 
				 dbRequest(dataString);
				 $(this).attr("pay",null);
				 $("div#restore_payroll #save").attr("pay",null);
				 }
			}
		return false;
		});
		
		function disableFields()
		{
			$("#leavePaidN").val("0.00");
		    $("#overtimeN").val("0.00");
		    $("#cashAdvanceN").val("0.00");
			$("#empNoPayN").val("");
			$("#empPositionPayN").val("");
			$("#empDepartmentPayN").val("");
			$("#regularPayN").val("0.00");
			$("#hourRateN").val("0.00");
			$("#hoursWorkedN").val("0.00");
			$("#minRateN").val("0.00");
			$("#minsWorkedN").val("0.00");
			$("#dailyRateN").val("0.00");
			$("#daysWorkedN").val("0.00");
			$("#leavePaidN").val("0.00");
			$("#totalDeductionsN").val("0.00");
			$("#totalEarningsN").val("0.00");
			$("#netPayN").val("0.00");
			$("#regHolidayN").val("0.00");
			$("#allowanceN").val("0.00");
			$("#companyLoansN").val("0.00");
			$("#withholdingTaxNCheck").attr("checked",false);
			$("#withholdingTaxN").attr("disabled",true);
			$("#withholdingTaxN").val("0");
			$('#new_payroll #formDataCont').html("<table><th>Leave Name</th><th>From</th><th>To</th></table>");
			
		    totDed=0;totEarn=0;wTax = 0;cLoan = 0;cAdvance = 0;regHol = 0;allow = 0;
		    otherDeduc = 0; otherEarn = 0;
			netPay=0;work=0;overtime = 0;leavePaid = 0;overmin = 0;leaveID="";
			
			/*$.post("/ebms/apps/view/personnel/employeePayroll/payrollList.php",{role:"VIEW",viewType:"otherEarning"},
					function(response)
					{
					$("#otherEarn").html(response);
					});
			$.post("/ebms/apps/view/personnel/employeePayroll/payrollList.php",{role:"VIEW",viewType:"otherDeduction"},
					function(response)
					{
					$("#otherDed").html(response);
					});*/
		}
		
		dbRequest("role=VIEW");
		
		function dbRequestSelect(dataStringSel)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataStringSel,
			cache:false,
			success:
				function(response)
				{
				$('#empNamePayN').html(response);
				}
			});
		}
		
	    function dbRequestCashAdvance(dataStringCA)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataStringCA,
			cache:false,
			success:
				function(response)
				{
				   if(isNaN(response) || response=="" || response==null)
				   {
				   	   cAdvance = 0;
				   }
				   else
				   {
						cAdvance = response;
				   }
				   
				   $('#cashAdvanceN').val((parseFloat(cAdvance)).toFixed(2));
				   totDed = parseFloat(totDed) + parseFloat(cAdvance);
				   $("#totalDeductionsN").val(totDed.toFixed(2));
				   totalDeducEarn();
				}
			});
		}
		
		function dbRequestOvertime(dataStringO,minRate)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataStringO,
			cache:false,
			success:
				function(response)
				{
				   if(isNaN(response) || response=="" || response==null)
				   {
				   	   overtime = 0;
					   overmin = 0;    
				   }
				   else
				   {
						overtime = parseFloat(response) * parseFloat(minRate);
					    overmin = response;
				   }
				   $('#overtimeN').val(overmin+" min ~ "+(parseFloat(overtime)).toFixed(2));
				   totEarn = parseFloat(totEarn) + parseFloat(overtime);
				   $("#totalEarningsN").val(totEarn.toFixed(2));
				   totalDeducEarn();
				   
				}
			});
		}
		
		function dbRequestLeave(dataStringL,dRate)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataStringL,
			cache:false,
			success:
				function(response)
				{
				   $('#new_payroll #formDataCont').html(response);  
				   
				   $(".payLeave").click(function()
					{
						if($(this).attr("checked")!=undefined)
						{
						    leaveID+=($(this).attr("lid")+"|");
							var lPaid = parseFloat($(this).attr("leaveCount"))*parseFloat(dRate);
							leavePaid += parseFloat(lPaid);
							$('#leavePaidN').val(leavePaid.toFixed(2));
							totEarn = parseFloat(totEarn) + (parseFloat($(this).attr("leaveCount"))*parseFloat(dRate));
							$("#totalEarningsN").val(totEarn.toFixed(2));
							totalDeducEarn();
						}
						else
						{
						    leaveID=leaveID.replace($(this).attr("lid")+"|","");
							leavePaid = parseFloat(leavePaid)-(parseFloat($(this).attr("leaveCount"))*parseFloat(dRate));
							$('#leavePaidN').val(leavePaid.toFixed(2));
							totEarn = parseFloat(totEarn) - (parseFloat($(this).attr("leaveCount"))*parseFloat(dRate));
							$("#totalEarningsN").val(totEarn.toFixed(2));
							totalDeducEarn();
						}
					});
				}
			});
		}
		function dbLeaveEdit(dataString,dRate)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataString,
			cache:false,
			success:
				function(response)
				{
				   $('#edit_payroll .leaveEdit').html(response);
				   leaveID="";
				   $(".payLeaveP").click(function()
					{
					
						if($(this).attr("checked")!=undefined)
						{
						    leaveID+=($(this).attr("lidP")+"|");
							var lPaid = parseFloat($(this).attr("leaveCountP"))*parseFloat(dRate);
							leavePaid = parseFloat(leavePaid) + parseFloat(lPaid);
							$('#leavePaidE').val(leavePaid.toFixed(2));
							totEarn = parseFloat(totEarn) + (parseFloat($(this).attr("leaveCountP"))*parseFloat(dRate));
							$("#totalEarningsE").val(totEarn.toFixed(2));
							totalDeducEarn();
						}
						else
						{
						    leaveID=leaveID.replace($(this).attr("lidP")+"|","");
							leavePaid = (parseFloat(leavePaid)).toFixed(2)-(parseFloat($(this).attr("leaveCountP"))*parseFloat(dRate)).toFixed(2);
							$('#leavePaidE').val(leavePaid.toFixed(2));
							
							totEarn = parseFloat(totEarn) - (parseFloat($(this).attr("leaveCountP"))*parseFloat(dRate));
							$("#totalEarningsE").val(totEarn.toFixed(2));
							totalDeducEarn();
						}
					});
					
					$(".payLeaveP").ready(function()
					{
						leaveID="";
							$('.payLeaveP').each(function(){
								if($(this).attr("checked")!=undefined)
								{
								    leaveID+=($(this).attr("lidP")+"|");
								}
								else
								{
									leaveID=leaveID.replace($(this).attr("lidP")+"|","");
								}
							});
				
					});
				}
			});
		}
		function dbEarnEdit(dataString)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataString,
			cache:false,
			success:
				function(response)
				{
				   $('#edit_payroll #otherEarnEdit').html(response);
						
						$(".payEarnE").click(function(){
							if($(this).val()=="0.00" || $(this).val()=="0")
							{ $(this).val("");}
						});
						
						$(".payEarnE").bind("keypress", function(e) 
						{ 
							if(e.which!=46 && (e.which<48 || e.which>57))
							{
								return(false);
							}
							if(e.which == 46 && $(this).val().indexOf(".") != -1)
							{
								return(false);
							}
						});
						
						$(".payEarnE").blur(function() 
						{ 
						var f = parseFloat($(this).val());
						$(this).val(f.toFixed(2));
						});
		
						$(".payEarnE").blur(function(){
							if($(this).val().trim()=="")
							{$(this).val("0.00");}
						});
						
						$(".payEarnE").ready(function()
						{
							oearn="";
							otherEarn=0;
							 
							$('.payEarnE').each(function(){
								 if($(this).val()=="" || $(this).val()==null)
								 {}
								 else
								 {
									otherEarn = parseFloat(otherEarn) + parseFloat($(this).val());
									oearn = oearn + $(this).attr("earnNameEdit") + "|" + $(this).val() + "|";
								 }
							});
							 
							totalDeducEarn();
							$("#totalEarningsE").val(totEarn);
							 
						});
						
						$(".payEarnE").keyup(function()
						{
							 oearn="";
							 otherEarn=0;
							 
							 $('.payEarnE').each(function(){
								 if($(this).val()=="" || $(this).val()==null)
								 {}
								 else
								 {
									otherEarn = parseFloat(otherEarn) + parseFloat($(this).val());
									oearn = oearn + $(this).attr("earnNameEdit") + "|" + $(this).val() + "|";
								 }
							 });
							 
							 totalDeducEarn();
							 $("#totalEarningsE").val(totEarn);
						});
				}
			});
		}
		function dbDedEdit(dataString)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataString,
			cache:false,
			success:
				function(response)
				{
				   $('#edit_payroll #otherDedEdit').html(response);
				   
						$(".payDedE").click(function(){
							if($(this).val()=="0.00" || $(this).val()=="0")
							{ $(this).val("");}
						});
						
						$(".payDedE").bind("keypress", function(e) 
						{ 
							if(e.which!=46 && (e.which<48 || e.which>57))
							{
								return(false);
							}
							if(e.which == 46 && $(this).val().indexOf(".") != -1)
							{
								return(false);
							}
						});
						
						$(".payDedE").blur(function() 
						{ 
						var f = parseFloat($(this).val());
						$(this).val(f.toFixed(2));
						});
						
						$(".payDedE").blur(function(){
							if($(this).val().trim()=="")
							{$(this).val("0.00");}
						});
						
						$(".payDedE").keyup(function()
						{
							oded="";
							otherDeduc=0;
							 
							 $('.payDedE').each(function(){
								 if($(this).val()=="" || $(this).val()==null)
								 {	}
								 else
								 {
									otherDeduc = parseFloat(otherDeduc) + parseFloat($(this).val());
									oded = oded + $(this).attr("dedNameEdit") + "|" + $(this).val() + "|";
								 }
							 });

							 totalDeducEarn();
							 $("#totalDeductionsE").val(totDed);
						});
						
						$(".payDedE").ready(function()
						{
							oded="";
							otherDeduc=0;
							 
							 $('.payDedE').each(function(){
								 if($(this).val()=="" || $(this).val()==null)
								 {	}
								 else
								 {
									otherDeduc = parseFloat(otherDeduc) + parseFloat($(this).val());
									oded = oded + $(this).attr("dedNameEdit") + "|" + $(this).val() + "|";
								 }
							 });

							 totalDeducEarn();
							 $("#totalDeductionsE").val(totDed);
						});
				}
			});
		}
		
		function dbRequest(dataString)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeePayroll/payrollList.php",
			type:"POST",
			data:dataString,
			cache:false,
			success:
				function(response)
				{
					//alert(response);
				    if(response=="new")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data: "module=" + "Payroll" + "&id=" + empIdAudit,
							success:
							function(response)
							{
								dataString = "role=" + "New Payroll" + "&noun=" + "Payroll record" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
										
									}
								});
							}
						});
					
					  alert("Payroll created!");
					  var x = confirm("Do you want to print payslip?")
					if(x == true)
					{
						window.open('/EBMS/apps/view/reports/employee/paySlip.php', 'Pay Slip');						
					}
					  disableFields();
					  dbRequest("role=VIEW");
					  $("#new_payroll .formClose").click();
					  $("#empNamePayN").val("none");
					  $("#payrollDateToN").val("");
					  $("#payrollDateFromN").val("");
					}
				    else if(response=="update")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data: "module=" + "Edit Payroll" + "&id=" + payrollId,
							success:
							function(response)
							{
								dataString = "role=" + "Edit Payroll" + "&noun=" + "Payroll record" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
										
									}
								});
							}
						});
						
					  alert("Payroll updated!");
					  disableFields();
					  dbRequest("role=VIEW");
					  $("#new_payroll .formClose").click();
					  $("#empNamePayN").val("none");
					  $("#payrollDateToN").val("");
					  $("#payrollDateFromN").val("");
					  $("button#delete,button#edit,button#restore").attr("disabled",true);
					}
				    else if(response=="restore")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data: "module=" + "Restore Payroll" + "&id=" + payrollId,
							success:
							function(response)
							{
								dataString = "role=" + "Restore Payroll" + "&noun=" + "Payroll record" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
										
									}
								});
							}
						});
					
					  alert("Payroll restored!");
					  $("#restore_payroll .formClose").click();
					  dbRequest("role=VIEW");
					  $("button#delete,button#edit,button#restore").attr("disabled",true);
					}
				    else if(response=="delete")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data: "module=" + "Delete Payroll" + "&id=" + payrollId,
							success:
							function(response)
							{
								dataString = "role=" + "Delete Payroll" + "&noun=" + "Payroll record" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
										
									}
								});
							}
						});
					
					  alert("Payroll deleted!");
					  $("#delete_payroll .formClose").click();
					  dbRequest("role=VIEW");
					  $("button#delete,button#edit,button#restore").attr("disabled",true);
					}
					else
					{
						$('#employeePayroll').html(response);
						datagrid("employeePayroll",true);
						
						$(".selPayroll").click(function(){
							disableFields();
							$(".selPayroll").removeClass("activeTr");
							$(this).addClass("activeTr");
							$("div#delete_payroll #save").attr("pay",$(this).attr("name"));
							$("div#edit_payroll #save").attr("pay",$(this).attr("name"));
							$("div#restore_payroll #save").attr("pay",$(this).attr("name"));
							$("div#delete_payroll #save").attr("del",$(this).attr("deleted"));
							$("div#restore_payroll #save").attr("del",$(this).attr("deleted"));
							$("#pdf").bind('click',(function ()
							{
								window.open("../../../view/reports/employee/paySlip.php","_new");
							}));
							
							$("#empNamePayE").val($(this).attr("userP"));
							$("#empNoPayE").val($(this).attr("empCodeP"));
							$("#empPositionPayE").val($(this).attr("posP"));
							$("#empDepartmentPayE").val($(this).attr("deptP"));
							$("#regularPayE").val($(this).attr("salP"));
							
							$("#hourRateE").val($(this).attr("hRateP"));
							$("#hoursWorkedE").val($(this).attr("hWorkP"));
							$("#minRateE").val($(this).attr("mRateP"));
							$("#minsWorkedE").val($(this).attr("mWork"));
							$("#dailyRateE").val($(this).attr("dRateP"));
							$("#daysWorkedE").val($(this).attr("dWorkP"));
							$("#overtimeE").val($(this).attr("oMinP") + " min ~ "+ $(this).attr("oRateP"));
							$("#regHolidayE").val($(this).attr("regHolP"));
							$("#allowanceE").val($(this).attr("allowP"));
							
							$("#payrollDateFromE").val($(this).attr("dateFromP"));
							$("#payrollDateToE").val($(this).attr("dateToP"));
							$("#totalEarningsE").val($(this).attr("totEarnP"));
							$("#totalDeductionsE").val($(this).attr("totDedP"));
							$("#netPayE").val($(this).attr("netPayP"));
							$("#leavePaidE").val($(this).attr("totLeaveP"));
							$("#cashAdvanceE").val($(this).attr("cAdP"));
							$("#companyLoansE").val($(this).attr("cLoanP"));
							
							if($(this).attr("wTaxPerP")=="" || $(this).attr("wTaxPerP")=="0" || $(this).attr("wTaxPerP")==null)
							{
								$("#withholdingTaxECheck").attr("checked",false);
							}
							else
							{
							    $("#withholdingTaxECheck").attr("checked",true);
								$("#withholdingTaxE").val($(this).attr("wTaxPerP"));
								$("#withholdingTaxE").attr("disabled",false);
							}
							
							
							totDed = $(this).attr("totDedP");
							totEarn = $(this).attr("totEarnP");
						    wTax = $(this).attr("wTaxP");
							cLoan = $(this).attr("cLoanP");
							cAdvance = $(this).attr("cAdP");
							regHol = $(this).attr("regHolP");
							allow = $(this).attr("allowP");
							netPay = $(this).attr("netPayP");
							work = parseFloat($(this).attr("mRateP")) * parseFloat($(this).attr("mWork"));
							overtime = $(this).attr("oRateP");
							overmin = $(this).attr("oMinP");
							leavePaid = (parseFloat($(this).attr("totLeaveP"))).toFixed(1);
							
							dbLeaveEdit("role=VIEW&viewType=editLeave&PayEmpID="+$(this).attr("empIDP"),$(this).attr("dRateP"));
							dbDedEdit("role=VIEW&viewType=payrollDeduction&payIdEdit="+$(this).attr("name"));
							dbEarnEdit("role=VIEW&viewType=payrollEarning&payIdEdit="+$(this).attr("name"));
							
							
							if($(this).attr("deleted")=="true")
							{
								$("button#delete,button#edit").attr("disabled",true);
								$("button#restore").attr("disabled",false);
							}
							else if($(this).attr("deleted")=="false")
							{
								$("button#delete,button#edit").attr("disabled",false);
								$("button#restore").attr("disabled",true);
							}
						});
						
						$(".otherDed,.otherEarn").click(function(){
							if($(this).val()=="0.00" || $(this).val()=="0")
							{ $(this).val("");}
						});
						
						$(".otherDed,.otherEarn").blur(function(){
							if($(this).val().trim()=="")
							{$(this).val("0.00");}
						});
						
						$(".otherDed,.otherEarn").bind("keypress", function(e) 
						{ 
							if(e.which!=46 && (e.which<48 || e.which>57))
							{
								return(false);
							}
							if(e.which == 46 && $(this).val().indexOf(".") != -1)
							{
								return(false);
							}
						});
						
						$(".otherDed,.otherEarn").blur(function() 
						{ 
						var f = parseFloat($(this).val());
						$(this).val(f.toFixed(2));
						});
						
						$(".otherDed").keyup(function()
						{
							oded="";
							otherDeduc=0;
							 
							 $('.otherDed').each(function(){
								 if($(this).val()=="" || $(this).val()==null)
								 {	}
								 else
								 {
									otherDeduc = parseFloat(otherDeduc) + parseFloat($(this).val());
									oded = oded + $(this).attr("dedName") + "|" + $(this).val() + "|";
								 }
							 });

							 totalDeducEarn();
							 $("#totalDeductionsN").val(totDed);
						});
						
						$(".otherDed").ready(function()
						{
							oded="";
							 
							 $('.otherDed').each(function(){
								 if($(this).val()!="" || $(this).val()!=null)
								 {
									oded = oded + $(this).attr("dedName") + "|" + $(this).val() + "|";
								 }
							 });
						});
						
						$(".otherEarn").ready(function()
						{
							oearn="";
							 
							 $('.otherEarn').each(function(){
								 if($(this).val()!="" || $(this).val()!=null)
								 {
									oearn = oearn + $(this).attr("earnName") + "|" + $(this).val() + "|";
								 }
							 });
						});
						
						$(".otherEarn").keyup(function()
						{
							 oearn="";
							 otherEarn=0;
							 
							 $('.otherEarn').each(function(){
								 if($(this).val()=="" || $(this).val()==null)
								 {}
								 else
								 {
									otherEarn = parseFloat(otherEarn) + parseFloat($(this).val());
									oearn = oearn + $(this).attr("earnName") + "|" + $(this).val() + "|";
								 }
							 });
							
							 totalDeducEarn();
							 $("#totalEarningsN").val(totEarn);
						});
					}
				}

			});
		}

		});
		
</script>
