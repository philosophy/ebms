<?php 
include ("../../../config/config.php");

$uname = @$_POST['uname'];
$user_fullname= @$_POST['user_fullname'];
$ans = @$_POST['forgot_pword_answer'];
$new_pword = @$_POST['new_pword'];

if($_POST['step'] == 1)
{

if($uname == "" && $user_fullname == "")
	{
	echo "null value";
	}
else //details are complete
	{
	$result_uname_finder = mysql_query("
	SELECT * 
	FROM user_account u 
		RIGHT JOIN employee_profile emp on u.EMP_ID = emp.EMP_ID
	WHERE u.USER_NAME = '$uname' 
	  AND emp.EMP_FIRST_NAME+emp.EMP_MIDDLE_NAME+emp.EMP_LAST_NAME = '$user_fullname'
	");
	
	if(mysql_num_rows($result_uname_finder)>0)
	{
	$row = mysql_fetch_assoc($result_uname_finder);	
	echo $row["FORGOT_PASSWORD_QUESTION"];
	}
	
	else //Username not found
		echo "not found";
	}
}

elseif($_POST['step'] == 2)
{
$result_forgot_pword_ans = mysql_query("
	SELECT u.FORGOT_PASSWORD_ANSWER as 'ANS'
	FROM user_account u 
	WHERE u.USER_NAME = '$uname'
	");

$row = mysql_fetch_assoc($result_forgot_pword_ans);
	
	if(strcasecmp($ans,$row['ANS']) == 0)
		{
		echo true;
		}
		
	else // if answer is incorrect
		{
		echo false;
		}
		
}

elseif($_POST['step'] == 3)
{
$update_result = mysql_query("
	UPDATE ebms.user_account u 
	SET u.USER_PASSWORD = sha('$new_pword')
	WHERE u.USER_NAME = '$uname'
	");
	
	echo "Password change successful";
}
	

?>