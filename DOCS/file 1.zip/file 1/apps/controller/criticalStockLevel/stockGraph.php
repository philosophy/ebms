﻿
		function graphPlot(qty,itemName)
		{
		//((itemName=='')?'Item Name':itemName)
		//((itemName=='')?0:Number(qty))
		
		s1 = [[itemName,parseInt(qty)]];
		plot5 = $.jqplot('datagridGraph',[s1],{
		seriesDefaults: {
           renderer: $.jqplot.MeterGaugeRenderer,
           rendererOptions: {
               label: 'Stock Level Graphical View',
               labelPosition: 'top',
               intervalOuterRadius: 130,
               ticks: [0, 100, 200, 300, 400, 500],
               intervals:[100, 400, 500],
               intervalColors:['#cc6666', '#E7E658', '#66cc66']
           }
		},
		legend: { show: true },
		highlighter: {
        show: true,
        sizeAdjust: 7.5
		}
		});
		
		plot5.replot();
		
		}
