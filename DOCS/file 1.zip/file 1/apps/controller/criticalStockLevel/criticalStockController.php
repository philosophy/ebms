﻿<?php 

//controller events for crm profile display

?>

<script>
var init,page,searchQuery="";

var listType = (($("#productAssetList").val() == "")?"product":($("#productAssetList").val()));
function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	}
//by default, the first page will be displayed
loadData(1,searchQuery);
$("#productAssetList").change(function(){
listType = (($(this).val() == "")?"product":($(this).val()));
loadData(1,searchQuery);
});

function loadData(page,searchQuery)
{
	initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
						
			$.ajax({
				type: "POST",
				url: "criticalStockLevel.php",
				data: "page="+page+"&searchQuery="+searchQuery+"&listType="+listType,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
				success: 
				function(response)
				{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				$("#critical-stock-level").html(arrResponse[0]);
				
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				datagrid("critical-stock-level",true);
				setPageResponse(arrResponse[1]);	
				
				
				$("#critical-stock-level table tr").click(function(){
					
					setCellContentValue($(this));
						
					});
				}

				});
}
			
	
				$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
					});
					
			function setCellContentValue(selector)
			{
			//remove all active classes in tr element
					$("#critical-stock-level table").find("tr").removeClass("activeTr");
					
					//then, set the active class to the clicked tr element
					$(selector).addClass("activeTr");
					var itemName = $(selector).attr("itemName");
					var image = $(selector).attr("itemImage");
					var description = $(selector).attr("desc");
					$("#itemImage").css({"background":"url('/ebms/images/stock/"+image+"')","background-size":"100% 100%"}).html('');
					$("#itemDescription span").html(((description=="")?"No description included":description));
					var min = $(selector).attr("min");
					var normal = $(selector).attr("normal");
					var qty = $(selector).attr("qty");
					graphPlot(qty,itemName,min,normal);
		

			}
		
		function graphPlot(qty,itemName,min,normal)
		{
		//((itemName=='')?'Item Name':itemName)
		//((itemName=='')?0:Number(qty))
		
		s1 = [[itemName,parseInt(qty)]];
		plot5 = $.jqplot('datagridGraph',[s1],{
		seriesDefaults: {
           renderer: $.jqplot.MeterGaugeRenderer,
           rendererOptions: {
               label: 'Stock Level Graphical View',
               labelPosition: 'top',
			   labelHeightAdjust:20,
               intervalOuterRadius: 100,
               ticks: [0,min,500,1000],
               intervals:[100,200,500,1000],
               intervalColors:['#cc6666', '#E7E658', '#66cc66','green']
           }
		},
		legend: { show: true },
		highlighter: {
        show: true,
        sizeAdjust: 3.5
		}
		});
		
		plot5.replot();
		
		}

</script>