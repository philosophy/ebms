<?php 
session_start();
include("../../../config/config.php");

$alarmDate = @$_POST['alarmDate'];
$alarmTime = DATE("H:i", STRTOTIME(@$_POST['alarmTime']));
$alarmRepeat = @$_POST['alarmRepeat'];
$subject = addslashes(@$_POST['subject']);
$remarks = addslashes(@$_POST['remarks']);

$empID = $_SESSION['login'];

	$rows = mysql_query("
		INSERT INTO `ebms`.`task_reminder` 
			(`EMP_ID`, `TASK_ALARM_DATE`, `TASK_ALARM_TIME`, `TASK_CREATE_DATE`, `TASK_SUBJECT`, `TASK_REMARKS`, `TASK_REPEAT_ID`, `IS_COMPLETED`) 
		VALUES 
			('$empID', '$alarmDate', '$alarmTime', NOW(), '$subject', '$remarks', '$alarmRepeat', '0')
		");
	echo "Task successfully created";


