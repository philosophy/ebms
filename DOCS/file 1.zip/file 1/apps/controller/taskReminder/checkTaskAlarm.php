<?php 
session_start();
include("../../../config/config.php");

$_SESSION['repeat'] = $_POST['repeat'];

function setAlarm()
{

$output="";
$time = mysql_fetch_array(mysql_query("SELECT CURTIME() as 'time' "));
	$query = mysql_query("
		SELECT task_subject
FROM task_reminder
WHERE (
task_alarm_time >= CURTIME( ) 
or task_alarm_time <= CURTIME( )
)
AND task_alarm_date <=  CURDATE()
AND is_completed =0
AND task_repeat_id = (

SELECT task_repeat_id
FROM task_repeat
WHERE task_repeat_name LIKE  '%".$_SESSION['repeat']."%'
)
		");
		
	if(mysql_num_rows($query)>0)
	{
	while($row = mysql_fetch_array($query))
	{
		$output .= "\n- ".$row['task_subject'];
		//$output = $time['time'];
	}
	
	echo "Task Reminder: ".$output."\n\n"."To stop this alarm, please see 'Mark Completed' on Settings button";
	
	}
	
	else 
		echo "Nothing";
	
	
}

setAlarm();