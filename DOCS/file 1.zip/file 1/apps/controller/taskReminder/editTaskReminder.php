<?php 
session_start();
include("../../../config/config.php");

$task = $_POST['task'];
$alarmDate = @$_POST['datepicker'];
$alarmTime = DATE("H:i", STRTOTIME(@$_POST['timepicker']));
$alarmRepeat = @$_POST['repeat'];
$subject = addslashes(@$_POST['subject']);
$remarks = addslashes(@$_POST['remarks']);

	$rows = mysql_query("
		UPDATE task_reminder 
		SET task_alarm_date = '$alarmDate', task_alarm_time = '$alarmTime', task_repeat_id = '$alarmRepeat', task_subject = '$subject',task_remarks = '$remarks'
		WHERE task_id = '$task'
		");
        echo "Task successfully edited!";
