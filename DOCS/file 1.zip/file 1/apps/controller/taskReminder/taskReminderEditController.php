
<script>
$(document).ready(function(){
	var taskID;

	$("#taskReminderList tr").hover(function(){
				$(".taskMenu").hide();
				
				taskID = $(this).attr("id");
				
				
						$("#taskReminderOption_grid[ref='"+taskID+"'] #markCompleted").click(function(){
							$.post("markCompleted.php",{target:"one",taskID:taskID},
								function()
								{
								alert("Task successfully completed");
								});
						});
					
					$("#taskReminderOption_widget[ref='"+taskID+"']").toggle(function(){
					$("#taskReminderOption_grid[ref='"+taskID+"']").show();
					
						
					},function(){
					$("#taskReminderOption_grid[ref='"+taskID+"']").hide();
					});
					
				$("a[ref='"+taskID+"']").click(function(){
					var task = $(this).attr("ref");
					
					$.ajax({
						url:"taskReminderEditView.php",
						type:"POST",
						data:"taskID="+task,
						success:
						function(response)
						{
						var val = response.split("&");
						$("#editTaskDatepicker").val(val[0]);
						$("#editTaskTimepicker").val(val[1]);
						$("#repeatAlarmCont").html(val[2]);
						$("#editSubject").val(val[3]);
						$("#editRemarks").val(val[4]);
						$("#editTask").dialog("open");
						
							$(".edit-reminder").click(function(){
								var taskDatepicker = $("#editTaskDatepicker").val().trim();
								var taskTimepicker = $("#editTaskTimepicker").val().trim();
								var taskRepeat = $("#editRepeatAlarm").val().trim();
								var taskSubj = $("#editSubject").val().trim();
								var taskRemarks = $("#editRemarks").val().trim();
								
								var dataString = "task="+task+"&datepicker="+taskDatepicker+"&timepicker="+taskTimepicker+"&repeat="+taskRepeat+"&subject="+taskSubj+"&remarks="+taskRemarks;
								
								$.ajax({
									url:"../../../../controller/taskReminder/editTaskReminder.php",
									type:"POST",
									data: dataString,
									cache:false,
									success:
										function()
										{
										alert("Edit successful");
										$(".taskReminderForm").dialog("close");
										}
								});
							return false;
							});
							
						}
					});
				});
					
					
					
				},function(){
					$(this).find("#taskReminderOption_grid[ref='"+taskID+"']").hide();
				});
		
});
	
		$("#editTaskDatepicker").datepicker({dateFormat:"yy-mm-dd"});
		$('#editTaskTimepicker').timePkr();

	$( "#editTask" ).dialog({
			height: 450,
			modal: true,
			autoOpen: false
		});
	
	
</script>