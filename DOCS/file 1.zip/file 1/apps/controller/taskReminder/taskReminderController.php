<script>
		$(document).ready(function(){
		
			$("#markAll").click(function(){
				$.post("markCompleted.php",{target:"all"},function(){alert("Successful");});
			});		
		
		
		$( "#createTask" ).dialog({
			height: 450,
			modal: true,
			autoOpen: false
		});
		
		$("#newTaskReminder").click(function(){
				$("#createTask").dialog("open");
		});
		
		
		$("#datepicker").datepicker({dateFormat:"yy-mm-dd"});
		$('#timepicker').timePkr();
		
		
		$(".save-reminder").click(function(){
		var alarmDate = $("#datepicker").val().trim();
		var alarmTime = $("#timepicker").val().trim();
		var alarmRepeat = $("#repeatAlarm").val().trim();
		var subject = $("#subject").val().trim();
		var remarks = $("#remarks").val();
		
		if(alarmDate == "" || alarmTime == "" || alarmRepeat == "" || subject == "")
			alert("Please complete necessar details");
		else
		{
		
		var dataString = "alarmDate="+alarmDate+"&alarmTime="+alarmTime+"&alarmRepeat="+alarmRepeat+"&subject="+subject+"&remarks="+remarks;
		
			$.ajax({
				url:"../../../../controller/taskReminder/createTaskReminder.php",
				type:"POST",
				data: dataString,
				cache:false,
				success:
					function(response)
					{
					alert(response);
					$(".taskReminderForm").dialog("close");
					
						
					}
			});
		}
		
			return false;
		
		});
		
		
		
		
		});
	</script>