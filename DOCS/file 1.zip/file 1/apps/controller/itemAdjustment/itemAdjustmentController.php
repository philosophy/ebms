<script>
	var searchQuery="";
	var test1=0;
	var test2=0;
	var ctr=0;
		$(document).ready(function(){
		$("#new").attr('title','New Adjustment');
		$("#edit").attr('title','Edit Adjustment');
			loadData(1,searchQuery);
			loadload("");
			
		
			$(".page-nav li button").click(function()
			{
				var activeBtn = $(this).attr("id");
				var cur_page = Number($(this).attr("cur_page"));
				var no_of_paginations = Number($(this).attr("no_of_pagination"));
								
				setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
				loadData(page,searchQuery);
			});
			
			$("div#new_adjustment #prodorasset").change(function(response)
			{
				loadload("");
			});
			
			$("#edit").click(function()
			{
				$("div#edit_adjustment #adjustmentCode").val(adjCode);
				$("div#edit_adjustment #remarks").val(remarks);
				$.post('/EBMS/apps/view/inventory/itemAdjustment/details.php', {adjid:ID, role:"render"},
			function(response)
			{
				$("div#edit_adjustment #items").html(response);
			});
				
			});
	
		$("div#new_adjustment button#save").click(function()
		{	
			test1=0;
			var quantity="";
			var stock="";
			var action="";
			var isAllowed=0;
			 $("div#new_adjustment #items tr").each(function(index)
			 {
				test2=0;
				test1++;
				 $("div#new_adjustment #items tr:eq(" + index + ") td").each(function(index2)
				 {
						test2++;
						if(test2==2)
						{
							quantity = parseInt($(this).find("#qty").val());
						}
						if(test2==3)
						{
							action = $(this).text();
						}
						if(test2==4)
						{
							stock = parseInt($(this).text());
						}
				 });
				 
				 if(action=="Less")
				 {
					if(quantity > stock)
					{
						isAllowed = 1;
					}
				 }
			 });
			 if($("table[ref='addAdjustment'] #items tr").length == 0)
			 {
				alert('Please select items to adjust.');
			 }
			else if(isAllowed == 0 && $("table[ref='addAdjustment'] #items tr").length > 0)
				{
					$.post('/EBMS/apps/view/inventory/itemAdjustment/addAdjustment.php', {role:"add",remarks:$("div#new_adjustment textarea#remarks").val()},
					function(adjCode)
					{
						var quantity="";
						var stock="";
						var action="";
						var code = "";
						var desc="";
						var remarks="";
						$("div#new_adjustment #items tr").each(function(index)
						{
							test2=0;
							 $("div#new_adjustment #items tr:eq(" + index + ") td").each(function(index2)
							 {
								test2++;
								if(test2==1)
								{
									code = $(this).text();
								}
								else if(test2==2)
								{
									quantity = parseInt($(this).find("#qty").val());
								}
								else if(test2==3)
								{
									action = $(this).text();
								}
								else if(test2==4)
								{
									stock = parseInt($(this).text());
								}
								else if(test2==5)
								{
									desc = $(this).text();
								}
								else if(test2==6)
								{
									remarks = $(this).find("#remarks").val();
								}
							 });
							//alert(code + " " + quantity + " " + action + " " + stock + " " + desc + " " + remarks);
							$.post('/EBMS/apps/view/inventory/itemAdjustment/addAdjustment.php', {role:"addDetails",itemCode:code, qty:quantity, method:action, inventory:stock, description:desc, remark:remarks, adjcode:adjCode},
							function(result)
							{
							});
							
							dataString = "role=" + "Adjust" + "&noun=" + "Item " + code + "&qty=" + quantity;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
								
								}
							});
							
						 });
						$("div#new_adjustment .formClose").click();
						loadData(1,searchQuery);
						loadload("");
						$('#details').html("");
						$("div#new_adjustment #items").html("");
						$("div#new_adjustment textarea#remarks").val("");
					});
					
					
				}
				else if(isAllowed == 1)
				{
					alert("Transaction not allowed. The quantity you entered is greater than the quantity in the database.");
				}
		});
			
		$("div#edit_adjustment button#save").click(function()
		{
				$.post('/EBMS/apps/view/inventory/itemAdjustment/addAdjustment.php', {role:"updateHeaderRemarks",adjCode:$("div#edit_adjustment #adjustmentCode").val(), remarks:$("div#edit_adjustment textarea#remarks").val()},
				function(result)
				{
					
				});
				
				$("div#edit_adjustment #items tr").each(function(index)
				{
					$.post('/EBMS/apps/view/inventory/itemAdjustment/addAdjustment.php', {role:"updateDetailsRemarks",id:$(this).attr('id'), remarks:$(this).find("#remarks").val()},
					function(result)
					{
						
					});
				});
				
				dataString = "role=" + "Edit" + "&noun=" + "Item adjustment" + "&code=" + adjCode;
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
					type:"POST",
					data:dataString,
					success:
					function(response)
					{
					
					}
				});
				
				$("div#edit_adjustment .formClose").click();
				$('#details').html("");
				loadData(1,searchQuery);
				loadload("");
				$('#details').html("");
				$("div#edit_adjustment #items").html("");
				$("div#edit_adjustment textarea#remarks").val("");
		});
		$("#new").click(function()
		{
			loadload("");
			
			
		});
		
		});
		
		
		function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
		}
		function loadData(page,searchQuery)
		{
		initialize();
		$("#edit").attr('disabled',true);
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}
		$.ajax({
			type: 'POST',
			url: 'adjustmentList.php',
			cache: false,
			data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
			success: function(response)
			{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
					
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				$('#adjustmentList').html(arrResponse[0]);
				datagrid('adjustmentList', true);
				setPageResponse(arrResponse[1]);
				
				$('#adjustmentList table tr').click(function()
				{
					setCellContentValue($(this));
					itemCode = $(this).attr("a");
				});
			}
			
		});		
		
		}
	
		
		function setCellContentValue(selector)
		{
			$("#adjustmentList table").find("tr").removeClass("activeTr");
			$(selector).addClass("activeTr");
			adjCode = $(selector).attr("a");
			ID = $(selector).attr("adjID");
			item = selector;
			remarks = $(selector).attr("remarks");
			$("#edit").attr('disabled',false);
			$.post('/EBMS/apps/view/inventory/itemAdjustment/details.php', {adjid:ID, role:"view"},
			function(response)
			{
				$('#details').html(response);
				datagrid('details', true);
			});
		}
		
		$(document).ready(function(){
		
		
			inputMask("adjFormDataContSearch","Search");
				
			$("#adjFormDataContSearch").keyup(function(){
			 loadload($(this).val().trim());
			});			
		
		});
		
		
		
		function loadload(q)
		{
			ctr++;
			$.ajax({
			url:"/ebms/apps/view/inventory/itemAdjustment/itemList.php",
			type:"POST",
			data: "q="+q+"&itemType=" + $("div#new_adjustment #prodorasset").val(),
			success:
			function(response){
			$("div[ref=adjustItems] ul").html(response);
			
				$("div[ref=adjustItems] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function(){
					
					$(this).click();
					return false;
					
				});
				var code = "", desc = "";
				$("#new_adjustment div[ref=adjustItems] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						code = $(this).attr("code");
						desc = $(this).attr("desc");
						
						if($("#new_adjustment #items").find("tr[code="+code+"] td").size() > 0)
						{
						
						$("#new_adjustment #items tr td").removeClass("itemActive");
						$("#new_adjustment #items").find("tr[code="+code+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("div.itemDetails").stop().animate({bottom:"100px",opacity:0.8},"1000").show();
						
						
						},function(){
						
						if($("#new_adjustment #items").find("tr[code="+code+"] td").size() > 0)
						$("#new_adjustment #items").find("tr[code="+code+"] td").removeClass("itemActive");
						
						$("div#new_adjustment div.itemDetails").stop().animate({bottom:"80px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
				
				$("div[ref=adjustItems] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function(){
						
						
		
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						
						if($(this).find(".addItem").css("display") == "none")
						{
						var code = $(this).attr("code");
						var qty = $(this).attr("qty");
						var desc = $(this).attr("desc");
						
							$("#items").append("<tr code='"+code+"'><td>"+ code +"</td><td><input type='number' id='qty' value=1></td><td>"+$("div#new_adjustment #addorless option:selected").text()+"</td><td>"+ qty +"</td><td>"+desc+"</td><td><input type='text' id='remarks'/></td></tr>");
							
							$("#items").find("tr[code='"+code+"'] input").bind("keyup input",function(){
								if($(this).val() == "0")
								{
									$(this).val(1);
								}								
							});
						}
						
					$("div#new_adjustment #qty").bind("keypress", function(e) 
					{ 
						return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
					});

						
						$(this).hover(function(){
						
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".select	em").hide();
						}
						
						},function(){
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						}
						
						else
						{
						
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						});
						
				return false;	
				},
				function()
				{
				var code = $(this).attr("code");
					$("#items").find("tr[code="+code+"]").fadeOut("slow",
						function()
						{
							$("#items").find("tr[code="+code+"]").remove();
						});
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						
				});
				
				if(ctr > 1)
				{
					var arr1 = new Array(),arr2 = new Array();
					$("div#new_adjustment div[ref=adjustItems] ul li a").each(function(index){

					var itemListCode = $(this).attr("code");
					arr1[index] = itemListCode;

				});	

				$("div#new_adjustment #items tr").each(function(index)
				{
					var requestedItemsCode = $(this).attr("code");
					arr2[index] = requestedItemsCode;
				});

				for(i=0;i<arr1.length;i++)
				{
					for(x=0;x<arr2.length;x++)
					if(arr1[i] == arr2[x])
					{
						$("div#new_adjustment div[ref=adjustItems] ul li a[code='"+arr1[i]+"']").click();
						$("#items").find("tr[code="+arr1[i]+"]:last-child").remove();
					}
				}
				}
				
			}
		});
		}
		
</script>
