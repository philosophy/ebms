<?php
session_start();
$_SESSION['from'] = $_POST['from'];
$_SESSION['to'] = $_POST['to'];
?>