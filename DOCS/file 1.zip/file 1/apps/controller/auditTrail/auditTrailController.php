<?php 

//controller events for crm profile display

?>

<script>
var init,page,searchQuery="",from="",to="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

$("#datepickers #go").click(function(){
loadData(1,searchQuery);				
});

function loadData(page,searchQuery)
{
	initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	from = $("#from").val();
	to = $("#to").val();
			
						
			$.ajax({
				type: "POST",
				url: "auditTrail.php",
				data: "page="+page+"&searchQuery="+searchQuery+"&from="+from+"&to="+to,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
				success: 
				function(response)
				{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				$("#audit-trail").html(arrResponse[0]);
				
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				datagrid("audit-trail",true);
				setPageResponse(arrResponse[1]);	
					
				}

				});
}
			
	
				$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
					});
					
			

</script>