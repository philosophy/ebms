﻿<?php session_start(); 
	if(!isset($_SESSION['login_auth']))
		{
		header("Location: http://localhost/ebms/"); /* Redirect browser */
		/* Make sure that code below does not get executed when we redirect. */
		exit;
		}	
?>