
<script>
	$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/cityList.php",
		type:"POST",
			
		cache:false,
		success:
			function(response)
			{
				$("#new_supplier #city").html(response);
			}
			
		});
		
	$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/cityList.php",
		type:"POST",
			
		cache:false,
		success:
			function(response)
			{
				$("#edit_supplier #city").html(response);
			}
			
		});
	
	
	$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/jobTitleList.php",
		type:"POST",
			
		cache:false,
		success:
			function(response)
			{
				$("#new_supplier #jobTitle").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/jobTitleList.php",
		type:"POST",
			
		cache:false,
		success:
			function(response)
			{
				$("#edit_supplier #jobTitle").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/locationTypeList.php",
		type:"POST",
			
		cache:false,
		success:
			function(response)
			{
				$("#new_supplier #locationType").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/locationTypeList.php",
		type:"POST",
			
		cache:false,
		success:
			function(response)
			{
				$("#edit_supplier #locationType").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/areaList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
				$("#new_supplier #area").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/areaList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
				$("#edit_supplier #Area").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/industryList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
				$("#new_supplier #industryType").html(response);
			}
			
		});
		
		$.ajax({
		url:"/ebms/apps/view/purchasing/suppliersManagement/industryList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
				$("#edit_supplier #industryType").html(response);
			}
			
		});
</script>