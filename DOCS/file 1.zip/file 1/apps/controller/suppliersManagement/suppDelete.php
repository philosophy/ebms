<?php
session_start();
include("../../../config/config.php");

$suppCode = $_POST['suppCode'];

mysql_query("UPDATE supplier_profile SET is_deleted = '1' WHERE supplier_code='".$suppCode."'");
?>