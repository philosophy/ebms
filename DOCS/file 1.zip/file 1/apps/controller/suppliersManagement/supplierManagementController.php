<script>

var init,page;

var searchQuery="";

var contactDataString = "";
var genDataString = "";
var locDataString = "";
var contactDataString1 = "";
var genDataString1 = "";
var locDataString1 = "";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	$("#new").attr('title', 'New Supplier');
	$('#edit').attr('title', 'Edit Supplier');
	$('div.datagrid-crud-menu #delete').attr('title', 'Delete Supplier');
	$('div.datagrid-crud-menu #restore').attr('title', 'Restore Supplier');
	
	$('#edit').attr('disabled',true);
	$('div.datagrid-crud-menu #delete').attr('disabled',true);
	$('div.datagrid-crud-menu #restore').attr('disabled',true);
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

$("#new_supplier #phoneNo").mask("(+99)-999-9999999");
$("#new_supplier #mobileNo").mask("(+99)9999999999");
$("#new_supplier #faxNo").mask("(+99)-999-9999999");

$("#edit_supplier #phoneNo").mask("(+99)-999-9999999");
$("#edit_supplier #mobileNo").mask("(+99)9999999999");
$("#edit_supplier #faxNo").mask("(+99)-999-9999999");

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	$.ajax({
		url:'/EBMS/apps/view/purchasing/suppliersManagement/supplierList.php', 
		type: "POST",
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]);
				
			$('#supplierList').html(arrResponse[0]);
			datagrid('supplierList', true);
			setPageResponse(arrResponse[1]);
				
			$("#supplierList table tr").click(function()
			{
			setCellContentValue($(this));
						
			});
			}
			});
}

			$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
						
					});
	function deptList()
	{	
		var jobid = $("#new_supplier #jobTitle").val();
		$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/departmentList.php",
			type:"POST",
			data: "jobid="+jobid,
			cache:false,
			success:
				function(response)
				{
					$("#new_supplier #department").html(response);
				}
			
			});
	}
	
	function deptList2()
	{	
		var jobid = $("#edit_supplier #jobTitle").val();
		$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/departmentList.php",
			type:"POST",
			data: "jobid="+jobid,
			cache:false,
			success:
				function(response)
				{
					$("#edit_supplier #department").html(response);
				}
			
			});
	}
	
	$("#edit_supplier #jobTitle").change(function(){
		deptList2();
	});
	
	$("#new_supplier #jobTitle").change(function(){
		deptList();
	});

	function brgyList()
	{
		var cityid = $("#new_supplier #city").val();
		$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/barangayList.php",
			type:"POST",
			data: "cityid="+cityid,
			cache:false,
			success:
				function(response)
				{
					$("#new_supplier #barangay").html(response);
				}
			
		});
	}
	
	function brgyList2()
	{
		var cityid = $("#edit_supplier #city").val();
		$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/barangayList.php",
			type:"POST",
			data: "cityid="+cityid,
			cache:false,
			success:
				function(response)
				{
					$("#edit_supplier #barangay").html(response);
				}
			
		});
	}
	
	
	$("#new_supplier #city").change(function(){
		brgyList();
	});
	
	$("#edit_supplier #city").change(function(){
		brgyList2();
	});

	$('#new').click(function(){
		
		brgyList();
		deptList();
		inputMask("supplierName","Supplier Name");
		$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
		$("#new_supplier a[href='#general']").show().click().addClass("modalTabActive");
		formReset();
		
		$("div#new_supplier .formFade,div#new_supplier .formClose, div#new_supplier #cancel").click(function(){
				
			formReset();
			return false;
				
		});
	});
	
	function formReset()
	{
		$("#general #supplierName").val("");
		$("#general #emailAddress").val("");
		$("#general #mobileNo").val("");
		$("#general #phoneNo").val("");
		$("#general #faxNo").val("");
		$("#general #remarks").val("");
		
		$("#supplierLocation #locationName").val("");
		$("#supplierLocation #address").val("");
		
		$("#supplierContact #contactName").val("");
		$("#supplierContact #emailAddress").val("");
		$("#supplierContact #mobileNo").val("");
		$("#supplierContact #phoneNo").val("");
		$("#supplierContact #faxNo").val("");
		$("#supplierContact #remarks").val("");
	}
	
	function getGenInfo()
	{
		suppName = $("div#new_supplier #general #supplierName").val().trim();
		industry = $("div#new_supplier #general #industryType").val();
		email = $("div#new_supplier #general #emailAddress").val().trim();
		mobile = $("div#new_supplier #general #mobileNo").val().trim();
		phone = $("div#new_supplier #general #phoneNo").val().trim();
		fax = $("div#new_supplier #general #faxNo").val().trim();
		remarks = $("div#new_supplier #general #remarks").val().trim();
		
		
		if ((suppName == "Supplier Name" || suppName == "") || (email == "" && mobile == "" && phone == "" && fax == ""))
		{
			return false;
		}
		else
		{
			genDataString = "suppName="+suppName+"&email="+email+"&mobile="+mobile+"&phone="+phone+"&fax="+fax+"&remarks="+remarks+"&industry="+industry;
			return true;
		}
	}
	
	function getGenInfo2()
	{
		suppName1 = $("div#edit_supplier #general #supplierName").val().trim();
		industry1 = $("div#edit_supplier #general #industryType").val();
		email1 = $("div#edit_supplier #general #emailAddress").val().trim();
		mobile1 = $("div#edit_supplier #general #mobileNo").val().trim();
		phone1 = $("div#edit_supplier #general #phoneNo").val().trim();
		fax1 = $("div#edit_supplier #general #faxNo").val().trim();
		remarks1 = $("div#edit_supplier #general #remarks").val().trim();
		var code = $('#edit').attr('suppCode');
		
		if ((suppName1 == "Supplier Name" || suppName1 == "") || (email1 == "" && mobile1 == "" && phone1 == "" && fax1 == ""))
		{
			return false;
		}
		else
		{
			genDataString1 = "suppName="+suppName1+"&email="+email1+"&mobile="+mobile1+"&phone="+phone1+"&fax="+fax1+"&remarks="+remarks1+"&industry="+industry1+"&code="+code;
			return true;
		}
	}
	
	function getLocInfo()
	{
		locType = $("div#new_supplier #supplierLocation #locationType").val();
		locName = $("div#new_supplier #supplierLocation #locationName").val().trim();
		city = $("div#new_supplier #supplierLocation #city").val();
		brgy = $("div#new_supplier #supplierLocation #barangay").val();
		area = $("div#new_supplier #supplierLocation #area").val();
		address = $("div#new_supplier #supplierLocation #address").val().trim();
		lphone = $("div#new_supplier #supplierLocation #phoneNo").val().trim();
		lfax = $("div#new_supplier #supplierLocation #faxNo").val().trim();
		
		if (locName == "" || address == "" || (lphone == "" && lfax == ""))
		{
			return false;
		}
		else
		{
			locDataString = "locName="+locName+"&city="+city+"&brgy="+brgy+"&area="+area+"&address="+address+"&locType="+locType+"&lphone="+lphone+"&lfax="+lfax;
			return true;
		}
		
	}
	
	function getLocInfo2()
	{
		locType1 = $("div#edit_supplier #supplierLocation #locationType").val();
		locName1 = $("div#edit_supplier #supplierLocation #locationName").val().trim();
		city1 = $("div#edit_supplier #supplierLocation #city").val();
		brgy1 = $("div#edit_supplier #supplierLocation #barangay").val();
		area1 = $("div#edit_supplier #supplierLocation #Area").val();
		address1 = $("div#edit_supplier #supplierLocation #address").val().trim();
		lphone1 = $("div#edit_supplier #supplierLocation #phoneNo").val().trim();
		lfax1 = $("div#edit_supplier #supplierLocation #faxNo").val().trim();
		var code = $('#edit').attr('suppCode');
		
		if (locName1 == "" || address1 == "" || (lphone1 == "" && lfax1 == ""))
		{
			return false;
		}
		else
		{
			locDataString1 = "locName="+locName1+"&city="+city1+"&brgy="+brgy1+"&area="+area1+"&address="+address1+"&locType="+locType1+"&lphone="+lphone1+"&lfax="+lfax1+"&code="+code;
			return true;
		}
		
	}
	
	function getContactInfo()
	{
		contactName = $("div#new_supplier #supplierContact #contactName").val().trim();
		job = $("div#new_supplier #supplierContact #jobTitle").val();
		dept = $("div#new_supplier #supplierContact #department").val();
		cemail = $("div#new_supplier #supplierContact #emailAddress").val().trim();
		cmobile = $("div#new_supplier #supplierContact #mobileNo").val().trim();
		cphone = $("div#new_supplier #supplierContact #phoneNo").val().trim();
		cfax = $("div#new_supplier #supplierContact #faxNo").val().trim();
		
		if ((contactName == "") || (cemail == "" && cmobile == "" && cphone == "" && cfax == ""))
		{
			return false;
		}
		else
		{
			contactDataString = "contactName="+contactName+"&job="+job+"&dept="+dept+"&cemail="+cemail+"&cmobile="+cmobile+"&cphone="+cphone+"&cfax="+cfax;
			return true;
		}
	}
	
	function getContactInfo2()
	{
		contactName1 = $("div#edit_supplier #supplierContact #contactName").val().trim();
		job1 = $("div#edit_supplier #supplierContact #jobTitle").val();
		dept1 = $("div#edit_supplier #supplierContact #department").val();
		cemail1 = $("div#edit_supplier #supplierContact #emailAddress").val().trim();
		cmobile1 = $("div#edit_supplier #supplierContact #mobileNo").val().trim();
		cphone1 = $("div#edit_supplier #supplierContact #phoneNo").val().trim();
		cfax1 = $("div#edit_supplier #supplierContact #faxNo").val().trim();
		
		if ((contactName1 == "") || (cemail1 == "" && cmobile1 == "" && cphone1 == "" && cfax1 == ""))
		{
			return false;
		}
		else
		{
			contactDataString1 = "&contactName="+contactName1+"&job="+job1+"&dept="+dept1+"&cemail="+cemail1+"&cmobile="+cmobile1+"&cphone="+cphone1+"&cfax="+cfax1;
			return true;
		}
	}
	
	$('#new_supplier #save').click(function(){
	
		var isCompleteGen = getGenInfo();
		var isCompleteLoc = getLocInfo();
		var isCompleteContact = getContactInfo();
		
		if (!isCompleteGen)
		{
			alert("Please fillup the necessary details in the General Tab.");
			$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
			$("#new_supplier a[href='#general']").show().click().addClass("modalTabActive");
		}
		else if(!isCompleteLoc)
		{
			alert("Please fillup the necessary details in the Location Tab.");
			$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
			$("#new_supplier a[href='#supplierLocation']").show().click().addClass("modalTabActive");
		}
		else if(!isCompleteContact)
		{
			alert("Please fillup the necessary details in the Contact Tab.");
			$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
			$("#new_supplier a[href='#supplierContact']").show().click().addClass("modalTabActive");
		}
		else
		{
			$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/insertSupplier.php",
			type:"POST",
			data: genDataString,
			cache:false,
			success:
				function(response)
				{
					
				}
			});
			
			$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/insertLocation.php",
			type:"POST",
			data: locDataString,
			cache:false,
			success:
				function(response)
				{
					
				}
			});
			
			$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/insertContact.php",
			type:"POST",
			data: contactDataString,
			cache:false,
			success:
				function(response)
				{
					dataString = "role=" + "New" + "&noun=" + "Supplier Record";
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
						
						}
					});
				
					alert("Supplier record successfully created!");
					loadData(1,searchQuery);
					formReset();
					$("div#new_supplier.modalForm").fadeOut("slow",0,
						function()
						{
							$(".formFade").fadeOut(300,
								function(){
									$(".formFade").remove();
								});
							$("div#new_po.modalForm").hide();
						
					});
				}
			});
		}
		
	});
	
	$('#edit_supplier #save').click(function(){
	
		
		var isCompleteGen = getGenInfo2();
		var isCompleteLoc = getLocInfo2();
		var isCompleteContact = getContactInfo2();
		
		if (!isCompleteGen)
		{
			alert("Please fillup the necessary details in the General Tab.");
			$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
			$("#edit_supplier a[href='#general']").show().click().addClass("modalTabActive");
		}
		else if(!isCompleteLoc)
		{
			alert("Please fillup the necessary details in the Location Tab.");
			$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
			$("#edit_supplier a[href='#supplierLocation']").show().click().addClass("modalTabActive");
		}
		else if(!isCompleteContact)
		{
			alert("Please fillup the necessary details in the Contact Tab.");
			$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
			$("#edit_supplier a[href='#supplierContact']").show().click().addClass("modalTabActive");
		}
		else
		{
			$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/editSupplier.php",
			type:"POST",
			data: genDataString1,
			cache:false,
			success:
				function(response)
				{
					
				}
			});
			
			$.ajax({
			url:"/ebms/apps/view/purchasing/suppliersManagement/editLocContact.php",
			type:"POST",
			data: locDataString1+contactDataString1,
			cache:false,
			success:
				function(response)
				{
					
					dataString = "role=" + "Edit" + "&noun=" + "Supplier record" + "&code=" + editSupplierId;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							
						}
					});
					
					alert("Supplier record successfully updated!");
					loadData(1,searchQuery);
					$("div#edit_supplier.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
							function(){
								$(".formFade").remove();
							});
						$("div#edit_supplier.modalForm").hide();
						
					});
				}
			});
		}
	
	});
	
	function setCellContentValue(selector)
	{
		//remove all active classes in tr element
		$("#supplierList table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		$("#edit").attr("suppCode",$(selector).attr("a"));
		$("#delete_supplier #delete").attr("suppCode",$(selector).attr("a"));
		$("#restore_supplier #restore").attr("suppCode",$(selector).attr("a"));
		editSupplierId = $(selector).attr('a');
		
		if ($(selector).attr("deleted") == "false")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",false);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
			$('#edit').attr('disabled',false);
		}
		else if ($(selector).attr("deleted") == "true")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",false);
			$('#edit').attr('disabled',true);
		}
		
		$.post('/EBMS/apps/view/purchasing/suppliersManagement/supplierIssuedItem.php', {suppCode:$(selector).attr('a')},
		function(response)
		{
			$('#supplierIssuedItem').html(response);
			datagrid('supplierIssuedItem', true);
		});
		$.post('/EBMS/apps/view/purchasing/suppliersManagement/supplierPurchasedItem.php', {suppCode:$(selector).attr('a')},
		function(response)
		{
			$('#supplierPurchasedItem').html(response);
			datagrid('supplierPurchasedItem', true);
		});
		$.post('/EBMS/apps/view/purchasing/suppliersManagement/supplierTransactionHistory.php', {suppCode:$(selector).attr('a')},
		function(response)
		{
			$('#supplierPurchaseHistory').html(response);
			datagrid('supplierPurchaseHistory', true);
		});
		
		$('#delete_supplier #delete').click(function()
		{
			$.post('../../../controller/suppliersManagement/suppDelete.php',{suppCode:$(this).attr('suppCode')},
				function()
				{
					dataString = "role=" + "Delete" + "&noun=" + "Supplier record" + "&code=" + editSupplierId;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							
						}
					});
				
					$("div#delete_supplier.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#delete_supplier.modalForm").hide();
					});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#restore_supplier #restore').click(function()
		{
			$.post('../../../controller/suppliersManagement/suppRestore.php',{suppCode:$(this).attr('suppCode')},
				function()
				{
					dataString = "role=" + "Restore" + "&noun=" + "Supplier record" + "&code=" + editSupplierId;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							
						}
					});
				
					$("div#restore_supplier.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#restore_supplier.modalForm").hide();
					});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#edit').click(function()
			{$.post('../../purchasing/suppliersManagement/supplierDetails.php',{suppCode:$(this).attr('suppCode')},function(response){ 
			
				
				$(".modalTabNav #modalTabList #modalTabLink").removeClass("modalTabActive");
				$("#edit_supplier a[href='#general']").show().click().addClass("modalTabActive");
			
				obj = JSON.parse(response);
				
				$("div#edit_supplier #general #supplierCode").val(obj.values["sCode"]);
				$("div#edit_supplier #general #supplierName").val(obj.values["sName"]);
				$("div#edit_supplier #general #emailAddress").val(obj.values["sMail"]);
				$("div#edit_supplier #general #mobileNo").val(obj.values["sMobile"]);
				$("div#edit_supplier #general #phoneNo").val(obj.values["sPhone"]);
				$("div#edit_supplier #general #faxNo").val(obj.values["sFax"]);
				$("div#edit_supplier #general #remarks").val(obj.values["sRemarks"]);
				$("div#edit_supplier #general #industryType").val(obj.values["sIndustryID"]);
				
				$("div#edit_supplier #supplierLocation #supplierCode").val(obj.values["sCode"]);
				$("div#edit_supplier #supplierLocation #locationType").val(obj.loc["lLocID"]);
				$("div#edit_supplier #supplierLocation #locationName").val(obj.loc["lName"]);
				$("div#edit_supplier #supplierLocation #city").val(obj.loc["lCityID"]);
				$("div#edit_supplier #supplierLocation #barangay").val(obj.loc["lBrgyID"]);
				brgyList2();
				$("div#edit_supplier #supplierLocation #area").val(obj.loc["lAreaID"]);
				$("div#edit_supplier #supplierLocation #address").val(obj.loc["lAddress"]);
				$("div#edit_supplier #supplierLocation #phoneNo").val(obj.loc["lPhone"]);
				$("div#edit_supplier #supplierLocation #faxNo").val(obj.loc["lFax"]);
				
				$("div#edit_supplier #supplierContact #supplierCode").val(obj.values["sCode"]);
				$("div#edit_supplier #supplierContact #contactName").val(obj.contact["cName"]);
				$("div#edit_supplier #supplierContact #jobTitle").val(obj.contact["jobTitle"]);
				$("div#edit_supplier #supplierContact #department").val(obj.contact["dept"]);
				deptList2();
				$("div#edit_supplier #supplierContact #emailAddress").val(obj.contact["cMail"]);
				$("div#edit_supplier #supplierContact #mobileNo").val(obj.contact["cMobile"]);
				$("div#edit_supplier #supplierContact #phoneNo").val(obj.contact["cPhone"]);
				$("div#edit_supplier #supplierContact #faxNo").val(obj.contact["cFax"]);
			});
		});
	}

</script>