<?php
session_start();
include("../../../config/config.php");

$suppCode = $_POST['suppCode'];

mysql_query("UPDATE supplier_profile SET is_deleted = '0' WHERE supplier_code='".$suppCode."'");
?>