<script>

	
	var init = "",page = "";
	var searchQuery="";
	var acctDetails = new Array();
	
	function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
		}
	
	//by default, the first page will be displayed
	loadData(1,searchQuery);

	function loadData(page,searchQuery)
	{
	
					initialize();
					if(init == "" || init == "Search...")
						{
						searchQuery = "";
						}
					
					else 
						{
						searchQuery = init;
						
						}	

				$.ajax({
					type: "POST",
					url: "bankList.php",
					data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
					success: function(response)
					{
						$("button#edit,button#delete,button#restore").attr("disabled",true);
						
						$("#loading").fadeTo("slow",0).hide();
						var arrResponse = response.split('&');
						
						$("#bank-records").html(arrResponse[0]);
						setPageBtnValue(arrResponse[2],arrResponse[3]);
						datagrid("bank-records", true);
						setPageResponse(arrResponse[1]);		
						
						$("#bank-records table tr").click(function()
						{
							$("#bankWithdrawal #newBankWithdrawal").removeAttr("disabled");
							
							$("#bank-records table").find("tr").removeClass("activeTr");
							$(this).addClass("activeTr");
							
						
							if($(this).attr("deleted") == "true")
							{
							$("button#restore").removeAttr("disabled");
							$("button#edit,button#delete").attr("disabled",true);
							}
							else if($(this).attr("deleted") == "false")
							{
							$("button#restore").attr("disabled",true);
							$("button#edit,button#delete").removeAttr("disabled");
							}
							
							
							cellContentClick($(this));
							
						});
					}
				});
	}
	
	$(".page-nav li button").click(function()
	{							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
	});
	
	var ctr2 = 0;
	function appendAcctInfo(container,acctName,acctNo,acctType)
				{
				var tblData = "";
				//alert("LOL");
				ctr2++;
					if(acctName != "" && acctNo != "")
					{
					tblData = "<tr rowNum="+ctr2+"><td class='option'><img ref="+ctr2+" title='Remove Detail' src='/ebms/images/remove.png' class='removeDetail'></td><td><input type='text' id='dataAcctName' value='"+acctName+"' disabled></td><td><input type='text' id='dataAcctNo' value='"+acctNo+"'></td> <td><input type='text' id='dataAcctType' value='"+acctType+"' disabled></td></tr>";
					$(container+" #acctDetails").append(tblData);
					
					$(container+" #acctName").val("").focus();
					$(container+" #acctNo").val("");
					$(container+" #acctType").val("current");
					
					$(container+" tr").dblclick(function(){
						$(this).find("input").removeAttr("disabled");
						$(this).find("td").css({"-webkit-box-shadow":"0 0 35px silver inset","-moz-box-shadow":"0 0 35px silver inset","box-shadow":"0 0 35px silver inset"});
							
					});
					
					$(container+" .removeDetail").click(function(){
				
					var ref = $(this).attr("ref");
					
						$(container+" #acctDetails").find("tr[rowNum="+ref+"]").remove();
					});
					}
					
					else
					{	
						$(container+" #acctName").focus();
						alert("Please specify necessary details");
					}
				}
			
	
	function setAcctType()
	{
				
				acctType = $("#new_bankWithdrawal #acctNo option:selected").attr("acctType")
				if(acctType == null)
				{
				}
				else 
				{
				acctType = acctType.toLowerCase();	
				}	
				$("#new_bankWithdrawal #acctType").val(acctType);
	}
	
	function cellContentClick(selector)
	{
		
		$("button#edit,button#restore,button#delete").attr("bankID",$(selector).attr("a"));
		
	
		$.post("/ebms/apps/view/accounting/bankRecords/bankAccountNo.php",
			{bankID:$(selector).attr("a")},
			function(response)
			{
				$("#new_bankWithdrawal #acctNo").html(response);
				
				setAcctType();
				
				$("#new_bankWithdrawal #acctNo").change(function(){
					setAcctType();
				});
				
			});
			
			
		//added by janine
		$.post("cashOnBankByAccountNo.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			alert(response);
			$("#cashOnBank").html(response);
			datagrid("cashOnBank", true);
		});
	
		
		$.post("bankDeposit.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("#bankDeposit #subgrid-first").html(response);
			datagrid("subgrid-first", true);
			
			$('#bankDeposit #subgrid-first table tr').click(function()
			{
				$("#bankDeposit #subgrid-first table").find("tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$.post("bankDepositDetails.php", {depositId:$(this).attr("a")},
				function(response)
				{
					$("#bankDeposit #subgrid-second").html(response);
					datagrid("subgrid-second", true);
				});
				return false;
			});
		});

		
		$.post("bankWithdrawal.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("#bankWithdrawalGrid").html(response);
			datagrid("bankWithdrawalGrid", true);
		});
		
		$.post("issuedCheques.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("div#issuedCheques").html(response);
			datagrid("issuedCheques", true);
		});
	}
	
	
	$("#edit").click(function(){
	bankID = $(this).attr("bankID");
	
		$.ajax({
			url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
			type:"POST",
			data:"role=fetchData&bankID="+bankID,
			cache:false,
			success:
				function(response)
				{
				
				}
		});
	
	});
	
	$("#new_bankWithdrawal #save").click(function(){
		
		withDate = $("#new_bankWithdrawal #withDate").val().trim();
		withAcctID = $("#new_bankWithdrawal #acctNo").val().trim();
		withAmount = $("#new_bankWithdrawal #amount").val().trim();
		withBy = $("#new_bankWithdrawal #withdrawnBy").val().trim();
		withRemarks = $("#new_bankWithdrawal #remarks").val().trim();
		bankID = $("#bank-records table tr.activeTr").attr("a");
			if(withDate == "" && withAcctNo == "" && (withAmount == "" || withAmount == 0) && withBy == "")
				alert("Please fill necessary fields");
				
			else 
			{
				dataString = "bankID="+bankID+"&withDate="+withDate+"&withAcctID="+withAcctID+"&withAmount="+withAmount+"&withBy="+withBy+"&withRemarks="+withRemarks;
				
				$.ajax({
					url:"/ebms/apps/view/accounting/bankRecords/bankWithdrawal.php",
					type:"POST",
					data:dataString+"&role=new",
					cache:false,
					success:
						function()
						{
							alert("Bank withdrawal successful");
							$("#bank-records table tr.activeTr").click();
							$(".formClose").click();
												
							$("#new_bankWithdrawal #withDate").val(<?php echo date("Y-m-d"); ?>);
							$("#new_bankWithdrawal #acctNo").val("");
							$("#new_bankWithdrawal #amount").val("0");
							$("#new_bankWithdrawal #withdrawnBy").val("");
							$("#new_bankWithdrawal #remarks").val("");
						}
				});
			}
	
	});

	
	$("#delete_bank #save").click(function(){
		
		$.post("/ebms/apps/view/accounting/bankRecords/bankList.php",
			{role:"delete",bankID:$("button#delete").attr("bankID")},
			function(response)
			{
				alert("Bank record successfully deleted");
				$(".formClose").click();
				loadData(1,"");
			});
			
		
	});	
	$("#restore_bank #save").click(function(){
		
		$.post("/ebms/apps/view/accounting/bankRecords/bankList.php",
			{role:"restore",bankID:$("button#restore").attr("bankID")},
			function(response)
			{
				alert("Bank record successfully restored");
				$(".formClose").click();
				loadData(1,"");
			});
			
			
	});
		
	
		$("#new_bank #saveDetailBtn").click(function(){
								acctName = $("#new_bank #acctName").val().trim();
								acctNo = $("#new_bank #acctNo").val().trim();
								acctType = $("#new_bank #acctType").val().trim();
								appendAcctInfo("#new_bank",acctName,acctNo,acctType);	

		});
		
		$("#new_bank #save").click(function(){
			
			bankName = $("#new_bank #bankName").val().trim();
			bankAddress = $("#new_bank #bankAddress").val().trim();
			
			website = $("#new_bank #website").val().trim();
			email = $("#new_bank #email").val().trim();
			phoneNo = $("#new_bank #phoneNo").val().trim();
			faxNo = $("#new_bank #faxNo").val().trim();
			
			contactPerson = $("#new_bank #contactPerson").val().trim();
			position = $("#new_bank #position").val().trim();
			department = $("#new_bank #dept").val().trim();
			
			contactEmail = $("#new_bank #contactEmail").val().trim();
			contactPhoneNo = $("#new_bank #contactPhoneNo").val().trim();
			contactMobileNo = $("#new_bank #contactMobileNo").val().trim();
			
			if(bankName == "" && bankAddress == "" && website == "" && email == "" && phoneNo == "" && faxNo == "" && contactPerson == "" && position == "" && department == "" && contactEmail == "" && contactPhoneNo == "" && contactMobileNo == "")
			{
				alert("Please complete necessary details");
				
			}
			
			else 
			{
			
			ans = confirm("We are now saving this record. Would you like to continue?");
				if(ans)
				{
					$("#new_bank #acctDetails tr").each(function(index){
										acctDetails[index] = new Array();
												$("#new_bank #acctDetails tr:eq("+index+") td").each(function(index2){
												
												if(index2 > 0)
												{
												//alert(index2+": "+$(this).find("input").val());
												acctDetails[index][index2-1] = $(this).find("input").val();
												}
												});
										});
										
										acctDetails = JSON.stringify(acctDetails);
				
				dataString = "bankName="+bankName+"&bankAddress="+bankAddress+"&website="+website+"&email="+email+"&phoneNo="+phoneNo+"&faxNo="+faxNo+"&contactPerson="+contactPerson+"&position="+position+"&department="+department+"&contactEmail="+contactEmail+"&contactPhoneNo="+contactPhoneNo+"&contactMobileNo="+contactMobileNo+"&acctDetails="+acctDetails;
				
					$.ajax({
						url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
						type:"POST",
						data:dataString+"&role=new",
						cache:false,
						success:
							function()
							{
								alert("Bank record successfully created");
								$(".formClose").click();
								loadData(1,"");
							}
					});
			
				
				}
				
			
			}
		});
		
	
			
	
</script>