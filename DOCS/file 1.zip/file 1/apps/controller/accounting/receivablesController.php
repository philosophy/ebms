<?php 

//controller events for receivables

?>

<script>
var init,page,searchQuery="",from="",to="";
var activeCust = "", osNo = "", balance = "", osId = "", bankId = "", custId = "";
var fromCollection = 0;
var on;

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

$("#datepickers #go").click(function(){
loadData(1,searchQuery);				
});

function loadData(page,searchQuery)
{
	initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	from = $("#from").val();
	to = $("#to").val();
			
						
			$.ajax({
				type: "POST",
				url: "receivables.php",
				data: "page="+page+"&searchQuery="+searchQuery+"&from="+from+"&to="+to,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
				success: 
				function(response)
				{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				$("#accounts-receivable").html(arrResponse[0]);
				
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				datagrid("accounts-receivable",true);
				setPageResponse(arrResponse[1]);	
				
				$('#accounts-receivable table tr').click(function()
				{
				$("#accounts-receivable table").find("tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				activeCust = $(this).attr('custNo');
				custId = $(this).attr('custId');
				osNo = $(this).attr('osNo');
				balance = $(this).attr('balance');
				osId = $(this).attr('osId');
					
				$.post('paymentHistory.php', {osNo:$(this).attr('osNo')},
				function(response)
				{
					$('#paymentHistoryGrid').html(response);
					datagrid('paymentHistoryGrid', true);
				});
				return false;
				});
					
				}

				});
}
			
	
				$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
					});
					
				$('#custPayment').click(function()
				{
					$('#new_custPayment input').val('');
					$('#transNo').val("<Auto>");
					$('#docType').val("OS");
					
					var d = new Date();
					var curr_date = d.getDate();
					var curr_month = d.getMonth() + 1;
					var curr_year = d.getFullYear();
					$('#transDate').val(curr_date + "-" + curr_month + "-" + curr_year);
					
					$.post('custPayment.php', {custCode:activeCust, osNo:osNo},
					function(response)
					{
						obj = JSON.parse(response);
						$('#custName').val(obj.values['customer_name']);
						$('#custLocation').val(obj.values['location']);
						$('#refNo').val(osNo);
						$('#balance').val(balance);
					});
					return false;
				});
				
				$('#paymentType').change(function()
				{
					if($(this).val() == "cheque")
					{
						$('#checkType').attr('disabled', false);
						$('#bankName').attr('disabled', false);
						$('#accountType').attr('disabled', false);
						$('#accountNo').attr('disabled', false);
						$('#checkNo').attr('disabled', false);
						$('#checkDateIssue').attr('disabled', false);
						$('#checkDueDate').attr('disabled', false);
						
						$.post('bankList.php', {custCode:activeCust},
						function(response)
						{
							$('#bankName').html("<option>...</option>");
							$('#bankName').append(response);
						});
					}
					else if($(this).val() == "cash")
					{
						$('#checkType').attr('disabled', true);
						$('#bankName').attr('disabled', true);
						$('#bankName').html("<option>...</option>");
						$('#address').val('');
						$('#accountType').attr('disabled', true);
						$('#accountNo').attr('disabled', true);
						$('#accountNo').html("<option>...</option>");
						$('#accountName').val('');
						$('#checkNo').attr('disabled', true);
						$('#checkNo').val('');
						$('#checkDateIssue').val('');
						$('#checkDueDate').val('');
						$('#checkDateIssue').attr('disabled', true);
						$('#checkDueDate').attr('disabled', true);
					}
				});
				
				$('#bankName, #accountType').change(function()
				{
					$('#address').val($('#bankName option:selected').attr('bankAddress'));
					$.post('bankAccounts.php', {bankId: $('#bankName option:selected').attr('bankId'), accountType: $('#accountType').val()},
					function(response)
					{
						$('#accountNo').html("<option>...</option>");
						$('#accountNo').append(response);
					});
				});
				
				$('#accountNo').change(function()
				{
					$('#accountName').val($('#accountNo option:selected').attr('accountName'));
				});
				
				$('#new_custPayment button#save').click(function()
				{
					if($('#paymentType').val().trim() == "cash")
					{
						if($('#amount').val().trim() != "")
						{
							on = 1;
						}
						else
						{
							on = 0;
						}
					}
					else if($('#paymentType').val().trim() == "cheque")
					{
						if($('#bankName option:selected').text() != "..." && $('#amount').val().trim() != "" && $('#checkNo').val().trim() != "" && $('#checkDueDate').val().trim() != "" && $('#checkDateIssue').val().trim() != "" && $('#accountNo option:selected').text() != "" && $('#checkType option:selected').text() != "...")
						{
							on = 1;
						}
						else
						{
							on = 0;
						}
					}
					
					if(parseFloat($('#new_custPayment #amount').val()) < parseFloat($('#new_custPayment #balance').val()))
					{
						if(on == 1)
						{
							refNo = $('#refNo').val().trim();
							particular = $('#particular').val().trim();
							paymentType = $('#paymentType').val().trim();
							amount = $('#amount').val().trim();
							checkNo = $('#checkNo').val().trim();
							checkDueDate = $('#checkDueDate').val().trim();
							checkDateIssue = $('#checkDateIssue').val().trim();
							checkType = $('#checkType').val();
							accountNo = $('#accountNo option:selected').attr('accountNo');
							accountName = $('#accountName').val().trim();
							bankId = $('#bankName option:selected').attr('bankId');
							
							if($('#fromCol').is(':checked'))
							{
								fromCollection = 1;
							}
							else
							{
								fromCollection = 0;
							}
							refType = $('#docType').val().trim();
							
							dataString = "refType=" + refType + "&particular=" + particular +
										"&paymentType=" + paymentType + "&amount=" + amount + "&fromCol=" + fromCollection +
										"&refNo=" + refNo + "&osNo=" + osNo + "&osId=" + osId + "&checkNo=" + checkNo +
										"&checkDueDate=" + checkDueDate + "&checkDateIssue=" + checkDateIssue +
										"&checkType=" + checkType + "&accountNo=" + accountNo + "&accountName=" + accountName +
										"&bankId=" + bankId + "&customerId=" + custId; 

							$.ajax({
								type: "POST",
								url: "savePayment.php",
								data: dataString,
								cache: false,
								success: function(response)
								{
									dataString = "role=" + "New Payment" + "&noun=" + "Payment" + "&code=" + osNo;
									$.ajax(
									{
										url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
										type:"POST",
										data:dataString,
										success:
										function(response)
										{
										
										}
									});
									
									// alert(response);
									loadData(1, searchQuery);
								}
							});
						}
						else
						{
							alert("Fields with asterisk are required.");
						}
					}
					else
					{
						alert("Please check your entry. Amount is greater than the balance.");
						$('#new_custPayment #amount').focus();
					}
						
					return false;
				});
</script>