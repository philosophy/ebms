<?php 

//controller events for payables
	session_start();
?>

<script>
	var init,page,searchQuery="",from="",to="";
	toEdit = 0;
	clickedId = 0;

	function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
			$("div#new_payables #remove").attr('disabled', true);
			$("div#new_payables #datepicker").attr('datepicker', true);
			$("div#edit_payables #datepickerEdit").attr('datepicker', true);
			
			$("#edit").attr('disabled', true);
			$("#delete").attr('disabled', true);
			$("#restore").attr('disabled', true);
			$("#custPayment").attr('disabled', true);
	
			$("#new").attr('title', 'New Company Payable');
			$("#edit").attr('title', 'Edit Company Payable');
			$("#delete").attr('title', 'Delete Company Payable');
			$("#restore").attr('title', 'Restore Company Payable');
		}
	//by default, the first page will be displayed
	loadData(1,searchQuery);

	$("#datepickers #go").click(function(){
	loadData(1,searchQuery);				
	});

	function loadData(page,searchQuery)
	{
		initialize();
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}
			
		from = $("#from").val();
		to = $("#to").val();
				
							
		$.ajax({
			type: "POST",
			url: "payables.php",
			data: "page="+page+"&searchQuery="+searchQuery+"&from="+from+"&to="+to,
			cache: false,
			beforeSend:
			function()
			{
			$("#loading").fadeTo("slow",0.7).show();
			},
			success: 
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
			$('#company-payables').html(arrResponse[0]);
		
			setPageBtnValue(arrResponse[2],arrResponse[3]);
			datagrid('company-payables', true);
			setPageResponse(arrResponse[1]);	
			
			$('#company-payables table tr').click(function()
			{
				$("#company-payables table").find("tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				if ($(this).attr('b') == '')
				{
					if ($(this).attr('c') == 0)
					{
						$("#edit").attr('disabled', false);
						$("#delete").attr('disabled', false);
						$("#restore").attr('disabled', true);
						$("#custPayment").attr('disabled', false);
					}
					else
					{
						$("#edit").attr('disabled', true);
						$("#delete").attr('disabled', true);
						$("#restore").attr('disabled', false);
						$("#custPayment").attr('disabled', false);
					}
				}
				else
				{
					$("#edit").attr('disabled', true);
					$("#delete").attr('disabled', true);
					$("#restore").attr('disabled', true);
					$("#custPayment").attr('disabled', false);
				}
				
				// alert($(this).attr('a'));
				apCode = $(this).attr('a');
				$.ajax(
				{
					url:"/ebms/apps/view/accounting/companyPayables/getApId.php",
					type:"POST",
					data:"code=" + $(this).attr('a'),
					success:
					function(response)
					{
						toEdit = response;
						clickedId = response;
						$("#edit").attr('toEdit', toEdit);
						$("#delete").attr('toDelete', toEdit);
						$("#restore").attr('toRestore', toEdit);
						$("#custPayment").attr('toPay', toEdit);
					}
				});
				
				$.ajax(
				{
					url:"/ebms/apps/view/accounting/companyPayables/apDetailList.php",
					type:"POST", 
					data:"code=" + $(this).attr('a'),
					success:
					function(response)
					{
						// alert(response);
						$('#apDetail').html(response);
						datagrid('apDetail', true);
					}
				});
					
				$.post('paymentHistory.php', {apCode:$(this).attr('a')},
				function(response)
				{
					$('#companyPayment').html(response);
					datagrid('companyPayment', true);
				});
				return false;
				});
				
			}
		});
	}
	
	$(".page-nav li button").click(function()
	{							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
	});
					
	$.ajax(
	{
		url:"/ebms/apps/view/accounting/companyPayables/getAccountType.php",
		type:"POST",
		success:
		function(response)
		{
			$("div#new_payables #accountType").html(response);
		}
	});
	
	$("div#new_payables #importFrom").change(function()
	{
		if ($(this).val() == "PO")
		{
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/getPoHeader.php",
				type:"POST",
				success:
				function(response)
				{
					// alert(response);
					$("div#new_payables table#poHdr tbody#poItems").html(response);
				
					datagrid('new_payables', true);
	
					$("div#new_payables table#poHdr tr").click(function()
					{
						totalAmount = 0;
						setCellContentValue($(this));
						importToApTable($(this));
					});
				}
			});
		}
	});
	
	function setCellContentValue(selector)
	{
		//remove all active classes in tr element
		$("div#new_payables table#poHdr").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		
		// alert($(selector).attr('a'));
		
		$.ajax(
		{
			url:"/ebms/apps/view/accounting/companyPayables/getPoDetails.php",
			type:"POST",
			data:"id=" + $(selector).attr('a'),
			success:
			function(response)
			{
				$("div#new_payables ul.gridViewNav").html(response);
			}
		});
	}
	
	var poId = 0;
	var rowId = 0;
	var toRemove = 0;
	
	totalAmount = 0;
	
	function importToApTable(selector)
	{
		poId = $(selector).attr('a');
		
		$("div#new_payables table#payables tbody#items tr").each(function(index)
		{
			if ($(this).attr('a') != "")
			{
				$(this).remove();
			}
		});
		
		$.ajax(
		{
			url:"/ebms/apps/view/accounting/companyPayables/moveToTable.php",
			type:"POST",
			data:"id=" + $(selector).attr('a'),
			success:
			function(response)
			{
				$("div#new_payables table#payables tbody#items").append(response);
				
				$("div#new_payables table#payables tbody#items tr").click(function()
				{
					$("div#new_payables table#payables tbody#items").find('tr').removeClass("activeTr");
					$(this).addClass("activeTr");
				
					if ($(this).attr('a') != "")
					{
						toRemove = $(this).attr('a');
						
						$("div#new_payables #remove").attr('disabled', false);
					}
				});
				
				// alert($("div#new_payables table#payables tbody#items tr").attr('a'));
				// alert(poId);
				// alert($("div#new_payables table#payables tbody#items td").attr('a'));
			}
		});
	}
	
	$("div#new_payables #add").click(function()
	{
		if ($("div#new_payables #amount").val() == "")
		{
			alert('Please input amount.');
		}
		else if ($("div#new_payables #description").val() == "")
		{
			alert('Please input description.');
		}
		else
		{
			rowId++;
			dataString = "accountTypeId=" + $("div#new_payables #accountType").val() + "&amount=" + $("div#new_payables #amount").val() + "&desc=" + $("div#new_payables #description").val() + "&rowId=" + rowId;
			// alert(dataString);
			
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/moveToTable2.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					$("div#new_payables table#payables tbody#items").append(response);
					
					$("div#new_payables table#payables tbody#items tr").click(function()
					{
						$("div#new_payables table#payables tbody#items").find('tr').removeClass("activeTr");
						$(this).addClass("activeTr");
				
						if ($(this).attr('b') != "")
						{
							toRemove = $(this).attr('b');
							// alert(toRemove);
			
							$("div#new_payables #remove").attr('disabled', false);
						}
					});
				}
			});
		}
		//binago
		rowId = 0;
	});
	
	$("div#new_payables #remove").click(function()
	{
		$("div#new_payables table#payables tbody#items tr").each(function(index)
		{
			if ($(this).attr('b') == toRemove && $(this).attr('a') == "")
			{
				$(this).remove();
				$("div#new_payables #remove").attr('disabled', true);
			}
			else if ($(this).attr('a') == toRemove && $(this).attr('b') == "")
			{
				$(this).remove();
				$("div#new_payables #remove").attr('disabled', true);
			}
			
			if ($("div#new_payables table#payables tbody#items tr").length == 0)
			{
				$("div#new_payables #remove").attr('disabled', true);
			}
		});
	});
	
	$("div#new_payables #save").click(function()
	{	
		if ($("div#new_payables table#payables tbody#items tr").length == 0)
		{
			alert('Please add Account Payable information first!');
		}
		else if ($("div#new_payables #datepicker").val() == "")
		{
			alert('Please provide a due date!');
		}
		else
		{
			$("div#new_payables table#payables tbody#items tr").each(function(index)
			{
				// alert($(this).find('#amount').text());
				var price = $(this).find("#amount").text().replace(/,/g, "");
				totalAmount += parseFloat(price);
				// alert(totalAmount);
			});	
		
			dataString = "amount=" + totalAmount + "&dueDate=" + $("div#new_payables #datepicker").val() + "&poId=" + poId;
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/newApHeaderRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					// alert(response);
			
					$("div#new_payables table#payables tbody#items tr").each(function(index)
					{
						// alert($(this).find('#accountType').attr('a'));
						// alert($(this).find('#desc').text());
						// alert($(this).find('#amount').text());
						
						dataString = "accountType=" + $(this).find('#accountType').attr('a') + "&desc=" + $(this).find('#desc').text() + "&amount=" + $(this).find('#amount').text().replace(/,/g, "") + "&hdrId=" + response;
						// alert(dataString);
						$.ajax(
						{
							url:"/ebms/apps/view/accounting/companyPayables/newApDetailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
								// alert(response);
							}
						});
					});
				}
			});
			
			dataString = "role=" + "New" + "&noun=" + "Account Payable record";
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString, 
				success:
				function(response)
				{
				
				}
			});
			
			alert('Record Created!');
			window.location.reload();
			
			totalAmount = 0;
		}
	});
	
	//=============================================================================EDIT==========================================================================
	
	$("#edit").click(function()
	{
		// alert($(this).attr('toEdit'));
		$("div#edit_payables #remove").attr('disabled', true);
		
		datagrid('edit_payables', true);
		
		if ($(this).attr('toEdit') > 0)
		{
			var editApId = $(this).attr('toEdit');
			
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/viewDueDate.php",
				type:"POST",
				data:"id=" + editApId,
				success:
				function(response)
				{
					// alert(response);
					$("div#edit_payables #datepickerEdit").val(response);
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/viewApDetails.php",
				type:"POST",
				data:"id=" + editApId,
				success:
				function(response)
				{
					// alert(response);
					$("div#edit_payables table#payables tbody#items").html(response);
		
					datagrid('edit_payables', true);
			
					$("div#edit_payables table#payables tbody#items tr").click(function()
					{
						toRemove = $(this).attr('d');
						$("div#edit_payables #remove").attr('disabled', false);
					});
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/getAccountType.php",
				type:"POST",
				success:
				function(response)
				{
					$("div#edit_payables #accountType").html(response);
				}
			});
			
			$("div#edit_payables #importFrom").change(function()
			{
				if ($(this).val() == "PO")
				{
					$.ajax(
					{
						url:"/ebms/apps/view/accounting/companyPayables/getPoHeader.php",
						type:"POST",
						success:
						function(response)
						{
							// alert(response);
							$("div#edit_payables table#poHdr tbody#poItems").html(response);
						
							datagrid('edit_payables', true);
			
							$("div#edit_payables table#poHdr tr").click(function()
							{
								totalAmount = 0;
								setCellContentValueEdit($(this));
								importToApTableEdit($(this));
							});
						}
					});
				}
			});
	
			function setCellContentValueEdit(selector)
			{
				//remove all active classes in tr element
				$("div#edit_payables table#poHdr").find("tr").removeClass("activeTr");
							
				//then, set the active class to the clicked tr element
				$(selector).addClass("activeTr");
				
				// alert($(selector).attr('a'));
				
				$.ajax(
				{
					url:"/ebms/apps/view/accounting/companyPayables/getPoDetails.php",
					type:"POST",
					data:"id=" + $(selector).attr('a'),
					success:
					function(response)
					{
						$("div#edit_payables ul.gridViewNav").html(response);
					}
				});
			}
			
			var poId = 0;
			var rowIdEdit = 0;
			var toRemove = 0;
			
			totalAmount = 0;
			
			function importToApTableEdit(selector)
			{
				poId = $(selector).attr('a');
				
				$("div#edit_payables table#payables tbody#items tr").each(function(index)
				{
					if ($(this).attr('a') != "" && $(this).attr('c') == "PO")
					{
						$(this).remove();
					}
				});
				
				$.ajax(
				{
					url:"/ebms/apps/view/accounting/companyPayables/moveToTable3.php",
					type:"POST",
					data:"id=" + $(selector).attr('a'),
					success:
					function(response)
					{
						$("div#edit_payables table#payables tbody#items").append(response);
						
						$("div#edit_payables table#payables tbody#items tr").click(function()
						{
							$("div#edit_payables table#payables tbody#items").find('tr').removeClass("activeTr");
							$(this).addClass("activeTr");
						
							if ($(this).attr('a') != "")
							{
								toRemove = $(this).attr('a');
								
								$("div#edit_payables #remove").attr('disabled', false);
							}
						});
						
						// alert($("div#new_payables table#payables tbody#items tr").attr('a'));
						// alert(poId);
						// alert($("div#new_payables table#payables tbody#items td").attr('a'));
					}
				});
			}
	
			$("div#edit_payables #add").click(function()
			{
				// alert(toRemove);
				if ($("div#edit_payables #amount").val() == "")
				{
					alert('Please input amount.');
				}
				else if ($("div#edit_payables #description").val() == "")
				{
					alert('Please input description.');
				}
				else
				{
					rowIdEdit++;
					dataString = "accountTypeId=" + $("div#edit_payables #accountType").val() + "&amount=" + $("div#edit_payables #amount").val() + "&desc=" + $("div#edit_payables #description").val() + "&rowId=" + rowIdEdit;
					// alert(dataString);
					
					$.ajax(
					{
						url:"/ebms/apps/view/accounting/companyPayables/moveToTable4.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							$("div#edit_payables table#payables tbody#items").append(response);
							
							$("div#edit_payables table#payables tbody#items tr").click(function()
							{
								$("div#edit_payables table#payables tbody#items").find('tr').removeClass("activeTr");
								$(this).addClass("activeTr");
				
								if ($(this).attr('d') != "")
								{
									toRemove = $(this).attr('d');
									// alert(toRemove);
					
									$("div#edit_payables #remove").attr('disabled', false);
								}
							});
						}
					});
				}
				//binago
				rowIdEdit = 0;
			});
			
			$("div#edit_payables #remove").click(function()
			{
				$("div#edit_payables table#payables tbody#items tr").each(function(index)
				{
					if ($(this).attr('d') == toRemove)
					{
						$(this).remove(); //alert('haha');
						$("div#edit_payables #remove").attr('disabled', true);
					}
					else if ($(this).attr('a') == toRemove && $(this).attr('b') == "")
					{
						$(this).remove(); //alert('hehe');
						$("div#edit_payables #remove").attr('disabled', true);
					}
					else if ($(this).attr('c') == "PO" && $(this).attr('d') == "")
					{
						$(this).remove(); //alert('hihi');
						$("div#edit_payables #remove").attr('disabled', true);
					}
					
					if ($("div#edit_payables table#payables tbody#items tr").length == 0)
					{
						$("div#edit_payables #remove").attr('disabled', true);
					}
				});
			});
			
			$("div#edit_payables #save").click(function()
			{
				if ($("div#edit_payables table#payables tbody#items tr").length == 0)
				{
					alert('Please add Account Payable information first!');
				}
				else if ($("div#edit_payables #datepickerEdit").val() == "")
				{
					alert('Please provide a due date!');
				}
				else
				{
					$("div#edit_payables table#payables tbody#items tr").each(function(index)
					{
						// alert($(this).find('#amount').text());
						var price = $(this).find('td[e]').text().replace(/,/g, "");
						totalAmount += parseFloat(price);
						// alert(totalAmount);
					});	
					
					dataString = "amount=" + totalAmount + "&dueDate=" + $("div#edit_payables #datepickerEdit").val() + "&toEdit=" + editApId;
					// alert(dataString);
					$.ajax(
					{
						url:"/ebms/apps/view/accounting/companyPayables/editApHeaderRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							alert(response);
			
							$.ajax(
							{
								url:"/ebms/apps/view/accounting/companyPayables/deleteApDetails.php",
								type:"POST",
								data:"id=" + editApId,
								success:
								function(response)
								{
									
								}
							});
					
							$("div#edit_payables table#payables tbody#items tr").each(function(index)
							{
								// alert($(this).find('#accountType').attr('a'));
								// alert($(this).find('#desc').text());
								// alert($(this).find('#amount').text());
								
								dataString = "accountType=" + $(this).find('td[f]').attr('f') + "&desc=" + $(this).find('td[g]').text() + "&amount=" + $(this).find('td[e]').text().replace(/,/g, "") + "&toEdit=" + editApId;
								// alert(dataString);
								$.ajax(
								{
									url:"/ebms/apps/view/accounting/companyPayables/editApDetailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
										// alert(response);
									}
								});
							});
						}
					});
					
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Accounts Payable" + "&id=" + editApId,
						success:
						function(response)
						{
							dataString = "role=" + "Edit" + "&noun=" + "Account payable record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
								
								}
							});
						}
					});
					
					alert('Record Edited!');
					window.location.reload();
					
					totalAmount = 0;
					// editApId = 0;
				}
			});
		}
	});	
	
	$("div#edit_payables #cancel").click(function()
	{
		window.location.reload();
	});
	
	$("#delete").click(function()
	{
		// alert(toEdit);
		$("div#delete_payables #save").click(function()
		{
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/deleteApHeaderRecord.php",
				type:"POST",
				data:"id=" + toEdit,
				success:
				function(response)
				{
				}
			});
					
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
				type:"POST",
				data:"module=" + "Accounts Payable" + "&id=" + toEdit,
				success:
				function(response)
				{
					dataString = "role=" + "Delete" + "&noun=" + "Account payable record" + "&code=" + response;
					// alert(dataString);
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							alert('Record Deleted!');
							window.location.reload();
						}
					});
				}
			});
			
			
		});
	});
	
	$("#restore").click(function()
	{
		// alert(toEdit);
		$("div#restore_payables #save").click(function()
		{
			$.ajax(
			{
				url:"/ebms/apps/view/accounting/companyPayables/restoreApHeaderRecord.php",
				type:"POST",
				data:"id=" + toEdit,
				success:
				function(response)
				{
				}
			});
					
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
				type:"POST",
				data:"module=" + "Accounts Payable" + "&id=" + toEdit,
				success:
				function(response)
				{
					dataString = "role=" + "Restore" + "&noun=" + "Account payable record" + "&code=" + response;
					// alert(dataString);
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							alert('Record Restored!');
							window.location.reload();
						}
					});
				}
			});
			
			
		});
	});
	
	$("#custPayment").click(function()
	{
		// alert(toEdit);
		
		$("div#new_custPayment #docType").val("AP");
		
		$.ajax(
		{
			url:"/ebms/apps/view/accounting/companyPayables/paymentRefNo.php",
			type:"POST",
			data:"id=" + toEdit,
			success:
			function(response)
			{
				$("div#new_custPayment #refNo").val(response);
			}
		});
		
		$.ajax(
		{
			url:"/ebms/apps/view/accounting/companyPayables/paymentGetBalance.php",
			type:"POST",
			data:"id=" + toEdit + "&code=" + apCode,
			success:
			function(response)
			{
				$("div#new_custPayment #balance").val(response);
			}
		});
	
		$('#paymentType').change(function()
		{
			if($(this).val() == "cheque")
			{
				$('div#new_custPayment #checkType').attr('disabled', false);
				$('div#new_custPayment #bankName').attr('disabled', false);
				$('div#new_custPayment #accountType').attr('disabled', false);
				$('div#new_custPayment #accountNo').attr('disabled', false);
				$('div#new_custPayment #checkNo').attr('disabled', false);
				$('div#new_custPayment #checkDateIssue').attr('disabled', false);
				$('div#new_custPayment #checkDueDate').attr('disabled', false);
				
				$.post('bankList.php',
				function(response)
				{
					$('div#new_custPayment #bankName').html("<option>...</option>");
					$('div#new_custPayment #bankName').append(response);
				});
			}
			else if($(this).val() == "cash")
			{
				$('div#new_custPayment #checkType').attr('disabled', true);
				$('div#new_custPayment #bankName').attr('disabled', true);
				$('div#new_custPayment #bankName').html("<option>...</option>");
				$('div#new_custPayment #address').val('');
				$('div#new_custPayment #accountType').attr('disabled', true);
				$('div#new_custPayment #accountNo').attr('disabled', true);
				$('div#new_custPayment #accountNo').html("<option>...</option>");
				$('div#new_custPayment #accountName').val('');
				$('div#new_custPayment #checkNo').attr('disabled', true);
				$('div#new_custPayment #checkNo').val('');
				$('div#new_custPayment #checkDateIssue').val('');
				$('div#new_custPayment #checkDueDate').val('');
				$('div#new_custPayment #checkDateIssue').attr('disabled', true);
				$('div#new_custPayment #checkDueDate').attr('disabled', true);
			}
		});
		
		$('div#new_custPayment #bankName, div#new_custPayment #accountType').change(function()
		{
			$('div#new_custPayment #address').val($('div#new_custPayment #bankName option:selected').attr('bankAddress'));
			$.post('bankAccounts.php', {bankId: $('div#new_custPayment #bankName option:selected').attr('bankId'), accountType: $('div#new_custPayment #accountType').val()},
			function(response)
			{
				$('div#new_custPayment #accountNo').html("<option>...</option>");
				$('div#new_custPayment #accountNo').append(response);
			});
		});
		
		$('div#new_custPayment #accountNo').change(function()
		{
			$('div#new_custPayment #accountName').val($('div#new_custPayment #accountNo option:selected').attr('accountName'));
		});
		
		$('div#new_custPayment button#save').click(function()
		{
			// alert('haha');
			refNo = $('div#new_custPayment #refNo').val().trim();
			particular = $('div#new_custPayment #particular').val().trim();
			paymentType = $('div#new_custPayment #paymentType').val().trim();
			amount = $('div#new_custPayment #amount').val().trim();
			checkNo = $('div#new_custPayment #checkNo').val().trim();
			checkDueDate = $('div#new_custPayment #checkDueDate').val().trim();
			checkDateIssue = $('div#new_custPayment #checkDateIssue').val().trim();
			checkType = $('div#new_custPayment #checkType').val();
			accountNo = $('div#new_custPayment #accountNo option:selected').attr('accountNo');
			accountName = $('div#new_custPayment #accountName').val().trim();
			bankId = $('div#new_custPayment #bankName option:selected').attr('bankId');
			
			if($('div#new_custPayment #fromCol').is(':checked'))
			{
				fromCollection = 1;
			}
			else
			{
				fromCollection = 0;
			}
			refType = $('div#new_custPayment #docType').val().trim();
			
			dataString = "refType=" + refType + "&particular=" + particular +
						"&paymentType=" + paymentType + "&amount=" + amount + "&fromCol=" + fromCollection +
						"&refNo=" + refNo + "&osNo=" + "0" + "&osId=" + "0" + "&checkNo=" + checkNo +
						"&checkDueDate=" + checkDueDate + "&checkDateIssue=" + checkDateIssue +
						"&checkType=" + checkType + "&accountNo=" + accountNo + "&accountName=" + accountName +
						"&bankId=" + bankId; 
						
			// alert(dataString);
			// alert($('div#new_custPayment #balance').val());
			
			if (parseFloat(amount) < 0)
			{
				alert('You cannot pay less than 0!');
			}
			else if (parseFloat(amount) > parseFloat($('div#new_custPayment #balance').val()))
			{
				alert('You cannot exceed your balance!');
			}
			else
			{
				// alert('save');
				$.ajax({
					type: "POST",
					url: "savePayment.php",
					data: dataString,
					cache: false,
					success: function(response)
					{
						// alert(response);
					}
				});
			
				// loadData(1, searchQuery);
				
				// return false;
			}
		});
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
</script>