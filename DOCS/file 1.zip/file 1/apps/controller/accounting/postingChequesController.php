<script>
	
	var totalAmount = 0;
	
	var depositId;
	
	
	var init,page,searchQuery="",from="",to="";
	
		function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
		
		}
	//by default, the first page will be displayed
	loadData(1,searchQuery);
	function loadData(page,searchQuery)
	{
		initialize();
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}	
			
		$.ajax({
			type: 'POST',
			url: 'chequeList.php',
			data: "page="+page+"&searchQuery="+searchQuery,
			cache: false,
			beforeSend:
			function()
			{
			$("#loading").fadeTo("slow",0.7).show();
			},
			success: function(response)
			{
				
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				
				$('#posted-cheques').html(arrResponse[0]);
				datagrid('posted-cheques', true);
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				setPageResponse(arrResponse[1]);		
				
				
				
				//toggle icons for included cheques
				$('#posted-cheques table tr a').toggle(function()
				{
					$(this).find('.includedItem').hide();
					$(this).find('.addItem').show();
					
					//when record is selected
					if($(this).find('.includedItem').css('display') == "none")
					{
						totalAmount += parseFloat($(this).parent().parent().attr('amount'));
						$('#chequeAmount').val(totalAmount);
					}
				},
				function()
				{
					$(this).find('.includedItem').show();
					$(this).find('.addItem').hide();
					
					//record deselected
					if($(this).find('.addItem').css('display') == "none")
					{
						totalAmount -= parseFloat($(this).parent().parent().attr('amount'));
						$('#chequeAmount').val(totalAmount);
					}
				});
			}
		});
	}
	
	$('#postCheque').click(function()
	{
		if($("#chequeBankName option:selected").text() != "..." && $("#chequeAccountNo option:selected").text() != "..." && $("#chequeAmount").val() != "")
		{
			//bank deposit header
			bankId = $('select#chequeBankName option:selected').attr('id');
			accountNo = $('#chequeAccountNo option:selected').attr('id');
			amount = $('#chequeAmount').val().trim();
			
			$.post('bankChequeDeposit.php', {bankId:bankId, accountNo:accountNo, amount:amount},
			function(response)
			{
				depositId = response;
				
				//is_posted = 1 and deposit details
				$('#posted-cheques table tr a').each(function()
				{
					if($(this).find('.addItem').css("display") != "none")
					{
						chequeNo = $(this).parent().parent().attr('no');
						chequeAmount = $(this).parent().parent().attr('amount');
						$.post('postCheques.php', {chequeNo:chequeNo, depositId:depositId, chequeAmount:chequeAmount});
					}
				});
				loadData(1, "");
				$('#chequeAccountNo').html("<option>...</option>");
				$('#chequeAmount').val("");
				alert("Cheque/s successfully posted and deposited.");
			});
		}
		else
		{
			alert("All fields are required.");
		}
			
		return false;
	});
	
	$.post('bankName.php',
	function(response)
	{
		$('#chequeBankName').html("<option>...</option>");
		$('#chequeBankName').append(response);
		
		$('#chequeBankName, #chequeAccountType').change(function()
		{
			$.post('accountName.php', {bankId:$('select#chequeBankName option:selected').attr('id'), type:$('#chequeAccountType option:selected').attr('id')},
			function(response)
			{
				$('select#chequeAccountNo').html("<option>...</option>");
				$('select#chequeAccountNo').append(response);
			});
		});
	});
	
</script>