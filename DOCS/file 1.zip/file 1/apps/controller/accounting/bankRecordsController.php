<script>

	
	var init = "",page = "";
	var searchQuery="";
	var acctDetails = new Array();
	
	function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
		}
	
	//by default, the first page will be displayed
	loadData(1,searchQuery);

	function loadData(page,searchQuery)
	{
	
					initialize();
					if(init == "" || init == "Search...")
						{
						searchQuery = "";
						}
					
					else 
						{
						searchQuery = init;
						
						}	

				$.ajax({
					type: "POST",
					url: "bankList.php",
					data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
					success: function(response)
					{
						$("button#edit,button#delete,button#restore").attr("disabled",true);
						
						$("button#new").attr("title","New Bank Record");	
						$("button#edit").attr("title","Edit Bank Record");	
						$("button#delete").attr("title","Delete Bank Record");	
						$("button#restore").attr("title","Restore Bank Record");
						
						$("#loading").fadeTo("slow",0).hide();
						var arrResponse = response.split('&');
						
						$("#bank-records").html(arrResponse[0]);
						setPageBtnValue(arrResponse[2],arrResponse[3]);
						datagrid("bank-records", true);
						setPageResponse(arrResponse[1]);		
						
						$("#bank-records table tr").click(function()
						{
							$("#bankWithdrawal #newBankWithdrawal").removeAttr("disabled");
							
							$("#bank-records table").find("tr").removeClass("activeTr");
							$(this).addClass("activeTr");
							
						
							if($(this).attr("deleted") == "true")
							{
							$("button#restore").removeAttr("disabled");
							$("button#edit,button#delete").attr("disabled",true);
							}
							else if($(this).attr("deleted") == "false")
							{
							$("button#restore").attr("disabled",true);
							$("button#edit,button#delete").removeAttr("disabled");
							}
							
							
							cellContentClick($(this));
							
						});
					}
				});
	}
	
	$(".page-nav li button").click(function()
	{							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
	});
	
	var ctr2 = 0;
	function appendAcctInfo(container,acctName,acctNo,acctType)
				{
				var tblData = "";
				//alert("LOL");
				ctr2++;
					if(acctName != "" && acctNo != "")
					{
					tblData = "<tr rowNum="+ctr2+"><td class='option'><img ref="+ctr2+" title='Remove Detail' src='/ebms/images/remove.png' class='removeDetail'></td><td><input type='text' id='dataAcctName' value='"+acctName+"' disabled></td><td><input type='text' id='dataAcctNo' value='"+acctNo+"'></td> <td><input type='text' id='dataAcctType' value='"+acctType+"' disabled></td></tr>";
					$(container+" #acctDetails").append(tblData);
					
					$(container+" #acctName").val("").focus();
					$(container+" #acctNo").val("");
					$(container+" #acctType").val("current");
					
					$(container+" tr").dblclick(function(){
						$(this).find("input").removeAttr("disabled");
						$(this).find("td").css({"-webkit-box-shadow":"0 0 35px silver inset","-moz-box-shadow":"0 0 35px silver inset","box-shadow":"0 0 35px silver inset"});
							
					});
					
					$(container+" .removeDetail").click(function(){
				
					var ref = $(this).attr("ref");
					
						$(container+" #acctDetails").find("tr[rowNum="+ref+"]").remove();
					});
					}
					
					else
					{	
						$(container+" #acctName").focus();
						alert("Please specify necessary details");
					}
				}
			
	
	function setAcctNo(selector)
	{
				
		$.post("/ebms/apps/view/accounting/bankRecords/bankAccountNo.php",
			{bankID:$(selector).attr("a"),acctType:$("#new_bankWithdrawal #acctType").val()},
			function(response)
			{
				$("#new_bankWithdrawal #acctNo").html(response);
				
			});	
			
		$.post("/ebms/apps/view/accounting/bankRecords/bankAccountNo.php",
			{bankID:$(selector).attr("a"),acctType:$("#new_bankDeposit #acctType").val()},
			function(response)
			{
				$("#new_bankDeposit #acctNo").html(response);
				
			});
	
	}
	
	function cellContentClick(selector)
	{
		
		$("button#edit,button#restore,button#delete").attr("bankID",$(selector).attr("a"));
		
		setAcctNo(selector);
		$("#new_bankWithdrawal #acctType,#new_bankDeposit #acctType").change(function(){
			setAcctNo(selector);
		});
		
	
		$.post("cashOnBankByAccountNo.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("#cashOnBank").html(response);
			datagrid("cashOnBank", true);
		});
		
		
		$.post("bankSummary.php", {bankId:$(selector).attr("a"), bankName:$(selector).attr("b")},
		function(response)
		{
			$("#bankSummary").html(response);
			datagrid("bankSummary", true);
		});
		
		$.post("bankDeposit.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("#bankDeposit #subgrid-first").html(response);
			datagrid("subgrid-first", true);
			
			$('#bankDeposit #subgrid-first table tr').click(function()
			{
				$("#bankDeposit #subgrid-first table").find("tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				
				$.post("bankDepositDetails.php", {depositId:$(this).attr("a")},
				function(response)
				{
					$("#bankDeposit #subgrid-second").html(response);
					datagrid("subgrid-second", true);
				});
				return false;
			});
		});
		
		$.post("bankWithdrawal.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("#bankWithdrawalGrid").html(response);
			datagrid("bankWithdrawalGrid", true);
		});
		
		$.post("issuedCheques.php", {bankId:$(selector).attr("a")},
		function(response)
		{
			$("div#issuedCheques").html(response);
			datagrid("issuedCheques", true);
		});
	}
	
	$("#new_bankDeposit #save").click(function(){
		
		depFrom = $("#new_bankDeposit #depositFrom").val().trim();
		refType = $("#new_bankDeposit #refType").val().trim();
		depAmount = $("#new_bankDeposit #depositAmount").val().trim();
		depDate = $("#new_bankDeposit #depDate").val().trim();
		acctType = $("#new_bankDeposit #acctType").val().trim();
		acctNo = $("#new_bankDeposit #acctNo").val().trim();
		depBy = $("#new_bankDeposit #depositedBy").val().trim();
		remarks = $("#new_bankDeposit #remarks").val().trim();
		
			if(depFrom == "" || refType == "" || depAmount == "" || depDate == "" || acctType == "" || acctNo == "" || depBy == "")
			{
				alert("Please fill necessary fields");
			}
			
			else 
			{
			dataString = "depFrom="+depFrom+"&refType="+refType+"&depAmount="+depAmount+"&depDate="+depDate+"&acctType="+acctType+"&acctID="+acctNo+"&depBy="+depBy+"&remarks="+remarks+"&bankID="+($("#bank-records table tr.activeTr").attr("a"));
			
			$.ajax({
					url:"/ebms/apps/view/accounting/bankRecords/bankDeposit.php",
					type:"POST",
					data:dataString+"&role=new",
					cache:false,
					success:
						function()
						{
							alert("Bank deposit successful");
							$("#bank-records table tr.activeTr").click();
							$(".formClose").click();
												
							$("#new_bankDeposit #depositFrom").val("Cash On Hand");
							$("#new_bankDeposit #refType").val("Cash On Hand");
							$("#new_bankDeposit #depDate").val("");
							$("#new_bankDeposit #remarks").val("");
						}
				});
			}
		
	});
	
	$("#new_bankWithdrawal #save").click(function(){
		
		withDate = $("#new_bankWithdrawal #withDate").val().trim();
		withAcctID = $("#new_bankWithdrawal #acctNo").val().trim();
		withAmount = $("#new_bankWithdrawal #amount").val().trim();
		withBy = $("#new_bankWithdrawal #withdrawnBy").val().trim();
		withRemarks = $("#new_bankWithdrawal #remarks").val().trim();
		bankID = $("#bank-records table tr.activeTr").attr("a");
			if(withDate == "" && withAcctNo == "" && (withAmount == "" || withAmount == 0) && withBy == "")
				alert("Please fill necessary fields");
				
			else 
			{
				dataString = "bankID="+bankID+"&withDate="+withDate+"&withAcctID="+withAcctID+"&withAmount="+withAmount+"&withBy="+withBy+"&withRemarks="+withRemarks;
				
				$.ajax({
					url:"/ebms/apps/view/accounting/bankRecords/bankWithdrawal.php",
					type:"POST",
					data:dataString+"&role=new",
					cache:false,
					success:
						function()
						{
							alert("Bank withdrawal successful");
							$("#bank-records table tr.activeTr").click();
							$(".formClose").click();
												
							$("#new_bankWithdrawal #withDate").val(<?php echo date("Y-m-d"); ?>);
							$("#new_bankWithdrawal #acctNo").val("");
							$("#new_bankWithdrawal #amount").val("0");
							$("#new_bankWithdrawal #withdrawnBy").val("");
							$("#new_bankWithdrawal #remarks").val("");
						}
				});
			}
	
	});
	
	
		function formReset(acctName,acctNo,acctType)
		{

			$("#acctInfo table tr.activeTr").find("td.bankAcctName").html(acctName);
			$("#acctInfo table tr.activeTr").find("td.bankAcctNo").html(acctNo);
			$("#acctInfo table tr.activeTr").find("td.bankAcctType").html(acctType);
			
			$("#acctInfo table tr.activeTr").find("#editAcctBtn").remove();
		}
	
	
		function loadAcctInfo(bankID)
		{
		$.ajax({
		url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
		type:"POST",
		data:"role=fetchAcctInfo&bankID="+bankID,
		cache:false,
		success:
			function(response)
			{
			$("#acctInfo").html(response);
			datagrid("acctInfo",true);
			
				$("#acctInfo table tr").click(function(){
					
					
					$("#acctInfo table tr").removeClass("activeTr");
					$(this).addClass("activeTr");
					
					if($(this).attr("bankAcctID") != null)
					{
					$("#editAcctInfo").removeAttr("disabled");
						$("#editAcctInfo").click(function()
						{
						acctName = $("#acctInfo table tr.activeTr").attr("bankAcctName");
						acctNo = $("#acctInfo table tr.activeTr").attr("bankAcctNo");
						acctType = $("#acctInfo table tr.activeTr").attr("bankAcctType");
						acctID = $("#acctInfo table tr.activeTr").attr("bankAcctID");
						
						$("#acctInfo table tr.activeTr").find("td.bankAcctName").html("<input type='text' style='width:92%' id='editAcctName' value='"+(acctName)+"'>");
						$("#acctInfo table tr.activeTr").find("td.bankAcctNo").html("<input type='text' style='width:92%' id='editAcctNo' value='"+(acctNo)+"'>");
						$("#acctInfo table tr.activeTr").find("td.bankAcctType").html("<select id='editAcctType' style='width:100%' ><option value='"+($("#acctInfo table tr.activeTr").attr("bankAcctType"))+"'>"+($("#acctInfo table tr.activeTr").attr("bankAcctType"))+"</option><option value='"+((acctType=='Current')?"Savings":"Current")+"'>"+((acctType=='Current')?"Savings":"Current")+"</option>");
						$("#acctInfo table tr.activeTr").append("<div id='editAcctBtn' style='position:absolute;white-space:nowrap;right:20px;margin-top:30px'><button class='editCancelAcct'>Cancel</button><button class='editSaveAcct'>Save</button></div>");
				
						$("#editAcctName").focus();
						
						$(".editCancelAcct").click(function(){
							
							formReset(acctName,acctNo,acctType);
							
						});
						
						$(".editSaveAcct").click(function(){
						
						acctName = $("#editAcctName").val().trim();
						acctNo = $("#editAcctNo").val().trim();
						acctType = $("#editAcctType").val().trim();
						
						if(acctName == "" || acctNo == "")
						{
							alert("Please complete necessary fields");
							$("#editAcctName").focus();
						}
						
						else
						{
							dataString = "bankID="+bankID+"&acctName="+acctName+"&acctNo="+acctNo+"&acctType="+acctType+"&acctID="+acctID;
							
								$.ajax({
									url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
									type:"POST",
									data:"role=editAcctInfo&"+dataString,
									cache:false,
									success:
										function()
										{
										$("#editCancelAcct").click();
										loadAcctInfo(bankID);
										
										}
								});
						}
					
						});
						
						
						
						});
						
						
					}
					
				});
			
			}
		});
		}
		
		
	$("#edit").click(function(){
	
	bankID = $(this).attr("bankID");
		loadAcctInfo(bankID);
		
		$("#newAcctInfo").click(function(){
				elem = "<tr class='newRow'><td><input type='text' id='newAcctName' style='width:92%'></td><td><input type='text' id='newAcctNo' style='width:92%'></td><td><select id='newAcctType' style='width:100%'><option value='Current'>Current</option><option value='Savings'>Savings</option></select></td>";
				
				if($("#acctInfo").find("tr.newRow").size() == 0)
				{
				$("#acctInfo table").append(elem);
				
				$("#acctInfo").append("<div id='acctBtn'><button id='cancelAcct'>Cancel</button><button id='saveAcct'>Save</button></div>");
					
					$("#cancelAcct").click(function(){
						$("#acctInfo").find("tr.newRow").remove();
						$("#acctBtn").remove();
					});
					
					$("#saveAcct").click(function(){
						acctName = $("#newAcctName").val().trim();
						acctNo = $("#newAcctNo").val().trim();
						acctType = $("#newAcctType").val().trim();
						
						if(acctName == "" || acctNo == "")
						{
							alert("Please complete necessary fields");
							$("#newAcctName").focus();
						}
						
						else
						{
							dataString = "bankID="+bankID+"&acctName="+acctName+"&acctNo="+acctNo+"&acctType="+acctType;
							
								$.ajax({
									url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
									type:"POST",
									data:"role=createAcctInfo&"+dataString,
									cache:false,
									success:
										function()
										{
										$("#cancelAcct").click();
										loadAcctInfo(bankID);
										}
								});
						}
						
					});
				
				}
				
				$("#newAcctName").focus();
			
			});
			
				
		$.ajax({
			url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
			type:"POST",
			data:"role=fetchData&bankID="+bankID,
			cache:false,
			success:
				function(response)
				{
					obj = JSON.parse(response);
					
					$("#edit_bank #bankName").val(obj.data['bank_name']);
					$("#edit_bank #bankAddress").val(obj.data['bank_address']);
						
					$("#edit_bank #phoneNo").val(obj.data['bank_phone_no']);
					$("#edit_bank #faxNo").val(obj.data['bank_fax_no']);
					$("#edit_bank #website").val(obj.data['bank_website']);
					$("#edit_bank #email").val(obj.data['bank_email_address']);
					$("#edit_bank #contactPerson").val(obj.data['bank_contact_person']);
					$("#edit_bank #position").val(obj.data['bank_contact_position']);
					$("#edit_bank #contactDept").val(obj.data['bank_contact_department']);
					$("#edit_bank #contactPhoneNo").val(obj.data['bank_contact_phone_no']);
					$("#edit_bank #contactMobileNo").val(obj.data['bank_contact_mobile_no']);
					$("#edit_bank #contactEmail").val(obj.data['bank_contact_email_address']);
					
					
					
					/*
					tblData = "<tr bankAcctID="+obj.acct['bank_account_id']+"><td class='option'><img ref="+ctr2+" title='Remove Detail' src='/ebms/images/remove.png' class='removeDetail'></td><td><input type='text' id='dataAcctName' value='"+acctName+"' disabled></td><td><input type='text' id='dataAcctNo' value='"+acctNo+"'></td> <td><input type='text' id='dataAcctType' value='"+acctType+"' disabled></td></tr>";
					$(container+" #acctDetails").append(tblData);
					
					$(container+" #acctName").val("").focus();
					$(container+" #acctNo").val("");
					$(container+" #acctType").val("current");
					
					$(container+" tr").dblclick(function(){
						$(this).find("input").removeAttr("disabled");
						$(this).find("td").css({"-webkit-box-shadow":"0 0 35px silver inset","-moz-box-shadow":"0 0 35px silver inset","box-shadow":"0 0 35px silver inset"});
							
					});
					*/
					
					$("#edit_bank #save").click(function(){
					
					bankName = $("#edit_bank #bankName").val().trim();
					bankAddress = $("#edit_bank #bankAddress").val().trim();
						
					phoneNo = $("#edit_bank #phoneNo").val().trim();
					faxNo = $("#edit_bank #faxNo").val().trim();
					website = $("#edit_bank #website").val().trim();
					email = $("#edit_bank #email").val().trim();
					contactPerson = $("#edit_bank #contactPerson").val().trim();
					position = $("#edit_bank #position").val().trim();
					contactDept = $("#edit_bank #contactDept").val().trim();
					contactPhoneNo = $("#edit_bank #contactPhoneNo").val().trim();
					contactMobileNo = $("#edit_bank #contactMobileNo").val().trim();
					contactEmail = $("#edit_bank #contactEmail").val().trim();
			
					if(bankName == "" || bankAddress == "" || website == "" || email == "" || phoneNo == "" || faxNo == "" || contactPerson == "" || position == "" || contactDept == "" || contactEmail == "" || contactPhoneNo == "" || contactMobileNo == "")
					{
						alert("Please complete necessary details");
						
					}

					else
					{
					dataString = "&bankName="+bankName+"&bankAddress="+bankAddress+"&website="+website+"&email="+email+"&phoneNo="+phoneNo+"&faxNo="+faxNo+"&contactPerson="+contactPerson+"&position="+position+"&department="+contactDept+"&contactEmail="+contactEmail+"&contactPhoneNo="+contactPhoneNo+"&contactMobileNo="+contactMobileNo;
						$.ajax({
						url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
						type:"POST",
						data:"role=edit&bankID="+bankID+dataString,
						cache:false,
						success:
							function()
							{
							alert("Bank record successfully updated");
							loadData(1,"");
							$(".formClose").click();
							}
						});
						
					}
					
					});
				}
		});
	
	});
	
	$("#delete_bank #save").click(function(){
		
		$.post("/ebms/apps/view/accounting/bankRecords/bankList.php",
			{role:"delete",bankID:$("button#delete").attr("bankID")},
			function(response)
			{
				alert("Bank record successfully deleted");
				$(".formClose").click();
				loadData(1,"");
			});
			
		
	});	
	$("#restore_bank #save").click(function(){
		
		$.post("/ebms/apps/view/accounting/bankRecords/bankList.php",
			{role:"restore",bankID:$("button#restore").attr("bankID")},
			function(response)
			{
				alert("Bank record successfully restored");
				$(".formClose").click();
				loadData(1,"");
			});
			
			
	});
		
	
		$("#new_bank #saveDetailBtn").click(function(){
								acctName = $("#new_bank #acctName").val().trim();
								acctNo = $("#new_bank #acctNo").val().trim();
								acctType = $("#new_bank #acctType").val().trim();
								appendAcctInfo("#new_bank",acctName,acctNo,acctType);	

		});
		
		$("#new_bank #save").click(function(){
			
			bankName = $("#new_bank #bankName").val().trim();
			bankAddress = $("#new_bank #bankAddress").val().trim();
			
			website = $("#new_bank #website").val().trim();
			email = $("#new_bank #email").val().trim();
			phoneNo = $("#new_bank #phoneNo").val().trim();
			faxNo = $("#new_bank #faxNo").val().trim();
			
			contactPerson = $("#new_bank #contactPerson").val().trim();
			position = $("#new_bank #position").val().trim();
			department = $("#new_bank #dept").val().trim();
			
			contactEmail = $("#new_bank #contactEmail").val().trim();
			contactPhoneNo = $("#new_bank #contactPhoneNo").val().trim();
			contactMobileNo = $("#new_bank #contactMobileNo").val().trim();
			
			if(bankName == "" || bankAddress == "" || website == "" || email == "" || phoneNo == "" || faxNo == "" || contactPerson == "" || position == "" || contactDept == "" || contactEmail == "" || contactPhoneNo == "" || contactMobileNo == "")
			{
				alert("Please complete necessary details");
				
			}
			
			else 
			{
			
			ans = confirm("We are now saving this record. Would you like to continue?");
				if(ans)
				{
					$("#new_bank #acctDetails tr").each(function(index){
										acctDetails[index] = new Array();
												$("#new_bank #acctDetails tr:eq("+index+") td").each(function(index2){
												
												if(index2 > 0)
												{
												//alert(index2+": "+$(this).find("input").val());
												acctDetails[index][index2-1] = $(this).find("input").val();
												}
												});
										});
										
										acctDetails = JSON.stringify(acctDetails);
				
				dataString = "bankName="+bankName+"&bankAddress="+bankAddress+"&website="+website+"&email="+email+"&phoneNo="+phoneNo+"&faxNo="+faxNo+"&contactPerson="+contactPerson+"&position="+position+"&department="+department+"&contactEmail="+contactEmail+"&contactPhoneNo="+contactPhoneNo+"&contactMobileNo="+contactMobileNo+"&acctDetails="+acctDetails;
				
					$.ajax({
						url:"/ebms/apps/view/accounting/bankRecords/bankList.php",
						type:"POST",
						data:dataString+"&role=new",
						cache:false,
						success:
							function()
							{
								alert("Bank record successfully created");
								$(".formClose").click();
								loadData(1,"");
							}
					});
			
				
				}
				
			
			}
		});
			
	
</script>