<script>
	var totalAmount = 0;
	var init,page,searchQuery="",from="",to="";

	function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
		
		}
	//by default, the first page will be displayed
	loadData(1,searchQuery);
	function loadData(page,searchQuery)
	{
		initialize();
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}	
			
		$.ajax({
			type: "POST",
			url: "chequeList.php",
			data: "page="+page+"&searchQuery="+searchQuery,
			cache: false,
			beforeSend:
			function()
			{
			$("#loading").fadeTo("slow",0.7).show();
			},
			success: function(response)
			{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				$("#cleared-cheques").html(arrResponse[0]);
				datagrid("cleared-cheques", true);
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				setPageResponse(arrResponse[1]);		
				
				
				//toggle icons for included cheques
				$('#cleared-cheques table tr a').toggle(function()
				{
					$(this).find('.includedItem').hide();
					$(this).find('.addItem').show();
						
					//when record is selected
					if($(this).find('.includedItem').css('display') == "none")
					{
						totalAmount += parseFloat($(this).parent().parent().attr('amount'));
						$('#clearAmount').val(totalAmount);
					}
				},
				function()
				{
					$(this).find('.includedItem').show();
					$(this).find('.addItem').hide();
						
					//record deselected
					if($(this).find('.addItem').css('display') == "none")
					{
						totalAmount -= parseFloat($(this).parent().parent().attr('amount'));
						$('#clearAmount').val(totalAmount);
					}
				});
			}
		});
	}
	
	$(".page-nav li button").click(function()
	{							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
	});
	
	$("#clearCheque").click(function()
	{
		if($("#clearAmount").val() != "")
		{
			$("#cleared-cheques table tr a").each(function()
			{
				if($(this).find('.addItem').css("display") != "none")
				{
					chequeNo = $(this).parent().parent().attr('no');
					chequeAmount = $(this).parent().parent().attr('amount');
					bankId = $(this).parent().parent().attr("bankid");
					accountId = $(this).parent().parent().attr("accountid");
					chequeId = $(this).parent().parent().attr("chequeid");
					$.post('clearCheques.php', {chequeNo:chequeNo, chequeAmount:chequeAmount, bankId:bankId, accountId:accountId, chequeId:chequeId});
				}
			});
			
			alert("Cheque/s successfully cleared.");
			loadData(1,"");
		}
		else
		{
			alert("All fields are required.");
		}
		return false;
	});
	
</script>