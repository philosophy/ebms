﻿<!-- PAYABLES CONTROLLER -->
<script>
var searchQuery="";
var amount=0;
var hdrNo=0;
var suppId =0;
var ctr=0;

function initialize()
		{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
		}
		
	
		
		function loadData(page,searchQuery)
		{
		initialize();
		if(init == "" || init == "Search...")
			{
			searchQuery = "";
			}
		
		else 
			{
			searchQuery = init;
			}
		
			
		$.ajax({
			type: 'POST',
			url: 'expenseList.php',
			cache: false,
			data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
			success: function(response)
			{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
					
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				$('#expenses').html(arrResponse[0]);
				datagrid('expenses', true);
				setPageResponse(arrResponse[1]);
				
				$('#expenses table tr').click(function()
				{
					$("#edit").attr('disabled',false);
					$("#expenses table").find("tr").removeClass("activeTr");
					$(this).addClass("activeTr");
					expId = $(this).attr("a");
					$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"render",id:expId},
					function(response)
					{
						obj = JSON.parse(response);
						// $("div#edit_expense #transactionCode").val(obj.values["code"]);
						// $("div#edit_expense #particular").val(obj.values["particular"]);
						// $("div#edit_expense #refNo").val(obj.values["refNo"]);
						// $("div#edit_expense #empName").val(obj.values["emp"]);
						// $("div#edit_expense #vendor").val(obj.values["suppId"]);
						$("div#edit_expense #bankName").val(obj.values["bankName"]);
						$("div#edit_expense #bankAccountType").val(obj.values["accountType"]);
						$("div#edit_expense #accountName").val(obj.values["accountName"]);
						$("div#edit_expense #accountNumber").val(obj.values["accountNo"]);
						$("div#edit_expense #checkNumber").val(obj.values["checkNo"]);
						$("div#edit_expense #checkType").val(obj.values["checkType"]);
						$("div#edit_expense #editCheckDueDate").val(obj.values["dueDate"]);
						$("div#edit_expense #editCheckDateIssue").val(obj.values["dateIssued"]);
						if($("div#edit_expense #bankName").val() != "")
						{
							$("div#edit_expense #payment").val("Check");
						}
						else
						{
							$("div#edit_expense #payment").val("Cash");
						}
					});
					$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"amount",id:expId},
						function(result)
						{
							obj = JSON.parse(result);
							$("div#edit_expense #transactionNumber").val(obj.cash["code"]);
							$("div#edit_expense #particular").val(obj.cash["particular"]);
							$("div#edit_expense #refNo").val(obj.cash["refNo"]);
							$("div#edit_expense #empName").val(obj.cash["emp"]);
							$("div#edit_expense #vendor").val(obj.cash["suppId"]);
							$("div#edit_expense #totalAmount").val(obj.cash["amount"]);
						});
					$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"view",id:expId},
					function(response)
					{
						$('div#edit_expense #expense').html(response);	
					});
					
					$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"view",id:expId},
					function(response)
					{
						$('#details').html(response);	
						datagrid('details',true);
					});
				});
			}
			
		});
		
		}
$("div#edit_expense #save").click(function()
{
	$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"edit",id:expId, emp:$("div#edit_expense #empName").val(), particular:$("div#edit_expense #particular").val()},
	function(response)
	{
		loadData(1,searchQuery);
		$("div#edit_expense .formClose").click();
	});
});

$(document).ready(function()
{
	inputMask("formDataContSearch","Search");
	$("#edit").attr('disabled',true);
	loadData(1,searchQuery);
	$(".page-nav li button").click(function()
	{
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
		setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
		loadData(page,searchQuery);
	});
		$("#new").attr('title', 'New Expense');
		$("#edit").attr('title', 'Edit Expense');
	
	$.ajax({
		type: 'POST',
		url: 'fromPOtable.php',
		data:"role=PO",
		success: function(response)
		{
			$('div#import #items').html(response);
			datagrid('import', true);
			
			$('table#expense tbody#items tr').click(function()
			{
				setCellContentValue($(this));
			});
		}
		});
		
	$.ajax(
	{
		url:"/ebms/apps/view/accounting/companyPayables/getAccountType.php",
		type:"POST",
		success:
		function(response)
		{
			$("div#new_expense #accountType").html(response);
		}
	});
	
	$.ajax(
	{
		url:"/ebms/apps/view/accounting/expenses/comboBoxes.php",
		type:"POST",
		data: "role=employee",
		success:
		function(response)
		{
			$("div#new_expense #empName").append(response);
		}
	});
	$.ajax(
	{
		url:"/ebms/apps/view/accounting/expenses/comboBoxes.php",
		type:"POST",
		data: "role=employee",
		success:
		function(response)
		{
			$("div#edit_expense #empName").append(response);
		}
	});
	
	$.ajax(
	{
		url:"/ebms/apps/view/accounting/expenses/comboBoxes.php",
		type:"POST",
		data: "role=supplier",
		success:
		function(response)
		{
			$("div#new_expense #vendor").append(response);
		}
	});
	
		$.ajax(
	{
		url:"/ebms/apps/view/accounting/expenses/comboBoxes.php",
		type:"POST",
		data: "role=supplier",
		success:
		function(response)
		{
			$("div#edit_expense #vendor").append(response);
		}
	});
		
	function setCellContentValue(selector)
	{
		$("table#expense tbody#items").find("tr").removeClass("activeTr");
		$(selector).addClass("activeTr");
		item = $(selector).attr("a");
		$.post('/EBMS/apps/view/accounting/expenses/fromPOtable.php', {role:"image", id:item},
		function(response)
		{
			$('div#import #details').html(response);
			datagrid('import', true);
		});
		amount = $(selector).attr("amount");
		hdrNo = $(selector).attr("hdrNo");
		suppId = $(selector).attr("supplierID");
		//alert(amount+ " " + hdrNo + " " + suppId);
	}
	
	
	$("#btnImport").click(function()
	{
		$("div#import").show();
		var fade = "<div class='formSubFade'></div>";
			
			if($(".formSubFade").length == 0)
			$("body").append(fade);
	});
	$("#importCancel").click(function()
	{
		$("div#import").hide();
		$(".formSubFade").remove();
		$("div#new_expense #refNo").val("");
		$("div#new_expense #vendor").val("");
		$('div#new_expense #totalAmount').val("0");
		return false;
	});
	$("#importSave").click(function()
	{
		$("div#import").hide();
		$(".formSubFade").remove();
		//alert(amount+ " " + hdrNo + " " + suppId);
		$("div#new_expense #refNo").val(hdrNo);
		$("div#new_expense #vendor").val(suppId);
		$("div#new_expense #totalAmount").val("0");
		$.ajax(
		{
			url:"/ebms/apps/view/accounting/expenses/addtoPO.php",
			type:"POST",
			data:"ctr="+ ctr +"&role=selected&amount=" + amount + "&desc=From PO",
			success:
			function(response)
			{
				//alert(response);
				$('div#new_expense #poDetails').html(response);
				$('div#new_expense #poDetails img').click(function()
				{
					row = $(this).attr("rowNum");
					$("div#new_expense #poDetails tr[rowNum=" + row + "]").remove();
					computeTotal();
				});
				ctr++;
				computeTotal();
			}
		});
		return false;
	});
	
});
$("div#new_expense #save").click(function()
{
	if($("div#new_expense #payment").val()=="Cash")
	{
		$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"cashOnHand"},
		function(cash)
		{
			if(parseFloat(cash) >= parseFloat($("div#new_expense #totalAmount").val()))
			{
				insertExpenseHeaderAndDetail("cash");
			}
			else
			{
				alert('Transaction not possible. Insufficient amount in cash on hand.');
			}
		});
	}
	else if($("div#new_expense #payment").val()=="Check")
	{
		
		if($("div#new_expense #bankName").val() == "" || $("div#new_expense #bankAccountType").val()== "" || $("div#new_expense #accountNumber").val() == "" || $("div#new_expense #checkNumber").val().trim() == "" || $("div#new_expense #checkDateIssue").val() == "" || $("div#new_expense #checkDueDate").val() == "")
		{
			alert('All payment related fields are required.');
		}
		else
		{
			insertExpenseHeaderAndDetail("check");
		}
	}
	
});

function insertExpenseHeaderAndDetail(type)
{
	if($("div#new_expense #poDetails tr").length == 0)
	{
		alert('Please insert expense in the table.');
	}
	else if($("div#new_expense #particular").val().trim()=="" || $("div#new_expense #empName").val()=="...") 
	{
		alert('Please fill the particular and Employee name fields.');
	}
	else
	{
		//alert($("div#new_expense #empName").val());
		$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"addExpense", amount:$("div#new_expense #totalAmount").val(),particular:$("div#new_expense #particular").val(), refNo:$("div#new_expense #refNo").val(), empId:$("div#new_expense #empName").val(), suppId:$("div#new_expense #vendor").val()},
		function(expCode)
		{
			if(type=="cash")
			{
				$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"insertPayment", particular:$("div#new_expense #particular").val(), paymentType:"cash", amount:$("div#new_expense #totalAmount").val(), emp: $("div#new_expense #empName").val(), refNo:expCode},
				function(result)
				{
				
				});
			}
			else if(type=="check")
			{
				$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"insertPayment", particular:$("div#new_expense #particular").val(), paymentType:"check", amount:$("div#new_expense #totalAmount").val(), emp: $("div#new_expense #empName").val(), refNo:expCode},
				function(paymentNo)
				{
				
					//alert("bankName:" + $("div#new_expense #bankName").val() + ", bankAccountType:" + $("div#new_expense #bankAccountType").val() + ", accountNumber:" + $("div#new_expense #accountNumber option:selected").text() + ", accountName:" + $("div#new_expense #accountName").val() + ", checkNumber:" + $("div#new_expense #checkNumber").val() + ", checkType:" + $("div#new_expense #checkType").val() + ", checkDateIssue:" + $("div#new_expense #checkDateIssue").val() + ", checkDueDate:"+ $("div#new_expense #checkDueDate").val() + ", particular:" + $("div#new_expense #particular").val() + ", paymentType:" + $("div#new_expense #payment").val());
					$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"checkProfile", pmntNo: paymentNo, amount:$("div#new_expense #totalAmount").val(), emp: $("div#new_expense #empName").val(), refNo:expCode, checkNo:$("div#new_expense #checkNumber").val(), checkDueDate:$("div#new_expense #checkDueDate").val(), checkDateIssue:$("div#new_expense #checkDateIssue").val(), checkType: $("div#new_expense #checkType").val(), accountNo: $("div#new_expense #accountNumber option:selected").text(),accountName:$("div#new_expense #accountName").val(), bankId:$("div#new_expense #bankName").val()},
					function(result)
					{

					});
				});
			}
			
			
			account = "";
			desc = "";
			amt = "";
			$("div#new_expense #poDetails tr").each(function(index)
			{
				//account = $("div#new_expense #poDetails tr").attr("a");
				a=0;
				$("div#new_expense #poDetails tr:eq(" + index + ") td").each(function(index2)
				{
					a++;
					if(a==2)
					{					
						account = $(this).attr("a");
					} else if(a==3)
					{					
						desc = $(this).text();
					} else if(a==4)
					{					
						amt = $(this).text().replace(/,/g,"");
					}
				});
				//alert(expCode + " " + account + " " + desc + " " + amt);
				$.post('/EBMS/apps/view/accounting/expenses/expenseCrud.php', {role:"addDetail", exp: expCode, accountId: account, description: desc, amount:amt},
				function(response)
				{
					loadData(1,searchQuery);
					clear();
					$("div#new_expense .formClose").click();
				});
				
			});
			
		});
	}
}

function clear()
{
	$("div#new_expense #bankName").attr("disabled",true);
	$("div#new_expense #bankAccountType").attr("disabled",true);
	$("div#new_expense #accountNumber").attr("disabled",true);
	$("div#new_expense #checkNumber").attr("disabled",true);
	$("div#new_expense #checkType").attr("disabled",true);
	$("div#new_expense #checkDateIssue").attr("disabled",true);
	$("div#new_expense #checkDueDate").attr("disabled",true);
	$("div#new_expense #bankName").html("");
	$("div#new_expense #bankAccountType").html("");
	$("div#new_expense #accountNumber").html("");
	$("div#new_expense #checkNumber").val("");
	$("div#new_expense #accountName").val("");
	$("div#new_expense #checkDateIssue").val("");
	$("div#new_expense #checkDueDate").val("");
	$("div#new_expense #particular").val("");
	$("div#new_expense #empName").val("0");
	$("div#new_expense #vendor").val("0");
	$("div#new_expense #amount").val("0");
	$("div#new_expense #totalAmount").val("0");
	$("div#new_expense #refNo").val("");
	$("div#new_expense #description").val("0");
	$('div#new_expense #poDetails').html("");
}




$("div#new_expense #payment").change(function()
{
	if($("div#new_expense #payment").val()=="Check")
	{
		$("div#new_expense #bankName").attr("disabled",false);
		$("div#new_expense #bankAccountType").attr("disabled",false);
		$("div#new_expense #accountNumber").attr("disabled",false);
		$("div#new_expense #checkNumber").attr("disabled",false);
		$("div#new_expense #checkType").attr("disabled",false);
		$("div#new_expense #checkDateIssue").attr("disabled",false);
		$("div#new_expense #checkDueDate").attr("disabled",false);
		
		$("div#new_expense #bankName").html("");
		$.post("/EBMS/apps/view/accounting/expenses/comboboxes.php", {role:"bankName"},function(response)
		{
			$("div#new_expense #bankName").append(response);
			accountType();
		});
	}
	else if($("div#new_expense #payment").val()=="Cash")
	{
		$("div#new_expense #bankName").attr("disabled",true);
		$("div#new_expense #bankAccountType").attr("disabled",true);
		$("div#new_expense #accountNumber").attr("disabled",true);
		$("div#new_expense #checkNumber").attr("disabled",true);
		$("div#new_expense #checkType").attr("disabled",true);
		$("div#new_expense #checkDateIssue").attr("disabled",true);
		$("div#new_expense #checkDueDate").attr("disabled",true);
		$("div#new_expense #bankName").html("");
		$("div#new_expense #bankAccountType").html("");
		$("div#new_expense #accountNumber").html("");
		$("div#new_expense #checkNumber").val("");
		$("div#new_expense #accountName").val("");
		$("div#new_expense #checkDateIssue").val("");
		$("div#new_expense #checkDueDate").val("");
	}

});

$("div#new_expense #bankName").change(function()
{
	accountType();
});

$("div#new_expense #accountNumber").change(function()
{
	$.post("/EBMS/apps/view/accounting/expenses/comboboxes.php", {role:"accountName", acctId:$("div#new_expense #accountNumber").val()},function(response)
	{
		$("div#new_expense #accountName").val(response);
	});
});

$("div#new_expense #bankAccountType").change(function()
{
	accountNumber();
});

function accountType()
{
	$("div#new_expense #bankAccountType").html("");
	$.post("/EBMS/apps/view/accounting/expenses/comboboxes.php", {role:"accountType", bank:$("div#new_expense #bankName").val()},function(response)
	{
		$("div#new_expense #bankAccountType").append(response);
		accountNumber();
		
	});
}	

function accountNumber()
{
	$("div#new_expense #accountNumber").html("");
	$.post("/EBMS/apps/view/accounting/expenses/comboboxes.php", {role:"accountNumber", type:$("div#new_expense #bankAccountType").val(), bank:$("div#new_expense #bankName").val()},function(response)
	{
		$("div#new_expense #accountNumber").append(response);
		$.post("/EBMS/apps/view/accounting/expenses/comboboxes.php", {role:"accountName", acctId:$("div#new_expense #accountNumber").val()},function(response)
		{
			$("div#new_expense #accountName").val(response);
		});
	});
}



$("div#new_expense #amount").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});

$("div#new_expense #totalAmount").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});


$("div#new_expense #checkDateIssue").bind("keypress", function(e) 
{ 
return(false);
});

$("div#new_expense #checkDueDate").bind("keypress", function(e) 
{ 
return(false);
});
	


$("div#new_expense #add").click(function()
{
	//alert("accountTypeId=" + $("div#new_expense #accountType").val() + "&amount=" + $("div#new_expense #amount").val() + "&desc=" + $("div#new_expense #description").val());
	if($("div#new_expense #accountType").val()=="" || $("div#new_expense #amount").val().trim()=="" || parseInt($("div#new_expense #amount").val()) == 0 || $("div#new_expense #description").val().trim()=="")
	{
		alert("Please fill the account type, amount and description fields.");
	}
	else
	{
		$.ajax(
		{
			url:"/ebms/apps/view/accounting/expenses/addtoPO.php",
			type:"POST",
			data:"ctr=" + ctr +"&role=add&accountTypeId=" + $("div#new_expense #accountType").val() + "&amount=" + $("div#new_expense #amount").val() + "&desc=" + $("div#new_expense #description").val(),
			success:
			function(response)
			{
				
				//alert(response);
				$('div#new_expense #poDetails').append(response);
				$('div#new_expense #poDetails img').click(function()
				{
					row = $(this).attr("rowNum");
					
					$("div#new_expense #poDetails tr[rowNum=" + row + "]").remove();
					computeTotal();
					
				});
				ctr++;
				computeTotal();
			}
		});
		
	}
});

function computeTotal()
{
	total=0;
	$("div#new_expense #poDetails tr").each(function(index)
	{
		a=0;
		$("div#new_expense #poDetails tr:eq(" + index + ") td").each(function(index2)
		{
			a++;
			if(a==4)
			{
				total = total + parseFloat($(this).text().replace(/,/g,""));
				//alert(total);
				//alert($(this).text());
			}
			
		});
	});
	$("div#new_expense #totalAmount").val(total.toFixed(2))
}

</script>