<?php 

//controller events for crm profile display

?>

<script>
var init,page;
var searchQuery="";
var locationId ="", brgy = "", contact="", contactStatus="", mode = "";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	onLoad();
	}
	
	$("#new").attr('title', 'New Customer');
	$("#edit").attr('title', 'Edit Customer');
	$("#delete").attr('title', 'Delete Customer');
	$("#restore").attr('title', 'Restore Customer');
	
//by default, the first page will be displayed
loadData(1,searchQuery);

$("#customerInfo #phoneNo").mask("(+99)-999-9999999");
$("#customerInfo #mobileNo").mask("(+99)9999999999");
$("#customerInfo #faxNo").mask("(+99)-999-9999999");
$("#customerLocation #phoneNo").mask("(+99)-999-9999999");
$("#customerLocation #mobileNo").mask("(+99)9999999999");
$("#customerLocation #faxNo").mask("(+99)-999-9999999");
$("#customerContact #phoneNo").mask("(+99)-999-9999999");
$("#customerContact #mobileNo").mask("(+99)9999999999");
$("#customerContact #faxNo").mask("(+99)-999-9999999");

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
				
			$.ajax({
				type: "POST",
				url: "../../view/crm/crm.php",
				data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
				success: 
				function(response)
				{
				$("#loading").fadeTo("slow",0).hide();
				var arrResponse = response.split('&');
				$("#crm-profile").html(arrResponse[0]);
				
				setPageBtnValue(arrResponse[2],arrResponse[3]);
				datagrid("crm-profile",true);
				setPageResponse(arrResponse[1]);
				
				$("#crm-profile table tr").click(function(){
					
				$("#newLocation").attr("disabled", true);
				$("#editLocation").attr("disabled", true);
				$("#restoreLocation").attr("disabled", true);
				$("#deleteLocation").attr("disabled", true);
				$("#newContact").attr("disabled", true);
				$("#editContact").attr("disabled", true);
				$("#restoreContact").attr("disabled", true);
				$("#deleteContact").attr("disabled", true);
					$("#customerLocation #subgrid-second").html("");
					$(".subdatagrid").html("");
					setCellContentValue($(this));
						
								var custName = $(this).attr("customerName");
								custCode =  $(this).attr("a");
							
								$("#subgrid-head-first span.name").html(" - "+custName);
					});	
				}

				});
		}
			$("#customerInfo #mobileNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			
			$("#customerInfo #phoneNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			$("#customerInfo #faxNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			$("#customerLocation #phoneNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			$("#customerLocation #faxNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			$("#customerContact #mobileNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			$("#customerContact #phoneNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			$("#customerContact #faxNo").bind("keypress", function(e) { 
				
							return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
			});
			
			
	
				$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
						
					});
					
				
				$("#restore_crm #save").click(function()
				{ 
					$.post("restore.php",{customerCode:custCode});
					$("div#restore_crm.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					function(){
						$(".formFade").remove();
					});
					    $("div#restore_crm.modalForm").hide();
					});
					loadData(1,searchQuery);
				});
				
				
				$("#delete_crm #save").click(function()
				{ 
					$.post("delete.php",{customerCode:custCode});
					$("div#delete_crm.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					function(){
						$(".formFade").remove();
					});
					    $("div#delete_crm.modalForm").hide();
					});
					loadData(1,searchQuery);
				});
				
				$("#delete_location #save").click(function()
				{ 	
					$.post("deleteLocation.php",{locId:locationId});
					$("div#delete_location.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					
					function(){
						$(".formFade").remove();
					});
					    $("div#delete_location.modalForm").hide();
					});
					$("div#crm-profile table tr.activeTr").trigger("click");
					$("#newLocation").attr("disabled", true);
					$("#newContact").attr("disabled", true);
				});
				
				$("#restore_location #save").click(function()
				{ 	
					$.post("restoreLocation.php",{locId:locationId});
					
					$("div#delete_location.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					function(){
						$(".formFade").remove();
					});
					    $("div#restore_location.modalForm").hide();
					});
					$("div#crm-profile table tr.activeTr").trigger("click");
					$("#newLocation").attr("disabled", true);
					$("#newContact").attr("disabled", true);
				});

				$("#edit").click(function()
				{
					$("div#edit_crm a[href = #customerLocation]").hide();
					$("a[href = #customerContact]").hide();
					$("a[href = #customerInfo]").show();
					$("a[href = #customerInfo]").trigger("click");

					fillData();

					$.post("update.php",{customer:custCode}, function(response){ 
					
					obj = JSON.parse(response);		
					$("div#customerInfo #customerCode").val(custCode).attr("disabled", true);
					$("div#customerInfo #customerName").val(obj.values["name"]);
					$("div#customerInfo #customerType").val(obj.values["customer_type"]);
					$("div#customerInfo #industryType").val(obj.values["industry_type"]);
					$("div#customerInfo #emailAddress").val(obj.values["email"]);
					$("div#customerInfo #mobileNo").val(obj.values["mobile"]);
					$("div#customerInfo #phoneNo").val(obj.values["phone"]);
					$("div#customerInfo #faxNo").val(obj.values["fax"]);
					$("div#customerInfo #remarks").val(obj.values["remarks"]);

					});
				});
				
				
				
				$("#edit_crm #save").click(function()
				{ 
					if($("a[href = #customerInfo]").is(":visible"))
							updateCustomer();
					else
						if(mode == "location")
							updateLocation(); 
								
						else
							updateContact();
				});
				
				
				function updateLocation()
				{
					locCode = locationId;
					locName = $("div#edit_crm div#customerLocation #customerName").val().trim();
					locType = $("div#edit_crm div#customerLocation #locationType").val().trim();
					locCity = $("div#edit_crm div#customerLocation #city").val().trim();
					locBarangay = $("div#edit_crm div#customerLocation #barangay").val().trim();
					locArea = $("div#edit_crm div#customerLocation #Area").val().trim();
					locAddress = $("div#edit_crm div#customerLocation #address").val().trim();
					locPhoneNo = $("div#edit_crm div#customerLocation #phoneNo").val().trim();
					locFaxNo = $("div#edit_crm div#customerLocation #faxNo").val().trim();
					dataString = "locId="+locCode+"&locName="+locName+"&locType="+locType+"&locCity="+locCity+"&locBarangay="+locBarangay+"&locArea="+locArea+"&locAddress="+locAddress+"&locPhoneNo="+locPhoneNo+"&locFaxNo="+locFaxNo;
				
					if(locName == "" || locType == "")
					{
						alert("Please fill up all required fields (*).");
					}
					else
					{
						$.ajax({
						type: "POST",
						url: "/ebms/apps/view/crm/updateLocation.php",
						data: dataString,
						cache: false,
						success:
						
							function(response)
							{ 
								$("div#edit_crm.modalForm").fadeOut("slow",0,
								function()
								{
									$(".formFade").fadeOut(300,
									function(){
									$(".formFade").remove();
									});
									$("div#edit_crm.modalForm").hide();
									});
									loadData(1,searchQuery);
									clearLocation();
								}
						});
					}	
				}
				
				function updateCustomer()
				{
						
				code = custCode; 
				customerName = $("div#edit_crm div#customerInfo #customerName").val().trim();
				customerType = $("div#edit_crm div#customerInfo #customerType").val().trim();
				industryType = $("div#edit_crm div#customerInfo #industryType").val().trim();
				emailAddress = $("div#edit_crm div#customerInfo #emailAddress").val().trim(); 
				mobileNo = $("div#edit_crm div#customerInfo #mobileNo").val().trim();
				phoneNo = $("div#edit_crm div#customerInfo #phoneNo").val().trim();
				faxNo = $("div#edit_crm div#customerInfo #faxNo").val().trim();
				remarks = $("div#edit_crm div#customerInfo #remarks").val().trim();	
				dataString = "code=" + code + "&customerName="+customerName+"&customerType="+customerType+"&industryType="+industryType+"&emailAddress="+emailAddress+"&mobileNo="+mobileNo+"&phoneNo="+phoneNo+"&faxNo="+faxNo+"&remarks="+remarks; 
				if(customerName == "" || customerType == "")
					{
						alert("Please fill up all required fields (*).");
					}
					else 
						if( $("div#edit_crm  #customerInfo #emailAddress").val() != "" && !isValidEmailAddress($("div#new_crm #customerInfo #emailAddress").val())) { 
							alert("Invalid email address");
							$("div#new_crm #customerInfo #emailAddress").focus();
						}		
				else{
				$.ajax({
				type: "POST",
				url: "../../view/crm/update.php",
				data: dataString,
				cache: false,
				success:
					function(){
					$("div#edit_crm.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					function(){
						$(".formFade").remove();
					});
					    $("div#edit_crm.modalForm").hide();
					});
					loadData(1,searchQuery);
					}
				
				});	
				}
				}
				
			
				
				function customerInfo()
				{
					
				
					customerName = $("div#new_crm div#customerInfo #customerName").val().trim();
					customerType = $("div#new_crm div#customerInfo #customerType").val().trim();
					industryType = $("div#new_crm div#customerInfo #industryType").val().trim();
					emailAddress = $("div#new_crm div#customerInfo #emailAddress").val().trim(); 
					mobileNo = $("div#new_crm div#customerInfo #mobileNo").val().trim();
					phoneNo = $("div#new_crm div#customerInfo #phoneNo").val().trim();
					faxNo = $("div#new_crm div#customerInfo #faxNo").val().trim();
					remarks = $("div#new_crm div#customerInfo #remarks").val().trim();	
					dataString = "customerName="+customerName+"&customerType="+customerType+"&industryType="+industryType+"&emailAddress="+emailAddress+"&mobileNo="+mobileNo+"&phoneNo="+phoneNo+"&faxNo="+faxNo+"&remarks="+remarks; 
					if(customerName == "" || customerType == "")
					{
						alert("Please fill up all required fields (*).");
					}
					else 
						if( $("div#new_crm  #customerInfo #emailAddress").val() != "" && !isValidEmailAddress($("div#new_crm  #customerInfo#emailAddress").val())) { 
							alert("Invalid email address");
							$("div#new_crm  #customerInfo #emailAddress").focus();
						}		
					else
					{
						$.ajax({
						type: "POST",
						url: "/ebms/apps/view/crm/createCustomer.php",
						data: dataString,
						cache: false,
						success:
						
							function(response)
							{ 
								var x = confirm("Do you want to add location?");
								if(x == true)
								{
									$("a[href = #customerLocation]").show();
									$("a[href = #customerLocation]").trigger("click");
									$("div#customerLocation #customerCode").val(response).attr("disabled", true);
									$("a[href = #customerInfo]").hide();
									$("a[href = #customerContact]").hide();
								}
								else
								{
									$("div#new_crm.modalForm").fadeOut("slow",0,
									function()
									{
										$(".formFade").fadeOut(300,
									function(){
										$(".formFade").remove();
									});
										$("div#new_crm.modalForm").hide();
									});
									loadData(1,searchQuery);
								}
							}
						
						});
					}	
				}
				
				function customerContact()
				{
					contactName = $("div#new_crm div#customerContact #contactName").val().trim();
					contactDepartment = $("div#new_crm div#customerContact #department option:selected").text().trim();
					contactJobTitle = $("div#new_crm div#customerContact #jobTitle option:selected").text().trim();
					contactEmailAddress = $("div#new_crm div#customerContact #emailAddress").val().trim(); 
					contactMobileNo = $("div#new_crm div#customerContact #mobileNo").val().trim();
					contactPhoneNo = $("div#new_crm div#customerContact #phoneNo").val().trim();
					contactFaxNo = $("div#new_crm div#customerContact #faxNo").val().trim();
					locId = locationId;	
					deptId = $("div#new_crm div#customerContact #department").val().trim();	
					jobId = $("div#new_crm div#customerContact #jobTitle").val().trim();	
					dataString = "contactName="+contactName+"&contactDepartment="+contact+"&contactJobTitle="+contactJobTitle+"&contactEmailAddress="+contactEmailAddress+"&contactMobileNo="+contactMobileNo+"&contactPhoneNo="+contactPhoneNo+"&contactFaxNo="+contactFaxNo+"&locId="+locId+"&deptId="+deptId+"&jobId="+jobId; 
					
					if(contactName == "")
					{
						alert("Contact Name is required.");
					}
					else
					if( $("div#new_crm #customerContact #emailAddress").val() != "" && !isValidEmailAddress($("div#new_crm #customerContact #emailAddress").val())) { 
							alert("Invalid email address");
							$("div#new_crm #customerContact #emailAddress").focus();
						}
					else
					if(contactEmailAddress == "" && contactMobileNo == "" && contactPhoneNo == "" && contactFaxNo == "" )
					{
						alert("Please provide at least one contact detail.");
					}
					else
					{
						$.ajax({
						type: "POST",
						url: "/ebms/apps/view/crm/createContact.php",
						data: dataString,
						cache: false,
						success:
						
							function(response)
							{ 
								$("div#new_crm.modalForm").fadeOut("slow",0,
								function()
								{
									$(".formFade").fadeOut(300,
								function(){
									$(".formFade").remove();
								});
									$("div#new_crm.modalForm").hide();
								});
								loadData(1,searchQuery);
							}
						
						});
					}	
				}
				
		
				
				function updateContact()
				{
					newContactName = $("div#edit_crm div#customerContact #contactName").val().trim();
					contactName = contact;
					contactDepartment = $("div#edit_crm div#customerContact #department option:selected").text().trim();
					contactJobTitle = $("div#edit_crm div#customerContact #jobTitle option:selected").text().trim();
					contactEmailAddress = $("div#edit_crm div#customerContact #emailAddress").val().trim(); 
					contactMobileNo = $("div#edit_crm div#customerContact #mobileNo").val().trim();
					contactPhoneNo = $("div#edit_crm div#customerContact #phoneNo").val().trim();
					contactFaxNo = $("div#edit_crm div#customerContact #faxNo").val().trim();
					locId = locationId;	
					deptId = $("div#edit_crm div#customerContact #department").val().trim();	
					jobId = $("div#edit_crm div#customerContact #jobTitle").val().trim();	
					dataString = "contactName="+contactName+"&newContactName="+newContactName+"&contactDepartment="+contactDepartment+"&contactJobTitle="+contactJobTitle+"&contactEmailAddress="+contactEmailAddress+"&contactMobileNo="+contactMobileNo+"&contactPhoneNo="+contactPhoneNo+"&contactFaxNo="+contactFaxNo+"&locationId="+locId+"&deptId="+deptId+"&jobId="+jobId;
					if(newContactName == "")
					{
						alert("Contact Name is required.");
					}
					else
					if( $("div#edit_crm #customerContact #emailAddress").val() != "" && !isValidEmailAddress($("div#edit_crm #customerContact #emailAddress").val())) { 
							alert("Invalid email address");
							$("div#edit_crm  #customerContact #emailAddress").focus();
						}
					else
					if(contactEmailAddress == "" && contactMobileNo == "" && contactPhoneNo == "" && contactFaxNo == "" )
					{
						alert("Please provide at least one contact detail.");
					}
					else
					{
						$.ajax({
						type: "POST",
						url: "/ebms/apps/view/crm/updateContact.php",
						data: dataString,
						cache: false,
						success:
						
							function(response)
							{ 	
								$("div#edit_crm.modalForm").fadeOut("slow",0,
								function()
								{
									$(".formFade").fadeOut(300,
								function(){
									$(".formFade").remove();
								});
									$("div#edit_crm.modalForm").hide();
								});
								loadData(1,searchQuery);
								$("div#customerLocation table tr.activeTr").trigger("click");
								contact = "";
								locationId = "";
							}
						
						});
					}	
				}
				
				
				$("#newLocation").click(function()
				{
					clearLocation();
					$("a[href = #customerLocation]").show();
					$("a[href = #customerLocation]").trigger("click");
					$("div#customerLocation #customerCode").val(custCode).attr("disabled", true);
					$("a[href = #customerInfo]").hide();
					$("a[href = #customerContact]").hide();
					fillData();
				
					
				});	
				
				$("#newContact").click(function()
				{
					clearLocation();
					$("a[href = #customerLocation]").hide();
					$("a[href = #customerContact]").show();
					$("a[href = #customerContact]").trigger("click");
					$("div#customerContact #customerCode").val(custCode).attr("disabled", true);
					$("a[href = #customerInfo]").hide();
					$("a[href = #customerContact]").show();
				
					
				$.post("locationType.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerContact #locationType").empty();
				$("div#customerContact #locationType").append("<option value='...'>...</option>");
				for(i=0;i<obj.lt.length;i++)
				{
					$("div#customerContact #locationType").append("<option value='" +obj.lt[i]+ "'>"+obj.lt[i]+"</option>");
				}
				});	
			
					getContactData();
		
				});
				
				
				$("#editContact").click(function()
				{
					mode = "contact";
					clearLocation();
					$("a[href = #customerLocation]").hide();
					$("a[href = #customerContact]").show();
					$("a[href = #customerContact]").trigger("click");
					$("div#customerContact #customerCode").val(custCode).attr("disabled", true);
					$("a[href = #customerInfo]").hide();
					$("a[href = #customerContact]").show();
				
					
				$.post("locationType.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerContact #locationType").empty();
				$("div#customerContact #locationType").append("<option value='...'>...</option>");
				for(i=0;i<obj.lt.length;i++)
				{
					$("div#customerContact #locationType").append("<option value='" +obj.lt[i]+ "'>"+obj.lt[i]+"</option>");
				}
				});	
			
					getContactData();
					$.post("updateContact.php",{contactId:contact, locationId:locationId}, function(response){
					obj = JSON.parse(response);	
					$("div#edit_crm div#customerContact #contactName").val(obj.values["name"]);
					$("div#edit_crm div#customerContact #emailAddress").val(obj.values["email"]);
					$("div#edit_crm div#customerContact #mobileNo").val(obj.values["mobileNo"]);
					$("div#edit_crm div#customerContact #phoneNo").val(obj.values["phoneNo"]);
					$("div#edit_crm div#customerContact #faxNo").val(obj.values["faxNo"]);
					$("div#edit_crm div#customerContact #department option:selected").text(obj.values["department"]);
					$("div#edit_crm div#customerContact #jobTitle option:selected").text(obj.values["jobTitle"]);
					});
				});
				
				
				
				function getContactData()
				{
					
					$.post("getLocation.php",{locId:locationId}, function(response){ 
	
					obj = JSON.parse(response);	
					$("div#customerContact #locationType").val(obj.values["location_type_name"]).attr("disabled", true);
					$("div#customerContact #locationName").append("<option value='" +obj.values["location_name"]+ "'>"+obj.values["location_name"]+"</option>").attr("disabled", true);
					$("div#customerContact #locationName").val(obj.values["location_name"]);
				
					});
					
					$.post("job.php", function(response){
					$("div#customerContact #jobTitle").html(response);
					});
					
					$.post("department.php", function(response){
					$("div#customerContact #department").html(response);
					});
					
				}
				
				
				
				$("#editLocation").click(function()
				{
					mode = "location";
					clearLocation();
					$("a[href = #customerLocation]").show();
					$("a[href = #customerLocation]").trigger("click");
					$("div#customerLocation #customerCode").val(custCode).attr("disabled", true);
					$("a[href = #customerInfo]").hide();
					$("a[href = #customerContact]").hide();
					fillData();
					
					$.post("updateLocation.php",{locId:locationId}, function(response){ 
					obj = JSON.parse(response);
					$("div#edit_crm div#customerLocation #customerName").val(obj.values["locationName"]);
					$("div#edit_crm div#customerLocation #locationType").val(obj.values["locationType"]);
					$("div#edit_crm div#customerLocation #city").val(obj.values["city"]);
					brgy = obj.values["barangay"];
					
				$.post("barangay.php",{city:obj.values["city"]}, function(response){ 
				obj = JSON.parse(response);
				
				$("div#edit_crm div#customerLocation #barangay").empty();
				$("div#edit_crm div#customerLocation #barangay").append("<option value='...'>...</option>");
				for(i=0;i<obj.brgy.length;i++)
				{
					$("div#edit_crm div#customerLocation #barangay").append("<option value='"+obj.brgy[i]+"'>"+obj.brgy[i]+"</option>");
				}
				$("div#edit_crm div#customerLocation #barangay").val(brgy);
				});	
				
					
					$("div#edit_crm div#customerLocation #Area").val(obj.values["area"]);
					$("div#edit_crm div#customerLocation #address").val(obj.values["address"]);
					$("div#edit_crm div#customerLocation #phoneNo").val(obj.values["phone"]);
					$("div#edit_crm div#customerLocation #faxNo").val(obj.values["fax"]);				
					});
					
				});
		
				function clearLocation()
				{
					$("div#new_crm div#customerLocation #locationName").val('');
					$("div#new_crm div#customerLocation #locationType").val('...');
					$("div#new_crm div#customerLocation #city").val('...');
					$("div#new_crm div#customerLocation #barangay").val('...');
					$("div#new_crm div#customerLocation #Area").val('...');
					$("div#new_crm div#customerLocation #address").val('');
					$("div#new_crm div#customerLocation #phoneNo").val('');
					$("div#new_crm div#customerLocation #faxNo").val('');	
				}
				
						function customerLocation()
						{  
							locCode = $("div#new_crm div#customerLocation #customerCode").val().trim();
							locName = $("div#new_crm div#customerLocation #locationName").val().trim();
							locType = $("div#new_crm div#customerLocation #locationType").val().trim();
							locCity = $("div#new_crm div#customerLocation #city").val().trim();
							locBarangay = $("div#new_crm div#customerLocation #barangay").val().trim();
							locArea = $("div#new_crm div#customerLocation #Area").val().trim();
							locAddress = $("div#new_crm div#customerLocation #address").val().trim();
							locPhoneNo = $("div#new_crm div#customerLocation #phoneNo").val().trim();
							locFaxNo = $("div#new_crm div#customerLocation #faxNo").val().trim();
							dataString = "code="+locCode+"&locName="+locName+"&locType="+locType+"&locCity="+locCity+"&locBarangay="+locBarangay+"&locArea="+locArea+"&locAddress="+locAddress+"&locPhoneNo="+locPhoneNo+"&locFaxNo="+locFaxNo;

							if(locName == "" || locType == "")
							{
								alert("Please fill up all required fields (*).");
							}
							else
							{
								$.ajax({
								type: "POST",
								url: "/ebms/apps/view/crm/newLocation.php",
								data: dataString,
								cache: false,
								success:
								
									function(response)
									{ 
										var y = confirm("Do you want to add another location?");
										if(y == true)
										{
											clearLocation();
										}
										else if(y == false)
										{
											var z = confirm("Do you want to add a contact?");
											if(z == true)
											{
												$("a[href = #customerLocation]").hide();
												$("a[href = #customerContact]").trigger("click");
												$("div#customerContact #customerCode").val(custCode).attr("disabled", true);
												$("a[href = #customerInfo]").hide();
												$("a[href = #customerContact]").show();
											}
										
											else
											{
												$("div#new_crm.modalForm").fadeOut("slow",0,
												function()
												{
													$(".formFade").fadeOut(300,
												function(){
													$(".formFade").remove();
												});
													$("div#new_crm.modalForm").hide();
												});
												loadData(1,searchQuery);
												clearLocation();
											}
										}
									}
								});
							}	
						}			
		
		
				$("#new_crm #save").click(function()
				{ 
					if($("a[href = #customerInfo]").is(":visible"))
							customerInfo();
					else
						if($("a[href = #customerLocation]").is(":visible"))
							customerLocation();
						else
							customerContact();
				});
			
				$("div#customerLocation #city").change(function()
				{
				$.post("barangay.php",{city:$("div#customerLocation #city").val()}, function(response){ 
				obj = JSON.parse(response);
				
				$("div#customerLocation #barangay").empty();
				$("div#customerLocation #barangay").append("<option value='...'>...</option>");
				for(i=0;i<obj.brgy.length;i++)
				{
					$("div#customerLocation #barangay").append("<option value='"+obj.brgy[i]+"'>"+obj.brgy[i]+"</option>");	
				}
				});	
				});
			

			$("#new").click(function()
			{	
				$("div#new_crm a[href = #customerLocation]").hide();
				$("a[href = #customerContact]").hide();
				$("a[href = #customerInfo]").show();
				$("a[href = #customerInfo]").trigger("click");
				$("div#customerInfo #customerCode").val('<Auto>').attr("disabled", true);
				$("div#customerInfo #customerName").val('');
				$("div#customerInfo #customerType").val('');
				$("div#customerInfo #industryType").val('');
				$("div#customerInfo #emailAddress").val('');
				$("div#customerInfo #mobileNo").val('');
				$("div#customerInfo #phoneNo").val('');
				$("div#customerInfo #faxNo").val('');
				$("div#customerInfo #remarks").val('');	
				fillData();
			});
			

				
			function fillData()
			{
				$.post("customerType.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerInfo #customerType").empty();
				$("div#customerInfo #customerType").append("<option value='...'>...</option>");
				for(i=0;i<obj.ct.length;i++)
				{
					$("div#customerInfo #customerType").append("<option value='" +obj.ct[i]+ "'>"+obj.ct[i]+"</option>");
				}
				});		
				
				$.post("locationType.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerLocation #locationType").empty();
				$("div#customerLocation #locationType").append("<option value='...'>...</option>");
				for(i=0;i<obj.lt.length;i++)
				{
					$("div#customerLocation #locationType").append("<option value='" +obj.lt[i]+ "'>"+obj.lt[i]+"</option>");
				}
				});	
			
				
				
				$.post("city.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerLocation #city").empty();
				$("div#customerLocation #city").append("<option value='...'>...</option>");
				for(i=0;i<obj.city.length;i++)
				{
					$("div#customerLocation #city").append("<option value='" +obj.city[i]+ "'>"+obj.city[i]+"</option>");
				}
				});	

				$.post("industryType.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerInfo #industryType").empty();
				$("div#customerInfo #industryType").append("<option value='...'>...</option>");
				for(i=0;i<obj.it.length;i++)
				{
					$("div#customerInfo #industryType").append("<option value='" +obj.it[i]+ "'>"+obj.it[i]+"</option>");
				}
				});		
				
				$.post("area.php", function(response){ 
				obj = JSON.parse(response);
				$("div#customerLocation #Area").empty();
				$("div#customerLocation #Area").append("<option value='...'>...</option>");
				for(i=0;i<obj.area.length;i++)
				{
					$("div#customerLocation #Area").append("<option value='" +obj.area[i]+ "'>"+obj.area[i]+"</option>");
				}
				});					
			}			
		
			function onLoad()
			{
				$("#edit").attr("disabled", true);
				$("#restore").attr("disabled", true);
				$("#delete").attr("disabled", true);
				$("#newLocation").attr("disabled", true);
				$("#editLocation").attr("disabled", true);
				$("#restoreLocation").attr("disabled", true);
				$("#deleteLocation").attr("disabled", true);
				$("#newContact").attr("disabled", true);
				$("#editContact").attr("disabled", true);
				$("#restoreContact").attr("disabled", true);
				$("#deleteContact").attr("disabled", true);
			}
		
			function deleted()
			{
				$("#edit").attr("disabled", true);
				$("#restore").attr("disabled", false);
				$("#delete").attr("disabled", true);
			}
			
			function restored()
			{
				$("#edit").attr("disabled", false);
				$("#restore").attr("disabled", true);
				$("#delete").attr("disabled", false);
			}
			
			function setCellContentValue(selector)
			{
			//remove all active classes in tr element
			
					if($(selector).attr("deleted") == "true")
						deleted();
					else
						restored();
						
					$("#crm-profile table").find("tr").removeClass("activeTr");
					
					//then, set the active class to the clicked tr element
					$(selector).addClass("activeTr");
					
					//fetch Issued Item records
				
					
					//fetch Customer Transactions records
					
					
					//fetch Customer Checks records
					$.post("issuedChecks.php",{customerCode:$(selector).attr("a")},
						function(response)
						{
						$("#checkPayment").html(response);
						datagrid("checkPayment",true);
						});		
						
						showLocation(selector);
						showIssuedItems(selector);
						showTransactions(selector);
					
					
			}
			
			$("#delete_contact #save").click(function(){
				
				$.post("deleteContact.php",{contId:contact, locId:locationId} );
				
					$("div#delete_contact.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					
					function(){
						$(".formFade").remove();
					});
					    $("div#delete_contact.modalForm").hide();
					});
					$("div#customerLocation table tr.activeTr").trigger("click");
					contact = "";
					locationId = "";
					
					$("#editContact").attr("disabled", true);
					$("#deleteContact").attr("disabled", true);
					$("#restoreContact").attr("disabled", true);
								
			});
			
			
				$("#restore_contact #save").click(function(){
				
					$.post("restoreContact.php",{contId:contact, locId:locationId} );
				
					$("div#restore_contact.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					
					function(){
						$(".formFade").remove();
					});
					    $("div#restore_contact.modalForm").hide();
					});
					$("div#customerLocation table tr.activeTr").trigger("click");
					contact = "";
					locationId = "";
					$("#editContact").attr("disabled", true);
					$("#deleteContact").attr("disabled", true);
					$("#restoreContact").attr("disabled", true);
						
			});
			
			$("#customerInfo #emailAddress").blur(function(){
		
			});
			
			function isValidEmailAddress(emailAddress) {
				var pattern = new RegExp(/^(("[\w-+\s]+")|([\w-+]+(?:\.[\w-+]+)*)|("[\w-+\s]+")([\w-+]+(?:\.[\w-+]+)*))(@((?:[\w-+]+\.)*\w[\w-+]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
				return pattern.test(emailAddress);
			};
			
			function showTransactions(selector)
			{
				$.post("customerTransactions.php",{customerCode:$(selector).attr("a")},
				function(response)
				{
				var arrResponse = response.split(';');
				$("#customerTransact #transaction_header").html(arrResponse[0]);
				$("#total").html(arrResponse[1]);
				datagrid("transaction_header",true);
				$("#transaction_header table tr").click(function(){
						
				$("#transaction_header table").find("tr").removeClass("activeTr");

				//then, set the active class to the clicked tr element
				$(this).addClass("activeTr");
				//fetch customer location contact records
				orderSlip = $(this).attr("a").trim();
				$.post('/EBMS/apps/view/sales/orderSlip/osDetails.php', {osCode:orderSlip},
				function(response)
				{	
					$('#customerTransact #transaction_details').html(response);
					datagrid('transaction_details', true);
				});
								
				});
				
			});					
				
			}
			function showIssuedItems(selector)
			{
				$.post("issuedItem.php",{customerCode:$(selector).attr("a")},
						function(response)
						{
						$("#customerIssuedItem #issued_item_header").html(response);
						datagrid("issued_item_header",true);
						
						$("#issued_item_header table tr").click(function(){
						
						$("#issued_item_header table").find("tr").removeClass("activeTr");

						//then, set the active class to the clicked tr element
						$(this).addClass("activeTr");
						//fetch customer location contact records
						withCode = $(this).attr("a").trim();
						$.post('/EBMS/apps/view/inventory/itemWithdrawal/withdrawalDetails.php', {withdrawCode:withCode},
						function(response)
						{
							$('#customerIssuedItem #issued_item_details').html(response);
							datagrid('issued_item_details', true);
						});
										
						});
						});
			
			}
		
			function showLocation(selector)
			{
			//fetch customer location records
					$("#editLocation").attr("disabled", true);
					$("#deleteLocation").attr("disabled", true);
					$("#restoreLocation").attr("disabled", true);
					
			
					$.post("location.php",{customerCode:$(selector).attr("a")},
						function(response)
						{

						$("#subgrid-first").html(response);
						datagrid("subgrid-first",true);
							
							$("#customerLocation table tr").click(function(){
								
								
								if($(this).attr("deleted") == "true")
								{
									$("#editLocation").attr("disabled", true);
									$("#deleteLocation").attr("disabled", true);
									$("#restoreLocation").attr("disabled", false);
								}
								else
								{
									$("#editLocation").attr("disabled", false);
									$("#deleteLocation").attr("disabled", false);
									$("#restoreLocation").attr("disabled", true);
								}
								
								//remove all active classes in tr element
								$("#customerLocation table").find("tr").removeClass("activeTr");
								locationId = $(this).attr("b");
								
								$("#newLocation").attr("disabled", false);
								$("#newContact").attr("disabled", false);
									
								//then, set the active class to the clicked tr element
								$(this).addClass("activeTr");
								//fetch customer location contact records
									$.post("contacts.php",{customerCode:custCode,locationID:locationId},
										function(response)
										{
										
										$("#subgrid-second").html(response);
										datagrid("subgrid-second",true);
										
										$("#customerLocation div#subgrid-second  table tr").click(function(){
										if($(this).attr("deleted") == "true")
										{
											$("#editContact").attr("disabled", true);
											$("#deleteContact").attr("disabled", true);
											$("#restoreContact").attr("disabled", false);
										}
										else
										{
											$("#editContact").attr("disabled", false);
											$("#deleteContact").attr("disabled", false);
											$("#restoreContact").attr("disabled", true);
										}
										$("#customerLocation div#subgrid-second  table").find("tr").removeClass("activeTr");
										$(this).addClass("activeTr");
										contact = $(this).attr("contact");
									
										});
										});
								});
						});
			}

</script>