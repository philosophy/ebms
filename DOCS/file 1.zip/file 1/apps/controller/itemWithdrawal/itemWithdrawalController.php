
<script>
	var withId;
	var init,page;

	var searchQuery="";

	function initialize()
	{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
	}
	//by default, the first page will be displayed
	loadData(1,searchQuery);
	
	$("#new").attr('title', 'New Withdrawal Record');
	$("#edit").attr('title', 'Edit Withdrawal Record');
	$("#delete").attr('title', 'Delete Withdrawal Record');
	$("#restore").attr('title', 'Restore Withdrawal Record');
	
	$("#edit").attr('disabled', true);
	$("#delete").attr('disabled', true);
	$("#restore").attr('disabled', true);

	function loadData(page,searchQuery)
	{
		initialize();
		if(init == "" || init == "Search...")
		{
			searchQuery = "";
		}
		
		else 
		{
			searchQuery = init;
		}
			
		$.ajax(
		{
			url:'/EBMS/apps/view/inventory/itemWithdrawal/withdrawalList.php', 
			type: "POST",
			data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
			success:
				function(response)
				{
					$("#loading").fadeTo("slow",0).hide();
					var arrResponse = response.split('&');
						
					setPageBtnValue(arrResponse[2],arrResponse[3]); 
						// alert('test');
					$('#withdrawalList').html(arrResponse[0]);
					datagrid('withdrawalList', true);
					setPageResponse(arrResponse[1]);
						
					$("#withdrawalList table tr").click(function()
					{
						// alert('haha');
						setCellContentValue($(this));
						withId = $(this).attr('a');	
						$("#edit").attr('withId', withId);
						$("#edit").attr('disabled', false);
					});
				}
		});
	}

	$(".page-nav li button").click(function()
	{										
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
	});
	
	function setCellContentValue(selector)
	{
		//remove all active classes in tr element
		$("#withdrawalList table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		
		$.post('/EBMS/apps/view/inventory/itemWithdrawal/withdrawalDetails.php', {withdrawCode:$(selector).attr('a')},
		function(response)
		{
			$('#withdrawalDetails').html(response);
			datagrid('withdrawalDetails', true);
		});
	}
	
//========================================================================WITHDRAW==========================================================================================
	
	//ONLOAD TYPE DEFAULT
	$.ajax({
		url:"/ebms/apps/view/modalForms/inventory/withdrawToList.php",
		type:"POST",
		data:"wType=Customer",
		success:
		function(response)
		{
			$("div#new_withdrawal #withdrawTo").html(response);
		}
	});
	
	def = $("div#new_withdrawal #withdrawTo")[0].selectedIndex = 0;
		
	//ONLOAD DEFAULT CUSTOMER
	dataString = "code=" + def + "&type=" + $("div#new_withdrawal #wType").val();
		
	// alert(dataString);
	$.ajax({
		url:"/ebms/apps/view/modalForms/inventory/cityList.php",
		type:"POST",
		data:dataString,
		success:
		function(response)
		{
			$("div#new_withdrawal #city").html(response);
		}
	});
	
	
	$("div#new_withdrawal #wType").change(function()
	{		
		if ($("div#new_withdrawal #wType").val() == "Employee" || $("div#new_withdrawal #wType").val() == "Supplier")
		{
			$("div#new_withdrawal #city").html("<option value=''>N/A</option>");
			$("div#new_withdrawal #barangay").html("<option value=''>N/A</option>");
			$("div#new_withdrawal #area").html("<option value=''>N/A</option>");
			$("div#new_withdrawal #location").html("<option value''>N/A</option>");
			$("div#new_withdrawal #address").val('');
		}
		else 
		{
			$("div#new_withdrawal #city").html("<option value=''></option>");
			$("div#new_withdrawal #barangay").html("<option value=''></option>");
			$("div#new_withdrawal #area").html("<option value=''></option>");			
			$("div#new_withdrawal #location").html("<option value''></option>");
			$("div#new_withdrawal #address").val('');
		}
		
		$.ajax({
		url:"/ebms/apps/view/modalForms/inventory/withdrawToList.php",
		type:"POST",
		data:"wType="+$("div#new_withdrawal #wType").val(),
		success:
		function(response)
		{
			$("div#new_withdrawal #withdrawTo").html(response);
		}
		});
	});
	
	$("div#new_withdrawal #withdrawTo").change(function()
	{	
		if ($("div#new_withdrawal #wType").val() == "Employee" || $("div#new_withdrawal #wType").val() == "Supplier")
		{
			$("div#new_withdrawal #city").html("<option value=''>N/A</option>");
			$("div#new_withdrawal #barangay").html("<option value=''>N/A</option>");
			$("div#new_withdrawal #area").html("<option value=''>N/A</option>");
			$("div#new_withdrawal #location").html("<option value''>N/A</option>");
			
			dataString = "code=" + $("div#new_withdrawal #withdrawTo").val() + "&type=" + $("div#new_withdrawal #wType").val();
			
			$.ajax({
				url:"/ebms/apps/view/modalForms/inventory/addressList.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					$("div#new_withdrawal #address").val(response);
				}
			});
		}
		else if ($("div#new_withdrawal #wType").val() == "Customer")
		{
			dataString = "code=" + $("div#new_withdrawal #withdrawTo").val() + "&type=" + $("div#new_withdrawal #wType").val();
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/locationList.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					$("div#new_withdrawal #location").html(response);
			
					$.ajax({
						url:"/ebms/apps/view/modalForms/inventory/cityList.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							$("div#new_withdrawal #city").html(response);
							
							$.ajax({
								url:"/ebms/apps/view/modalForms/inventory/addressList.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									$("div#new_withdrawal #address").val(response);
								}
							});
							
							$.ajax({
								url:"/ebms/apps/view/modalForms/inventory/barangayList.php",
								type:"POST",
								data:"cityId="+$("div#new_withdrawal #city").val(),
								success:
								function(response)
								{
									$("div#new_withdrawal #barangay").html(response);
								
									$.ajax({
										url:"/ebms/apps/view/modalForms/inventory/areaList.php",
										type:"POST",
										data:"barangayId=" + $("div#new_withdrawal #barangay").val(),
										success:
										function(response)
										{
											$("div#new_withdrawal #area").html(response);
										}
									});
								}
							});
						}
					});	
				}
			});		
		}
	});
	
	$("div#new_withdrawal #save").click(function()
	{
		if ($("div#new_withdrawal #wType").val() == "Customer")
		{
			if ($("div#new_withdrawal #city").val() == "")
			{
				alert('Please choose a customer to select a city.');
			}			
			else if ($("div#new_withdrawal #barangay").val() == "")
			{
				alert('Please choose a correct barangay.');
			}
			else if ($("div#new_withdrawal #area").val() == "")
			{
				alert('Please choose a correct area.');
			}
			else if ($("div#new_withdrawal #address").val() == "")
			{
				alert('Please input correct address.');
			}
			else
			{
				if ($("div#new_withdrawal div#formDataCont table tr").length == 1)
				{
					// alert($("div#new_withdrawal div#formDataCont table tr").length);
					alert('Please choose item(s) to withdraw.');
				}				
				else if ($("div#new_withdrawal div#formDataCont table tr").length > 1)
				{		
					insert();
				}
			}
		}
		else if ($("div#new_withdrawal #wType").val() == "Employee")
		{
			if ($("div#new_withdrawal #address").val() == "")
			{
				alert('Please input correct address.');
			}
			else
			{
				if ($("div#new_withdrawal div#formDataCont table tr").length == 1)
				{
					// alert($("div#new_withdrawal div#formDataCont table tr").length);
					alert('Please choose item(s) to withdraw.');
				}				
				else if ($("div#new_withdrawal div#formDataCont table tr").length > 1)
				{
					insert();
				}
			}
		}
		else if ($("div#new_withdrawal #wType").val() == "Supplier")
		{
			if ($("div#new_withdrawal #address").val() == "")
			{
				alert('Please input correct address.');
			}
			else
			{
				if ($("div#new_withdrawal div#formDataCont table tr").length == 0)
				{
					alert('Please choose item(s) to withdraw.');
				}				
				else if ($("div#new_withdrawal div#formDataCont table tr").length > 0)
				{
					insert();
				}
			}
		}
	});
	
	function insert()
	{
		var maySobra = ""; 
					
		var qtyArray = new Array();
		var stockArray = new Array();
		var itemCode = new Array();
		var desc = new Array();
		var i = 0;
	
		$("div#new_withdrawal #withdrawnItems tr").each(function(index)
		{
			// // alert($(this).find("#qty").val()+';'+$(this).text());
			// var withdrawArray = new Array();
			
			// withdrawArray[index] = $(this).find("#qty").val()+';'+$(this).text();
			
			// arrayUlit = withdrawArray[index].split(';');
			
			// var qty = arrayUlit[0];
			// var stock = arrayUlit[1];
			
			// qtyArray[i] = arrayUlit[0];
			// stockArray[i] = arrayUlit[1];
			// itemCode[i] = arrayUlit[3];
			// desc[i] = arrayUlit[4];
			
			// var stockInt = parseInt(stock);
			// alert($(this).find('#qty') + ' and ' + $(this).find('#stock'));
			if (parseInt($(this).find('#qty').val()) > parseInt($(this).find('#stock').text()))
			{
				maySobra = "true";						
			}							
			// qty = 0;
			// stock = 0;
			
			// i++;
		});
		
		if (maySobra == "true")
		{
										// for (j = 0; j < i; j++)
										// {
			alert('Quantity to withdraw is greater than the current stock.');
										// }
		}
		else if (maySobra == "")
		{
			dataString = "type=" + $("div#new_withdrawal #wType").val() +
					"&purpose=" + $("div#new_withdrawal #purpose").val() +
					"&remarks=" + $("div#new_withdrawal #remarks").val() +
					"&location=" + $("div#new_withdrawal #location").val() +
					"&issuedTo=" + $("div#new_withdrawal #withdrawTo").val();	
			// alert(dataString);
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/newWithdrawalHeaderRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{					
					$("div#new_withdrawal #withdrawnItems tr").each(function(index)
					{
						dataString = "qty=" + $(this).find('#qty').val() + "&itemCode=" + $(this).find('#itemCode').text() + "&desc=" + $(this).find('#itemDesc').text() + "&hdrId=" + response;
						
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/newWithdrawalDetailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response2)
							{
								// alert(response);
							}
						});
						
						dataString2 = "qty=" + $(this).find('#qty').val() + "&itemCode=" + $(this).find('#itemCode').text();
						
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/deductInventory.php",
							type:"POST",
							data:dataString2,
							success:
							function(response3)
							{
								// alert(response);
							}
						});
					});
				}
			});
			
			dataString = "role=" + "New" + "&noun=" + "Withdrawal record";
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
			
			alert("Record Created!");
			window.location.reload();
		}
	}	

	//==============================================================EDIT=========================================================================
	$("#edit").click(function()
	{
		if ($(this).attr('withId') != null)
		{
			// alert($(this).attr('withId'));
			var editWithId = $(this).attr('withId');
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/viewDate.php",
				type:"POST",
				data:"id=" + editWithId,
				success:
				function(response)
				{
					$("div#edit_withdrawal #stockWithdrawalDate").val(response);
					// alert(response);
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/viewWithdrawalCode.php",
				type:"POST",
				data:"id=" + editWithId,
				success:
				function(response)
				{
					$("div#edit_withdrawal #wNo").val(response);
					// alert(response);
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/viewType.php",
				type:"POST",
				data:"id=" + editWithId,
				success:
				function(response)
				{
					$("div#edit_withdrawal #wType").val(response);
					// alert(response);
					
					if ($("div#edit_withdrawal #wType").val() == "Employee" || $("div#edit_withdrawal #wType").val() == "Supplier")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/viewWithdrawTo.php",
							type:"POST",
							data:"id=" + editWithId,
							success:
							function(response)
							{
								$("div#edit_withdrawal #withdrawTo").val(response);
																
								$.ajax(
								{
									url:"/ebms/apps/view/modalForms/inventory/viewAddress.php",
									type:"POST",
									data:"id=" + editWithId,
									success:
									function(response)
									{
										$("div#edit_withdrawal #address").val(response);
									}
								});
							}
						});
					
						$("div#edit_withdrawal #location").val('N/A');
						$("div#edit_withdrawal #city").val('N/A');
						$("div#edit_withdrawal #barangay").val('N/A');
						$("div#edit_withdrawal #area").val('N/A');						
					}
					else if ($("div#edit_withdrawal #wType").val() == "Customer")
					{
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/viewWithdrawTo.php",
							type:"POST",
							data:"id=" + editWithId,
							success:
							function(response)
							{
								$("div#edit_withdrawal #withdrawTo").val(response);
								
								$.ajax(
								{
									url:"/ebms/apps/view/modalForms/inventory/viewLocation.php",
									type:"POST",
									data:"id=" + editWithId,
									success:
									function(response)
									{
										$("div#edit_withdrawal #location").val(response);
										
										$.ajax(
										{
											url:"/ebms/apps/view/modalForms/inventory/viewCity.php",
											type:"POST",
											data:"id=" + editWithId,
											success:
											function(response)
											{
												$("div#edit_withdrawal #city").val(response);
												
												$.ajax(
												{
													url:"/ebms/apps/view/modalForms/inventory/viewBarangay.php",
													type:"POST",
													data:"id=" + editWithId,
													success:
													function(response)
													{
														$("div#edit_withdrawal #barangay").val(response);
														
														$.ajax(
														{
															url:"/ebms/apps/view/modalForms/inventory/viewArea.php",
															type:"POST",
															data:"id=" + editWithId,
															success:
															function(response)
															{
																$("div#edit_withdrawal #area").val(response);
																
																$.ajax(
																{
																	url:"/ebms/apps/view/modalForms/inventory/viewAddress.php",
																	type:"POST",
																	data:"id=" + editWithId,
																	success:
																	function(response)
																	{
																		$("div#edit_withdrawal #address").val(response);
																	}
																});
															}
														});
													}
												});
											}
										});
									}
								});
							}
						});
					}
				}
			});
			
			$.ajax(
			{	
				url:"/ebms/apps/view/modalForms/inventory/viewRemarks.php",
				type:"POST",
				data:"id=" + editWithId,
				success:
				function(response)
				{
					$("div#edit_withdrawal #remarks").val(response);
				}
			});
			
			$.ajax(
			{	
				url:"/ebms/apps/view/modalForms/inventory/viewPurpose.php",
				type:"POST",
				data:"id=" + editWithId,
				success:
				function(response)
				{
					// alert(response);
					$("div#edit_withdrawal #purpose").val(response);
				}
			});
		}	
	
		$("div#edit_withdrawal #save").click(function()
		{
			// alert(editWithId);
			$.ajax(
			{	
				url:"/ebms/apps/view/modalForms/inventory/editWithdrawalHeaderRecord.php",
				type:"POST",
				data:"id=" + editWithId + "&purpose=" + $("div#edit_withdrawal #purpose").val(),
				success:
				function(response)
				{
					// alert(response);
					// $("div#edit_withdrawal #purpose").val(response);
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
				type:"POST",
				data:"module=" + "Withdrawal" + "&id=" + editWithId,
				success:
				function(response)
				{
					dataString = "role=" + "Edit" + "&noun=" + "Withdrawal record" + "&code=" + response;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
							
						}
					});
				}
			});
			
			alert("Record Edited!");
			window.location.reload();
			
			// $("div#edit_withdrawal .formClose").click();
						
			// $('#withdrawalList').load('../../../controller/itemWithdrawal/itemWithdrawalController.php');
		});			
	});
	
</script>