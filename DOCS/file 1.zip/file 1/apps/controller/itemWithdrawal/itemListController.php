<script>
		$(document).ready(function(){
		$("div#new_OS button#save").click(function()
		{
			alert("okay");
			
		});
		
		inputMask("formDataContSearch","Search");
		
		itemList("asset","");
		
		$("#formDataContSearch").keyup(function(){
			 itemList("asset",$(this).val().trim());
			});		
		
		var ctr = 0;
		function itemList(type,q)
		{ctr++;
			var dataString = "itemType="+type+"&q="+q;
			
			$.ajax({
			url:"/ebms/apps/view/modalForms/inventory/assetList.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
				$("div[ref=itemList] ul").html(response); 
				
				$("div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function(){
					
					$(this).trigger("click");
					return false;
					
				});
				
				var code = "", desc = "";
				$("div#new_withdrawal div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						code = $(this).attr("code");
						desc = $(this).attr("desc");
						
						if($("div#new_withdrawal #withdrawnItems").find("tr[code="+code+"] td").size() > 0)
						{
						
						$("div#new_withdrawal #withdrawnItems tr td").removeClass("itemActive");
						$("div#new_withdrawal #withdrawnItems").find("tr[code="+code+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("div.itemDetails").stop().animate({bottom:"10px",opacity:0.8},"1000").show();
						
						
						},function(){
						
						if($("div#new_withdrawal #withdrawnItems").find("tr[code="+code+"] td").size() > 0)
						$("div#new_withdrawal #withdrawnItems").find("tr[code="+code+"] td").removeClass("itemActive");
						
						$("div#new_withdrawal div.itemDetails").stop().animate({bottom:"0px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
				
				$("div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function()
				{					
					// alert('haha');
					$(this).find(".addItem").hide();
					$(this).find(".removeItem").hide();
					$(this).find(".selectedItem").show();
					
					if($(this).find(".addItem").css("display") == "none")
					{
						var code = $(this).attr("code");
						var unitPrice = $(this).attr("unitPrice");
						var desc = $(this).attr("desc");
						var stockOnHand = $(this).attr("stockOnHand");
					
						$("div#new_withdrawal table[ref = 'withdraw'] tbody#withdrawnItems").append("<tr code='"+code+"'><td><input type='number' id='qty' value=1></td><td id='stock'>"+stockOnHand+"</td><td>"+unitPrice+"</td><td id='itemCode'>"+code+"</td><td id='itemDesc'>"+desc+"</td></tr>");
						
						$("div#new_withdrawal table[ref = 'withdraw'] tbody#withdrawnItems").find("tr[code='"+code+"'] input").bind("keyup input",function(){
							if($(this).val() == "0")
							{
								$(this).val(1);
							}								
						});
					}
					
					$("div#new_withdrawal #qty").bind("keypress", function(e) 
					{ 
						// alert('haha');
						return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
					});
					
					$(this).hover(function()
					{					
						if($(this).find(".addItem").css("display") != "block")
						{
							$(this).find(".addItem").hide();
							$(this).find(".removeItem").show();
							$(this).find(".selectedItem").hide();
						}
						
						else
						{
							$(this).find(".addItem").show();
							$(this).find(".removeItem").hide();
							$(this).find(".selectedItem").hide();
						}					
					},
					function()
					{					
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						}
						
						else
						{
							$(this).find(".addItem").show();
							$(this).find(".removeItem").hide();
							$(this).find(".selectedItem").hide();
						}					
					});
						
				return false;	
				},
				function()
				{
				var code = $(this).attr("code");
					$("div#new_withdrawal table[ref = 'withdraw'] tbody#withdrawnItems").find("tr[code="+code+"]").fadeOut("slow",
						function()
						{
							$("div#new_withdrawal table[ref = 'withdraw'] tbody#withdrawnItems").find("tr[code="+code+"]").remove();
						});
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						
				});
				
				if(ctr > 1)
				{
					var arr1 = new Array(),arr2 = new Array();
					$("div#new_withdrawal div[ref=itemList] ul li a").each(function(index){

					var itemListCode = $(this).attr("code");
					arr1[index] = itemListCode;

				});	

				$("div#new_withdrawal #withdrawnItems tr").each(function(index)
				{
					var requestedItemsCode = $(this).attr("code");
					arr2[index] = requestedItemsCode;
				});

				for(i=0;i<arr1.length;i++)
				{
					for(x=0;x<arr2.length;x++)
					if(arr1[i] == arr2[x])
					{
						$("div#new_withdrawal div[ref=itemList] ul li a[code='"+arr1[i]+"']").click();
						$("div#new_withdrawal #withdrawnItems").find("tr[code="+arr1[i]+"]:last-child").remove();
					}
				}
				}
				
			}
		});
		}
		
		});
</script>
