<?php
session_start();
include("../../../config/config.php");

$caID = $_POST['caID'];

mysql_query("UPDATE employee_cash_advance SET is_deleted = '1' WHERE EMP_CASH_ID='".$caID."'");
?>