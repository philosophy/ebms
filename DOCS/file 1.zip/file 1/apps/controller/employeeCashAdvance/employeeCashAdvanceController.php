<script>

var init,page;

var searchQuery="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	$("#new").attr('title', 'New Cash Advance Record');
	$('#edit').attr('title', 'Edit Cash Advance Record');
	$('div.datagrid-crud-menu #delete').attr('title', 'Delete Cash Advance Record');
	$('div.datagrid-crud-menu #restore').attr('title', 'Restore Cash Advance Record');
	
	$('#edit').attr('disabled',true);
	$('div.datagrid-crud-menu #delete').attr('disabled',true);
	$('div.datagrid-crud-menu #restore').attr('disabled',true);
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	$.ajax({
		url:'/EBMS/apps/view/personnel/employeeCashAdvance/caList.php', 
		type: "POST",
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]);
				
			$('#cash-advance').html(arrResponse[0]);
			datagrid('cash-advance', true);
			setPageResponse(arrResponse[1]);
				
			$("#cash-advance table tr").click(function()
			{
			$('#itemDetails').html("");
					
			setCellContentValue($(this));
						
			});
			
			}
			});
}
	
	$.ajax({
		url:"/ebms/apps/view/personnel/employeeCashAdvance/empList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
				$("div#new_cashAdvance #empName").html(response);
			}
			
	});
	
	function acctName()
	{
		$.ajax({
			url:"/ebms/apps/view/personnel/employeeCashAdvance/accountList.php",
			type:"POST",
		
			cache:false,
			success:
				function(response)
				{
					$("div#new_cashAdvance #acctName").html(response);
					bank();
				}
			
		});
	}
	
	function bank()
	{
		var acctID = $("div#new_cashAdvance #acctName").val();
		$.ajax({
			url:"/ebms/apps/view/personnel/employeeCashAdvance/bankList.php",
			type:"POST",
			data: "acctID="+acctID,
			cache:false,
			success:
			function(response)
			{
				$("div#new_cashAdvance #bankName").html(response);
			}
			
		});
		
		$.ajax({
			url:"/ebms/apps/view/personnel/employeeCashAdvance/acctNoList.php",
			type:"POST",
			data: "acctID="+acctID,
			cache:false,
			success:
			function(response)
			{
				$("div#new_cashAdvance #acctNo").html(response);
			}
			
		});
	}
	
	$("div#new_cashAdvance #paymentAmount").bind("keyup input", function(){
		if($(this).val() == "")
		{
			$(this).val(1);
		}
		else if($(this).val() < 1)
		{
			$(this).val(1);
		}
	});
	
	$("div#edit_cashAdvance #paymentAmount").bind("keyup input", function(){
		if($(this).val() == "")
		{
			$(this).val(1);
		}
		else if($(this).val() < 1)
		{
			$(this).val(1);
		}
	});
	
	$('#new').click(function(){
		
		$("div#new_cashAdvance #paymentType").val("CASH");
		$("div#new_cashAdvance #empName").val("1");
		$("div#new_cashAdvance #paymentAmount").val("1");
		formReset();
	});
	
	function formReset()
	{
		$("div#new_cashAdvance #acctName").attr("disabled", true);
		$("div#new_cashAdvance #checkNo").attr("disabled", true);
		$("div#new_cashAdvance #checkType").attr("disabled", true);
		$("div#new_cashAdvance #checkInOut").attr("disabled", true);
		$("div#new_cashAdvance #checkDateIssue").attr("disabled", true);
		$("div#new_cashAdvance #checkDueDate").attr("disabled", true);
		$("div#new_cashAdvance #bankName").html("");
		$("div#new_cashAdvance #acctNo").html("");
		$("div#new_cashAdvance #acctName").html("");
		$("div#new_cashAdvance #checkType").html("");
		$("div#new_cashAdvance #checkInOut").html("");
		$("div#new_cashAdvance #checkNo").val("");
		$("div#new_cashAdvance #checkDateIssue").val("");
		$("div#new_cashAdvance #checkDueDate").val("");
		$("div#new_cashAdvance #remarks").val("");
	}
	
	$("div#new_cashAdvance #acctName").change(function(){
		bank();
	});
		
	$("div#new_cashAdvance #paymentType").change(function(){
		
		if ($(this).val() == "CASH")
		{
			$("div#new_cashAdvance #acctName").attr("disabled", true);
			$("div#new_cashAdvance #checkNo").attr("disabled", true);
			$("div#new_cashAdvance #checkType").attr("disabled", true);
			$("div#new_cashAdvance #checkInOut").attr("disabled", true);
			$("div#new_cashAdvance #checkDateIssue").attr("disabled", true);
			$("div#new_cashAdvance #checkDueDate").attr("disabled", true);
			$("div#new_cashAdvance #bankName").html("");
			$("div#new_cashAdvance #acctNo").html("");
			$("div#new_cashAdvance #acctName").html("");
			$("div#new_cashAdvance #checkType").html("");
			$("div#new_cashAdvance #checkInOut").html("");
		}
		else if($(this).val() == "CHECK")
		{
			acctName();
			$("div#new_cashAdvance #acctName").attr("disabled", false);
			$("div#new_cashAdvance #checkNo").attr("disabled", false);
			$("div#new_cashAdvance #checkType").attr("disabled", false);
			$("div#new_cashAdvance #checkInOut").attr("disabled", false);
			$("div#new_cashAdvance #checkDateIssue").attr("disabled", false);
			$("div#new_cashAdvance #checkDueDate").attr("disabled", false);
			
			$("div#new_cashAdvance #checkType").html("<option value='Post-Dated'>Post-Dated</option><option value='On-Dated'>On-Dated</option>");
			$("div#new_cashAdvance #checkInOut").html("<option value='Check-Out'>Check-Out</option><option value='Check-In'>Check-In</option>");
		}
	});
	
	$("div#new_cashAdvance #save").click(function(){
		
		if ($("div#new_cashAdvance #checkNo").val() == "" && $("div#new_cashAdvance #paymentType").val() == "CHECK")
		{
			alert("Please input a Check Number.");
		}
		else if ($("div#new_cashAdvance #checkDateIssue").val() == "" && $("div#new_cashAdvance #paymentType").val() == "CHECK")
		{
			alert("Please select a date for Check Issue Date.");
		}
		else if ($("div#new_cashAdvance #checkDueDate").val() == "" && $("div#new_cashAdvance #paymentType").val() == "CHECK")
		{
			alert("Please select a date for Check Due Date.");
		}
		else
		{
		
			var empID = $("div#new_cashAdvance #empName").val();
			var remarks = $("div#new_cashAdvance #remarks").val();
			var payType = $("div#new_cashAdvance #paymentType").val();
			var payAmt = $("div#new_cashAdvance #paymentAmount").val();
			var bankID = $("div#new_cashAdvance #bankName").val();
			var acctNo = $("div#new_cashAdvance #acctNo").val();
			var checkType = $("div#new_cashAdvance #checkType").val();
			var checkInOut = $("div#new_cashAdvance #checkInOut").val();
			var checkDateIssue = $("div#new_cashAdvance #checkDateIssue").val();
			var checkDueDate = $("div#new_cashAdvance #checkDueDate").val();
			var checkNo = $("div#new_cashAdvance #checkNo").val();
			var acctName = $("div#new_cashAdvance #acctName").val();
		
			$.ajax({
				url:"/ebms/apps/view/personnel/employeeCashAdvance/insertCashAdvance.php",
				type:"POST",
				data: "empID="+empID+"&remarks="+remarks+"&payType="+payType+"&payAmt="+payAmt+"&bankID="+bankID+"&acctNo="+acctNo+"&checkType="+checkType+"&checkInOut="+checkInOut+"&checkDateIssue="+checkDateIssue+"&checkDueDate="+checkDueDate+"&checkNo="+checkNo+"&acctName="+acctName,
				cache:false,
				success:
				function(response)
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "New Cash Advance" + "&id=" + empID,
						success:
						function(response)
						{
							dataString = "role=" + "New Cash Advance" + "&noun=" + "Cash advance record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									
								}
							});
						}
					});
				
					alert("Employee Cash Advance successfully created!");
					loadData(1,searchQuery);
					$("div#new_cashAdvance.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#new_cashAdvance.modalForm").hide();
					});
				}
			
			});
		}
	});
	
	$("div#edit_cashAdvance #save").click(function(){

		var remarks = $("div#edit_cashAdvance #remarks").val();
		var payAmt = $("div#edit_cashAdvance #paymentAmount").val();
		var payType = $("div#edit_cashAdvance #paymentType").val();
		var id = $('#edit').attr('caID');
		
			$.ajax({
				url:"/ebms/apps/view/personnel/employeeCashAdvance/editCashAdvance.php",
				type:"POST",
				data: "remarks="+remarks+"&payAmt="+payAmt+"&payType="+payType+"&id="+id,
				cache:false,
				success:
				function(response)
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Edit Cash Advance" + "&id=" + id,
						success:
						function(response)
						{
							dataString = "role=" + "Edit Cash Advance" + "&noun=" + "Cash advance record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									
								}
							});
						}
					});
				
					// alert(response);
					alert("Employee Cash Advance successfully updated!");
					loadData(1,searchQuery);
					$("div#edit_cashAdvance.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#edit_cashAdvance.modalForm").hide();
					});
				}
			
			});
	});
	
	function setCellContentValue(selector)
	{
		//remove all active classes in tr element
		$("#cash-advance table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		$("#edit").attr("caID",$(selector).attr("a"));
		$("#delete_cashAdvance #delete").attr("caID",$(selector).attr("a"));
		$("#restore_cashAdvance #restore").attr("caID",$(selector).attr("a"));
		//$("#edit_po #orderedItems tr").attr("")
		
		if ($(selector).attr("deleted") == "false")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",false);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
		}
		else if ($(selector).attr("deleted") == "true")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",false);
		}
		
		if ($(selector).find("img").attr("src") == "/EBMS/images/icons/checkIcon.png")
		{
			$("#edit").attr("disabled",true);
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
		}
		else
		{
			$("#edit").attr("disabled",false);
		}
		
		$('img.pr_approve').click(function()
		{
			$.post('../../../controller/employeeCashAdvance/caApprove.php',{caID: $(this).attr('a')});
			$(this).fadeOut('slow', function()
			{
				$(this).replaceWith("<img class='approved' src='/EBMS/images/icons/checkIcon.png'>");
			});
			loadData(1,searchQuery);
			return false;
		});
		
		
		$('#delete_cashAdvance #delete').click(function()
		{
			id = $(this).attr('caID');
			$.post('../../../controller/employeeCashAdvance/caDelete.php',{caID:$(this).attr('caID')},
				function()
				{	
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Delete Cash Advance" + "&id=" + id,
						success:
						function(response)
						{
							dataString = "role=" + "Delete Cash Advance" + "&noun=" + "Cash advance record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									
								}
							});
						}
					});
				
					$("div#delete_cashAdvance.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#delete_cashAdvance.modalForm").hide();
					});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#restore_cashAdvance #restore').click(function()
		{
			id = $(this).attr('caID');
			$.post('../../../controller/employeeCashAdvance/caRestore.php',{caID:$(this).attr('caID')},
				function()
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Restore Cash Advance" + "&id=" + id,
						success:
						function(response)
						{
							dataString = "role=" + "Restore Cash Advance" + "&noun=" + "Cash advance record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
									
								}
							});
						}
					});
				
					$("div#restore_cashAdvance.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
						$("div#restore_cashAdvance.modalForm").hide();
					});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#edit').click(function()
			{$.post('../../personnel/employeeCashAdvance/caFill.php',{caID:$(this).attr('caID')},function(response){ 
						
				obj = JSON.parse(response);
					
				$("div#edit_cashAdvance #voucherNo").val(obj.ca["code"]);
				$("div#edit_cashAdvance #empName").val(obj.ca["empName"]);
				$("div#edit_cashAdvance #remarks").val(obj.ca["remarks"]);
				$("div#edit_cashAdvance #paymentType").val(obj.ca["payType"]);
				$("div#edit_cashAdvance #paymentAmount").val(obj.ca["payAmount"]);
				$("div#edit_cashAdvance #editCashAdvDate").val(obj.ca["date"]);
		
				$("div#edit_cashAdvance #bankName").val(obj.check["bankName"]);
				$("div#edit_cashAdvance #acctNo").val(obj.check["acctNo"]);
				$("div#edit_cashAdvance #checkType").val(obj.check["checkType"]);
				$("div#edit_cashAdvance #editCheckDateIssue").val(obj.check["issueDate"]);
				$("div#edit_cashAdvance #editCheckDueDate").val(obj.check["dueDate"]);
				$("div#edit_cashAdvance #checkNo").val(obj.check["code"]);
				$("div#edit_cashAdvance #acctName").val(obj.check["acctName"]);
					
				if (obj.ca["payType"] == "CHECK")
				{
					$("div#edit_cashAdvance #checkInOut").val("Check-Out");
				}
				else
				{
					$("div#edit_cashAdvance #checkInOut").val("");
				}
			});
		});
		
		/*
		$.post('/EBMS/apps/view/purchasing/purchaseOrder/poDetails.php', {poCode:$(selector).attr('a')},
		function(response)
		{
			$('#itemDetails').html(response);
			datagrid('itemDetails', true);
		});*/
		
		
	}

</script>