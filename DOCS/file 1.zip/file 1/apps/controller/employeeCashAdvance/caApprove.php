<?php
session_start();
include("../../../config/config.php");

$caID = $_POST['caID'];


mysql_query("UPDATE employee_cash_advance SET EMP_CASH_APPROVED_BY_ID = '".$_SESSION['login']."' WHERE EMP_CASH_ID ='".$caID."'");

mysql_query("UPDATE employee_cash_advance SET EMP_CASH_STATUS = 'APPROVED' WHERE EMP_CASH_ID ='".$caID."'");


?>