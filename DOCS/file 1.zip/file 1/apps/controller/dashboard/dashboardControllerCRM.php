<!--Customer Type-->
<script type="text/javascript">
		 $(document).ready(function() {
        $.jqplot.config.enablePlugins = false;
 
		
		var dailyCustType = new Array();
		var dataArr = new Array();
		var monthlyCustType = new Array();
		var dailyCustStat = new Array();
		var dailyCustInd = new Array();
		var dailyCustArea = new Array();
		var monthlyCustArea = new Array();
		var monthlyCustInd = new Array();
		var monthlyCustStat = new Array();
		var parameter=$(".period-option .optionActive").text().toLowerCase();
		var href;
		var plot1,plot2,plot3,plot4;
		
			var dateFrom = $("#daily_datepicker #dayFrom").val();
			var dateTo = $("#daily_datepicker #dayTo").val();
			
		var dataString = "dateFrom="+dateFrom+"&dateTo="+dateTo;
		
			
		customerType();
		customerStat();
		industryType();
		customerArea();
		
		
		$("#graph-tabs ul.graph-nav li a,#monthly_datepicker #go,#daily_datepicker #go").click(function(){
		
		parameter=$(".period-option .optionActive").text().toLowerCase();
		
		dateFrom = $("#"+parameter+"_datepicker #"+((parameter=="daily")?"day":"month")+"From").val();
		dateTo = $("#"+parameter+"_datepicker #"+((parameter=="daily")?"day":"month")+"To").val();
		dataString = "dateFrom="+dateFrom+"&dateTo="+dateTo;
				
		customerType();
		customerStat();
		industryType();
		customerArea();
		});
		
		$(".period-option a").click(function(){
		parameter = $(".period-option .optionActive").text().toLowerCase();
		href = $("#graph-tabs ul.graph-nav li a.tabOnDisplay").attr("href").toLowerCase();
		
		if(href == "#customer-type")
		{
		customerType();
		}
		
		else if(href == "#customer-stat")
		customerStat();
		
		else if(href == "#industry-type")
		industryType();
		
		else if(href == "#customer-area")
		customerArea();
		
		});
		
		//customer types
		function customerType()
		{
		$.ajax({
			url:"../../view/dashboard/"+parameter+"CustType.php",
			type:"POST",
			data:dataString,
			success:
				function(response)
				{
				if(response === "Nothing")
					dataArr = [['No Records Found from any Months of this Year.<br/>Please select Month range from different year',0]];
				
				else
				{
				obj = JSON.parse(response);
				
				dailyCustType = [];
				monthlyCustType = [];
				
				for(i=0;i<obj.data.length;i++)
					{
						if(parameter == "daily")
						{
						dailyCustType[i] = obj.data[i];	
						}
						
						else if(parameter == "monthly")
						{
						monthlyCustType[i] = obj.data[i];	
						}
					}
					dataArr = [];
					if(parameter == "daily")
						dataArr = dailyCustType;
					else if(parameter == "monthly")
						dataArr = monthlyCustType;
				}
				
				
				plot1 = $.jqplot('customer-type', [dataArr], {
				title: "Pie Chart for Customer Types",
				seriesColors: ["#FF4D4D","#06f","#5CAD5C"],
				seriesDefaults: {
				renderer: jQuery.jqplot.PieRenderer, 
				rendererOptions: 
					{
					sliceMargin: 1,
					showDataLabels: true
					}
				},
				legend:
					{
					show:true
					},
				grid:
					{
					background:"#F0FAFF"
					}		
				});
				
				
				plot1.redraw();
				}
		});
		}
		
		//customer status
		function customerStat()
		{
		$.ajax({
			url:"../../view/dashboard/"+parameter+"CustStat.php",
			type:"POST",
			data:dataString,
			success:
				function(response)
				{
				obj = JSON.parse(response);
				dailyCustStat = [];
				monthlyCustStat = [];
				for(i=0;i<obj.data.length;i++)
					{
						if(parameter == "daily")
						{
						dailyCustStat[i] = obj.data[i];	
						}
						
						else if(parameter == "monthly")
						{
						monthlyCustStat[i] = obj.data[i];	
						}
					}
					dataArr = [];
					if(parameter == "daily")
						dataArr = dailyCustStat;
					else if(parameter == "monthly")
						dataArr = monthlyCustStat;
				
				plot2 = $.jqplot('customer-stat', [dataArr], {
				seriesDefaults: {
				renderer: jQuery.jqplot.PieRenderer, 
				rendererOptions: {
				sliceMargin: 1,
				showDataLabels: true
				}
				},
				title: "Active & Inactive Customers",
				seriesColors: ["#06f","#FF4D4D"],
				legend:{show:true},
				grid:{background:"#F0FAFF"}
				});
				
				plot2.redraw();
				}
		});
		
		}
		
		//industry type
		function industryType()
		{
		$.ajax({
			url:"../../view/dashboard/"+parameter+"CustInd.php",
			type:"POST",
			data:dataString,
			success:
				function(response)
				{
				obj = JSON.parse(response);
				dailyCustInd = [];
				monthlyCustInd = [];
				for(i=0;i<obj.data.length;i++)
					{
						if(parameter == "daily")
						dailyCustInd[i] = obj.data[i];

						else if(parameter == "monthly")
						monthlyCustInd[i] = obj.data[i];						
					}
					dataArr = [];
					if(parameter == "daily")
						dataArr = dailyCustInd;
					else if(parameter == "monthly")
						dataArr = monthlyCustInd;
				
		
				plot3 = $.jqplot('industry-type', [dataArr], {
				seriesDefaults: {
				renderer: jQuery.jqplot.PieRenderer, 
				rendererOptions: {
				sliceMargin: 1,
				showDataLabels: true
				}
				},
				title: "Customer Industry Type Chart",
				seriesColors: ["#003366","#6cf","#3399FF","#36c","#0099CC"],
				legend:{show:true},
				grid:{background:"#F0FAFF"}
				});
				
				plot3.redraw();
				}
		});
		}

		
		//customer per area
		function customerArea()
		{
		$.ajax({
			url:"../../view/dashboard/"+parameter+"CustArea.php",
			type:"POST",
			data:dataString,
			success:
				function(response)
				{
				obj = JSON.parse(response);
				dailyCustArea = [];
				monthlyCustArea = [];
				for(i=0;i<obj.data.length;i++)
					{
					
						if(parameter == "daily")
						dailyCustArea[i] = obj.data[i];	
						
						else if(parameter == "monthly")
						monthlyCustArea[i] = obj.data[i];	
					
					}
					dataArr = [];
					if(parameter == "daily")
						dataArr = dailyCustArea;
					else if(parameter == "monthly")
						dataArr = monthlyCustArea;			
		
				plot4 = $.jqplot('customer-area', [dataArr], {
				seriesDefaults: {
				renderer: jQuery.jqplot.PieRenderer, 
				rendererOptions: {
				sliceMargin: 1,
				showDataLabels: true
				}
				},
				title: "Customer Per Area",
				seriesColors: ["#99CC00","#5C7A00","#374900","#FFFF4D","#FFFF99","#A3CC7A","#99FF66","#FFFF4D","#99FF66"],
				legend:
					{
					renderer: $.jqplot.EnhancedLegendRenderer,
					show:true,
					rendererOptions:{numberRows:6}
					},
				grid:{background:"#F0FAFF"}
				});
    
				plot4.redraw();
				}
		});
		}
		
	
	});
</script>