<?php 
//controller for Sales Report

?>
<script>
$(document).ready(function(){
    
	$(".jqplot-table-legend").css({"color":"red"},{"background":"red"});
     
	$.jqplot.config.enablePlugins = false;
	    var dailyForecast = new Array();
		var monthlyForecast = new Array();
		var weeklyForecast = new Array();
		
	var arr = new Array();
	var graphTitle = "Sales Forecast";
	var currentTime = new Date();
	var month = currentTime.getMonth() + 1;
	var year = currentTime.getFullYear();
	var parameter = "Daily";
	var plot1,plot2,plot3;
	
	var numDays = new Date(year, month, 0).getDate();
	
	var dateFrom = year+"-"+month+"-"+"01";
	var dateTo = year+"-"+month+"-"+numDays;
	
	
	var dataString = "dateFrom="+dateFrom+"&dateTo="+dateTo;
	
	postGraphData();
	
	function getActivePeriodParam()
	{
		parameter = $(".period-option .optionActive").text();	
		
		if(parameter == "Daily")
		{
		$("div[ref='graphPlot']").hide();
		$("div#dailyForecast").show();
		$("#daily_datepicker button#go").click(function(){
			dateFrom = $("#dayFrom").val();
			dateTo = $("#dayTo").val();
		dataString = "dateFrom="+dateFrom+"&dateTo="+dateTo;
		postGraphData();
		});
		postGraphData();
		}
		
		
		else if(parameter == "Monthly")
		{
		var monthFrom="",monthTo="";
		$("div[ref='graphPlot']").hide();
		$("div#monthlyForecast").show();
		$("#monthly_datepicker button#go").click(function(){
			monthFrom = $("#monthFrom").val();
			monthTo = $("#monthTo").val();
		dataString = "dateFrom="+monthFrom+"&dateTo="+monthTo;
		postGraphData();
		});
		postGraphData();
		}
		
		
		else if(parameter == "Weekly")
		{
		$("div[ref='graphPlot']").hide();
		$("div#weeklyForecast").show();
		
		var weekFrom = 1 , weekTo = 4;
		
		function getWeekVal()
			{
		
				if($("#weekFrom").attr("weekFromNo"))
				weekFrom = $("#weekFrom").attr("weekFromNo").trim();
				
				if($("#weekTo").attr("weekToNo"))
				weekTo = $("#weekTo").attr("weekToNo").trim();
				
			}
		getWeekVal();	
		dataString = "weekFrom="+weekFrom+"&weekTo="+weekTo+"&diff="+(weekTo-weekFrom);
		$(".ui-datepicker-calendar").hide();
		$("#weekly_datepicker #go").click(function(){
			getWeekVal();	
			dataString = "weekFrom="+weekFrom+"&weekTo="+weekTo+"&diff="+(weekTo-weekFrom);
			postGraphData();
		});
		postGraphData();
		}
		
	}
			
		
	$(".period-option a").click(getActivePeriodParam);
	
		getActivePeriodParam();
		
	function postGraphData()
	{
	
	parameter = $(".period-option .optionActive").text().toLowerCase();
		
	$.ajax({
		url:"../../view/dashboard/"+parameter+"Forecast.php",
		type:"POST",
		data:dataString,
		success:
		function(response)
		{
		var dataArr = response.split("&&");
		var obj;
		
		if(dataArr[0] == "exceed")
			alert("Resource too many. Limit your parameters and try again");
        else if(dataArr[0] == "part")
		    {
					dailyForecast = ["0",0];
					monthlyForecast = ["0",0];
					$("#dayFrom").attr("disabled",true);
					$("#dayTo").attr("disabled",true);
					graphPlot("cannot");
					
			}
		        else if(dataArr[0] == "part1")
		    {
					monthlyForecast = ["0",0];
					$("#dayFrom").attr("disabled",true);
					$("#dayTo").attr("disabled",true);
					graphPlot("cannot1");
					
			}
		else
			{
			dailyForecast = [];
			weeklyForecast = [];
			monthlyForecast = [];
			
				obj = JSON.parse(dataArr[0]);
				
					for(i=0;i<obj.data.length;i++)
					{
						if(dataArr[1]=="daily")
						{
						dailyForecast[i] = obj.data[i];
						}
						
						else if(dataArr[1]=="monthly")
						{
						monthlyForecast[i] = obj.data[i];
						}	


						else if(dataArr[1]=="weekly")
						{
						weeklyForecast[i] = obj.data[i];
						}							
						
					}
				graphPlot(dataArr[1]);	
			}
		}
		});
	}
	
	function graphPlot(period)
	{
	if(period == "cannot")
		{
		plot1 = $.jqplot('dailyForecast', [dailyForecast], {
		title:"Daily "+graphTitle,
		legend: {
		renderer: $.jqplot.EnhancedLegendRenderer,
        show: true,
		labels:['Not Enough Previous Record/s, cannot calculate Sales Projection'],
        location: 'nw',
        xoffset: 1,
        yoffset: 12,
		},
	   seriesColors: ["red","red"],
	   series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#99CCFF" }
        },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
         },
      ],
      axes:{
        xaxis:{
		  renderer: $.jqplot.DateAxisRenderer,
	      label: 'Day',
		  padMin:1.5,
		  min:dateFrom,
		  max:dateTo,
		  tickInterval: '1 Days',
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
	      tickOptions: {
          angle: -45,
		  fontSize:'8pt'
	      }
        },
        yaxis:{
		label:"Sales Amount (Php)",
          tickOptions:{
            formatString:'%.2f'
            },
		  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
        }
      },
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  }
  if(period == "cannot1")
		{
		plot1 = $.jqplot('monthlyForecast', [monthlyForecast], {
		title:"Monthly "+graphTitle,
		legend: {
		renderer: $.jqplot.EnhancedLegendRenderer,
        show: true,
		labels:['Not Enough Previous Record/s, cannot calculate Sales Projection'],
        location: 'nw',
        xoffset: 1,
        yoffset: 12,
		},
	   seriesColors: ["red","red"],
	   series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#99CCFF" }
        },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
         },
      ],
      axes:{
        xaxis:{
		  renderer: $.jqplot.DateAxisRenderer,
	      label: 'Day',
		  padMin:1.5,
		  min:dateFrom,
		  max:dateTo,
		  tickInterval: '1 Days',
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
	      tickOptions: {
          angle: -45,
		  fontSize:'8pt'
	      }
        },
        yaxis:{
		label:"Sales Amount (Php)",
          tickOptions:{
            formatString:'%.2f'
            },
		  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
        }
      },
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  }
		if(period == "daily")
		{
		plot1 = $.jqplot('dailyForecast', [dailyForecast], {
		title:"Daily "+graphTitle,
		legend: {
        show: true,
		labels:['Forecasted Sales'],
        location: 'nw',
        xoffset: 1,
        yoffset: 12,
		},
	   seriesColors: ["#3366FF","#3366FF"],
	   series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#99CCFF" }
        },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
         },
      ],
      axes:{
        xaxis:{
		  renderer: $.jqplot.DateAxisRenderer,
	      label: 'Day',
		  padMin:1.5,
		  min:dateFrom,
		  max:dateTo,
		  tickInterval: '1 Days',
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
	      tickOptions: {
          angle: -45,
		  fontSize:'8pt'
	      }
        },
        yaxis:{
		label:"Sales Amount (Php)",
          tickOptions:{
            formatString:'%.2f'
            },
		  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
        }
      },
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  plot1.redraw();
  }
		else if(period == "weekly")
		{
  
  plot2 = $.jqplot('weeklyForecast',  [weeklyForecast],
  { title:"Weekly "+graphTitle,
    legend: {
        show: true,
		labels:['Forecasted Sales'],
        location: 'nw',
        xoffset: 1,
        yoffset: 12,
		},
    axes:{
		xaxis:
			{
			renderer:$.jqplot.CategoryAxisRenderer,
			padMin:1.5,
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
			tickOptions: {
				angle: -45,
				fontSize:'8pt'
				}
			},
		yaxis:
			{
			min:0.00
			}
		},
	   seriesColors: ["#3366FF","##3366FF"],
	   series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#99CCFF" }
         },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
         },
      ],
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  
  plot2.redraw();
  }
  
		else if(period == "monthly")
		{
    
  plot3 = $.jqplot('monthlyForecast',  [monthlyForecast],
  { title:"Monthly "+graphTitle,
    axes:{
		xaxis:
			{
			renderer:$.jqplot.CategoryAxisRenderer,
			padMin:1.5,
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
			tickOptions: {
			// labelPosition: 'middle',
				angle: -45,
				fontSize:'8pt'
				}
			},
		yaxis:
			{
			min:0.00
			}
		},
	  seriesColors: ["#3366FF","##3366FF"],
	  legend: {
        show: true,
		labels:['Forecasted Sales'],
        location: 'nw',
        xoffset: 1,
        yoffset: 12,
		},
	  series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#99CCFF" }
         },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
         },
      ],
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  plot3.redraw();
  }
  
  
  }//end graphPlot function
  
});
</script>