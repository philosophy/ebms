<?php 
//controller for Sales Report
include "../../../config/config.php";
include "../../view/accounting/currency.php";

?>
<script>
$(document).ready(function(){

	
      $.jqplot.config.enablePlugins = false;
		var dailySales = new Array();
		var dailyExp = new Array();
		var monthlySales = new Array();
		var monthlyExp = new Array();
		var weeklySales = new Array();
		var weeklyExp = new Array();
		
	var arr = new Array();
	var graphTitle = "Sales & Expenses Dashboard";
	var currentTime = new Date();
	var month = currentTime.getMonth() + 1;
	var year = currentTime.getFullYear();
	var parameter = "Daily";
	var plot1,plot2,plot3;
	
	var numDays = new Date(year, month, 0).getDate();
	
	var dateFrom = year+"-"+month+"-"+"01";
	var dateTo = year+"-"+month+"-"+numDays;
	
	
	var dataString = "dateFrom="+dateFrom+"&dateTo="+dateTo;
	
	postGraphData();
	
	function getActivePeriodParam()
	{
		parameter = $(".period-option .optionActive").text();	
		
		if(parameter == "Daily")
		{
		$("div[ref='graphPlot']").hide();
		$("div#dailySales").show();
		$("#daily_datepicker button#go").click(function(){
			dateFrom = $("#dayFrom").val();
			dateTo = $("#dayTo").val();
		dataString = "dateFrom="+dateFrom+"&dateTo="+dateTo;
		postGraphData();
		});
		postGraphData();
		}
		
		
		else if(parameter == "Monthly")
		{
		var monthFrom="",monthTo="";
		$("div[ref='graphPlot']").hide();
		$("div#monthlySales").show();
		$("#monthly_datepicker button#go").click(function(){
			monthFrom = $("#monthFrom").val();
			monthTo = $("#monthTo").val();
		dataString = "dateFrom="+monthFrom+"&dateTo="+monthTo;
		postGraphData();
		});
		postGraphData();
		}
		
		
		else if(parameter == "Weekly")
		{
		$("div[ref='graphPlot']").hide();
		$("div#weeklySales").show();
		
		var weekFrom = 1 , weekTo = 4;
		
		function getWeekVal()
			{
		
				if($("#weekFrom").attr("weekFromNo"))
				weekFrom = $("#weekFrom").attr("weekFromNo").trim();
				
				if($("#weekTo").attr("weekToNo"))
				weekTo = $("#weekTo").attr("weekToNo").trim();
				
			}
		getWeekVal();	
		dataString = "weekFrom="+weekFrom+"&weekTo="+weekTo+"&diff="+(weekTo-weekFrom);
		$(".ui-datepicker-calendar").hide();
		$("#weekly_datepicker #go").click(function(){
			getWeekVal();	
			dataString = "weekFrom="+weekFrom+"&weekTo="+weekTo+"&diff="+(weekTo-weekFrom);
			postGraphData();
		});
		postGraphData();
		}
		
	}
			
		
	$(".period-option a").click(getActivePeriodParam);
		getActivePeriodParam();
	
	function postGraphData()
	{
	
	parameter = $(".period-option .optionActive").text().toLowerCase();
		
	$.ajax({
		url:"../../view/dashboard/"+parameter+"Sales.php",
		type:"POST",
		data:dataString,
		success:
		function(response)
		{
		var dataArr = response.split("&&");
		var obj;
		
		
		if(dataArr[0] == "exceed")
			alert("Resource too many. Limit your parameters and try again");

		else
			{
			dailySales = [];
			dailyExp = [];
			weeklySales = [];
			weeklyExp = [];
			monthlySales = [];
			monthlyExp = [];
			
				obj = JSON.parse(dataArr[0]);
				
					for(i=0;i<obj.data.length;i++)
					{
						if(dataArr[1]=="daily")
						{
						dailySales[i] = obj.data[i];
						dailyExp[i] = obj.exp[i];
						}
						
						else if(dataArr[1]=="monthly")
						{
						monthlySales[i] = obj.data[i];
						monthlyExp[i] = obj.exp[i];
						}	


						else if(dataArr[1]=="weekly")
						{
						weeklySales[i] = obj.data[i];
						weeklyExp[i] = obj.exp[i];
						}							
						
					}
		
				graphPlot(dataArr[1]);
				
				
			}
		}
		});
	}
	
	
	function graphPlot(period)
	{
		if(period == "daily")
		{
		plot1 = $.jqplot('dailySales', [dailyExp,dailySales], {
		title:"Daily "+graphTitle,
		legend: {
        show: true,
		labels:['Expenses','Sales'],
        location: 'ne',
        xoffset: 1,
        yoffset: 12,
		},
	   seriesColors: ["#D11919","#47B224"],
	   series:[ 
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
          },
		  {
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5}
          }
      ],
      axes:{
        xaxis:{
		  renderer: $.jqplot.DateAxisRenderer,
	      label: 'Day',
		  padMin:1.5,
		  min:dateFrom,
		  max:dateTo,
		  tickInterval: '1 Days',
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
	      tickOptions: {
          // labelPosition: 'middle',
          angle: -45,
		  fontSize:'8pt'
	      }
        },
        yaxis:{
		label:"Sales Amount (<?php echo $symbol; ?>)",
          tickOptions:{
            formatString:"%'.2f"
            },
		  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
        }
      },
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  plot1.redraw();
  }

 
		else if(period == "weekly")
		{
  
  plot2 = $.jqplot('weeklySales',  [weeklySales,weeklyExp],
  { title:"Weekly "+graphTitle,
  legend: {
        show: true,
		labels:['Sales','Expenses'],
        location: 'ne',
        xoffset: 1,
        yoffset: 12,
		},
    axes:{
		xaxis:
			{
			renderer:$.jqplot.CategoryAxisRenderer,
			padMin:1.5,
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
			tickOptions: {
			// labelPosition: 'middle',
				angle: -45,
				fontSize:'8pt'
				}
			},
		yaxis:
			{
			min:0.00
			}
		},
	   seriesColors: ["#47B224","#D11919"],
	   series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#CCFF99" }
          },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
          },
      ],
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  
  plot2.redraw();
  }
  
		else if(period == "monthly")
		{
    
  plot3 = $.jqplot('monthlySales',  [monthlySales,monthlyExp],
  { title:"Monthly "+graphTitle,
  legend: {
        show: true,
		labels:['Sales','Expenses'],
        location: 'ne',
        xoffset: 1,
        yoffset: 12,
		},
    axes:{
		xaxis:
			{
			renderer:$.jqplot.CategoryAxisRenderer,
			padMin:1.5,
	      labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	      tickRenderer: $.jqplot.CanvasAxisTickRenderer,
			tickOptions: {
			// labelPosition: 'middle',
				angle: -45,
				fontSize:'8pt'
				}
			},
		yaxis:
			{
			min:0.00
			}
		},
	   seriesColors: ["#47B224","#D11919"],
	   series:[
		{
            lineWidth:5, 
            markerOptions: { style:"filledCircle", size:5,color: "#CCFF99" }
          },
		  
		{
            lineWidth:4, 
            markerOptions: { style:"filledCircle", size:5 }
          },
      ],
      highlighter: {
        show: true,
        sizeAdjust: 7.5
      },
      cursor: {
        show: true,
        zoom:true, 
        showTooltip:false
      }
  });
  plot3.redraw();
  }
  
  
  }//end graphPlot function
  
});
</script>