<script>
				$.ajax({
					url:"/ebms/apps/view/notifications/notifications.php",
					type:"POST",
					cache:false,
					success:
						function(response)
						{
						$(".notif-nav").html(response);
						}
				});
				
</script>