﻿<script>
		$(document).ready(function(){
		
		$("#log").attr('title', 'Log');
		
		$(".page-nav li button").hide();
		$("#datagrid-search-box").hide();
		$("#pdf").hide();
		$("#search-btn").hide();
		var dataString="";
		
		$("div#log_DTR #time").click(function()
		{	
		
		if($('#empName').val()=="none"|| $('#empPassword').val()=="")
		{
		    alert("Please select employee and input password!");
		}
		else
		{
		    var empID = $('#empName').val();
			var pword = $('#empPassword').val();
			
			if($('#time').val()=="Time In")
			{
				$("#time").attr("role","timein");
				dataString = "role="+($(this).attr("role"))+"&empID="+empID+"&pword="+pword;
				dbRequest(dataString);
			}
			
			else if($('#time').val()=="Time Out")
			{
				$("#time").attr("role","timeout");
				dataString = "role="+($(this).attr("role"))+"&empID="+empID+"&pword="+pword;	
				dbRequest(dataString);
			}
		}

		return false;
		});
		
		$("div#log_DTR .formFade,div#log_DTR .formClose, div#log_DTR #cancel").click(function(){
		disable();
		});
		
		$("#timeIn").click(function()
		{
			$('#time').val('Time In');
		});
		
		$("#timeOut").click(function()
		{
			$('#time').val('Time Out');
		});
        

		
		function disable()
		{
		 	$('#empName').val('none');
			$('#empPassword').val('');
			$('#timeIn').attr('checked', false);
			$('#timeOut').attr('checked', false);
		}
		
		dbRequest("role=VIEW");
	    
		function dbRequest(dataString)
	    {
		    $.ajax({
			url:"/ebms/apps/view/personnel/employeeDTR/dtrList.php",
			type:"POST",
			data:dataString,
			cache:false,
			success:
				function(response)
				{
					if(response=="TimeIn" || response=="TimeOut")
					{
					  dbRequest("role=VIEW");
					  disable();
					}
					else if(response=="Invalid")
					{
					  alert("Unauthorized User!");
					  $('#empPassword').val('');
					}
					else if(response=="ExistIn")
					{
					  alert("Already Login!");
					  disable();
					}
					else if(response=="ExistOut")
					{
					  alert("Already Logout!");
					  disable();
					}
					else if(response=="ExistLogIn")
					{
					  alert("You must Login first!");
					}
					else
					{
						$('div[ref=dtrList]').html(response);
						//datagrid("div[ref=dtrList]",true);
						$('#dtr-view').html(response);
						datagrid("dtr-view",true);
					}
					
				}
				
				
				
			});
		}

		});
		
</script>
