<?php 

//controller events for crm profile display

?>

<script>
var init,page,searchQuery;


function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

$("div#new_owners-equity #bankName").attr('disabled',true);
$("div#new_owners-equity #accountType").attr('disabled',true);
$("div#new_owners-equity #accountNumber").attr('disabled',true);

$("#new").attr('title', 'Add Capital');

function bankName()
{
	$.post("/EBMS/apps/view/accounting/ownersEquity/comboboxes.php", {role:"accountType", bank:$("div#new_owners-equity #bankName").val()},function(response)
	{
		$("div#new_owners-equity #accountType").html(response);
		accountType();
	});
}

function accountType()
{
	$.post("/EBMS/apps/view/accounting/ownersEquity/comboboxes.php", {role:"accountNumber", type:$("div#new_owners-equity #accountType").val(), bank:$("div#new_owners-equity #bankName").val()},function(response)
	{
		$("div#new_owners-equity #accountNumber").html(response);
	});
}



$("div#new_owners-equity #accountType").change(function()
{
	accountType();
});


$("div#new_owners-equity #bankName").change(function()
{
	bankName();
});


$("div#new_owners-equity #cashorbank").change(function()
{
	if($("div#new_owners-equity #cashorbank").val() == "cash")
	{
		$("div#new_owners-equity #bankName").attr('disabled',true);
		$("div#new_owners-equity #accountType").attr('disabled',true);
		$("div#new_owners-equity #accountNumber").attr('disabled',true);
		$("div#new_owners-equity #bankName").val("");
		$("div#new_owners-equity #accountType").val("");
		$("div#new_owners-equity #accountNumber").val("");
	}
	else if($("div#new_owners-equity #cashorbank").val() == "bank")
	{
		$("div#new_owners-equity #bankName").attr('disabled',false);
		$("div#new_owners-equity #accountType").attr('disabled',false);
		$("div#new_owners-equity #accountNumber").attr('disabled',false);
		
		$.post("/EBMS/apps/view/accounting/ownersEquity/comboboxes.php", {role:"bankName"},function(response)
		{
			$("div#new_owners-equity #bankName").html(response);
			
			bankName();
		});
	}
	
});


$("div#new_owners-equity #save").click(function()
{
	if($("div#new_owners-equity #cashorbank").val()=="cash")
	{
		if($("div#new_owners-equity #amount").val().trim() == "" || parseInt($("div#new_owners-equity #amount").val()) <= 0)
		{
			alert('Amount field is required.');
		}
		else
		{
			$.post("/EBMS/apps/view/accounting/ownersEquity/crudOwnersEquity.php", {role:"addCash",amount:$("div#new_owners-equity #amount").val(), remarks:$("div#new_owners-equity #remarks").val()},function(response)
			{
				$("div#new_owners-equity .formClose").click();
				loadData(1,searchQuery);
				clearing();
			});
		}
	}
	else if($("div#new_owners-equity #cashorbank").val()=="bank")
	{
		if($("div#new_owners-equity #amount").val().trim() == "" || $("div#new_owners-equity #bankName").val()==null || $("div#new_owners-equity #accountType").val()==null || $("div#new_owners-equity #accountNumber").val()==null)
		{
			alert('Please fill all the required fields.');
		}
		else
		{
			$.post("/EBMS/apps/view/accounting/ownersEquity/crudOwnersEquity.php", {role:"addBank",amount:$("div#new_owners-equity #amount").val(), remarks:$("div#new_owners-equity #remarks").val(), bankId:$("div#new_owners-equity #bankName").val(), bankAccountId:$("div#new_owners-equity #accountNumber").val()},function(response)
			{
				$("div#new_owners-equity .formClose").click();
				loadData(1,searchQuery);
				clearing();
			});
			
		}
	}
	
});


function clearing()
{
	$("div#new_owners-equity #amount").val("");
	$("div#new_owners-equity #remarks").val("");
	$("div#new_owners-equity #cashorbank").val("cash");
	$("div#new_owners-equity #bankName").attr('disabled',true);
	$("div#new_owners-equity #accountType").attr('disabled',true);
	$("div#new_owners-equity #accountNumber").attr('disabled',true);
	$("div#new_owners-equity #bankName").val("");
	$("div#new_owners-equity #accountType").val("");
	$("div#new_owners-equity #accountNumber").val("");
}

$("div#new_owners-equity #amount").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});

function loadData(page,searchQuery)
{
	initialize();
	if(init == "" || init == "Search...")
	{
		searchQuery = "";
	}
	
	else 
	{
		searchQuery = init;
	}
		
	$.post("../../accounting/ownersEquity/ownersEquity.php",{page:page,searchQuery:searchQuery},//set page value for every datagrid execution
	function(response)
	{
		var arrResponse = response.split('&');
		$("#owners-equity").html(arrResponse[0]);
		
		setPageBtnValue(arrResponse[2],arrResponse[3]);
		datagrid("owners-equity",true);
		setPageResponse(arrResponse[1]);
		$("#totalEquity p").html($("table[ref=equity]").attr("totalEquity"));
		
	});
				
}
	$(".page-nav li button").click(function()
	{
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
		setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
		loadData(page,searchQuery);
	});
					
		
			

</script>