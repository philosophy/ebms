<?php
include("../../../config/config.php");
$outputData = "";
$strSeparator = "&";

$page = $_POST['page'];
$searchQuery = addslashes($_POST['searchQuery']);

if($searchQuery!="")
	{
	$condition = "WHERE ph.pr_hdr_no LIKE '%".$searchQuery."%' or concat(e.emp_first_name,' ',left(e.emp_middle_name,1),'. ',e.emp_last_name) LIKE '%".$searchQuery."%' or concat(ep.emp_first_name,' ',left(ep.emp_middle_name,1),'. ',ep.emp_last_name) LIKE '%".$searchQuery."%' ";
	}

elseif ($searchQuery == "")
	$condition = "";


$cur_page = $page;
$page -= 1;
$per_page = 7;
/*
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
*/
$start = $page * $per_page;
$outputData = "<table >
			<th></th>
			<th >Pr. No.</th>
			<th >Requestor Name</th>
			<th>Department</th>
			<th>Position</th>
			<th >Created By</th>
			<th >Date Created</th>
			<th >Date Needed</th>
			<th >Remarks</th>";
			
$query = "SELECT ph.pr_hdr_id, ph.pr_hdr_no, ep.emp_first_name, ep.emp_middle_name, ep.emp_last_name, 
				date_format(ph.pr_hdr_date_created,'%b-%d-%Y') as 'created', date_format(ph.pr_hdr_date_needed,'%b-%d-%Y') as 'needed', ph.pr_hdr_remarks, 
				e.emp_first_name, e.emp_middle_name, e.emp_last_name, d.dept_name, p.position_name, ph.pr_hdr_approved_by_id, ph.is_deleted
				FROM pr_header ph 
				INNER JOIN employee_profile ep ON ph.pr_hdr_requestor_id = ep.emp_id 
				INNER JOIN employee_profile e ON ph.pr_hdr_created_by_id = e.emp_id
				INNER JOIN department d ON ep.dept_id = d.dept_id
				INNER JOIN position p ON p.position_id = ep.position_id
				".$condition." ORDER BY PR_HDR_APPROVED_BY_ID";

	$count = mysql_num_rows(mysql_query($query));
	$no_of_paginations = ceil($count / $per_page);
	
	$result = mysql_query($query." limit $start,$per_page");

	
	if(mysql_num_rows($result) > 0)
	{		
	while($arrPR = mysql_fetch_array($result))
	{
	$x = (($arrPR['is_deleted']==1)?"deleted=true":"deleted=false");
	
		$outputData .= "<tr ".$x." a=".$arrPR['pr_hdr_id'].">";
		if($arrPR['pr_hdr_approved_by_id'] == null)
		{
			$outputData .= "<td ><img class='pr_approve' ".$x." a=".$arrPR['pr_hdr_id']." src='/EBMS/images/icons/approved_icon.png'></td>";
		}
		else
		{
			$outputData .= "<td ><img class='approved' src='/EBMS/images/icons/checkIcon.png'></td>";
		}

		$outputData .= "<td >".$arrPR['pr_hdr_no']."</td>";
		$outputData .= "<td >".$arrPR[2]." ".$arrPR[3]." ".$arrPR[4]."</td>";
		$outputData .= "<td >".$arrPR['dept_name']."</td>";
		$outputData .= "<td >".$arrPR['position_name']."</td>";
		$outputData .= "<td >".$arrPR[8]." ".$arrPR[9]." ".$arrPR[10]."</td>";
		$outputData .= "<td >".date("D M d, Y",strtotime($arrPR['created']))."</td>";
		$outputData .= "<td>".date("D M d, Y",strtotime($arrPR['needed']))."</td>";
		$outputData .= "<td>".$arrPR['pr_hdr_remarks']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
	
	else
	{
	include("../../view/noResults.php");
	$cur_page = 0;
	}

	
echo $outputData.
	$strSeparator.
		"Page $cur_page of $no_of_paginations".
	$strSeparator.
		@$cur_page.
	$strSeparator.
		@$no_of_paginations; 
		
mysql_free_result($result);