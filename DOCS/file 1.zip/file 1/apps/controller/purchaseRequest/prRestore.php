<?php
session_start();
include("../../../config/config.php");

$prID = $_POST['prID'];
mysql_query("UPDATE pr_header SET is_deleted = '0' WHERE pr_hdr_id='".$prID."'");
?>