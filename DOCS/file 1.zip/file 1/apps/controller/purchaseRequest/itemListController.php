<script>
		$(document).ready(function(){
		$("div#new_pr button#save").click(function()
		{
		});
		
		inputMask("formDataContSearch","Search");
			
		$("#formDataContSearch").keyup(function(){
		
		var q = $(this).val().trim();
		itemList($("#itemType").val(),q);
			
		});
	
		itemList($("#itemType").val(),$("#formDataContSearch").val().trim());
		
		$("#itemType").change(function(){
		$("#formDataContSearch").val("Search");
			itemList($("#itemType").val(),$("#formDataContSearch").val().trim());
		});
		var ctr = 0;
		function itemList(type,q)
		{
		ctr++;
		var dataString = "itemType="+type+"&q="+q;
		$.ajax({
			url:"/ebms/apps/view/purchasing/purchaseRequest/purchaseItemList.php",
			type:"POST",
			data:dataString,
			success:
			function(response){
			$("div[ref=orderItemsList] ul").html(response);
				
				$("div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function(){
					
					$(this).trigger("click");
					return false;
					
				});
				$("#new_pr div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						var code = $(this).attr("code");
						var desc = $(this).attr("desc");
						
						if($("#new_pr #requestedItems").find("tr[code="+code+"] td").size() > 0)
						{
						
						$("#new_pr #requestedItems tr td").removeClass("itemActive");
						$("#new_pr #requestedItems").find("tr[code="+code+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("#new_pr div.itemDetails").stop().animate({bottom:"100px",opacity:0.8},"1000").show();
						
						
						},function(){
						
						code = $(this).attr("code");
						desc = $(this).attr("desc");
						if($("#new_pr tbody#requestedItems").find("tr[code="+code+"] td").size() > 0)
						$("#new_pr tbody#requestedItems").find("tr[code="+code+"] td").removeClass("itemActive");
						
						$("#new_pr div.itemDetails").stop().animate({bottom:"90px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
						
				$("div[ref=orderItemsList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function(){
						
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						
						if($(this).find(".addItem").css("display") == "none")
						{
						var code = $(this).attr("code");
						var unitPrice = $(this).attr("unitPrice");
						var desc = $(this).attr("desc");
						var unit = $(this).attr("unit");
						var cat = $(this).attr("cat");
						var sub = $(this).attr("sub");
						var brand = $(this).attr("brand");
						
							$("#requestedItems").append("<tr code='"+code+"'><td><input type='number' id='qty' value=1></td><td id='itemUnit'>"+unit+"</td><td id='itemCode'>"+code+"</td><td id='itemPrice'>"+unitPrice+"</td><td id='itemCategory'>"+cat+"</td><td id='itemDesc'>"+desc+"</td></tr>");
							
							
							$("#requestedItems").find("tr[code='"+code+"'] input").bind("keyup input",function(){
								if($(this).val() == "0")
								{
									$(this).val(1);
								}								
							});
						}
						
						
						$(this).hover(function(){
						
						
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
						}
						
						else
						{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						},function(){
						
						if($(this).find(".addItem").css("display") != "block")
						{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
						}
						
						else
						{
						
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						}
						
						});
						
				return false;	
				},
				function()
				{
				var code = $(this).attr("code");
					$("#requestedItems").find("tr[code="+code+"]").fadeOut("slow",
						function()
						{
							$("#requestedItems").find("tr[code="+code+"]").remove();
						});
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
						
				});
				
				if(ctr > 1)
				{
				var arr1 = new Array(),arr2 = new Array();
				$("div#new_pr div[ref=orderItemsList] ul li a").each(function(index){
						
						var itemListCode = $(this).attr("code");
						arr1[index] = itemListCode;
							
					});	
					
				$("div#new_pr #requestedItems tr").each(function(index){
						var requestedItemsCode = $(this).attr("code");
						arr2[index] = requestedItemsCode;
				});
				
				for(i=0;i<arr1.length;i++)
					{
						for(x=0;x<arr2.length;x++)
						if(arr1[i] == arr2[x])
							{
							$("div#new_pr div[ref=orderItemsList] ul li a[code='"+arr1[i]+"']").click();
							$("#requestedItems").find("tr[code="+arr1[i]+"]:last-child").remove();
							}
					}
					
					
				}
				
			}
		});
		}
		
		});
</script>
