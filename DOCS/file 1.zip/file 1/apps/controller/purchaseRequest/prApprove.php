<?php
session_start();
include("../../../config/config.php");

$prID = $_POST['prID'];


mysql_query("UPDATE pr_header SET pr_hdr_approved_by_id = '".$_SESSION['login']."' WHERE PR_HDR_ID ='".$prID."'");

mysql_query("UPDATE pr_detail SET PR_DTL_STATUS = 'APPROVED' WHERE PR_HDR_ID ='".$prID."'");


?>