<?php
include("../../../config/config.php");

$prID = @$_POST['prID'];

$outputData = "";

$prItems = mysql_query("SELECT pr.pr_dtl_qty, u.unit_name, pr.item_code, pr.pr_dtl_item_description, pr.pr_dtl_status
						FROM pr_detail pr
						INNER JOIN unit u ON pr.unit_id = u.unit_id 
						WHERE pr.pr_hdr_id = '".$prID."'");
	
	if (mysql_num_rows($prItems) > 0)
	{						
	$outputData = "<table >
			<th >Quantity</th>
			<th >Unit</th>
			<th >Item Code</th>
			<th >Item Description</th>
			<th >Item Status</th>";
			
	while($arrAsset = mysql_fetch_array($prItems))
	{
		$outputData .= "<tr>";
		$outputData .= "<td>".$arrAsset['pr_dtl_qty']."</td>";
		$outputData .= "<td>".$arrAsset['unit_name']."</td>";
		$outputData .= "<td>".$arrAsset['item_code']."</td>";
		$outputData .= "<td>".$arrAsset['pr_dtl_item_description']."</td>";
		$outputData .= "<td>".$arrAsset['pr_dtl_status']."</td>";
		$outputData .= "</tr>";
	}
	
	$outputData .= "</table>";
	}
else
{
	$outputData .= "No results found.";
}

echo $outputData;
?>