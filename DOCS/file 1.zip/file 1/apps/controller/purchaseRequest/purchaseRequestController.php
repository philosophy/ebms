<!-- CONTROLLER FOR PURCHASE REQUEST APPROVAL -->
<script>

var init,page;

var searchQuery="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	$('#edit').attr('disabled',true);
	$('div.datagrid-crud-menu #delete').attr('disabled',true);
	$('div.datagrid-crud-menu #restore').attr('disabled',true);
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

function loadData(page,searchQuery)
{
initialize();

	$("#new").attr('title', 'New Purchase Request');
	$("#edit").attr('title', 'Edit Purchase Request');
	$("div.datagrid-crud-menu #delete").attr('title', 'Delete Purchase Request');
	$("div.datagrid-crud-menu #restore").attr('title', 'Restore Purchase Request');
	
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}

	$.ajax({
		url:'../../../controller/purchaseRequest/prList.php',
		type: "POST",
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
		function(response)
		{
		
		$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]);
			
			$('#purchase-request').html(arrResponse[0]);
			datagrid("purchase-request",true);
			setPageResponse(arrResponse[1]);
		
		$("#purchase-request table tr").click(function()
		{
			setCellContentValue($(this));
						
		});
		
		
		}
		});
}
			
			$(".page-nav li button").click(function(){
										
					var activeBtn = $(this).attr("id");
					var cur_page = Number($(this).attr("cur_page"));
					var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
						setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
						loadData(page,searchQuery);
						
					});
			

$('#edit_pr #save').click(function(){

			var dateNeeded = $('#edit_pr #prEditDateNeeded').val().trim();
			var remarks = $('#edit_pr #prRemarks').val().trim();
			var id = $('#edit').attr('prID');
			var prEditDataString = "dateNeeded="+dateNeeded+"&remarks="+remarks+"&id="+id;

		$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseRequest/editPRHeader.php",
		type:"POST",
		data: prEditDataString,
		cache: false,
		success:
			function(response)
			{
				$('#edit_pr #requestedItems tr').map(function(index) {
						var testArray = new Array();
			
						testArray[index] = $(this).find("#qty").val()+$(this).text();
						prItems = testArray[index].split(';');
						var qty = prItems[0];
						var code = prItems[2];
						var prID = $('#edit').attr('prID');
			
							$.ajax({
								url:"/ebms/apps/view/purchasing/purchaseRequest/editPRDetails.php",
								type:"POST",
								data: "id="+prID+"&code="+code+"&qty="+qty,
								cache:false,
								success:
									function(response)
									{
					
									}
							});
						});
				
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
					type:"POST",
					data:"module=" + "Purchase Request" + "&id=" + id,
					success:
					function(response)
					{
						dataString = "role=" + "Edit" + "&noun=" + "Purchase request record" + "&code=" + response;
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
							
							}
						});
					}
				});
						
				alert('Purchase Request record successfully updated!');
				loadData(1,searchQuery);
				$("#request-item").html("");
				$("div#edit_pr.modalForm").fadeOut("slow",0,
				function()
				{
					$(".formFade").fadeOut(300,
						function(){
							$(".formFade").remove();
						});
					$("div#edit_pr.modalForm").hide();
						
				});
			}
		
		});

		});



$('#new_pr #save').click(function(){
		
			var dateNeeded = $('#new_pr #prDateNeeded').val().trim();
			var requestorId	= $('#new_pr #requestName').val();
			var remarks = $('#new_pr #prRemarks').val().trim();
		if($('#new_pr #prDateNeeded').val()=="")
		{
			alert("Please specify the date.");
		}
		else if($('#new_pr #formDataCont table tr').length == 1)
		{
			alert("Please select item/s to be purchased.");
		}
		else
		{
			var prDataString = "dateNeeded="+dateNeeded+"&requestorId="+requestorId+"&remarks="+remarks;
			
			
			
				$.ajax({
				url:"/ebms/apps/view/purchasing/purchaseRequest/prInsert.php",
				type:"POST",
				data: prDataString,
				cache:false,
				success:
					function()
					{
						$('#new_pr #requestedItems tr').map(function(index) 
						{
						// var testArray = new Array();
			
						// testArray[index] = $(this).find("#qty").val()+$(this).text();
						// prItems = testArray[index].split(';');
			
						// var qty = prItems[0];
						// var unit = prItems[1];
						// var code = prItems[2];
						// var cat = prItems[4];
						// var desc = prItems[5];
			
							$.ajax(
							{
								url:"/ebms/apps/view/purchasing/purchaseRequest/prInsertItems.php",
								type:"POST",
								data: "unit=" + $(this).find('#itemUnit').text() + "&code=" + $(this).find('#itemCode').text() + "&cat=" + $(this).find('#itemCategory').text() + "&desc=" + $(this).find('#itemDesc').text() + "&qty=" + $(this).find('#qty').val(),
								cache:false,
								success:
									function()
									{
									
									}
							});
						});
						
						dataString = "role=" + "New" + "&noun=" + "Purchase request record";
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
							
							}
						});
					
						alert('Purchase Request successfully created!');
						loadData(1,searchQuery);
						$('#new_pr #prDateNeeded').val('');
						$('#new_pr #prRemarks').val('');
						$('#new_pr #requestedItems').html('');
						$("div#new_pr.modalForm").fadeOut("slow",0,
						function()
						{
							$(".formFade").fadeOut(300,
								function(){
									$(".formFade").remove();
								});
							$("div#new_pr.modalForm").hide();
							
						});
					}
				});
		}
			return false;
		});
		
	
	function prDetails(selector)
	{
		$.post('../../../controller/purchaseRequest/prDetails.php', {prID: $(selector).attr('a')},
		function(response)
		{
			$('#request-item').html(response);
			datagrid("request-item",true);
		});
	}
	
	function setCellContentValue(selector)
	{
		$("#purchase-request table").find("tr").removeClass("activeTr");
		$(selector).addClass("activeTr");
		$("#edit").attr("prID",$(selector).attr("a"));
		$("#delete_pr #delete").attr("prID",$(selector).attr("a"));
		$("#restore_pr #restore").attr("prID",$(selector).attr("a"));
		
		editPrId = $(selector).attr('a');
		
		setInterval(prDetails(selector),100);
		
		if ($(selector).attr("deleted") == "false")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",false);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
		}
		else if ($(selector).attr("deleted") == "true")
		{
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",false);
		}
		
		if ($(selector).find("img").attr("src") == "/EBMS/images/icons/checkIcon.png")
		{
			$("#edit").attr("disabled",true);
			$("div.datagrid-crud-menu #delete").attr("disabled",true);
			$("div.datagrid-crud-menu #restore").attr("disabled",true);
		}
		else
		{
			$("#edit").attr("disabled",false);
		}
		
		$('img.pr_approve').click(function()
		{
			if ($(this).attr("deleted") == "true")
			{
				
			}
			else if ($(this).attr("deleted") == "false")
			{
				$.post('../../../controller/purchaseRequest/prApprove.php',{prID: $(this).attr('a')});
				
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
					type:"POST",
					data:"module=" + "Purchase Request" + "&id=" + editPrId,
					success:
					function(response)
					{
						dataString = "role=" + "Approve PR" + "&noun=" + "Purchase request record" + "&code=" + response;
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
							
							}
						});
					}
				});
				
				$(this).fadeOut('slow', function()
				{
					$(this).replaceWith("<img class='approved' src='/EBMS/images/icons/checkIcon.png'>");
					setInterval(prDetails(this),1000);
				});
				return false;
			}
		});
		
		$('#delete_pr #delete').click(function()
		{
			$.post('../../../controller/purchaseRequest/prDelete.php',{prID:$(this).attr('prID')},
				function()
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Purchase Request" + "&id=" + editPrId,
						success:
						function(response)
						{
							dataString = "role=" + "Delete" + "&noun=" + "Purchase request record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
								
								}
							});
						}
					});
					
					$("div#delete_pr.modalForm").fadeOut("slow",0,
		function()
		{
			$(".formFade").fadeOut(300,
				function(){
					$(".formFade").remove();
					});
			$("div#delete_pr.modalForm").hide();
		});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#restore_pr #restore').click(function()
		{
			$.post('../../../controller/purchaseRequest/prRestore.php',{prID:$(this).attr('prID')},
				function()
				{
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
						type:"POST",
						data:"module=" + "Purchase Request" + "&id=" + editPrId,
						success:
						function(response)
						{
							dataString = "role=" + "Restore" + "&noun=" + "Purchase request record" + "&code=" + response;
							$.ajax(
							{
								url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
								type:"POST",
								data:dataString,
								success:
								function(response)
								{
								
								}
							});
						}
					});
					
					$("div#restore_pr.modalForm").fadeOut("slow",0,
		function()
		{
			$(".formFade").fadeOut(300,
				function(){
					$(".formFade").remove();
					});
			$("div#restore_pr.modalForm").hide();
		});
				});
			loadData(1,searchQuery);
			return false;
		});
		
		$('#edit').click(function()
		{$.post('../../purchasing/purchaseRequest/headerFill.php',{prID:$(this).attr('prID')},function(response){ 
					
					obj = JSON.parse(response);
					
					$("div#edit_pr #prNo").val(obj.values["code"]);
					$("div#edit_pr #requestName").val(obj.values["requestor"]);
					$("div#edit_pr #prDate").val(obj.values["dateCreated"]);
					$("div#edit_pr #prEditDateNeeded").val(obj.values["dateNeeded"]);
					$("div#edit_pr #prRemarks").val(obj.values["remarks"]);
					
					$.post('../../purchasing/purchaseRequest/detailFill.php',{prID:$("#edit").attr('prID')},function(response){
						$("#edit_pr #requestedItems").html(response);
					});
					});
		});
		
		
	}

</script>