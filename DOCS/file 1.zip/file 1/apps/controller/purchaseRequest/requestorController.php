
<script>
	
	$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseRequest/requestorList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
			$("#requestName").html(response);
			}
			
		});
		
		/*$.ajax({
		url:"/ebms/apps/view/purchasing/purchaseRequest/supplierList.php",
		type:"POST",
		
		cache:false,
		success:
			function(response)
			{
			$("#poSupplier").html(response);
			}
			
		});*/
		
</script>