<script>
var init,page;
var os;
var searchQuery="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	$("#edit").attr("disabled", true);
	$("#restore").attr("disabled", true);
	$("#delete").attr("disabled", true);
	$("#import").attr("disabled", true);
	$("#print").attr("disabled", true);
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	$.ajax({
		url:'/EBMS/apps/view/sales/orderSlip/osList.php', 
		type: "POST",
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			//setPageBtnValue(arrResponse[2],arrResponse[3]); */
				
			$('#osList').html(arrResponse[0]);
			datagrid('osList', true);
			//setPageResponse(response);
				
			$("#osList table tr").click(function()
			{
			setCellContentValue($(this));
			os = $(this).attr('a');	
			});
			}
			});
}
	
	
	$("div#delete_OS #save").click(function(){
		$.post('/EBMS/apps/view/sales/orderSlip/deleteOS.php', {osCode:os},
		function(response)
		{ 
			dataString = "role=" + "Delete" + "&noun=" + "Order slip record" + "&code=" + os;
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
		
		 $(".formFade").fadeOut(300,
			function(){
				$(".formFade").remove();
			});
				$("div#delete_OS.modalForm").hide();
		});
		loadData(1,searchQuery);
	});
	

	$("div#restore_OS #save").click(function(){
		$.post('/EBMS/apps/view/sales/orderSlip/restoreOS.php', {osCode:os},
		function(response)
		{ 
			dataString = "role=" + "Restore" + "&noun=" + "Order slip record" + "&code=" + os;
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
			
		 $(".formFade").fadeOut(300,
			function(){
				$(".formFade").remove();
			});
				$("div#restore_OS.modalForm").hide();
		});
		loadData(1,searchQuery);
	});
	
	function deleted()
			{
				$("#edit").attr("disabled", true);
				$("#restore").attr("disabled", false);
				$("#delete").attr("disabled", true);
				$("#import").attr("disabled", true);
				$("#pdf").unbind("click");
			}
	
	function restored()
	{
		$("#edit").attr("disabled", false);
		$("#restore").attr("disabled", true);
		$("#delete").attr("disabled", false);
		$("#import").attr("disabled", false);
		$("#pdf").bind("click");
	}


	function setCellContentValue(selector)
		{
		
		if($(selector).attr("deleted") == "true")
			deleted();
		else
			restored();
		if($(selector).attr("cleared") == "true") 
		{
			$("#edit").attr("disabled", true);
			$("#delete").attr("disabled", true);
			$("#restore").attr("disabled", true);
		}
		//remove all active classes in tr element
		$("#osList table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		
		$.post('/EBMS/apps/view/sales/orderSlip/osDetails.php', {osCode:$(selector).attr('a')},
		function(response)
		{
			$('#orderDetails').html(response);
			datagrid('orderDetails', true);
		});
	}
	
	
	
	
	$("#import_OS #save").click(function(){
		
		if($("#import_OS #deliveredBy").val() == "..." ||  $("#import_OS #location").val() == "..." || $("#import_OS #contact").val() == "..." || $("#import_OS #area2").val() == "..." )
		{
			alert("Please fill up required fields (*).");
		}
		
		else
		{
			drRefNo = $("#import_OS #refNo").val();
			customerId = $("#import_OS #customer").val();
			deliveredBy = $("#import_OS #deliveredBy").val();
			shipToId = $("#import_OS #location").val();
			area = $("#import_OS #area2").val();
			contact = $("#import_OS #contact").val();
			grossAmount = $("#import_OS #grossAmount").val();
			netAmount = $("#import_OS #netAmount").val();
			discount = $("#import_OS #discount").val().replace("%", "");
			remarks = $("#import_OS #remarks").text();
			
			dataString = "drRefNo="+drRefNo+"&deliveredBy="+deliveredBy+"&customerId="+customerId+"&shipToId="+shipToId+"&area="+area+"&contact="+contact+"&grossAmount="+grossAmount+"&netAmount="+netAmount+"&discount="+discount+"&remarks="+remarks;
			
			$.ajax({
			type: "POST",
			url:'/EBMS/apps/view/sales/deliveryReceipt/insertDr.php', 
			data: dataString,
			success:
			function(response)
			{
					$('#import_OS #orderedItems tr').each(function(index){
					qty = $(this).find("#qty").val(); 
					item = $(this).find("#itemId").text();
					desc = $(this).find("#description").text(); 
					dataString = "itemCode="+item+"&qty="+qty+"&desc="+desc+"&drHdrId="+response.trim();
				
						$.ajax({
							type: "POST",
							url: "../deliveryReceipt/insertDrDetails.php",
							data: dataString,
							cache: false,
							success:
							function(response)
							{
							}
						});	
					
					});
					
					dataString = "role=" + "Import to DR" + "&noun=" + "Order slip record" + "&code=" + drRefNo;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
						
						}
					});
					
					var x = confirm("Do you want to print delivery receipt?")
					if(x == true)
					{
						window.open('/EBMS/apps/view/reports/sales/deliveryReceipt.php', 'Delivery Receipt');								
					}
					
					$("div#import_OS.modalForm").fadeOut("slow",0,
					function()
					{	
						$(".formFade").fadeOut(300,
					function(){
						$(".formFade").remove();
					});
						$("div#new_OS.modalForm").hide();
					});
					window.location = '/EBMS/apps/view/sales/deliveryReceipt/';
			}
			});
		}
	});
	
	
		function details(drHdrId)
		{
			
		}
	
	$("#pdf").click(function(){
			$.post('/EBMS/apps/view/reports/sales/report.php', {osNo:os});
			window.open('/EBMS/apps/view/reports/sales/orderSlip.php', 'Order Slip');
		});
		
	
	
	
	function fillData()
	{
		$("#import_OS #customer").empty();
		$("#import_OS #customer").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/orderSlip/getCustomer.php', function(response){
			$("#import_OS #customer").append(response);
		});
		
		$("#import_OS #city").empty();
		$("#import_OS #city").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/city.php', function(response){
			$("#import_OS #city").append(response);
		
		});
		
		$("#import_OS #area1").empty();
		$("#import_OS #area1").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/area.php', function(response){
			$("#import_OS #area1").append(response);
			
		});
		
		$("#import_OS #area2").empty();
		$("#import_OS #area2").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/area.php', function(response){
			$("#import_OS #area2").append(response);
			
		});
		
		$("#import_OS #deliveredBy").empty();
		$("#import_OS #deliveredBy").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/employee.php', function(response){
			$("#import_OS #deliveredBy").append(response);
			
		});
		
	}

	$("#import_OS #location").change(function(){
		$("#import_OS #contact").empty();
		$("#import_OS #contact").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/getContact.php',{locationId:$("#import_OS #location").val()}, function(response){
			$("#import_OS #contact").append(response);
			var x = response.split(",");
			$("#import_OS #shipTo").val(x[1]).attr("disabled", true);
		});
	});

	$("#import").click(function(){
		$("#import_OS #shipTo").attr("disabled", true);
		$("#import_OS #orderedItems").html("");
		$("#import_OS #drNo").val("<Auto>").attr("disabled", true);
		$("#import_OS #refNo").val(os).attr("disabled", true)
	
		$.post('/EBMS/apps/view/sales/deliveryReceipt/getOrderedItems.php', {osCode:os},
		function(response)
		{
			obj = JSON.parse(response);
			 for(x = 0; x < obj.values.length; x++)
			 {
				arrayItems = obj.values[x].split("~");
				$("#import_OS #orderedItems").append("<tr><td><input type='number' disabled id='qty' value='"+arrayItems[0]+"' style='width:70px;'></td><td id='itemId'>"+arrayItems[1]+"</td><td id='unitPrice' style='text-align:right'>"+arrayItems[3]+"</td><td id='description'>"+arrayItems[2]+"</td></tr>");
			 }
			 
		});
	
	
		fillData();
		$.post('/EBMS/apps/view/sales/deliveryReceipt/importDr.php', {osCode:os},
		function(response)
		{
		 obj = JSON.parse(response);
		  $("#import_OS #remarks").val(obj.values['remarks']);
		 $("#import_OS #customer").val(obj.values['customerId']).attr("disabled", true);		
		 $("#import_OS #location").empty();
			$("#import_OS #location").append("<option value='...'>...</option>");
			$.post('/EBMS/apps/view/sales/orderSlip/getLocation.php',{customer:obj.values['customerId']}, function(response){
				$("#import_OS #location").append(response);
			});
		 $("#import_OS #city").val(obj.values['city']);
			$("#import_OS #barangay").empty();
			$("#import_OS #barangay").append("<option value='...'>...</option>");
			$.post('/EBMS/apps/view/sales/deliveryReceipt/barangay.php',{cityId:obj.values['city']}, function(response){
				$("#import_OS #barangay").append(response);
			$("#import_OS #barangay").val(obj.values['barangay']);
			});
		$("#import_OS #address").val(obj.values['address']).attr("disabled", true);
		$("#import_OS #area1").val(obj.values['areaId']);
		$("#import_OS #salesPerson").val(obj.values['empName']).attr("disabled", true);
		$("#import_OS #grossAmount").val(obj.values['grossAmount']).attr("disabled", true);
		$("#import_OS #netAmount").val(obj.values['netAmount']).attr("disabled", true);
		$("#import_OS #netAmount").val(obj.values['netAmount']).attr("disabled", true);
		$("#import_OS #discount").val(obj.values['discount']+'%').attr("disabled", true);
		});

	});

</script>