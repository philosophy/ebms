﻿<?php 

$query_pag_num = "SELECT COUNT(*) AS count FROM messages";
$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];
$no_of_paginations = ceil($count / $per_page);

?>