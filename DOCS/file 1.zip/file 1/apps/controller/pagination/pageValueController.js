﻿function setPageBtnValue(cur_page,no_of_paginations)	
				{
				
				$(".page-nav li button").attr({"cur_page":cur_page,"no_of_pagination":no_of_paginations});
				setPageBtnBehavior(cur_page,no_of_paginations,"");
				
				}
				
			function setPageBtnBehavior(cur_page,no_of_paginations,activeBtn)
				{
					if(activeBtn == "")
						{
							if(cur_page == 1)
								{
								$(".page-nav li button#First,.page-nav li button#Prev").addClass("pageBtnInactive").attr("disabled",true);
								}
								
							else if(cur_page > 1)
								{
								$(".page-nav li button#First,.page-nav li button#Prev").removeClass("pageBtnInactive").removeAttr("disabled");	
								}
							
							if(cur_page == no_of_paginations)
								{
								$(".page-nav li button#Last,.page-nav li button#Next").addClass("pageBtnInactive").attr("disabled",true);
								}
							else if(cur_page < no_of_paginations)
									{
									$(".page-nav li button#Last,.page-nav li button#Next").removeClass("pageBtnInactive").removeAttr("disabled");
									}	
						}
					
					else if(activeBtn != "")
						{
							//if first button
							if(activeBtn == "First" )
								{
									if(cur_page > 1)
										{
										page =  1;
										}
								}
					
							//if prev button
							else if(activeBtn == "Prev")
								{
									if(cur_page > 1)
										{
										page = cur_page - 1;
										}
								}
						
							//if next button
							else if(activeBtn == "Next")
								{
									if(cur_page < no_of_paginations)
										{
										page = cur_page + 1;
										}
								}
					
							//if last button
							else if(activeBtn == "Last")
								{
									if(cur_page < no_of_paginations)
										{
										page = no_of_paginations;
										}
								}
						}
				}
		
		function setPageResponse(responseVal)
			{
			//alert(responseVal);
				$("#pagination #pageno").html(responseVal).fadeIn("slow");
			}