<script>

var init,page;

var searchQuery="";
var empCode1, approvalId1;
var empCode2, approvalId2;
var empCode;

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}

	$.ajax({
		url:"../../userManagement/approvalList/approvalsView.php",
		type:"POST",
		cache:false,
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]);
				
			$("#approval-list").html(arrResponse[0]);
			datagrid("approval-list",true);
			setPageResponse(arrResponse[1]);
			
			$("#approval-list table tr").click(function(){
			$("#subgrid-second").html("");
			$("#subgrid-first").html("");
			cellContentValue($(this));
			});
			}
	});
}

function cellContentValue(selector)
{
	$("#approval-list table").find("tr").removeClass("activeTr");			
	$(selector).addClass("activeTr");	
	empCode = $(selector).attr('d');
	loadApprovals();
}

function loadApprovals()
{
	$.post("approvalslist.php", {employeeCode:empCode},
	function(response)
	{
		$("#subgrid-second").html(response);
		datagrid("subgrid-second", true);
		
		$("#subgrid-second table tr").click(function()
		{
			$("#subgrid-second table").find("tr").removeClass("activeTr");
			$(this).addClass("activeTr");
			empCode1 = $(this).attr('b');
			approvalId1 = $(this).attr('c');
		});	
	});
		
	$.post("grantview.php", {employeeCode:empCode},
	function(response)
	{
		$("#subgrid-first").html(response);
		datagrid("subgrid-first", true);
			
			$("#subgrid-first table tr").click(function()
			{
				$("#subgrid-first table").find("tr").removeClass("activeTr");
				$(this).addClass("activeTr");
				empCode2 = $(this).attr('b');
				approvalId2 = $(this).attr('c');
			});
	});
}

	$("#grantBtn").click(function()
	{	
		$.post("grant.php", {employeeCode:empCode1, approvalID:approvalId1});
		loadApprovals();
		return false;	
	});
	
	
	$("#pendingBtn").click(function()
	{	
		$.post("approved.php", {employeeCode:empCode2, approvalID:approvalId2});	
		loadApprovals();
		return false;	
	});
	
	
	
</script>
