<?php
	include("../../../config/config.php");
	
	session_start();
	$empId = $_SESSION['emp_id'];
	
	$username = $_POST['username'];
	
	$query = mysql_query("Update user_account Set IS_ONLINE = '0' Where USER_NAME = '" . $username . "'");
	
	session_destroy();
?>