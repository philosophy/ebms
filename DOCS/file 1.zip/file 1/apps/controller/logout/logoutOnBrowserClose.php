<?php
	include("../../../config/config.php");
	
	session_start();
	$empId = $_SESSION['emp_id'];
	
	$query = mysql_query("Update user_account Set IS_ONLINE = '0' Where EMP_ID = '" . $empId . "'");
	
	session_destroy();
?>