<?php 
	// session_start();
	include("../../../config/config.php");
	// include("../login/updateIsOnline.php");
	session_start();
	$emp = $_SESSION['emp_id'];
	mysql_query("INSERT INTO audit_trail VALUES (curdate(),curtime(),'The user logged out',".$emp.")");
	
	$query = mysql_query("Update user_account Set IS_ONLINE = '0' Where EMP_ID = '" . $_SESSION['emp_id'] . "'");
	echo $_SESSION['emp_id'];
	session_destroy();
?>