<script>
	// var previousLink = "";
	// var toGoLink = "";
	
	// $("body").ready(function()
	// {
		// // alert('ready body');
		// previousLink = window.location.pathname;
		// // alert(previousLink);
	// alert($.cookie("userIsLogin"));
	
	
	// });
	
	// $("a").click(function()
	// {
		// toGoLink = $(this).attr('href');
		// // alert(toGoLink);
	// });
	
	// $(window).bind("beforeunload", function()
	// {
		// if ((previousLink == window.location.pathname) && (previousLink != toGoLink))
		// {
			// alert('wag leave');
		// }
		// else
		// {
			// alert('leave');
			// $.ajax(
			// {
				// url:"/ebms/apps/controller/logout/logoutOnBrowserClose.php",
				// type:"POST",
				// success:
				// function(response)
				// {
					
				// }
			// });	
		// }
	// });
</script>