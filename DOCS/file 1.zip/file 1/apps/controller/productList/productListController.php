<script type="text/javascript" src="/EBMS/js/timepicker1.js"></script>

<script>

var init,page;

var searchQuery="";
var itemCode="";
var categoryName="", subcatName="", brandName="", unitName="", price=0, categoryID="",brandID="",subCatID="",unitID					="",img="";
var listType = (($("#productAssetList").val() == "")?"product":($("#productAssetList").val()));
var cat="";

function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	}
//by default, the first page will be displayed
loadData(1,searchQuery);
var item;


$("#transfer").attr('title','Transfer Product to Asset');
$("#new").attr('title','New Product');
$("#edit").attr('title','Edit Product');
$("#delete").attr('title','Delete Product');
$("#restore").attr('title','Restore Product');

$("#transfer").click(function()
{
	$("div#transfer_prodAsset #assetOrProduct").text("Are you sure you want to transfer " + $("#productAssetList").val());
});
$("div#transfer_prodAsset #save").click(function()
{
	if($("#productAssetList").val()=='product')
	{
		$.post('/EBMS/apps/view/inventory/productList/transfer.php', {role:"transfer", flag:"A", code:prodCode},
		function(result)
		{
			dataString = "role=" + "Transfer to Asset" + "&noun=" + "Product record" + "&code=" + prodCode;
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
		
			alert('Record Transferred');
			$("div#transfer_prodAsset .formClose").click();
			$("#productAssetList").val("asset");
			$("#productAssetList").change();
		});
	}
	else
	{
		$.post('/EBMS/apps/view/inventory/productList/transfer.php', {role:"transfer", flag:"P", code:prodCode},
		function(result)
		{
			dataString = "role=" + "Transfer to Product" + "&noun=" + "Asset record" + "&code=" + prodCode;
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
		
			alert('Record Transferred');
			$("div#transfer_prodAsset .formClose").click();
			$("#productAssetList").val("product");
			$("#productAssetList").change();
		});
	}
});

$("#productAssetList").change(function(){
listType = (($(this).val() == "")?"product":($(this).val()));
$("button#new").attr("listType", listType);



loadData(1,searchQuery);
if(listType=='product')
{
	$("a[href='#itemHistory']").hide();
	$("a[href='#maintenance']").hide();
	$("a[href='#maintenanceHistory']").hide();
	$("a[href='#generalTab']").click();
	$("#transfer").attr('title','Transfer Product to Asset');
	$("#new").attr('title','New Product');
	$("#edit").attr('title','Edit Product');
	$("#delete").attr('title','Delete Product');
	$("#restore").attr('title','Restore Product');
}
else
{
	$("a[href='#itemHistory']").show();
	$("a[href='#maintenance']").show();
	$("a[href='#maintenanceHistory']").show();
	$("#transfer").attr('title','Transfer Asset to Product');
	$("#new").attr('title','New Asset');
	$("#edit").attr('title','Edit Asset');
	$("#delete").attr('title','Delete Asset');
	$("#restore").attr('title','Restore Asset');
}
});


function loadData(page,searchQuery)
{

$("#edit").attr('disabled',true);
$("#restore").attr('disabled',true);
$("#delete").attr('disabled',true);
$("#transfer").attr('disabled',true);
$("button#new_maintenance").attr('disabled',true);
$("button#edit_maintenance").attr('disabled',true);
$("button#delete_maintenance").attr('disabled',true);
$("button#restore_maintenance").attr('disabled',true);

$("button#new_maintenanceHistory").attr('disabled',true);
$("button#edit_maintenanceHistory").attr('disabled',true);
$("button#delete_maintenanceHistory").attr('disabled',true);
$("button#restore_maintenanceHistory").attr('disabled',true);
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
	
		$("a[href='#itemHistory']").hide();	
		$("a[href='#maintenance']").hide();
		$("a[href='#maintenanceHistory']").hide();
		if($("button#new").attr("listType") == 'asset')
		{
			$("#modalTitle").text("Asset");
		}
		else
		{
			$("#modalTitle").text("Product");
		}
		
		$("#itemCode").attr("disabled", true);
		
		
		
	$.ajax({
		type: 'POST',
		url: 'productList.php',
		cache: false,
		data: "page="+page+"&searchQuery="+searchQuery+"&listType="+listType,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success: function(response)
		{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]);
			$('#product-list').html(arrResponse[0]);
			datagrid('product-list', true);
			setPageResponse(arrResponse[1]);
			
			$('#product-list table tr').click(function()
			{
				setCellContentValue($(this));
				itemCode = $(this).attr("a");
			});
		}
	});
	
}

	$(".page-nav li button").click(function(){
										
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
						
		setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
		loadData(page,searchQuery);
	});

function clear()
{
	$("div#new_prodAsset #category").val('<Auto>');
	$("div#new_prodAsset #subCategory").val('<Auto>');
	$("div#new_prodAsset #brand").val('...');
	$("div#new_prodAsset #unit").val('...');
	$("div#new_prodAsset #price").val('0');
	$("div#new_prodAsset #minimumstock").val('0');
	$("div#new_prodAsset #normalstock").val('0');
	$("div#new_prodAsset #remarks").val('');
	$("div#new_prodAsset #itemImage").val('');
	$("div#new_prodAsset table[ref='divDescription'] #desc").html("");
	$("div#new_prodAsset #description").empty();
}

$("div#edit_prodAsset #price").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});

$("div#edit_prodAsset #normalstock").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});

$("div#edit_prodAsset #minimumstock").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});

$("div#new_prodAsset #price").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});

$("div#new_prodAsset #normalstock").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});
$("div#new_prodAsset #minimumstock").bind("keypress", function(e) 
{ 
	if(e.which!=46 && (e.which<48 || e.which>57))
	{
		return(false);
	}
	if(e.which == 46 && $(this).val().indexOf(".") != -1)
	{
		return(false);
	}
});
		
		
		
		function addDesc()
		{
		
			$a=1;
			$exists = 0;
			$("div#new_prodAsset table[ref='divDescription'] #desc td").each(function(index)
			{
				if($a%2!=0)
				{
					if($(this).text() == $("div#new_prodAsset #description option:selected").text())
					{
						$exists = 1;
					}
				}
				$a++;
			});
			if($("div#new_prodAsset #description").val() == "0")
			{
			
			}
			else
			{
				if($exists==0 && $("div#new_prodAsset #description").val()!="0")
				{
					
					$.post('/EBMS/apps/view/inventory/productList/addDescription.php', {role:"add", desc:$("div#new_prodAsset #description option:selected").text(), fieldid:$("div#new_prodAsset #description").val(), productCode:$(item).attr('a')},
					function(response)
					{
						$("div#new_prodAsset table[ref='divDescription'] #desc").append(response);
						$("div#new_prodAsset table[ref='divDescription'] #desc tr").click(function()
						{
							$("div#new_prodAsset table[ref='divDescription'] #desc tr").removeClass("activeTr");
							$(this).addClass("activeTr");
							$("div#new_prodAsset #removeDescription").click(function()
							{
								$("div#new_prodAsset table[ref='divDescription'] #desc tr.activeTr").remove();
								$("div#new_prodAsset #description").val(0);
							});
						});
					});
				}
				else if($exists == 1)
				{
				alert('Duplicate record not allowed.');
				}
			}
		}
		
		$("div#edit_prodAsset #addDescription").click(function()
		{
			//addEditDesc();
		});
		
		function addEditDesc()
		{
		
			$a=1;
			$exists = 0;
			$("div#edit_prodAsset table[ref='divDescription'] #desc td").each(function(index)
			{
				if($a%2!=0)
				{
					if($(this).text() == $("div#edit_prodAsset #description option:selected").text())
					{
						$exists = 1;
					}
				}
				$a++;
			});
			if($("div#edit_prodAsset #description").val() == null)
			{
				
			}
			else
			{
				if($exists==0 && $("div#edit_prodAsset #description").val()!="0")
				{
					$.post('/EBMS/apps/view/inventory/productList/addDescription.php', {role:"add", desc:$("div#edit_prodAsset #description option:selected").text(), fieldid:$("div#edit_prodAsset #description").val(), productCode:$(item).attr('a')},
					function(response)
					{
						$("div#edit_prodAsset table[ref='divDescription'] #desc").append(response);
						$("div#edit_prodAsset table[ref='divDescription'] #desc tr").click(function()
							{
								$("div#edit_prodAsset table[ref='divDescription'] #desc tr").removeClass("activeTr");
								$(this).addClass("activeTr");
								$("div#edit_prodAsset #removeDescription").click(function()
								{
									$("div#edit_prodAsset table[ref='divDescription'] #desc tr.activeTr").remove();
									$("div#edit_prodAsset #description").val(0);
								});
							});
					});
				}
				else if($exists == 1)
				{
					alert('Duplicate record not allowed.');
				}
			}
			
		}
			
		$("div#new_prodAsset #save").click(function()
		{			
			$i=1;
			$isAllowed = 1;
			$("div#new_prodAsset table[ref='divDescription'] #desc td").each(function(index)
			{
				if($i%2==0)
				{
					if($(this).find("#txtValue").val().trim() ==null || $(this).find("#txtValue").val().trim() =="")
					{
						$isAllowed = 0;
					}
				}
				$i++;
			});
			if ($("div#new_prodAsset #category").val() == "" || $("div#new_prodAsset #category").val() == "<Auto>" || $("div#new_prodAsset #subCategory").val() == "" || $("div#new_prodAsset #unit").val() == "" || $("div#new_prodAsset #unit").val() == "..." || $("div#new_prodAsset #subcategory").val() == "<Auto>" || $("div#new_prodAsset #brand").val() == "" || $("div#new_prodAsset #brand").val() == "..." || $("div#new_prodAsset #price").val().trim() == "" || $("div#new_prodAsset #normalstock").val().trim() == "" || $("div#new_prodAsset #minimumstock").val().trim() == "")
			{
				alert('Please fill all the required fields.');
			}
			else if($("div#new_prodAsset table[ref='divDescription'] #desc tr").length == 0)
			{
				alert('Please insert a description.');
			}
			else if($isAllowed == 0)
			{
				alert('Please complete the details in the table.');
			}
			else
			{
				
				var what = "";
				var dataString = "";
				var tmp = $("div#new_prodAsset #itemImage").val().trim();
				var img = tmp.replace(/C:\\fakepath\\/i, '');
				$("div#new_prodAsset #image").ajaxForm().submit();
				
				if(listType=='product')
				{	
					dataString = "role=addproduct&image="+ img + "&remarks=" + $("div#new_prodAsset #remarks").val().trim() 
						+"&cat=" + $("div#new_prodAsset #category").val() + "&subCat="
						+ $("div#new_prodAsset #subCategory").val() + "&brand=" 
						+ $("div#new_prodAsset #brand").val() + "&price=" 
						+ $("div#new_prodAsset #price").val() + "&unit=" + $("div#new_prodAsset #unit").val() 
						+ "&min=" + $("div#new_prodAsset #minimumstock").val() + "&norm=" 
						+ $("div#new_prodAsset #normalstock").val();
					what = "Product";
				}
				else
				{
					dataString = "role=addasset&image="+ img + "&remarks=" + $("div#new_prodAsset #remarks").val().trim() 
						+"&cat=" + $("div#new_prodAsset #category").val() 
						+ "&subCat=" + $("div#new_prodAsset #subCategory").val() 	
						+ "&brand=" + $("div#new_prodAsset #brand").val() 
						+ "&price=" + $("div#new_prodAsset #price").val() 
						+ "&unit=" + $("div#new_prodAsset #unit").val() + "&min=" 
						+ $("div#new_prodAsset #minimumstock").val() + "&norm=" 
						+ $("div#new_prodAsset #normalstock").val();
						what = "Asset";
				}
				$.ajax({
					type: 'POST', 
					url: 'addItem.php',
					data: dataString,
					success: function(response)
					{
						$a=1;
						$exists = 0;
						$field="";
						$value="";
						$("div#new_prodAsset table[ref='divDescription'] #desc td").each(function(index)
						{
							if($a%2!=0)
							{
								$field = $(this).attr('fieldid');
							}
							else
							{
								$value = $(this).find("#txtValue").val().trim();
								$.post('/EBMS/apps/view/inventory/productList/insertFieldsDescription.php', {role:"add", field:$field, value:$value, productCode:response},
								function(result)
								{
									
								});
							}
							$a++;
						
						});
						alert('Record Created');
						$("div#new_prodAsset .formClose").click();
						loadData(1,searchQuery);
						clear();
					}
				});
				
				if (listType == 'product')
				{
					dataString = "role=" + "New" + "&noun=" + "Product record";
				}
				else
				{
					dataString = "role=" + "New" + "&noun=" + "Asset record";
				}
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
					type:"POST",
					data:dataString,
					success:
					function(response)
					{
					
					}
				});
			}
		});
///////////////////////////////////////////////////////////////////////////////////////////////////////	
		$("div#edit_prodAsset #save").click(function()
		{			
			$i=1;
			$isAllowed = 1;
			$("div#edit_prodAsset table[ref='divDescription'] #desc td").each(function(index)
			{
				if($i%2==0)
				{
					if($(this).find("#txtValue").val().trim() ==null || $(this).find("#txtValue").val().trim() =="")
					{
						$isAllowed = 0;
					}
				}
				$i++;
			});
			if ($("div#edit_prodAsset #category").val() == "" || $("div#edit_prodAsset #category").val() == "<Auto>" || $("div#edit_prodAsset #subCategory").val() == "" || $("div#edit_prodAsset #unit").val() == "" || $("div#edit_prodAsset #unit").val() == "..." || $("div#edit_prodAsset #subcategory").val() == "<Auto>" || $("div#edit_prodAsset #brand").val() == "" || $("div#edit_prodAsset #brand").val() == "..." || $("div#edit_prodAsset #price").val().trim() == "" || $("div#edit_prodAsset #normalstock").val().trim() == "" || $("div#edit_prodAsset #minimumstock").val().trim() == "")
			{
				alert('Please fill all the required fields.');
			}
			else if($("div#edit_prodAsset table[ref='divDescription'] #desc tr").length == 0)
			{
				alert('Please insert a description.');
			}
			else if($isAllowed == 0)
			{
				alert('Please complete the details in the table.');
			}
			else
			{
				var dataString = "";
				var tmp = $("div#edit_prodAsset #itemImage").val().trim();
				var img = tmp.replace(/C:\\fakepath\\/i, '');
				$("div#edit_prodAsset #image").ajaxForm().submit();
				dataString = "role=edit&image="+ img + "&remarks=" + $("div#edit_prodAsset #remarks").val().trim() 
					+"&cat=" + $("div#edit_prodAsset #category").val() + "&subCat="
					+ $("div#edit_prodAsset #subCategory").val() + "&brand=" 
					+ $("div#edit_prodAsset #brand").val() + "&price=" 
					+ $("div#edit_prodAsset #price").val().replace(/,/g,"") + "&unit=" + $("div#edit_prodAsset #unit").val() 
					+ "&min=" + $("div#edit_prodAsset #minimumstock").val() + "&norm=" 
					+ $("div#edit_prodAsset #normalstock").val()+ "&code=" + itemCode;
				
				
				$.ajax({
					type: 'POST', 
					url: 'addItem.php',
					data: dataString,
					success: function(response)
					{
						$.post('/EBMS/apps/view/inventory/productList/insertFieldsDescription.php', {role:"delete",productCode:response},
						function(result)
						{
						$a=1;
						$exists = 0;
						$field="";
						$value="";
						$("div#edit_prodAsset table[ref='divDescription'] #desc td").each(function(index)
						{
							if($a%2!=0)
							{
								$field = $(this).attr('fieldid');
							}
							else
							{
								$value = $(this).find("#txtValue").val().trim();
							
								$.post('/EBMS/apps/view/inventory/productList/insertFieldsDescription.php', {role:"add", field:$field, value:$value, productCode:response},
								function(result)
								{
								
								});
							}
							$a++;
						
						});
						
						$.ajax(
						{
							url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
							type:"POST",
							data:"module=" + "ProdAsset" + "&id=" + response,
							success:
							function(response2)
							{
								dataString = "role=" + "Edit" + "&noun=" + response2 +  " record" + "&code=" + response;
								$.ajax(
								{
									url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
									type:"POST",
									data:dataString,
									success:
									function(response)
									{
										
									}
								});
							}
						});
						
						alert('Record Updated');
						$("div#edit_prodAsset .formClose").click();
						loadData(1,searchQuery);
						
						});
						
					}
				});
			}
		});
////////////////////////////////////////////////////////////////////////////////////////////////////////		
		$("div#delete_prodAsset #save").click(function()
		{	
			$.post('/EBMS/apps/view/inventory/productList/updateItem.php', {role:"delete", item:itemCode},
			function(result)
			{
				//alert(result);
			});
				
			$.ajax(
			{	
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
				type:"POST",
				data:"module=" + "ProdAsset" + "&id=" + itemCode,
				success:
				function(response)
				{
					dataString = "role=" + "Delete" + "&noun=" + response + " record" + "&code=" + itemCode;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response2)
						{
							
						}
					});
				}
			});
			
			alert('Record Deleted');
			$("div#delete_prodAsset .formClose").click();
			loadData(1,searchQuery);
		});
		
		$("div#restore_prodAsset #save").click(function()
		{	
			$.post('/EBMS/apps/view/inventory/productList/updateItem.php', {role:"restore", item:itemCode},
			function(result)
			{
				//alert(result);
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
				type:"POST",
				data:"module=" + "ProdAsset" + "&id=" + itemCode,
				success:
				function(response)
				{
					dataString = "role=" + "Restore" + "&noun=" + response + " record" + "&code=" + itemCode;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response2)
						{
							
						}
					});
				}
			});
			
			alert('Record Restored');
			$("div#restore_prodAsset .formClose").click();
			loadData(1,searchQuery);
		});
		
		$("div#new_prodAsset .formClose").click(function()
		{
			clear();
		});
		
		$("div#new_prodAsset #brand").change(function()
		{
			$("div#new_prodAsset #description").html("<option value='0'>-Select Description-</option>");
			$("div#new_prodAsset table[ref='divDescription'] #desc").html("");
			var brandID = $(this).val();	
			$.post("../../systemRecords/fileMaintenance/brandManager/brandManager.php",{role:"Search",brandID:brandID},function(response)
			{
				var arrResponse = response.split("&&");
				$("div#new_prodAsset #category").attr("categoryID",arrResponse[0]);
				$("div#new_prodAsset #category").val(arrResponse[1]);
				$("div#new_prodAsset #subCategory").attr("subCategoryID",arrResponse[2]);
				$("div#new_prodAsset #subCategory").val(arrResponse[3]);
				dataString = "subcat=" + $("div#new_prodAsset #subCategory").val() + "&cat=" + $("div#new_prodAsset #category").val();
		
				$.ajax({
					type: 'POST', 
					url: 'description.php',
					data: dataString,
					success: function(result)
					{
						$("div#new_prodAsset #description").append(result);
					}
				});
			});
		});
		$("div#new_prodAsset #refreshdesc").click(function()
		{
			$("div#new_prodAsset #description").html("<option value='0'>-Select Description-</option>");
			dataString = "subcat=" + $("div#new_prodAsset #subCategory").val() + "&cat=" + $("div#new_prodAsset #category").val();
		
				$.ajax({
					type: 'POST', 
					url: 'description.php',
					data: dataString,
					success: function(result)
					{
						$("div#new_prodAsset #description").append(result);
					}
				});
		});
		
		$("div#edit_prodAsset #refreshdesc").click(function()
		{
			$("div#edit_prodAsset #description").html("<option value='0'>-Select Description-</option>");
			dataString = "subcat=" + $("div#edit_prodAsset #subCategory").val() + "&cat=" + $("div#edit_prodAsset #category").val();
		
				$.ajax({
					type: 'POST', 
					url: 'description.php',
					data: dataString,
					success: function(result)
					{
						$("div#edit_prodAsset #description").append(result);
					}
				});
		});
		
		$("div#edit_prodAsset #brand").change(function()
		{
			$("div#edit_prodAsset #description").html("<option value='0'>-Select Description-</option>");
			$("div#edit_prodAsset table[ref='divDescription'] #desc").html("");
			var brandID = $("div#edit_prodAsset #brand").val();	
			$.post("../../systemRecords/fileMaintenance/brandManager/brandManager.php",{role:"Search",brandID:brandID},function(response)
			{
				var arrResponse = response.split("&&");
				
				$("div#edit_prodAsset #category").attr("categoryID",arrResponse[0]);
				$("div#edit_prodAsset #category").val(arrResponse[1]);
				$("div#edit_prodAsset #subCategory").attr("subCategoryID",arrResponse[2]);
				$("div#edit_prodAsset #subCategory").val(arrResponse[3]);
				
					dataString = "subcat=" + $("div#edit_prodAsset #subCategory").val() + "&cat=" + $("div#edit_prodAsset #category").val();
				$.ajax({
					type: 'POST', 
					url: 'description.php',
					data: dataString,
					success: function(response)
					{
						$("div#edit_prodAsset #description").append(response);
					}
				});
			
			});
		
		});
		
		$("div#new_prodAsset #description").change(function()
		{
			addDesc();
		});
		$("div#edit_prodAsset #description").change(function()
		{
			addEditDesc();
		});
			

		$("#edit").click(function()
		{			
			$("div#edit_prodAsset #itemCode").attr("disabled",true);
			$("div#edit_prodAsset #brand").empty("");
			

			$.post("unit.php", function(response)
			{ 
				obj = JSON.parse(response);
				$("div#edit_prodAsset #unit").empty();
				for(i=0;i<obj.u.length;i++)
				{
					$("div#edit_prodAsset #unit").append("<option value='" +obj.u[i]+ "'>"+obj.u[i]+"</option>");
				}
			});	
			$.post("brand.php", function(result)
			{ 
				$("div#edit_prodAsset #brand").append(result);
			});	
			
			$.post("updateItem.php",{item:itemCode,role:"update"}, function(response)
			{
				obj = JSON.parse(response);
				$("div#edit_prodAsset #minimumstock").val(obj.values["min"]);
				$("div#edit_prodAsset #normalstock").val(obj.values["norm"]);
				$("div#edit_prodAsset #itemCode").val(itemCode);
				$("div#edit_prodAsset #brand").val(obj.values["brandID"]);
				$("div#edit_prodAsset #unit").val(obj.values["unit"]);
				$("div#edit_prodAsset #price").val(obj.values["price"]);
				$("div#edit_prodAsset #remarks").val(obj.values["remarks"]);
				
				
				
				var brandID = obj.values["brandID"];	
				$.post("../../systemRecords/fileMaintenance/brandManager/brandManager.php",{role:"Search",brandID:brandID},function(response)
				{
					$("div#edit_prodAsset #description").html("<option value='0'>-Select Description-</option>");
					var arrResponse = response.split("&&");
					
					$("div#edit_prodAsset #category").attr("categoryID",arrResponse[0]);
					$("div#edit_prodAsset #category").val(arrResponse[1]);
					$("div#edit_prodAsset #subCategory").attr("subCategoryID",arrResponse[2]);
					$("div#edit_prodAsset #subCategory").val(arrResponse[3]);
			
					dataString = "subcat=" + $("div#edit_prodAsset #subCategory").val() 
								+ "&cat=" + $("div#edit_prodAsset #category").val();
					$.ajax({
						type: 'POST', 
						url: 'description.php',
						data: dataString,
						success: function(result)
						{
							$("div#edit_prodAsset #description").append(result);
							$("div#edit_prodAsset table[ref='divDescription'] #desc tr").click(function()
							{
								$("div#edit_prodAsset table[ref='divDescription'] #desc tr").removeClass("activeTr");
								$(this).addClass("activeTr");
								$("div#edit_prodAsset #removeDescription").click(function()
								{
									$("div#edit_prodAsset table[ref='divDescription'] #desc tr.activeTr").remove();
									$("div#edit_prodAsset #description").val(0);
								});
							});
						}
					});
				});
				
				
				
			});
			$("div#edit_prodAsset table[ref='divDescription'] #desc").html("");
			$.post('/EBMS/apps/view/inventory/productList/addDescription.php', {role:"rows", productCode:itemCode}, function(rows)
			{
				for(i=0;i<rows;i++)
				{
					$.post('/EBMS/apps/view/inventory/productList/addDescription.php', {role:"view", productCode:itemCode}, function(response)
					{
						$("div#edit_prodAsset table[ref='divDescription'] #desc").html(response);
					});
				}
			});
			
			
		});
	
	function setCellContentValue(selector)
	{
		$("#product-list table").find("tr").removeClass("activeTr");
		$(selector).addClass("activeTr");
		item = selector;
		prodCode = $(selector).attr('a');
		
		$("button#new_maintenance").attr('disabled',false);
		$("button#edit_maintenance").attr('disabled',true);
		$("button#restore_maintenance").attr('disabled',true);
		$("button#delete_maintenance").attr('disabled',true);
		
		$("button#new_maintenanceHistory").attr('disabled',false);
		$("button#edit_maintenanceHistory").attr('disabled',true);
		$("button#restore_maintenanceHistory").attr('disabled',true);
		$("button#delete_maintenanceHistory").attr('disabled',true);
		
		$.post('/EBMS/apps/view/inventory/productList/itemHistory.php', {productCode:$(item).attr('a')},
		function(response)
		{
			$('#itemHistoryGrid').html(response);
			datagrid('itemHistoryGrid', true);
		});
		
		$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"view",code:$(item).attr('a')},
		function(response)
		{
			$('#maintenanceGrid').html(response);
			datagrid('maintenanceGrid', true);
			maintenanceGrid();
		});
		
		$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"view",code:$(item).attr('a')},
		function(response)
		{
			$('#maintenanceHistoryGrid').html(response);
			datagrid('maintenanceHistoryGrid', true);
			maintenanceHistoryGrid();
		});
		
		
		$.post('/EBMS/apps/view/inventory/productList/generalDescription.php', {productCode:$(item).attr('a')},
		function(response)
		{
			$('#generalTab').html(response);
			datagrid('generalTab', true);
		});
		if($(selector).attr('deleted') == "true")
		{
			$("#edit").attr('disabled',true);
			$("#delete").attr('disabled',true);
			$("#restore").attr('disabled',false);
			$("#transfer").attr('disabled',true);
		}
		else if($(selector).attr('deleted') == "false")
		{
			$("#edit").attr('disabled',false);
			$("#delete").attr('disabled',false);
			$("#restore").attr('disabled',true);
			$("#transfer").attr('disabled',false);
		}
	}
	
	function maintenanceHistoryGrid()
	{
		$('#maintenanceHistoryGrid table tr').click(function()
		{
			$("#maintenanceHistoryGrid table").find("tr").removeClass("activeTr");
			$(this).addClass("activeTr");
			historyid = $(this).attr("historyID");
			if($(this).attr("deleted")=="false")
			{
				$("button#edit_maintenanceHistory").attr('disabled',false);
				$("button#restore_maintenanceHistory").attr('disabled',true);
				$("button#delete_maintenanceHistory").attr('disabled',false);
			}
			else
			{
				$("button#edit_maintenanceHistory").attr('disabled',true);
				$("button#restore_maintenanceHistory").attr('disabled',false);
				$("button#delete_maintenanceHistory").attr('disabled',true);
			}
		});
	}
	
	function maintenanceGrid()
	{
	
		$('#maintenanceGrid table tr').click(function()
		{
			$("#maintenanceGrid table").find("tr").removeClass("activeTr");
			$(this).addClass("activeTr");
			maintenanceid = $(this).attr("maintenanceID");
					
			if($(this).attr("deleted")=="false")
			{
				$("button#edit_maintenance").attr('disabled',false);
				$("button#restore_maintenance").attr('disabled',true);
				$("button#delete_maintenance").attr('disabled',false);
			}
			else
			{
				$("button#edit_maintenance").attr('disabled',true);
				$("button#restore_maintenance").attr('disabled',false);
				$("button#delete_maintenance").attr('disabled',true);
			}
		});
	
	}
	
	$("div#new_maintenanceHistory #save").click(function()
	{
		$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"add",code:$(item).attr('a'),date:$("div#new_maintenanceHistory #addDate").val(),person:$("div#new_maintenanceHistory #personName").val(),contact:$("div#new_maintenanceHistory #contactNo").val(),findings:$("div#new_maintenanceHistory #findings").val(),steps:$("div#new_maintenanceHistory #steps").val()},
		function(result)
		{
			dataString = "role=" + "New Maintenance History" + "&noun=" + "Maintenance history record" + "&code=" + $(item).attr('a');
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					
				}
			});
		
			alert('Maintenance history created');
			$("div#new_maintenanceHistory .formClose").click();
			$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"view",code:$(item).attr('a')},
			function(response)
			{
				$('#maintenanceHistoryGrid').html(response);
				datagrid('maintenanceHistoryGrid', true);
				maintenanceHistoryGrid();
			});
		});
	});
	
	$("div#edit_maintenanceHistory #save").click(function()
	{
		$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"update",id:historyid,date:$("div#edit_maintenanceHistory #editDate").val(),person:$("div#edit_maintenanceHistory #personName").val(),contact:$("div#edit_maintenanceHistory #contactNo").val(),findings:$("div#edit_maintenanceHistory #findings").val(),steps:$("div#edit_maintenanceHistory #steps").val()},
		function(result)
		{
			dataString = "role=" + "Edit Maintenance History" + "&noun=" + "Maintenance history record" + "&code=" + $(item).attr('a');
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					
				}
			});
		
			alert('Maintenance history updated');
			$("div#edit_maintenanceHistory .formClose").click();
			$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"view",code:$(item).attr('a')},
			function(response)
			{
				$('#maintenanceHistoryGrid').html(response);
				datagrid('maintenanceHistoryGrid', true);
				maintenanceHistoryGrid();
			});
		});
	});
	
	$("div#delete_maintenanceHistory #save").click(function()
	{
		$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"delete",id:historyid},
		function(result)
		{
			dataString = "role=" + "Delete Maintenance History" + "&noun=" + "Maintenance history record" + "&code=" + $(item).attr('a');
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					
				}
			});
		
			alert('Maintenance history deleted');
			$("div#edit_maintenanceHistory .formClose").click();
			$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"view",code:$(item).attr('a')},
			function(response)
			{
				$('#maintenanceHistoryGrid').html(response);
				datagrid('maintenanceHistoryGrid', true);
				maintenanceHistoryGrid();
			});
		});
	});
	
	$("div#restore_maintenanceHistory #save").click(function()
	{
		$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"restore",id:historyid},
		function(result)
		{
			dataString = "role=" + "Restore Maintenance History" + "&noun=" + "Maintenance history record" + "&code=" + $(item).attr('a');
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					
				}
			});
		
			alert('Maintenance history restored');
			$("div#edit_maintenanceHistory .formClose").click();
			$.post('/EBMS/apps/view/inventory/productList/maintenanceHistory.php', {role:"view",code:$(item).attr('a')},
			function(response)
			{
				$('#maintenanceHistoryGrid').html(response);
				datagrid('maintenanceHistoryGrid', true);
				maintenanceHistoryGrid();
			});
		});
	});
	
	$("div#new_maintenance #save").click(function()
	{
	$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"add", code:$(item).attr('a'), date:$("div#new_maintenance #addAlertDate").val(), remind:$("div#new_maintenance #remindEvery").val(), time:$("div#new_maintenance #alertTime").val(), subject:$("div#new_maintenance #subject").val(), note: $("div#new_maintenance #note").val(), status: $("div#new_maintenance #status").val()},
	function(result)
	{
		dataString = "role=" + "New Maintenance" + "&noun=" + "Maintenance reminder" + "&code=" + $(item).attr('a');
		$.ajax(
		{
			url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
				
			}
		});
	
		alert('Maintenance reminder created');
		$("div#new_maintenance .formClose").click();
		
		$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"view",code:$(item).attr('a')},
		function(response)
		{
			$('#maintenanceGrid').html(response);
			datagrid('maintenanceGrid', true);
			maintenanceGrid();
		});
	});
	});
	
	$("div#maintenanceHistory button#edit_maintenanceHistory").click(function()
	{
		$.post("maintenanceHistory.php",{role:"render",id:historyid}, function(response)
		{
			obj = JSON.parse(response);
			$("div#edit_maintenanceHistory #personName").val(obj.datum["person"]);
			$("div#edit_maintenanceHistory #findings").val(obj.datum["findings"]);
			$("div#edit_maintenanceHistory #steps").val(obj.datum["steps"]);
			$("div#edit_maintenanceHistory #contactNo").val(obj.datum["contact"]);
			$("div#edit_maintenanceHistory #editDate").val(obj.datum["date"]);
			
		});
	});
	
	$("div#maintenance button#edit_maintenance").click(function()
	{
		$.post("maintenance.php",{role:"render",id:maintenanceid}, function(response)
		{
			obj = JSON.parse(response);
			$("div#edit_maintenance #subject").val(obj.details["subjectMaintenance"]);
			$("div#edit_maintenance #note").val(obj.details["noteMaintenance"]);
			$("div#edit_maintenance #editAlertDate").val(obj.details["alertDate"]);
			$("div#edit_maintenance #editAlertTime").val(obj.details["alertTime"]);
			$("div#edit_maintenance #status").val(obj.details["statusMaintenance"]);
			$("div#edit_maintenance #remindEvery").val(obj.details["remindEvery"]);
			
		});
	});
	
	$("div#edit_maintenance #save").click(function()
	{
	$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"update", id:maintenanceid, date:$("div#edit_maintenance #editAlertDate").val(), remind:$("div#edit_maintenance #remindEvery").val(), time:$("div#edit_maintenance #editAlertTime").val(), subject:$("div#edit_maintenance #subject").val(), note: $("div#edit_maintenance #note").val(), status: $("div#edit_maintenance #status").val()},
	function(result)
	{
		dataString = "role=" + "Edit Maintenance" + "&noun=" + "Maintenance reminder" + "&code=" + $(item).attr('a');
		$.ajax(
		{
			url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
			
			}
		});
	
		alert('Maintenance reminder updated');
		$("div#edit_maintenance .formClose").click();
		
		$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"view",code:$(item).attr('a')},
		function(response)
		{
			$('#maintenanceGrid').html(response);
			datagrid('maintenanceGrid', true);
			maintenanceGrid();
		});
	});
	
	});
	
	$("div#delete_maintenance #save").click(function()
	{
	$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"delete", id:maintenanceid},
	function(result)
	{
		dataString = "role=" + "Delete Maintenance" + "&noun=" + "Maintenance reminder" + "&code=" + $(item).attr('a');
		$.ajax(
		{
			url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
			
			}
		});
		
		alert('Maintenance reminder deleted');
		$("div#edit_maintenance .formClose").click();
		
		$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"view",code:$(item).attr('a')},
		function(response)
		{
			$('#maintenanceGrid').html(response);
			datagrid('maintenanceGrid', true);
			maintenanceGrid();
		});
	});
	
	});
	
	$("div#restore_maintenance #save").click(function()
	{
	$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"restore", id:maintenanceid},
	function(result)
	{
		dataString = "role=" + "Restore Maintenance" + "&noun=" + "Maintenance reminder" + "&code=" + $(item).attr('a');
		$.ajax(
		{
			url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
			
			}
		});		
		
		alert('Maintenance reminder restored');
		$("div#edit_maintenance .formClose").click();
		
		$.post('/EBMS/apps/view/inventory/productList/maintenance.php', {role:"view",code:$(item).attr('a')},
		function(response)
		{
			$('#maintenanceGrid').html(response);
			datagrid('maintenanceGrid', true);
			maintenanceGrid();
		});
	});
	
	});
	$('#alertTime,#editAlertTime').timepicker({
		ampm: true});
	
	$("div#new_maintenanceHistory #addDate").bind("keypress", function(e) 
	{ 
		return(false);
	});
	
	$("div#edit_maintenanceHistory #editDate").bind("keypress", function(e) 
	{ 
		return(false);
	});
	
	$("div#new_maintenance #addAlertDate").bind("keypress", function(e) 
	{ 
		return(false);
	});
	
	$("div#edit_maintenance #editAlertDate").bind("keypress", function(e) 
	{ 
		return(false);
	});
	
	$("#pdf").click(function()
	{
		if($("#productAssetList").val()=='product')
		{
			$.ajax({
				type: 'POST',
				url: '/EBMS/apps/view/reports/ProductList/productCode.php',
				data: {productCode:$(item).attr('a')},
				cache: false,
				success: function()
				{
					window.open("/ebms/apps/view/reports/product/productStock.php","_blank");
				}
			});
			return false;
		}
		else
		{
			$.ajax({
				type: 'POST',
				url: '/EBMS/apps/view/reports/ProductList/productCode.php',
				data: {productCode:$(item).attr('a')},
				cache: false,
				success: function()
				{
					window.open("/ebms/apps/view/reports/product/suppliesStock.php","_blank");
				}
			});
			return false;
		}
	});
	
	$("div#itemHistory #pdf").click(function()
	{
		$.ajax({
			type: 'POST',
			url: '/EBMS/apps/view/reports/ProductList/productCode.php',
			data: {productCode:$(item).attr('a')},
			cache: false,
			success: function()
			{
				window.open("/EBMS/apps/view/reports/ProductList/itemHistory.php","_blank");
			}
		});
		return false;
	});

</script>