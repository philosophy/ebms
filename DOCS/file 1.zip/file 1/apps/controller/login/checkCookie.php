<script>
	if ($.cookie("userIsLogin") == null || $.cookie("userIsLogin") == "")
	{
		$.ajax(
		{
			url:"/ebms/apps/controller/logout/logoutOnBrowserClose2.php",
			type:"POST",
			data:"username=" + $.cookie("userUsername"),
			success:
			function(response)
			{
				
			}
		});	
	}
</script>