<?php 
session_start();
require("../../../config/config.php");


//post login form values to php variables
$uname = $_POST['uname'];
$pword = $_POST['pword'];

$result = mysql_query("
	SELECT * FROM user_account u 
	WHERE u.USER_NAME = '$uname' 
	AND u.USER_PASSWORD  = sha('$pword')
	");
$empresult = mysql_query("
	SELECT emp_id FROM user_account u 
	WHERE u.USER_NAME = '$uname' 
	AND u.USER_PASSWORD  = sha('$pword')
	");

	if(mysql_fetch_row($result)>0)
		{
		echo "correct";
		$empID = mysql_fetch_array($empresult);
		$emp = $empID['emp_id'];
		
		$_SESSION['emp_id'] = $emp;
		$_SESSION['login'] = $emp;
		$_SESSION['uname'] = $uname;
		mysql_query("INSERT INTO audit_trail (AUDIT_DATE,AUDIT_TIME,AUDIT_ACTION_TAKEN,EMP_ID) VALUES (curdate(),curtime(),'The user logged in',".$emp.")");
		}
	
	elseif (mysql_fetch_row($result)==0)
		{
		echo "incorrect";
		}
		
	
?>