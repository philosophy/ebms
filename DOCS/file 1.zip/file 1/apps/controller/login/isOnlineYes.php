<?php
	include("../../../config/config.php");
	$outputData = "";
	$uname = $_POST['uname'];
	$pword = $_POST['pword'];
	
	$result = mysql_query("Select * From user_account Where USER_NAME = '" . $uname . "' and USER_PASSWORD = sha('" . $pword . "')");
	// SELECT * FROM user_account u 
	// WHERE u.USER_NAME = '$uname' 
	// AND u.USER_PASSWORD  = sha('$pword')
	// ");
	if (mysql_num_rows($result) > 0)
	{
		while ($arr = mysql_fetch_array($result))
		{
			$toOnline = $arr['USER_ID'];
			if ($arr['IS_ONLINE'] == 0)
			{
				$query = mysql_query("Update user_account Set IS_ONLINE = '1' Where USER_ID = '" . $toOnline . "'");
				$outputData = "Not logged in";
			}
			else
			{
				$outputData = "Logged in";
			}
		}
	}
	echo $outputData;
?>