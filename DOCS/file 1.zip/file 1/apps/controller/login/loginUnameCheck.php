﻿<?php 

session_start();
require("../../../config/config.php");

$uname = $_POST['uname'];

	$query = mysql_query("
						SELECT user_name 
						FROM user_account u 
						WHERE user_name = '$uname'
						");
		
		if(mysql_num_rows($query) <= 0)
		{
		echo "Oops... Seems like the username '<b>".$uname."</b>' does not exist. Please try again";
		}
		
		else 
		{
		echo "";
		}
		
mysql_free_result($query);

						