
<script>

var init,page;

var searchQuery="";
var dr = "";
var os = "";
function initialize()
	{
	//initialize search input value 
	init = $("#datagrid-search-box").val().trim();
	$("#edit").attr("disabled", true);
	$("#restore").attr("disabled", true);
	$("#delete").attr("disabled", true);
	$("#print").attr("disabled", true);
	}
//by default, the first page will be displayed
loadData(1,searchQuery);

$("#edit").attr('title', 'Edit Delivery Receipt');
$("#delete").attr('title', 'Delete Delivery Receipt');
$("#restore").attr('title', 'Restore Delivery Receipt');

function loadData(page,searchQuery)
{
initialize();
	if(init == "" || init == "Search...")
		{
		searchQuery = "";
		}
	
	else 
		{
		searchQuery = init;
		}
		
	$.ajax({
		url:'/EBMS/apps/view/sales/deliveryReceipt/drList.php', 
		type: "POST",
		data: "page="+page+"&searchQuery="+searchQuery,
				cache: false,
				beforeSend:
				function()
				{
				$("#loading").fadeTo("slow",0.7).show();
				},
		success:
			function(response)
			{
			$("#loading").fadeTo("slow",0).hide();
			var arrResponse = response.split('&');
				
			setPageBtnValue(arrResponse[2],arrResponse[3]); 
				
			$('#drList').html(arrResponse[0]);
			datagrid('drList', true);
			setPageResponse(arrResponse[1]);
				
			$("#drList table tr").click(function()
			{
			setCellContentValue($(this));
						
			});
			}
			});
}


	$(".page-nav li button").click(function(){
							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
			
		});
	
	function setCellContentValue(selector)
	{
		
		if($(selector).attr("deleted") == "true")
			deleted();
		else
			restored();
			
		//remove all active classes in tr element
		$("#drList table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		dr = $(selector).attr('a');
		os = $(selector).attr('y');
		$.post('/EBMS/apps/view/reports/sales/report.php', {drNo:$(selector).attr('a')});
		$.post('/EBMS/apps/view/sales/deliveryReceipt/drDetails.php', {drCode:$(selector).attr('a')},
		function(response)
		{
			$('#drDetails').html(response);
			datagrid('drDetails', true);
		});
	}
	
	$("#delete_dr #save").click(function(){
		$.post('/EBMS/apps/view/sales/deliveryReceipt/deleteDr.php', {drCode:dr});
		
		dataString = "role=" + "Delete" + "&noun=" + "Delivery receipt" + "&code=" + dr;
		$.ajax(
		{
			url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
				
			}
		});
		
		$("div#delete_dr.modalForm").fadeOut("slow",0,
				function()
				{
					$(".formFade").fadeOut(300,
				function(){
					$(".formFade").remove();
				});
					$("div#delete_crm.modalForm").hide();
				});
		loadData(1,searchQuery);
	});
	
	$("#restore_dr #save").click(function(){
		$.post('/EBMS/apps/view/sales/deliveryReceipt/restoreDr.php', {drCode:dr});
		
		dataString = "role=" + "Restore" + "&noun=" + "Delivery receipt" + "&code=" + dr;
		$.ajax(
		{
			url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
			type:"POST",
			data:dataString,
			success:
			function(response)
			{
				
			}
		});
		
		$("div#restore_dr.modalForm").fadeOut("slow",0,
					function()
					{
						$(".formFade").fadeOut(300,
					function(){
						$(".formFade").remove();
					});
					    $("div#restore_crm.modalForm").hide();
					});
		loadData(1,searchQuery);
		
		
	});
	
	$("#edit").click(function(){
		$("#edit_dr #drNo").val(dr).attr("disabled", true);
		$("#edit_dr #shipTo").attr("disabled", true);
		$("#edit_dr #orderedItems").html("");
		$("#edit_dr #refNo").val(os).attr("disabled", true)
		$.post('/EBMS/apps/view/sales/deliveryReceipt/getOrderedItems.php', {osCode:os},
		function(response)
		{
			obj = JSON.parse(response);
			 for(x = 0; x < obj.values.length; x++)
			 {
				arrayItems = obj.values[x].split("~");
				$("#edit_dr #orderedItems").append("<tr><td><input type='number' disabled id='qty' value='"+arrayItems[0]+"' style='width:70px;'></td><td id='itemId'>"+arrayItems[1]+"</td><td id='unitPrice' style='text-align:right'>"+arrayItems[3]+"</td><td id='description'>"+arrayItems[2]+"</td></tr>");
			 }
		});
		
		fillData();
		$.post('/EBMS/apps/view/sales/deliveryReceipt/importDr.php', {osCode:os},
		function(response)
		{
		 obj = JSON.parse(response);
		 $("#edit_dr #customer").val(obj.values['customerId']).attr("disabled", true);		
		 $("#edit_dr #location").empty();
			$("#edit_dr #location").append("<option value='...'>...</option>");
			$.post('/EBMS/apps/view/sales/orderSlip/getLocation.php',{customer:obj.values['customerId']}, function(response){
				$("#edit_dr #location").append(response);
				$.post('/EBMS/apps/view/sales/deliveryReceipt/getData.php', {drCode:dr}, 
				function(response)
				{
					obj = JSON.parse(response);
					$("#edit_dr #deliveredBy").val(obj.values['deliver']);
					$("#edit_dr #shipTo").text(obj.values['address']);
					$("#edit_dr #location").val(obj.values['shipToId']);
					$("#edit_dr #area2").val(obj.values['area']);
					
					$("#edit_dr #contact").empty();
					$("#edit_dr #contact").append("<option value='...'>...</option>");
					$.post('/EBMS/apps/view/sales/deliveryReceipt/getContact.php',
					{locationId:$("#edit_dr #location").val()}, 
					function(response)
					{
						$("#edit_dr #contact").append(response);
						var x = response.split(",");
						$("#edit_dr #shipTo").val(x[1]).attr("disabled", true);
						$("#edit_dr #contact").val(obj.values['contact']);
					});

				});
				
			});

			
			
		 $("#edit_dr #city").val(obj.values['city']);
			$("#edit_dr #barangay").empty();
			$("#edit_dr #barangay").append("<option value='...'>...</option>");
			$.post('/EBMS/apps/view/sales/deliveryReceipt/barangay.php',{cityId:obj.values['city']}, function(response){
				$("#edit_dr #barangay").append(response);
			$("#edit_dr #barangay").val(obj.values['barangay']);
			});
		$("#edit_dr #address").val(obj.values['address']).attr("disabled", true);
		$("#edit_dr #area1").val(obj.values['areaId']);
		$("#edit_dr #salesPerson").val(obj.values['empName']).attr("disabled", true);
		$("#edit_dr #grossAmount").val(obj.values['grossAmount']).attr("disabled", true);
		$("#edit_dr #netAmount").val(obj.values['netAmount']).attr("disabled", true);
		$("#edit_dr #netAmount").val(obj.values['netAmount']).attr("disabled", true);
		$("#edit_dr #discount").val(obj.values['discount']+'%').attr("disabled", true);
		});		
	});	
	
	$("#edit_dr #save").click(function(){
		if($("#edit_dr #deliveredBy").val() == "..." ||  $("#edit_dr #location").val() == "..." || $("#edit_dr #contact").val() == "..." || $("#edit_dr #area2").val() == "..." )
		{
			alert("Please fill up required fields (*).");
		}
		
		else
		{
			drNo = dr;
			deliveredBy = $("#edit_dr #deliveredBy").val();
			shipToId = $("#edit_dr #location").val();
			area = $("#edit_dr #area2").val();
			contact = $("#edit_dr #contact").val();
			remarks = $("#edit_dr #remarks").val();
			dataString = "drNo="+drNo+"&deliver="+deliveredBy+"&shipToId="+shipToId+"&area="+area+"&contact="+contact+"&remarks="+remarks;
			// alert(dataString);
			$.ajax({
			type: "POST",
			url:'/EBMS/apps/view/sales/deliveryReceipt/updateDr.php', 
			data: dataString,
			success:
			function(response)
			{	
				// alert(response);
				
				dataString = "role=" + "Edit" + "&noun=" + "Delivery receipt" + "&code=" + drNo;
				$.ajax(
				{
					url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
					type:"POST",
					data:dataString,
					success:
					function(response)
					{
						
					}
				});
				
				var x = confirm("Do you want to print delivery slip?")
				if(x == true)
				{
					window.open('/EBMS/apps/view/reports/sales/deliveryReceipt.php', 'Delivery Receipt');								
				}
				
				$("div#import_OS.modalForm").fadeOut("slow",0,
				function()
				{	
					$(".formFade").fadeOut(300,
				function(){
					$(".formFade").remove();
				});
					$("div#new_OS.modalForm").hide();
				});
				window.location = '/EBMS/apps/view/sales/deliveryReceipt/';
			}
			});
		}
	});
	
	
	function fillData()
	{
		$("#edit_dr #customer").empty();
		$("#edit_dr #customer").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/orderSlip/getCustomer.php', function(response){
			$("#edit_dr #customer").append(response);
		});
		
		$("#edit_dr #city").empty();
		$("#edit_dr #city").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/city.php', function(response){
			$("#edit_dr #city").append(response);
		
		});
		
		$("#edit_dr #area1").empty();
		$("#edit_dr #area1").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/area.php', function(response){
			$("#edit_dr #area1").append(response);
			
		});
		
		$("#edit_dr #area2").empty();
		$("#edit_dr #area2").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/area.php', function(response){
			$("#edit_dr #area2").append(response);
			
		});
		
		$("#edit_dr #deliveredBy").empty();
		$("#edit_dr #deliveredBy").append("<option value='...'>...</option>");
		$.post('/EBMS/apps/view/sales/deliveryReceipt/employee.php', function(response){
			$("#edit_dr #deliveredBy").append(response);
			
		});
		
	}
	

	
	
	
	function deleted()
	{
		$("#edit").attr("disabled", true);
		$("#restore").attr("disabled", false);
		$("#delete").attr("disabled", true);
		$("#pdf").unbind("click");
	}
	
	function restored()
	{
		$("#edit").attr("disabled", false);
		$("#restore").attr("disabled", true);
		$("#delete").attr("disabled", false);
		$("#pdf").bind("click");
	}
			
	
	$("#pdf").click(function(){
			
			window.open('/EBMS/apps/view/reports/sales/deliveryReceipt.php', 'Delivery Receipt');
		});
	
</script>