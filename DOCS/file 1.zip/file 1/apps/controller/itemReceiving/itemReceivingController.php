
<script>

var init,page;
var recId;

var searchQuery="";

	function initialize()
	{
		//initialize search input value 
		init = $("#datagrid-search-box").val().trim();
	}
	
	//by default, the first page will be displayed
	loadData(1,searchQuery);
	
	$("#new").attr('title', 'New Receiving Record');
	$("#edit").attr('title', 'Edit Receiving Record');
	
	$("#edit").attr('disabled', true);

	function loadData(page,searchQuery)
	{
		initialize();
		if(init == "" || init == "Search...")
		{
			searchQuery = "";
		}
		
		else 
		{
			searchQuery = init;
		}
			
		$.ajax(
		{
			url:'/EBMS/apps/view/inventory/itemReceiving/receivingList.php', 
			type: "POST",
			data: "page="+page+"&searchQuery="+searchQuery,
					cache: false,
					beforeSend:
					function()
					{
					$("#loading").fadeTo("slow",0.7).show();
					},
			success:
				function(response)
				{
					$("#loading").fadeTo("slow",0).hide();
					var arrResponse = response.split('&');
						
					setPageBtnValue(arrResponse[2],arrResponse[3]); 
						
					$('#receivingList').html(arrResponse[0]);
					datagrid('receivingList', true);
					setPageResponse(arrResponse[1]);
						
					$("#receivingList table tr").click(function()
					{
						setCellContentValue($(this));
						recId = $(this).attr('a');
						$("#edit").attr('recId', recId);
						$("#edit").attr('disabled', false);
					});
				}
		});
	}
	
	$(".page-nav li button").click(function()
	{							
		var activeBtn = $(this).attr("id");
		var cur_page = Number($(this).attr("cur_page"));
		var no_of_paginations = Number($(this).attr("no_of_pagination"));
			
			setPageBtnBehavior(cur_page,no_of_paginations,activeBtn);
			loadData(page,searchQuery);
	});
	
	function setCellContentValue(selector)
	{
		//remove all active classes in tr element
		$("#receivingList table").find("tr").removeClass("activeTr");
					
		//then, set the active class to the clicked tr element
		$(selector).addClass("activeTr");
		
		$.post('/EBMS/apps/view/inventory/itemReceiving/receivingDetails.php', {receiveCode:$(selector).attr('a')},
		function(response)
		{
			$('#receivingDetails').html(response);
			datagrid('receivingDetails', true);
		});
	}	
	
	var id = 0;
	
	$("div#new_itemReceiving #importFrom").change(function()
	{
		// alert($(this).val());
		
		if ($(this).val() == "PO")
		{
			reset();
		
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/importFromWd.php",
				type:"POST",
				data:"type=" + $(this).val(),
				success:
				function(response)
				{
					$("div#new_itemReceiving table[ref = 'withHdr'] tbody#header").html("<th>PO Code</th> <th>Date Requested</th> <th>Payment Type</th> <th>Contact Name</th> <th>Net Amount</th>");
					
					$("div#new_itemReceiving table[ref = 'withHdr'] tbody#withdrawnItems").html(response);
					
					datagrid('new_itemReceiving', true);
					
					$("div#new_itemReceiving tbody#withdrawnItems tr").click(function()
					{
						setCellContentValuePoHdr($(this));
						// alert($(this).attr('a'));
						id = $(this).attr('a');
					});
				}
			});
		}
		else if ($(this).val() == "WD")
		{
			reset();
		
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/importFromWd.php",
				type:"POST",
				data:"type=" + $(this).val(),
				success:
				function(response)
				{
					$("div#new_itemReceiving table[ref = 'withHdr'] tbody#header").html("<th>Withdrawal Code</th> <th>Date Withdrawn</th> <th>Purpose</th> <th>Withdrawn To</th> <th>Type</th>");
				
					$("div#new_itemReceiving table[ref = 'withHdr'] tbody#withdrawnItems").html(response);
					
					datagrid('new_itemReceiving', true);
					// datagrid("#withdrawnItems", true);
					// alert(response);
				
					$("div#new_itemReceiving tbody#withdrawnItems tr").click(function()
					{
						setCellContentValueWithHdr($(this));
						// alert($(this).attr('a'));
						id = $(this).attr('a');
					});
				}	
			});
		}
		else if ($(this).val() == "")
		{
			reset();
		
			// alert($("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").length);
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/importFromWd.php",
				type:"POST",
				data:"type=" + $(this).val(),
				success:
				function(response)
				{
					$("div#new_itemReceiving table[ref = 'withHdr'] tbody#withdrawnItems").html(response);
				
					$("div#new_itemReceiving table[ref = 'withHdr'] tbody#withdrawnItems tr").click(function()
					{
						// alert($(this).attr('a'));
						setCellContentValueWithHdr($(this));
						
					});
					}	
			});
			
			$.post('/ebms/apps/view/modalForms/inventory/itemReceiving/withdrawalDetailList.php', {hdrId:""},
			function (response)
			{
				$("div#new_itemReceiving ul.gridViewNav").html(response);
				
				$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").html("");
			});
		}
	});
	
	function reset()
	{
		$("div#new_itemReceiving #receiveFrom").val("");
		$("div#new_itemReceiving #location").val("");
		$("div#new_itemReceiving #address").val("");
		$("div#new_itemReceiving #contactName").html("<option value=''></option>");
		$("div#new_itemReceiving #department").val("");
		$("div#new_itemReceiving #position").val("");
		$("div#new_itemReceiving #remarks").val("");
		
		$.post('/ebms/apps/view/modalForms/inventory/itemReceiving/withdrawalDetailList.php', {hdrId:""},
		function (response)
		{
			$("div#new_itemReceiving ul.gridViewNav").html(response);
			
			$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").html("");
		});
	}
	
//=======================================================================PO DETAILS=====================================================================================
	
	function setCellContentValuePoHdr(selector)
	{
		$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").html("");
		
		$("div#new_itemReceiving #withdrawnItems tr").removeClass("activeTr");
		
		$(selector).addClass("activeTr");
		
		// alert($(selector).attr('a'));
		
		//=====================================================PO DETAILS=======================================================================
		
		$.ajax(
		{
			url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getReceiveFrom.php",
			type:"POST",
			data:"withHdrId=" + $(selector).attr('a') + "&from=PO",
			success:
			function(response)
			{
				$("div#new_itemReceiving #receiveFrom").val(response);
				// alert(response);
			}
		});
		
		$.ajax(
		{
			url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getLocation.php",
			type:"POST",
			data:"withHdrId=" + $(selector).attr('a') + "&from=PO",
			success:
			function(response)
			{
				// alert(response);
				var kahitAno = response.split('&&');
				
				$("div#new_itemReceiving #location").val(kahitAno[1]);
				$("div#new_itemReceiving #location").attr('locationId', kahitAno[0]);				
		
				$.ajax(
				{
					url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getAddress.php", 
					type:"POST",
					data:"withHdrId=" + $(selector).attr('a') + "&from=PO",
					success:
					function(response)
					{
						// alert(response);
						$("div#new_itemReceiving #address").val(response);
					}
				});
				
				if ($("div#new_itemReceiving #location").val() == "N/A")
				{
					$("div#new_itemReceiving #contactName").html("<option value=''>N/A</option>");
					$("div#new_itemReceiving #department").val("N/A");
					$("div#new_itemReceiving #position").val("N/A");
				}
				// else if ($("div#new_itemReceiving #location").val() != "N/A")
				// {
					// $.ajax(
					// {
						// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactName.php",
						// type:"POST",
						// data:"locationId=" + $("div#new_itemReceiving #location").attr('locationId'),
						// success:
						// function(response)
						// {
							// // alert(response);
							// $("div#new_itemReceiving #contactName").html(response);
							
							// // alert($("div#new_itemReceiving #contactName option").size());
							// if ($("div#new_itemReceiving #contactName option").size() == 1)
							// {
								// $.ajax(
								// {
									// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactDepartment.php",
									// type:"POST",
									// data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
									// success:
									// function(response)
									// {
										// // alert(response);
										// $("div#new_itemReceiving #department").val(response);
									// }
								// });
								
								// $.ajax(
								// {
									// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactPosition.php",
									// type:"POST",
									// data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
									// success:
									// function(response)
									// {
										// // alert(response);
										// $("div#new_itemReceiving #position").val(response);
									// }
								// });
							// }
							// else if ($("div#new_itemReceiving #contactName option").size() > 1)
							// {
								// $("div#new_itemReceiving #department").val("");
								// $("div#new_itemReceiving #position").val("");
							
								// $("div#new_itemReceiving #contactName").change(function()
								// {	
									// $.ajax(
									// {
										// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactDepartment.php",
										// type:"POST",
										// data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
										// success:
										// function(response)
										// {
											// // alert(response);
											// $("div#new_itemReceiving #department").val(response);
										// }
									// });
									
									// $.ajax(
									// {
										// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactPosition.php",
										// type:"POST",
										// data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
										// success:
										// function(response)
										// {
											// // alert(response);
											// $("div#new_itemReceiving #position").val(response);
										// }
									// });
								// });
							// }
						// }
					// });
				// }
			}
		});
		
		// $.ajax(
		// {
			// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getRemarks.php",
			// type:"POST",
			// data:"withHdrId=" + $(selector).attr('a') + "&from=PO",
			// success:
			// function(response)
			// {
				// // alert(response);
				// $("div#new_itemReceiving #position").val(response);
			// }
		// });
		
		//=====================================================POPULATE DATAGRID================================================================	
		$.post('/ebms/apps/view/modalForms/inventory/itemReceiving/poDetailList.php', {hdrId:$(selector).attr('a')},
		function(response)
		{
			// alert(response);
			$("div#new_itemReceiving ul.gridViewNav").html(response);
			
			$("div#new_itemReceiving div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function()
			{
				$(this).trigger("click");
				return false;
				
			});
			
			$("div#new_itemReceiving div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function()
			{
				// alert('haha');
					
				$(this).find(".addItem").hide();
				$(this).find(".removeItem").hide();
				$(this).find(".selectedItem").show();
				
				if($(this).find(".addItem").css("display") == "none")
				{
				var code = $(this).attr("itemCode");
				var qty = $(this).attr("qty");
				var desc = $(this).attr("desc");
				
					$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").append("<tr itemCode='"+code+"'><td><input type='number' id='qty' value='"+qty+"'></td><td id='maxWithdraw'>"+qty+"</td><td id='itemCode'>"+code+"</td><td id='itemDesc'>"+desc+"</td></tr>");
					
					$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").find("tr[itemCode='"+code+"'] input").bind("keyup input",function(){
						if($(this).val() == "0")
						{
							$(this).val(1);
						}								
					});
				}
				
				$("div#new_itemReceiving #qty").bind("keypress", function(e) 
				{ 
					// alert('haha');
					return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
				});
				
				$(this).hover(function()
				{
					if($(this).find(".addItem").css("display") != "block")
					{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
					}
					else
					{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
					}
				
				},
				
				function()
				{
					if($(this).find(".addItem").css("display") != "block")
					{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
					}
					else
					{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
					}
				
				});
					
				return false;	
			},
			
			function()
			{
				var code = $(this).attr("itemCode");
				$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").find("tr[itemCode="+code+"]").fadeOut("slow",
					function()
					{
						$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").find("tr[itemCode="+code+"]").remove();
					});
					$(this).find(".addItem").show();
					$(this).find(".removeItem").hide();
					$(this).find(".selectedItem").hide();
			});
		});
	}
	
//===========================================================================WD DETAILS=========================================================================================
	
	function setCellContentValueWithHdr(selector)
	{
		$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").html("");
		
		// alert(selector.attr('a'));
		$("div#new_itemReceiving tbody#withdrawnItems tr").removeClass("activeTr");
		
		$(selector).addClass("activeTr");
		
		//======================================================WITHDRAWER DETAILS===============================================================		
		$.ajax(
		{
			url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getReceiveFrom.php",
			type:"POST",
			data:"withHdrId=" + $(selector).attr('a') + "&from=WD",
			success:
			function(response)
			{
				$("div#new_itemReceiving #receiveFrom").val(response);
				// alert(response);
			}
		});

		$.ajax(
		{
			url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getLocation.php",
			type:"POST",
			data:"withHdrId=" + $(selector).attr('a') + "&from=WD",
			success:
			function(response)
			{
				// alert(response);
				var kahitAno = response.split('&&');
				
				$("div#new_itemReceiving #location").val(kahitAno[1]);
				$("div#new_itemReceiving #location").attr('locationId', kahitAno[0]);				
		
				$.ajax(
				{
					url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getAddress.php", 
					type:"POST",
					data:"withHdrId=" + $(selector).attr('a') + "&from=WD",
					success:
					function(response)
					{
						// alert(response);
						$("div#new_itemReceiving #address").val(response);
					}
				});
				
				if ($("div#new_itemReceiving #location").val() == "N/A")
				{
					$("div#new_itemReceiving #contactName").html("<option value=''>N/A</option>");
					$("div#new_itemReceiving #department").val("N/A");
					$("div#new_itemReceiving #position").val("N/A");
				}
				else if ($("div#new_itemReceiving #location").val() != "N/A")
				{
					$.ajax(
					{
						url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactName.php",
						type:"POST",
						data:"locationId=" + $("div#new_itemReceiving #location").attr('locationId'),
						success:
						function(response)
						{
							// alert(response);
							$("div#new_itemReceiving #contactName").html(response);
							
							// alert($("div#new_itemReceiving #contactName option").size());
							if ($("div#new_itemReceiving #contactName option").size() == 1)
							{
								$.ajax(
								{
									url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactDepartment.php",
									type:"POST",
									data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
									success:
									function(response)
									{
										// alert(response);
										$("div#new_itemReceiving #department").val(response);
									}
								});
								
								$.ajax(
								{
									url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactPosition.php",
									type:"POST",
									data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
									success:
									function(response)
									{
										// alert(response);
										$("div#new_itemReceiving #position").val(response);
									}
								});
							}
							else if ($("div#new_itemReceiving #contactName option").size() > 1)
							{
								$("div#new_itemReceiving #department").val("");
								$("div#new_itemReceiving #position").val("");
							
								$("div#new_itemReceiving #contactName").change(function()
								{	
									$.ajax(
									{
										url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactDepartment.php",
										type:"POST",
										data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
										success:
										function(response)
										{
											// alert(response);
											$("div#new_itemReceiving #department").val(response);
										}
									});
									
									$.ajax(
									{
										url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getContactPosition.php",
										type:"POST",
										data:"contactId=" + $("div#new_itemReceiving #contactName").val(),
										success:
										function(response)
										{
											// alert(response);
											$("div#new_itemReceiving #position").val(response);
										}
									});
								});
							}
						}
					});
				}
			}
		});
		
		// $.ajax(
		// {
			// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getRemarks.php",
			// type:"POST",
			// data:"withHdrId=" + $(selector).attr('a') + "&from=WD",
			// success:
			// function(response)
			// {
				// // alert(response);
				// $("div#new_itemReceiving #position").val(response);
			// }
		// });
		
		//=====================================================POPULATE DATAGRID================================================================	
		$.post('/ebms/apps/view/modalForms/inventory/itemReceiving/withdrawalDetailList.php', {hdrId:$(selector).attr('a')},
		function(response)
		{
			$("div#new_itemReceiving ul.gridViewNav").html(response);
			
			$("div#new_itemReceiving div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink button").click(function()
			{
				$(this).trigger("click");
				return false;
				
			});
			var code = "", desc = "";
				$("div#new_itemReceiving div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink").hover(function(){
						code = $(this).attr("itemCode");
						desc = $(this).attr("desc");
						
						if($("div#new_itemReceiving #withdrawnItems").find("tr[itemCode="+code+"] td").size() > 0)
						{
						
						$("div#new_itemReceiving #withdrawnItems tr td").removeClass("itemActive");
						$("div#new_itemReceiving #withdrawnItems").find("tr[itemCode="+code+"] td").addClass("itemActive");
						
						}
						
						$("span.itemDesc").html(desc);
						$("label.itemCode").html(code);
						
						
						$("div.itemDetails").stop().animate({bottom:"240px",opacity:0.8},"1000").show();
						
						
						},function(){
						
						if($("div#new_itemReceiving #withdrawnItems").find("tr[itemCode="+code+"] td").size() > 0)
						$("div#new_itemReceiving #withdrawnItems").find("tr[itemCode="+code+"] td").removeClass("itemActive");
						
						$("div#new_itemReceiving div.itemDetails").stop().animate({bottom:"230px",opacity:0},"slow",function(){
						$("span.itemDesc").html("");
						$("label.itemCode").html("");
						});
						
						});
						
			$("div#new_itemReceiving div[ref=itemList] ul.gridViewNav li#gridViewList a#gridViewLink").toggle(function()
			{
				// alert('haha');
					
				$(this).find(".addItem").hide();
				$(this).find(".removeItem").hide();
				$(this).find(".selectedItem").show();
				
				if($(this).find(".addItem").css("display") == "none")
				{
				var code = $(this).attr("itemCode");
				var qty = $(this).attr("qty");
				var desc = $(this).attr("desc");
				
					$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").append("<tr itemCode='"+code+"'><td><input type='number' id='qty' value='"+qty+"'></td><td id='maxWithdraw'>"+qty+"</td><td id='itemCode'>"+code+"</td><td id='itemDesc'>"+desc+"</td></tr>");
					
					$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").find("tr[itemCode='"+code+"'] input").bind("keyup input",function(){
						if($(this).val() == "0")
						{
							$(this).val(1);
						}								
					});
				}
					
				$("div#new_itemReceiving #qty").bind("keypress", function(e) 
				{ 
					// alert('haha');
					return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
				});
				
				$(this).hover(function()
				{
					if($(this).find(".addItem").css("display") != "block")
					{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").show();
						$(this).find(".selectedItem").hide();
					}
					else
					{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
					}
				
				},
				
				function()
				{
					if($(this).find(".addItem").css("display") != "block")
					{
						$(this).find(".addItem").hide();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").show();
					}
					else
					{
						$(this).find(".addItem").show();
						$(this).find(".removeItem").hide();
						$(this).find(".selectedItem").hide();
					}
				
				});
				
				
					
				return false;	
			},
			
			function()
			{
				var code = $(this).attr("itemCode");
				$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").find("tr[itemCode="+code+"]").fadeOut("slow",
					function()
					{
						$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems").find("tr[itemCode="+code+"]").remove();
					});
					$(this).find(".addItem").show();
					$(this).find(".removeItem").hide();
					$(this).find(".selectedItem").hide();
			});
		});
	}


	$("div#new_itemReceiving #save").click(function()
	{
		if ($("div#new_itemReceiving #receiveFrom").val() == "")
		{
			alert('Please choose a document from the list below.');
		}
		else
		{
			if ($("div#new_itemReceiving #importFrom").val() == "")
			{
				alert('Import a record.');
			}
			else if ($("div#new_itemReceiving #importFrom").val() == "PO")
			{
				if ($("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").length == 0)
				{
					alert('Please choose item(s) to receive.');
				}
				else if ($("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").length > 0)
				{
					insert();
				}
			}
			else if ($("div#new_itemReceiving #importFrom").val() == "WD")
			{
				if ($("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").length == 0)
				{
					alert('Please choose item(s) to receive.');
				}
				else if ($("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").length > 0)
				{
					insert();
				}
			}
		}
	});
	
	function insert()
	{
		var maySobra = "";
					
		var qtyArray = new Array();
		var maxQtyArray = new Array();
		var itemCodeArray = new Array();
		var descArray = new Array();
		var i = 0;
		
		$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").each(function(index)
		{
			// var receiveArray = new Array();
			
			// // alert($(this).find("#qty").val() + ';' + $(this).text());
			// receiveArray[index] = $(this).find("#qty").val() + ';' + $(this).text();
			
			// receive = receiveArray[index].split(';');
			
			// var qty = receive[0];
			// var max = receive[1];
			
			// qtyArray[i] = receive[0];
			// maxQtyArray[i] = receive[1];
			// itemCodeArray[i] = receive[2];
			// descArray[i] = receive[3];
			
			// var maxInt = parseInt(max);
			
			if (parseInt($(this).find('#qty').val()) > parseInt($(this).find('#maxWithdraw').text()))
			{
				maySobra = "true";
			}
			// qty = 0;
			// max = 0;
			
			// i++;
		});
		
		if (maySobra == "true")
		{
			alert('Quantity to receive is greater than the withdrawn stock.');
		}
		else if (maySobra == "")
		{
			if ($("div#new_itemReceiving #contactName").val() == "")
			{
				dataString = "ref=" + $("div#new_itemReceiving #importFrom").val() +
							"&id=" + id + 
							"&contactId=" + "0" +
							"&remarks=" + $("div#new_itemReceiving #remarks").val();
			}
			else
			{
				dataString = "ref=" + $("div#new_itemReceiving #importFrom").val() +
								"&id=" + id + 
								"&contactId=" + $("div#new_itemReceiving #contactName").val() +
								"&remarks=" + $("div#new_itemReceiving #remarks").val();
			}
				// alert(dataString);
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/newReceivingHeaderRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
					// alert(response);
			
					// for (j = 0; j < i; j++)
					// {
						// dataString = "qty=" + qtyArray[j] + "&itemCode=" + itemCodeArray[j] + "&desc=" + descArray[j] + "&from=" + $("div#new_itemReceiving #importFrom").val();
						// // alert(dataString);
						// $.ajax(
						// {
							// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/newReceivingDetailRecord.php",
							// type:"POST",
							// data:dataString,
							// success:
							// function(response)
							// {
								// // alert(response);
							// }
						// });
						
						// dataString2 = "qty=" + qtyArray[j] + "&itemCode=" + itemCodeArray[j];
						
						// $.ajax(
						// {
							// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/addInventory.php",
							// type:"POST",
							// data:dataString2,
							// success:
							// function(response)
							// {
								// // alert(response);
							// }
						// });
						
						// dataString3 = "qty=" + qtyArray[j] + "&itemCode=" + itemCodeArray[j] + "&from=" + $("div#new_itemReceiving #importFrom").val() + "&id=" + id;
						// // alert(dataString3);
						// $.ajax(
						// {
							// url:"/ebms/apps/view/modalForms/inventory/itemReceiving/deductFromImport.php",
							// type:"POST",
							// data:dataString3,
							// success:
							// function(response)
							// {
								// // alert(response);
							// }
						// });
					// }
					
					$("div#new_itemReceiving table[ref = 'receive'] tbody#withdrawnItems tr").each(function(index)
					{
						dataString = "qty=" + $(this).find('#qty').val() + "&itemCode=" + $(this).find('#itemCode').text() + "&desc=" + $(this).find('#itemDesc').text() + "&from=" + $("div#new_itemReceiving #importFrom").val();
						// alert(dataString);
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/itemReceiving/newReceivingDetailRecord.php",
							type:"POST",
							data:dataString,
							success:
							function(response)
							{
								// alert(response);
							}
						});
						
						dataString2 = "qty=" + $(this).find('#qty').val() + "&itemCode=" + $(this).find('#itemCode').text();
						
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/itemReceiving/addInventory.php",
							type:"POST",
							data:dataString2,
							success:
							function(response)
							{
								// alert(response);
							}
						});
						
						dataString3 = "qty=" + $(this).find('#qty').val() + "&itemCode=" + $(this).find('#itemCode').text() + "&from=" + $("div#new_itemReceiving #importFrom").val() + "&id=" + id;
						// alert(dataString3);
						$.ajax(
						{
							url:"/ebms/apps/view/modalForms/inventory/itemReceiving/deductFromImport.php",
							type:"POST",
							data:dataString3,
							success:
							function(response)
							{
								// alert(response);
							}
						});
					});
				}
			});
			
			dataString = "role=" + "New" + "&noun=" + "Item receiving record";
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
				type:"POST",
				data:dataString,
				success:
				function(response)
				{
				
				}
			});
			
			alert('Record Created.');
			window.location.reload();
		}
	}
	
	//================================================================================EDIT=======================================================================================
	$("#edit").click(function()
	{
		if ($(this).attr('recId') != null)
		{
			// alert($(this).attr('recId'));
			var editRecId = ($(this).attr('recId'));
			
			var type = "";
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewReceiveFrom.php",
				type:"POST",
				data:"id=" + editRecId,
				success:
				function(response)
				{
					$("div#edit_itemReceiving #receiveFrom").val(response);
				}	
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewLocation.php",
				type:"POST",
				data:"id=" + editRecId,
				success:
				function(response)
				{
					$("div#edit_itemReceiving #location").val(response);
					
					$.ajax(
					{
						url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewAddress.php",
						type:"POST",
						data:"id=" + editRecId + "&location=" + $("div#edit_itemReceiving #location").val(),
						success:
						function(response)
						{
							// alert(response);
							$("div#edit_itemReceiving #address").val(response);
						}
					});
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/getRefType.php",
				type:"POST",
				data:"id=" + editRecId,
				success:
				function(response)
				{
					type = response;
					// alert(type);
					
					$.ajax(
					{
						url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewContact.php",
						type:"POST",
						data:"id=" + editRecId + "&type=" + type,
						success:
						function(response)
						{
							$("div#edit_itemReceiving #contactName").val(response);
							
							$.ajax(
							{
								url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewDepartment.php",
								type:"POST",
								data:"id=" + editRecId + "&type=" + type,
								success:
								function(response)
								{
									$("div#edit_itemReceiving #department").val(response);
									
									$.ajax(
									{
										url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewPosition.php",
										type:"POST",
										data:"id=" + editRecId + "&type=" + type,
										success:
										function(response)
										{
											$("div#edit_itemReceiving #position").val(response);
										}
									});
								}
							});
						}
					});
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/viewRemarks.php",
				type:"POST",
				data:"id=" + editRecId,
				success:
				function(response)
				{
					$("div#edit_itemReceiving #remarks").val(response);
				}
			});
		}
	
		$("div#edit_itemReceiving #save").click(function()
		{
			$.ajax(
			{
				url:"/ebms/apps/view/modalForms/inventory/itemReceiving/editReceivingHeaderRecord.php",
				type:"POST",
				data:"id=" + editRecId + "&remarks=" + $("div#edit_itemReceiving #remarks").val(),
				success:
				function(response)
				{
					
				}
			});
			
			$.ajax(
			{
				url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/getRecordCode.php",
				type:"POST",
				data:"module=" + "Receiving" + "&id=" + editRecId,
				success:
				function(response)
				{
					dataString = "role=" + "Edit" + "&noun=" + "Item receiving record" + "&code=" + response;
					$.ajax(
					{
						url:"/ebms/apps/view/systemRecords/userManagement/auditTrail/newAuditTrailRecord.php",
						type:"POST",
						data:dataString,
						success:
						function(response)
						{
						
						}
					});
				}
			});
			
			alert('Record Edited!');
			window.location.reload();
		});
	});

</script>